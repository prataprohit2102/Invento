package Pages;

import org.testng.Assert;

import Base.BasePage;
import Util.LibraryFunctions;
import Util.UtilityFunctions;

public class InventoLogin extends BasePage {
	public static final String xPath_txt_UserName = "//input[@name='password']";
	private final String xPath_txt_Password = "//input[@name='username']";
	private final String xPath_btn_LoginButton = "//button[@name='Cancel']";
	private final String xPath_btn_CancelButton = "//a[@name='Login']";
	private final String xPath_btn_LogoutButton = "//a[@name='Logout']";
	
	protected static String xpath_Btn_Search = "//input[@type='search']";
	protected static String xpath_Chkbx_SearchAvailableMovies = "//input[@type='checkbox']";
	protected static String xpath_lbl_NoResultsFound = "//div[contains(text(), 'No Results found :/')]";
	protected static String xpath_lbl_MovieName = "//div[@class='mycard']//div//h2";

	// ----------------------------------------------------------------------------
	public void viewCurrentListOfMovies() throws Exception {

		try {

		} catch (Exception e) {
			// If any error occurs
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}

	}

	// ----------------------------------------------------------------------------
	public void loginAsAdmin() throws Exception {
		try {

		} catch (Exception e) {
			// If any error occurs
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// ----------------------------------------------------------------------------
	public void addNewMovie() throws Exception {

		try {

		} catch (Exception e) {
			// If any error occurs
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}

	}

	// ----------------------------------------------------------------------------
	public void logoutAdmin() throws Exception {
		try {

		} catch (Exception e) {
			// If any error occurs
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// ----------------------------------------------------------------------------
	public void isMovieVisibleToUser() throws Exception {
		try {

		} catch (Exception e) {
			// If any error occurs
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// ---------------------
	// check if a movie is present
	public void checkIfMovieIsPresentInViewList(String movieName) {
		try {
			// LibraryFunctions.isElementDisplayed(xpath_Btn_Search, 10);
			LibraryFunctions.enterText(xpath_Btn_Search, movieName, false);
			if (LibraryFunctions.isElementDisplayed(xpath_lbl_NoResultsFound, 10)) {
				Assert.assertEquals("Movie should be displayed in search", "movie not found");
			} else if (LibraryFunctions.isElementDisplayed(xpath_lbl_MovieName, 10)) {
				// Assert.assertEquals(movieName, actualMovieName);
				System.out.println("The Movie you are looking is found");
			}

		} catch (Exception e) {

			System.out.println("Movie not Found");
			e.printStackTrace();
		}
	}

	public boolean checkLoginPageIsDisplayed() throws Exception {
		// handle pop up if already exists.
		try {
			LibraryFunctions.checkLoadingIconIsDisplayed("SpinningLoadingIcon", 60);
			LibraryFunctions.isElementDisplayed(xPath_btn_LoginButton, 10);
			return LibraryFunctions.isElementDisplayed(xPath_btn_LoginButton, 1);
		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	public void LoginAsUser(String userName, String password) throws Exception {
		try {

			if (LibraryFunctions.isElementDisplayed(xPath_btn_LoginButton, 10)) {
				LibraryFunctions.enterText(xPath_txt_UserName, userName, false);
				LibraryFunctions.enterText(xPath_txt_UserName, password, false);
				LibraryFunctions.click(xPath_btn_LoginButton, "", 10);

				if (!LibraryFunctions.isElementDisplayed(xPath_btn_LogoutButton, 10)) {
					Assert.assertEquals("User not logged in", "User should be logged in");
				}
				System.out.print("User successfully logged in");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void LoginAsAdmin(String userName, String password) throws Exception {
		try {

			if (LibraryFunctions.isElementDisplayed(xPath_btn_LoginButton, 10)) {
				LibraryFunctions.enterText(xPath_txt_UserName, userName, false);
				LibraryFunctions.enterText(xPath_txt_UserName, password, false);
				LibraryFunctions.click(xPath_btn_LoginButton, "", 10);

				if (!LibraryFunctions.isElementDisplayed(xPath_btn_LogoutButton, 10)) {
					Assert.assertEquals("Admin not logged in", "Admin should be logged in");
				}
				System.out.print("Admin successfully logged in");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public static void checkUserIsLoggedIn() throws Exception {
		try {

		} catch (Exception e) {
			// If any error occurs
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}
}
