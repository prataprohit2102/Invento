/*
 * package Util;
 * 
 * import java.util.Hashtable;
 * 
 * public class MultilingualSheet {
 * 
 * public static final Hashtable<String, String> MultilingualSheetEntries = new
 * Hashtable<String, String>() { {
 * 
 * put("ShortnameUniquenessValidationMessage", "XShort name already exists.X");
 * put("Code_Already_Exists", "XCode Name already exists.X");
 * put("CodeGroup_Already_Exists", "XCode Group already exists.X");
 * put("Required", "XRequiredX"); put("RevisionnameUniquenessValidationMessage",
 * "XPart revision already exists.X"); put("InvalidFormatValidationMessage",
 * "XInvalid format.X"); put("ResetPasswordLinkSendSuccessfully",
 * "XPlease check your registered e-mail for the link to reset your password.X"
 * ); put("InvalidLoginCredentials",
 * "XInvalid Login Credentials. Please try again.X");
 * put("ProcessState_Already_Exists", "XProcess state already exists.X");
 * put("ForgotPassword_DefaultMessage",
 * "XTo change your password, enter the user id used for login. A link will be sent to the registered email id.X"
 * ); put("UsernameUniquenessValidationMessage", "XUsername already exists.X");
 * put("EmaiUniquenessValidationMessage", "XEmail ID already exists.X");
 * put("SaveSuccessfullyMessage", "X<Element Name> saved successfully.X");
 * put("ProcessState_Configurations_Save_Successfully",
 * "XProcess state configurations saved successfully.X");
 * put("AccountDeactivationMessage",
 * "XYour account has been deactivated. Please contact your administrator.X");
 * put("ForgotPasswordLinkSendSuccessfully",
 * "XLink to reset password has been sent to the registered email id.X");
 * put("PartCountMessage", "X<count> XPartsX SelectedX");
 * put("ProcessCountMessage", "X<count> XProcessX SelectedX");
 * put("ParameterSet_NoProcessMessage", "XAny XProcessXX");
 * put("ParameterSet_NoFeatureMessage", "XAny XFeatureXX");
 * put("FeatureCountMessage", "X<count> XFeatureX SelectedX");
 * put("TagValueAlreayExists", "XTag already exists.X");
 * put("ParameterSet_NoPartMessage", "XAny XPartXX");
 * put("ParameterSet_NoCodeMessage", "XAny XCodeXX"); put("CodeCountMessage",
 * "X<count> XCodeX SelectedX"); put("ParameterSet_SelectedParts",
 * "XParts Selected:X"); put("ParameterSet_NoTagMessage", "XAny XTagXX");
 * put("ParameterSet_SelectedTags", "XSelect XTagsXX");
 * put("MultiProcessCountMessage", "X<count> XProcessesX SelectedX");
 * put("SinglePartCountMessage", "X<count> XPartX SelectedX");
 * put("MultiFeatureCountMessage", "X<count> XFeaturesX SelectedX");
 * put("EndDateSmallerThanStartDate",
 * "XEnd Date/Time cannot be smaller than Start Date/Time.X");
 * put("Part_AlreadyExists", "XPart already exists.X");
 * put("ValidationMessageForInvalidImage",
 * "XFile not uploaded. Invalid image format.X");
 * put("ValidationMessageForGreaterThan600KBImage",
 * "XFile not uploaded. Size exceeds 600 KB.X");
 * put("ValidationMessage_CreateSpecificationPage",
 * "XMissing/Incorrect Information ! Correct or cancel them before saving.X");
 * put("AccordionItem_OnlyInputPart",
 * "XPart recipe(s) having this part revision as the only input part will be removed. Impacted part recipeX"
 * ); put("AccordionItem_OnlyOutputPart",
 * "XPart recipe(s) having this part revision as a single output part will be removed. Impacted part recipeX"
 * ); put("Feature_DeleteConfirmaitonMessageWithAssociations",
 * "XOn removal of feature, following associations will also be removed:X");
 * put("SpecLimit_DeleteConfirmaitonMessage",
 * "XDo you want to remove manufacturing limit record for <Part,Revision,Feature,Lot,Process> combination?X"
 * ); put("Part_DeleteConfirmaitonMessageWithAssociations",
 * "XOn removal of part revision, following associations will also be removed:X"
 * ); put("Part_DeleteConfirmaitonMessageWithOutAssociations",
 * "XDo you want to remove <PartName,Revision>?X");
 * put("Tag_DeleteConfirmaitonMessageWithAssociations",
 * "XOn removal of tag, following associations will be impacted:X");
 * put("Feature_DeleteConfirmaitonMessageWithOutAssociations",
 * "XDo you want to remove <Element Name>?X");
 * put("CollectionAid_DeleteConfirmationMessage",
 * "XDo you want to remove part feature details record for <Part,Revision,Feature> combination?X"
 * ); put("RemovedSuccessfullyMessage",
 * "X<Element Removed> removed successfully.X");
 * put("Process_DeleteConfirmaitonMessageWithAssociations",
 * "XOn removal of process, following associations will also be removed:X");
 * put("ConfirmationMessageForUnsavedData",
 * "XDo you want to navigate away from this page? You will lose the unsaved changes.X"
 * ); put(
 * "EditPartRevision_ConfirmationMessageForUnsavedDataOnClickingCreateSpecButton"
 * , "XDo you want to save part revision changes before navigating away?X");
 * put("ValidationDisplayedOnGivingEndDateLessThanStartDate",
 * "XActivation Start Date & Time can�t be greater than the Activation End Date & Time.X"
 * ); put("ConfirmationMessage_EditFeaturePage",
 * "XDo you want to save part revision changes before navigating away?X");
 * put("AccordionItem_AssignedODMessage_Feature",
 * "XAssigned to process model - operationX");
 * put("AccordionItem_AssignedDCMessage_Feature",
 * "XAssigned to data collection definitionX");
 * put("AccordionItem_AssignedProcessMessage_Tag", "XAssigned to ProcessX");
 * put("AccordionItem_AssignedPartMessage_Tag", "XAssigned to PartX");
 * put("AccordionItem_AssignedFeatureMessage_Tag", "XAssigned to FeatureX");
 * put("AccordionItem_AssignedCodeMessage_Tag", "XAssigned to CodeX");
 * put("AccordionItem_AssignedUserMessage_Tag", "XAssigned to UserX");
 * put("AccordionItem_AssignedCodeGroupMessage_Tag",
 * "XAssigned to Code GroupX"); put("Feature_SpecLimit_ConfirmationMessage",
 * "XDo you want to save feature changes before navigating away?X");
 * put("TagGroup_DeleteConfirmaitonMessageWithAssociations",
 * "XOn removal of tag group, following associations will be impacted:X"); //
 * for feature dont change as message varies in feature and part\ // process
 * put("Feature_SubGroup_ConfirmationMessage",
 * "XAssociated subgroup data collection entry records may be impacted.X"); //
 * for part and process put("SubGroup_ConfirmationMessage",
 * "XAssociated subgroup data collection records may be impacted.X");
 * put("Part_SubGroup_ConfirmationMessage",
 * "XImpacted subgroup data collectionX"); put("ConfirmatioPopUp_MessageHeader",
 * "XConfirmation MessageX");
 * put("ConfirmationMessageForTotalCountGreaterThanSubGroupSize",
 * "XEntered Value is greater than subgroup size.X");
 * put("ConfirmationMessage_ParametSetSelectEntityPage_Dynamic_Feature",
 * "XExisting XFeatureX selections will be lost. Are you sure you want to switch selection mode to XDynamicX?X"
 * ); put("ConfirmationMessage_ParametSetSelectEntityPage_Dynamic_Process",
 * "XExisting XProcessX selections will be lost. Are you sure you want to switch selection mode to XDynamicX?X"
 * ); put("ConfirmationMessage_ParametSetSelectEntityPage_Static_Feature",
 * "XExisting XFeatureX selections will be lost. Are you sure you want to switch selection mode to XStaticX?X"
 * ); put("ConfirmationMessage_ParametSetSelectEntityPage_Static_Process",
 * "XExisting XProcessX selections will be lost. Are you sure you want to switch selection mode to XStaticX?X"
 * ); put("AccordionItem_AssignedParameterSetMessage_Tag",
 * "XAssigned to parameter setX");
 * put("ConfirmationMessage_ParametSetSelectEntityPage_Dynamic_Part",
 * "XExisting XPartX selections will be lost. Are you sure you want to switch selection mode to XDynamicX?X"
 * ); put("ConfirmationMessage_ParametSetSelectEntityPage_Static_Part",
 * "XExisting XPartX selections will be lost. Are you sure you want to switch selection mode to XStaticX?X"
 * ); put("ValidationDisplayedOnGivingCreateToDateLessThanFromDate",
 * "XFrom Date can't be greater than To Date.X"); put("SingleDCModalBoxMessage",
 * "x(<Count> xdata collection definitionx exists.)x"); put("DCModalBoxMessage",
 * "x(<Count> xdata collection definitionsx exist.)x");
 * put("SpecLimitModalBoxMessage", "x(<Count> xmanufacturing limitsx exist.)x");
 * put("SingleSpecLimitModalBoxMessage",
 * "x(<Count> xManufacturing Limitx exists.)x"); put("OperationModalBoxMessage",
 * "x(<Count> xoperationsx exist.)x"); put("SinglePartRecipeModalBoxMessage",
 * "x(<Count> xpart recipex exists.)x"); put("PartRecipeModalBoxMessage",
 * "x(<Count> xpart recipesx exist.)x"); put("OperationDiagramModalBoxMessage",
 * "x(<Count> xprocess modelsx exist.)x");
 * put("SingleOperationDiagramModalBoxMessage",
 * "x(<Count> xprocess modelx exists.)x");
 * put("Process_Can'tBeDeletedMessage_OnlyProcess",
 * "XProcess <Process Name> can't be removed as it is the only process at this level.X"
 * ); put("Process_Can'tBeDeletedMessage",
 * "XProcess <Entity Name> can't be removed as child processes are associated with it:X"
 * ); put("TagModalBoxMessage", "x(<Count> xtagsx exist.)x");
 * put("SingleTagModalBoxMessage", "x(<Count> xtagx exists.)x");
 * put("SingleDCDefModalBoxMessage",
 * "x(<Count> xdata collection definitionx exists.)x");
 * put("DCDefModalBoxMessage",
 * "x(<Count> xdata collection definitionsx exist.)x");
 * put("ModalBox_PartRecipe_Title", "XView Part RecipeX");
 * put("PromptForSampleSize", "XPrompt for Sample SizeX"); put("OnStart",
 * "XOn StartX"); put("OnSave", "XOn SaveX"); put("SampleSizeValidatonMessage",
 * "XSample Size must be greater than or equal to <SampleSize>X");
 * put("SytemEnteredSampleTime", "XSystem Entered Sample TimeX");
 * put("UserEnteredSampleTime", "XUser Entered Sample TimeX");
 * put("TimeStamp_ValidationForFutureDate",
 * "XEntered timestamp must be less than or equal to the current timestamp.X");
 * put("EnterSampleTime", "XEnter Sample TimeX");
 * 
 * put("ModalBox_OperationDiagram_Title", "XView Process ModelX");
 * put("SingleOperationModalBoxMessage", "x(<Count> xoperationx exists.)x");
 * put("ProcessPage_TagCount_MulitpleTag_Message",
 * "XProcessX: <ProcessName> x(<TagCount> xtagsx exist.)x");
 * put("Unauthorized_Access_Page_Message",
 * "XYou don't have permission to view this page.X");
 * put("ProcessPage_TagCount_SingleTag_Message",
 * "XProcessX: <ProcessName> x(1 xtagx exists.)x");
 * put("SaveSuccessfullyMessageForLimit",
 * "XLimit of <PartName> - <FeatureName> saved successfully.X");
 * put("Password_Change_Successful", "XPassword reset successfullyX");
 * put("UserConfiguredTagSaveSuccessfullyMessage",
 * "XUser configured fields saved successfullyX");
 * put("ModalBox_SpecLimit_Title", "XView Manufacturing LimitX");
 * put("AllowModification", "XAllow ModificationX");
 * put("SpecNotificationMessage",
 * "XDisplay ScaleX,XHighlight Grid NotificationX,XHighlight Popup NotificationX,XPlay sound when a gauge value is enteredX Notification Rule(s)"
 * ); put("ModalBox_DC_Title", "XView Data Collection DefinitionX");
 * put("PS_SelectCodeHeaderTitle", "XSelect XCodesX (to XincludeX)X");
 * put("PS_SelectProcessPopUpHeader_OpeationTitle",
 * "XOperationX - XSelected ProcessesX");
 * put("PS_SelectedProcessPopUpHeader_Title", "XSelected ProcessesX");
 * put("AccordionItem_AssignedODMessage",
 * "XAssigned to process model - part familyX");
 * put("AccordionItem_ImpactedPartRecipe", "XImpacted Part recipeX");
 * put("Default_ParentProcess", "XDefaultX");
 * put("AccordionItem_AssignedChildProcess", "XAssigned child processX");
 * put("actualAccordionItem_AssignedSpecLimitMessage_Feature",
 * "XAssigned to Manufacturing LimitX"); put("AccordionItem_AssignedSpecLimit",
 * "XAssigned to Manufacturing LimitX"); put("Create_Feature_Page_Title",
 * "XCreate FeatureX"); put("Spec_Page_Title", "XCreate LimitX");
 * put("Unauthorized_Access_Page_Title", "XUnauthorized AccessX");
 * put("Role_Header_Title", "XRolesX"); put("Create_Role_Page_Title",
 * "XCreate RoleX"); put("Individual_Settings_Page_Title",
 * "XIndividual SettingsX"); put("Create_Part_Page_Title", "XCreate PartX");
 * put("Set_Process_State_Page_Title", "XSet StateX");
 * put("Create_Part_Revision_Page_Title", "XCreate Part RevisionX");
 * put("CodeGroup_Page_Title", "XCreate Code GroupX");
 * put("UserLandingPageTitle", "XUsersX"); put("Edit_Limit_Page_Title",
 * "XEdit LimitX"); put("Edit_CodeGroup_Page_Title", "XEdit Code GroupX");
 * put("Create_Process_Page_Title", "XCreate ProcessX");
 * put("ManualDCLandingPageTitle", "XData CollectionsX");
 * put("TagGroup_Page_Title", "XCreate Tag GroupX");
 * put("Configure_User_Tags_Title", "XConfigure FieldsX");
 * put("ModalBox_ViewCode_Title", "XView CodeX"); put("Create_User_Page_Title",
 * "XCreate UserX"); put("DCTagPopUpTitle_AllPieces",
 * "XXAll PiecesX - Add TagsX"); put("CollectionAids_Page_Title",
 * "XPart Feature DetailsX"); put("Create_CollectionAids_Page_Title",
 * "XCreate Part Feature DetailsX"); put("Edit_CollectionAids_Page_Title",
 * "XEdit Part Feature DetailsX"); put("TagCount", "XTag 1 of 1X");
 * put("ParameterSet_Page_Title", "XCreate Parameter SetX");
 * put("ModalBox_Operation_Title", "XView OperationX");
 * put("ModalBox_Tag_Title", "XView TagX");
 * put("SelectProcessEntity_Page_Title", "XSelect XProcessesX (to XincludeX)X");
 * put("ModalBox_Reset_Password", "XReset PasswordX");
 * put("ModalBox_Change_Password", "XChange PasswordX");
 * put("Part_Header_Title", "XPartsX"); put("Process_Header_Title",
 * "XProcessesX"); put("Spec_Header_Title", "XManufacturing LimitsX");
 * put("Feature_Header_Title", "XFeaturesX");
 * put("DataCollectionConfiguration_Header_Title",
 * "XData Collection ConfigurationsX"); put("DataCollection_Header_Title",
 * "XData CollectionsX"); put("CodeGroup_Header_Title", "XCode GroupsX");
 * put("TagGroup_Header_Title", "XTag GroupsX");
 * put("PartRecipeQuickAddition_Header_Title", "XPart Recipe ManagementX");
 * put("DCSetting_Header_Title", "XSettingsX"); put("Process_States_Grid_Title",
 * "XActive Process StatesX"); put("Configure_Process_States_Page_Title",
 * "XConfigure Process StatesX"); put("PartRevision_Header_Title",
 * "XPart RevisionsX"); put("Process_States_Header_Title", "XProcess StatesX");
 * put("Dashboard_Header_Title", "XDashboardX");
 * put("Dashboard_Header_Title_Spanish", "XTableros de ControlX");
 * 
 * put("ColumnName_Piece", "XPieceX"); put("ParameterSet_Header_Title",
 * "XParameter SetsX"); put("GridProcessSelectedEntity",
 * "XProcesses Selected:X"); put("SelectProcessEntity_Header_Title",
 * "XSelect XProcessesXX"); put("SelectFeatureEntity_Header_Title",
 * "XSelect XFeaturesXX"); put("SelectPartsEntity_Header_Title",
 * "XSelect XPartsXX");
 * 
 * put("ControlLimit_Header_Title", "XControl LimitsX");
 * put("ColumnName_PartRevision", "XRevisionX"); put("ColumnName_Part_Name",
 * "XPart NameX"); put("ColumnName_USL", "XUSLX"); put("ColumnName_LSL",
 * "XLSLX"); put("ColumnName_Target", "XTargetX"); put("ColumnName_FeatureName",
 * "XFeature NameX"); put("ColumnName_FeatureName_Spec",
 * "XFeature (Variable)X"); put("ColumnName_Lot", "XLotX");
 * put("ColumnName_Process", "XProcessX"); put("ColumnName_URL", "XURLX");
 * put("ColumnName_UWL", "XUWLX"); put("ColumnName_LWL", "XLWLX");
 * put("ColumnName_LRL", "XLRLX"); put("ColumnName_UWP", "XUWPX");
 * put("ColumnName_LWP", "XLWPX"); put("ColumnName_USG", "XUSGX");
 * put("ColumnName_LSG", "XLSGX"); put("ColumnName_TagGroup", "XTag GroupX");
 * put("ColumnName_CurrentState_Part", "XCurrent StateX");
 * put("ColumnName_PreviousState_Part", "XPrevious StateX");
 * put("ColumnName_ProcessState", "XProcess StateX");
 * put("ColumnName_StateType", "XState TypeX");
 * put("ColumnName_ChangeIntitiation", "XChange InitiationX");
 * put("ColumnName_MAVUpper", "XMAV UpperX"); put("ColumnName_Max_MAVUpper",
 * "XMax % > MAV UpperX"); put("ColumnName_MAV_LSC", "XMAV - LSCX");
 * put("ColumnName_MAVLower", "XMAV LowerX"); put("ColumnName_Max_MAVLower",
 * "XMax % < MAV LowerX"); put("ColumnName_T2Upper", "XT2 UpperX");
 * put("ColumnName_T1Upper", "XT1 UpperX"); put("ColumnName_T1T2Upper",
 * "XMax % between T1T2 UpperX"); put("ColumnName_Max_T2Upper",
 * "XMax % > T2 UpperX"); put("ColumnName_T1T2_LSC", "XT1T2 - LSCX");
 * put("ColumnName_T1Lower", "XT1 LowerX"); put("ColumnName_T2Lower",
 * "XT2 LowerX"); put("ColumnName_Max_BetweenT1T2Lower",
 * "XMax % between T1T2 LowerX"); put("ColumnName_MaxT2Lower",
 * "XMax % < T2 LowerX"); put("ColumnName_UpdatedDate", "XUpdated DateX");
 * put("ColumnName_LastUpdatedBy", "XLast Updated byX");
 * put("ColumnName_CreationDate", "XCreation DateX");
 * put("ColumnName_CreatedBy", "XCreated byX"); put("ColumnName_Image",
 * "XImageX"); put("ColumnName_FeatureType", "XFeature TypeX");
 * put("ColumnName_Tag", "XTagX"); put("ColumnName_DataCollection",
 * "XData CollectionX"); put("ColumnName_SpecificationLimit",
 * "XManufacturing LimitX"); put("ColumnName_Operation", "XOperationX");
 * put("ColumnName_ProcessName", "XProcess NameX");
 * put("ColumnName_ProcessCategory", "XProcess CategoryX");
 * put("ColumnName_OperationDiagram", "XProcess ModelX");
 * put("ColumnName_Status", "XStatusX"); put("ColumnName_PartRecipe",
 * "XPart RecipeX");
 * 
 * put("ColumnName_Units", "XUnitsX");
 * put("ColumnName_DataCollectionDefinition", "XData Collection DefinitionX");
 * put("ColumnName_OperationDiagramName", "XProcess Model NameX");
 * put("ColumnName_Feature", "XFeatureX"); put("ColumnName_PartFamily",
 * "XPart FamilyX"); put("ColumnName_Code", "XCodeX");
 * put("ColumnName_CodeGroup", "XCode GroupX"); put("ColumnName_Active",
 * "XActiveX"); put("ColumnName_CodeName", "XCode NameX");
 * put("ColumnName_Role", "XRoleX"); put("ColumnName_Supervisor_Name",
 * "XSupervisor NameX"); put("ColumnName_Preferred_Language",
 * "XPreferred LanguageX"); put("ColumnName_Username", "XUsernameX");
 * put("ColumnName_Email", "XEmail IDX"); put("ColumnName_Access_Level",
 * "XAccess LevelX"); put("ColumnName_Name", "XNameX"); put("ColumnName_Weight",
 * "XWeightX"); put("ColumnName_TagType", "XTag TypeX");
 * put("ColumnName_TextingNumber", "XTexting No.X");
 * put("ColumnName_TagGroupName", "XTag Group NameX");
 * put("ColumnName_PartFamilyTitle", "X<Element Name> Part FamiliesX");
 * put("ColumnName_Part", "XPartX"); put("ColumnName_ CollectionAid",
 * "XPart Feature DetailsX");
 * 
 * put("ColumnName_ParentPrcoessName", "XParent ProcessX");
 * put("ColumnName_Part_Family", "XPart Family - NameX");
 * put("PartNotExistsValidationMessage", "XXPartX doesn't exist.X");
 * put("ColumnName_ParameterSetName", "XParameter Set NameX");
 * put("ColumnName_Summary", "XSummaryX"); put("ColumnName_Criteria",
 * "XCriteriaX"); put("ColumnName_AssignedWorkDashboard",
 * "XAssigned Work DashboardX"); put("ManualDCLandingPageGridHeader",
 * "XData Collection NameX"); put("ColumnName_SelectedFeature",
 * "XSelected FeaturesX"); put("CodeGroupNotExist",
 * "XCode group doesn't exist.X"); put("ResponseGroupNotExist",
 * "XResponse Group doesn�t exist.X"); put("ContextMenuUploadImage",
 * "XUpload ImageX"); put("ContextMenuChangeImage", "XChange ImageX");
 * put("ContextMenuRemoveImage", "XRemove ImageX");
 * put("LandingPage_ContextMenu_CreatePartRevisionIconText",
 * "XCreate RevisionX"); put("LandingPage_ContextMenu_HistoryIconText",
 * "XHistoryX"); put("LandingPage_ContextMenu_RemoveIconText", "XRemoveX");
 * put("StateType_Idle", "XIdleX"); put("StateType_Pause", "XPauseX");
 * put("StateType_Run", "XRunX"); put("StateType_ScheduledDown",
 * "XScheduled DownX"); put("StateType_Start", "XStartX"); put("StateType_Stop",
 * "XStopX"); put("StateType_UnscheduledDown", "XUnscheduled DownX");
 * put("TagType_Numeric", "XNumericX"); put("TagType_Textual", "XTextualX");
 * put("Status_Active", "0 - XActiveX"); put("Status_Inactive",
 * "1 - XInactiveX"); put("Status_Inactive_User", "0 - XInvalid assignee.X");
 * put("FeatureType_Variable", "XVariableX"); put("FeatureType_Defect",
 * "XDefectX"); put("FeatureType_Defective", "XDefectiveX");
 * put("FeatureType_CheckList", "XChecklistX"); put("ChangeIntitiation_Manual",
 * "0 - XManualX"); put("FeatureType_Time", "XTimeX");
 * put("ChangeIntitiation_Automatic", "2 - XAutomaticX");
 * put("ChangeIntitiation_Event", "1 - XEventX");
 * put("ParameterSetTimeZone_Latest", "XLatestX");
 * put("ParameterSetTimeZone_Current", "XCurrentX");
 * put("ParameterSetTimeZone_Earlier", "XEarlierX");
 * put("ParameterSetTimeUnit_Minute", "XMinute(s)X");
 * put("ParameterSetTimeUnit_Hour", "XHour(s)X");
 * put("ParameterSetTimeUnit_Day", "XDay(s)X"); put("ParameterSetTimeUnit_Week",
 * "XWeek(s)X"); put("ParameterSetTimeUnit_Month", "XMonth(s)X");
 * put("ParameterSetTimeUnit_Quarter", "XQuarter(s)X");
 * put("ParameterSetTimeUnit_Year", "XYear(s)X");
 * put("TimeSelectionType_Dynamic", "XDynamicX");
 * put("TimeSelectionType_Static", "XStaticX"); put("Module_PartRevision",
 * "XPart RevisionX"); put("Module_Part", "XPartX");
 * put("ResponseType_SingleAnswer", "1 - XSingle AnswerX");
 * put("ResponseType_MultipleAnswer", "2 - XMultiple AnswerX");
 * put("FilterButtonTitle", "XFiltersX"); put("BackButton", "XBackX");
 * put("ColumnName_ConfigureColumnTitle", "XConfigure ColumnsX");
 * put("CodeGroup_AddCodes", "XAdd CodesX"); put("CodeGroup_CheckBoxLabel",
 * "XLock list during useX"); put("Lable_SampleSize", "XSample SizeX");
 * 
 * put("LBL_All_Pieces", "XAll PiecesX"); put("Lable_Edit", "XEditX");
 * put("Lable_Delete", "XDeleteX"); put("Condition_And", "XANDX");
 * put("Condition_OR", "XORX"); put("Condition_XOR", "XXORX");
 * put("Condition_Is_Not", "Xis notX"); put("Condition_State_Is", "XState isX");
 * put("Condition_State_Is_Not", "XState is notX"); put("Condition_Between",
 * "XBetweenX"); put("TotalCount", "XTotal : <count>X"); put("Condition_Equals",
 * "XEqualsX"); put("Condition_Is", "XisX"); put("Label_Part", "XPartX");
 * put("LicenseType_Username", "XUsernameX"); put("LicenseType_Workstation",
 * "XWorkstationX"); put("SelectFeature_Exclude",
 * "XSelect XFeaturesX (to XexcludeX)X"); put("SelectPart_Exclude",
 * "XSelect XPartsX (to XexcludeX)X"); put("SelectProcess_Exclude",
 * "XSelect XProcessesX (to XexcludeX)X"); put("SelectTag_Exclude",
 * "XSelect XTagsX (to XexcludeX)X"); put("SelectFeature_Include",
 * "XSelect XFeaturesX (to XincludeX)X"); put("SelectPart_Include",
 * "XSelect XPartsX (to XincludeX)X"); put("SelectProcess_Include",
 * "XSelect XProcessesX (to XincludeX)X"); put("SelectTag_Include",
 * "XSelect XTagsX (to XincludeX)X"); put("ColumnName_SelectAll",
 * "XSelect AllX"); put("Lable_Process", "XProcessX");
 * put("AssignedDashboard_No", "XNoX"); put("ParameterSet_None", "XNoneX");
 * put("ParameterSet_TagNotExists", "XXTag GroupX doesn't exist.X");
 * put("GridFeatureSelectedEntity", "XFeatures Selected:X"); put("To", "XToX");
 * put("SelectCode_Exclude", "XSelect XCodesX (to XexcludeX)X");
 * put("HelperText_TypeSelect", "XType/SelectX"); put("HelperText_Select",
 * "XSelectX"); put("No_Record_Found", "XNo Record FoundX");
 * put("Password_Guidelines", "XPassword RulesX" + "\n" +
 * "XMinimum Password Length (characters): 8X" + "\n" +
 * "XPassword must contain the following :X" + "\n" +
 * "XAt least one numeric characterX" + "\n" +
 * "XAt least one upper and lower case characterX" + "\n" +
 * "XAt least one of the following special charactersX [ ] ? / < > ~ # ` ! @ _ - $ % ^ & * ( ) + = { } | : \" ; ' ,"
 * + "\n" + "XSelected password cannot be reused before 365 daysX");
 * put("Password_Guidelines_Change_Password", "XPassword RulesX" + "\n\n" +
 * "XPassword must contain the following:X" + "\n" +
 * "XPassword must contain the following :X" + "\n" +
 * "XAt least one numeric characterX" + "\n" +
 * "XAt least one upper and lower case characterX" + "\n" +
 * "XAt least one of the following special characters {}[]^$@%()...X" + "\n" +
 * "XNew Password must not be the same as any of the previous 5 passwordsX");
 * put("HelperText_Type", "XTypeX"); put("PS_FilterCountText",
 * "Xfilter appliedX"); put("CodeName_PlaceHolder", "XEnter CodeX");
 * put("USL_gt_LRL_LWL_Target_UWL_ErrorMessage",
 * "XXUSLX must be greater than the XLRLX, XLWLX, XTargetX and XUWLXX");
 * put("Target_lt_USL_ErrorMessage", "XXTargetX must be less than XUSLXX");
 * put("UWL_lt_USL_ErrorMessage", "XXUWLX must be less than XUSLXX");
 * put("LWL_lt_USL_ErrorMessage", "XXLWLX must be less than XUSLXX");
 * put("LRL_lt_USL_ErrorMessage", "XXLRLX must be less than XUSLXX");
 * put("URL_gt_Target_UWL_USL_ErrorMessage",
 * "XXURLX must be greater than the XTargetX, XUWLX and XUSLXX");
 * put("LSL_lt_LWL_Target_UWL_URL_ErrorMessage",
 * "XXLSLX must be less than the XLWLX, XTargetX, XUWLX, XUSLX and XURLXX");
 * put("LSG_lt_USG_ErrorMessage", "XXLSGX must be less than XUSGXX");
 * put("USG_gt_LSG_ErrorMessage", "XXUSGX must be greater than XLSGXX");
 * put("LWP_lt_UWP_ErrorMessage", "XXLWPX must be less than XUWPXX");
 * put("UWP_gt_LWP_ErrorMessage", "XXUWPX must be greater than XLWPXX");
 * put("UWL_gt_LWL_ErrorMessage", "XXUWLX must be greater than XLWLXX");
 * put("LWL_lt_UWL_ErrorMessage", "XXLWLX must be less than XUWLXX");
 * put("LSL_gt_LRL_ErrorMessage", "XXLSLX must be greater than XLRLXX");
 * put("LRL_lt_LSL_ErrorMessage", "XXLRLX must be less than XLSLXX");
 * put("USL_lt_URL_ErrorMessage", "XXUSLX must be less than XURLXX");
 * put("URL_gt_USL_ErrorMessage", "XXURLX must be greater than XUSLXX");
 * put("LSL_lt_LWL_ErrorMessage", "XXLSLX must be less than XLWLXX");
 * put("LWL_gt_LRL_LSL_ErrorMessage",
 * "XXLWLX must be greater than the XLRLX and XLSLXX");
 * put("LRL_lt_LWL_ErrorMessage", "XXLRLX must be less than XLWLXX");
 * put("UWL_lt_USL_URL_ErrorMessage",
 * "XXUWLX must be less than the XUSLX and XURLXX");
 * put("URL_gt_UWL_USL_ErrorMessage",
 * "XXURLX must be greater than the XUWLX and XUSLXX");
 * put("USL_gt_LWL_Target_ErrorMessage",
 * "XXUSLX must be greater than the XLWLX and XTargetXX");
 * put("LWL_lt_Target_USL_URL_ErrorMessage",
 * "XXLWLX must be less than the XTargetX, XUSLX and XURLXX");
 * put("URL_gt_LWL_ErrorMessage", "XXURLX must be greater than XLWLXX");
 * put("LSL_lt_Target_ErrorMessage", "XXLSLX must be less than XTargetXX");
 * put("Target_gt_LRL_LSL_LWL_ErrorMessage",
 * "XXTargetX must be greater than the XLRLX, XLSLX and XLWLXX");
 * put("LWL_lt_Target_ErrorMessage", "XXLWLX must be less than XTargetXX");
 * put("LRL_lt_LSL_Target_ErrorMessage",
 * "XXLRLX must be less than the XLSLX and XTargetXX");
 * put("Target_lt_UWL_USL_URL_ErrorMessage",
 * "XXTargetX must be less than the XUWLX, XUSLX and XURLXX");
 * put("LSL_lt_UWL_ErrorMessage", "XXLSLX must be less than XUWLXX");
 * put("Target_lt_UWL_ErrorMessage", "XXTargetX must be less than XUWLXX");
 * put("UWL_gt_LRL_LSL_LWL_Target_ErrorMessage",
 * "XXUWLX must be greater than the XLRLX, XLSLX, XLWLX and XTargetXX");
 * put("LRL_lt_UWL_ErrorMessage", "XXLRLX must be less than XUWLXX");
 * put("URL_gt_LRL_ErrorMessage", "XXURLX must be greater than XLRLXX");
 * put("LRL_lt_URL_ErrorMessage", "XXLRLX must be less than XURLXX");
 * put("USL_gt_LSL_ErrorMessage", "XXUSLX must be greater than XLSLXX");
 * put("LSL_lt_USL_ErrorMessage", "XXLSLX must be less than XUSLXX");
 * put("LWL_lt_Target_UWL_USL_URL_ErrorMessage",
 * "XXLWLX must be less than the XTargetX, XUWLX, XUSLX and XURLXX");
 * put("URL_gt_LRL_LSL_LWL_Target_UWL_USL_ErrorMessage",
 * "XXURLX must be greater than the XLRLX, XLSLX, XLWLX, XTargetX, XUWLX and XUSLXX"
 * ); put("LRL_lt_LSL_LWL_Target_UWL_USL_URL_ErrorMessage",
 * "XXLRLX must be less than the XLSLX, XLWLX, XTargetX, XUWLX, XUSLX and XURLXX"
 * ); put("UWL_lt_URL_ErrorMessage", "XXUWLX must be less than XURLXX");
 * put("LWL_lt_URL_ErrorMessage", "XXLWLX must be less than XURLXX");
 * put("URL_gt_LSL_LWL_Target_UWL_USL_ErrorMessage",
 * "XXURLX must be greater than the XLSLX, XLWLX, XTargetX, XUWLX and XUSLXX");
 * put("USL_gt_UWL_ErrorMessage", "XXUSLX must be greater than XUWLXX");
 * put("URL_gt_UWL_ErrorMessage", "XXURLX must be greater than XUWLXX");
 * put("Password_Not_Changed_Successfully",
 * "XPassword reset unsuccessful. Please try again.X"); put("InvalidCode",
 * "XInvalid CodeX"); put("InvalidValueValidationMessage", "XInvalid ValueX");
 * put("Password_Changed_Successfully",
 * "XPassword changed successfully. Please login using the new password.X");
 * put("Activation_Start_Date_Greater_Than_End_Date",
 * "XActivation Start Date can�t be greater than the Activation End Date.X");
 * put("LWL_gt_LSL_ErrorMessage", "XXLWLX must be greater than XLSLXX");
 * put("URL_gt_LSL_ErrorMessage", "XXURLX must be greater than XLSLXX");
 * put("Password_Reset_Unsuccessful",
 * "XPassword reset unsuccessful. Please try again.X");
 * put("Password_Change_Unsuccessful",
 * "XPassword change unsuccessful. Please try again.X");
 * put("Password_Expired_Message", "XPassword expired. Please reset.X");
 * put("T2_lt_T1_ErrorMessage", "XT2 XLowerX must be less than T1 XLowerXX");
 * put("T2_lt_LSC_T1_ErrorMessage",
 * "XT2 XLowerX must be less than the XLSCX and T1 XLowerXX");
 * put("LSC_gt_T1_T2_ErrorMessage",
 * "XXLSCX must be greater than the T1 XLowerX and T2 XLowerXX");
 * put("T1_lt_LSC_ErrorMessage", "XT1 XLowerX must be less than XLSCXX");
 * put("LSC_gt_MAVLower_ErrorMessage",
 * "XXLSCX must be greater than MAV XLowerXX");
 * put("MAVUpper_gt_MAVLower_ErrorMessage",
 * "XMAV XUpperX must be greater than MAV XLowerXX");
 * put("MAVLower_lt_LSC_ErrorMessage", "XMAV XLowerX must be less than XLSCXX");
 * put("MAVLower_lt_LSC_MAVUpper_ErrorMessage",
 * "XMAV XLowerX must be less than the XLSCX and MAV XUpperXX");
 * put("LSC_lt_MAVUpper_ErrorMessage", "XXLSCX must be less than MAV XUpperXX");
 * put("MAVUpper_gt_LSC_MAVLower_ErrorMessage",
 * "XMAV XUpperX must be greater than the XLSCX and MAV XLowerXX");
 * put("MAVLower_lt_MAVUpper_ErrorMessage",
 * "XMAV XLowerX must be less than MAV XUpperXX");
 * put("T1Lower_lt_T2Upper_T1Upper_LSC_ErrorMessage",
 * "XT1 XLowerX must be less than the T2 XUpperX, T1 XUpperX and XLSCXX");
 * put("T2Lower_lt_T2Upper_T1Upper_LSC_T1Lower_ErrorMessage",
 * "XT2 XLowerX must be less than the T2 XUpperX, T1 XUpperX, XLSCX and T1 XLowerXX"
 * ); put("T2Lower_lt_LSC_ErrorMessage",
 * "XT2 XLowerX must be less than XLSCXX");
 * put("T2Lower_lt_T1Upper_LSC_T1Lower_ErrorMessage",
 * "XT2 XLowerX must be less than the T1 XUpperX, XLSCX and T1 XLowerXX");
 * put("T1Lower_lt_T1Upper_LSC_ErrorMessage",
 * "XT1 XLowerX must be less than the T1 XUpperX and XLSCXX");
 * put("T1_gt_T2_ErrorMessage", "XT1 XLowerX must be greater than T2 XLowerXX");
 * put("T2Lower_lt_T1Upper_ErrorMessage",
 * "XT2 XLowerX must be less than T1 XUpperXX");
 * put("T1Lower_lt_T1Upper_ErrorMessage",
 * "XT1 XLowerX must be less than T1 XUpperXX");
 * put("T1Upper_lt_T2Upper_ErrorMessage",
 * "XT1 XUpperX must be less than T2 XUpperXX");
 * put("T2Lower_gt_T1Upper_ErrorMessage",
 * "XT2 XUpperX must be greater than T1 XUpperXX");
 * put("LSC_lt_T2Upper_T1Upper_ErrorMessage",
 * "XXLSCX must be less than the T2 XUpperX and T1 XUpperXX");
 * put("T2Upper_gt_LSC_ErrorMessage",
 * "XT2 XUpperX must be greater than XLSCXX");
 * put("LSC_gt_T1Lower_ErrorMessage",
 * "XXLSCX must be greater than T1 XLowerXX");
 * put("T2Upper_gt_T1Lower_ErrorMessage",
 * "XT2 XUpperX must be greater than T1 XLowerXX");
 * put("T1Upper_gt_T1Lower_ErrorMessage",
 * "XT1 XUpperX must be greater than T1 XLowerXX");
 * put("T1Upper_gt_Lsc_ErrorMessage",
 * "XT1 XUpperX must be greater than XLSCXX");
 * put("T1Upper_gt_T2Lower_ErrorMessage",
 * "XT1 XUpperX must be greater than T2 XLowerXX");
 * put("LSC_gt_T2Lower_ErrorMessage",
 * "XXLSCX must be greater than T2 XLowerXX");
 * put("T2Upper_gt_T2Lower_ErrorMessage",
 * "XT2 XUpperX must be greater than T2 XLowerXX");
 * put("MAVUpper_gt_LSC_ErrorMessage",
 * "XMAV XUpperX must be greater than XLSCXX");
 * put("T2Upper_gt_T1Upper_LSC_T1Lower_T2Lower_ErrorMessage",
 * "XT2 XUpperX must be greater than the T1 XUpperX, XLSCX, T1 XLowerX and T2 XLowerXX"
 * ); put("T1Upper_gt_LSC_T1Lower_T2Lower_ErrorMessage",
 * "XT1 XUpperX must be greater than the XLSCX, T1 XLowerX and T2 XLowerXX");
 * put("LSC_lt_T1Upper_ErrorMessage", "XXLSCX must be less than T1 XUpperXX");
 * put("Part_Is_Inactive", "XXPartX is inactive.X");
 * put("Part_Feature_Existing_Combination_Message",
 * "XPart - Feature combination already exists.X"); put("Process_Not_Exists",
 * "XXProcessX doesn't exist.X"); put("TagGroupName_Already_Exists",
 * "XTag Group Name already exists.X"); put("MinValue_lt_MaxValue",
 * "XMin. value should always be less than the Max. valueX");
 * put("MaxValue_gt_MinValue",
 * "XMax. value should always be greater than the Min. valueX");
 * put("FeatureNotExistsValidationMessage", "XXFeatureX doesn't exist.X");
 * put("InvalidMaxValueValidationMessage",
 * "XValue cannot be greater than maximum defined value.X");
 * put("InvalidMinValueValidationMessage",
 * "XValue cannot be less than minimum defined value.X");
 * put("EndDateTimeCannotLessThanStartDateTime",
 * "XEnd Date/Time cannot be smaller than Start Date/Time.X");
 * put("NewAndConfirmPasswordMismatch",
 * "XNew Password and Confirm New Password didn�t match. Try Again.X");
 * put("Part_Not_Exists", "XXPartX doesn't exist.X");
 * put("PopOverPieceSpecLimit", "XPiece Manufacturing LimitX");
 * put("Selected_Process", "XSelected ProcessX");
 * put("Would_You_Like_To_Continue", "XWould you like to continue?X");
 * put("ValueBelowReasonableLimit_Title", "XValue below Reasonable limitX");
 * put("ValueAboveReasonableLimit_Title", "XValue above Reasonable LimitX");
 * put("OutOfSpecificationLimits_Title",
 * "XOut of Specification Limits: <Part> - <Feature>X");
 * put("SelectPartPopUpHeader_Title", "XPart FamilyX - XSelected PartsX");
 * put("UnreasonableValueEntered", "XUnreasonable value enteredX");
 * put("ValueMustBeWithinResonableLimit",
 * "XValue must be within reasonable limitsX"); put("OutOfWarningLimits_Title",
 * "XOut of Warning Limits: <Part> - <Feature>X"); put("RemoveEntityPopupTitle",
 * "XRemove <Element Name>X"); put("IndividualSettings_AllValueRequired",
 * "XAll Values RequiredX"); put("IndividualSettings_AtLeastOneValueRequired",
 * "XAt Least One Value RequiredX"); put("IndividualSettings_NoValueRequired",
 * "XNo Values RequiredX"); put("IndividualSettings_ValueOnly", "XValue OnlyX");
 * put("IndividualSettings_ValueAndRequiredCode", "XValue and Required CodeX");
 * put("IndividualSettings_ValueAndOptionalCode", "XValue and Optional CodeX");
 * put("IndividualSettings_AllValues", "XAll ValuesX");
 * put("IndividualSettings_ReasonableValuesOnly", "XReasonable Values OnlyX");
 * put("IndividualSettings_CodeOnly", "XCode OnlyX");
 * put("ProcessState_History_Last_20", "XHistoryX (XLast 20X)");
 * put("Part_InActivation_Validation_Message",
 * "XPart will become inactive on <Date>.X"); put("Process_State_Idle",
 * "3 - XIdleX"); put("Process_State_Pause", "5 - XPauseX");
 * put("Process_State_Run", "2 - XRunX"); put("Process_State_ScheduledDown",
 * "6 - XScheduled DownX"); put("Process_State_Start", "1 - XStartX");
 * put("Process_State_Stop", "4 - XStopX"); put("Process_State_UnscheduledDown",
 * "7 - XUnscheduled DownX");
 * 
 * put("Permissions_Create", "XCreateX"); put("Permissions_View", "XViewX");
 * put("Permissions_CreateRevision", "XCreate RevisionX");
 * put("Permissions_Edit", "XEditX"); put("Permissions_Remove", "XRemoveX");
 * put("Permissions_EditUniqueId", "XEdit Unique IDX");
 * put("Permissions_Release", "XReleaseX"); put("Permissions_ViewHistory",
 * "XView HistoryX"); put("FilterApplied", "Xfilter appliedX");
 * put("FiltersApplied", "Xfilters appliedX"); put("InActivation_Date_Message",
 * "XProcess state is already set at this time.X"); put("MDC_AddLotDetails",
 * "XAdd lot detailsX"); put("MDC_ConfirmationMessageDataCollection",
 * "XDo you want to cancel the data collection?X");
 * put("OutOfWithInPieceLimits_Title",
 * "XOut of Within piece limits: <Part> - <Feature>X");
 * put("Lot_TestingReleased", "XTesting - ReleasedX");
 * put("ViewCodeModalBoxMessage",
 * "XCode Group: <CodeGroupName>X x(<Count> xcodex exists.)x");
 * put("MDC_MissingValue_HeaderTitle", "XMissing ValuesX");
 * put("MDC_MissingValueConfirmationMessage",
 * "XRequired Value(s) missing. Please complete before saving.X");
 * put("Create_Lot_Page_Title", "XCreate LotX");
 * put("MDC_CreateLot_ConfirmationMessage",
 * "X<LotName> doesn�t exist, a new lot will be created. Do you want to continue?X"
 * ); put("Checklist_Default_Processes_Selected", "XAny XProcessXX");
 * put("Checklist_Assignment_Grid_Label",
 * "XAllow only the following to complete this checklist.X");
 * put("Checklist_Process_Label", "XProcessX"); put("Checklist_Name_Header",
 * "XNameX"); put("Checklist_Assignee_Header", "XAssigneeX");
 * put("Checklist_Header_Title", "XChecklistsX");
 * put("Checklist_BasicInformation_Section_Title", "XBasic InformationX");
 * put("Checklist_ProcessSelection_Section_Title", "XProcess SelectionX");
 * put("Checklist_EventGeneration_Section_Title", "XEvent GenerationX");
 * put("Checklist_Assignment_Section_Title", "XAssignmentX");
 * put("Checklist_Preview", "Preview"); put("ColumnName_Checklist",
 * "XChecklistX"); put("Checklist_Create", "XCreate ChecklistX");
 * put("DefineCondition", "XDefine ConditionX"); put("DefineAction",
 * "XDefine ActionX"); put("RequirementCondition", "XRequirement ConditionX");
 * put("RequirementWindow", "XRequirement WindowX");
 * put("Test Requirement Condition", "XTest Requirement ConditionX");
 * put("Clear", "XClearX"); put("If True", "XIf TrueX");
 * 
 * put("DefineActionTabTitle", "XThen capture Xdata collectionXX");
 * put("SpecifyTime", "XSpecify TimeX"); put("RunOnce", "XRun OnceX");
 * put("DefineFrequency", "XDefine FrequencyX"); put("Every", "XEveryX");
 * put("SpecifyTime_FromLastDataCollection", "Xfrom last Xdata collectionXX");
 * put("SpecifyTime_BasedOnReference", "Xbased on referenceX"); put("Days",
 * "XDaysX"); put("Hours", "XHoursX"); put("Minutes", "XMinutesX");
 * put("SpecifyTime_ResetFrequencyOnPartChange", "XReset on part changeX");
 * put("SpecifyProcess", "XSpecify ProcessX"); put("Deadline", "XDeadlineX");
 * put("SetWindowTabTitle", "XSet WindowX");
 * put("SetWindow_AfterScheduledOccurrence", "Xafter scheduled occurrenceX");
 * put("SetWindow_BeforeScheduledOccurrence", "Xbefore scheduled occurrenceX");
 * put("SetWindow_MarkTheDataCollectionLateIfNotCollected",
 * "XMark the Xdata collectionX late if not collectedX"); put("EarlyReminder",
 * "XEarly ReminderX"); put("Reminder", "XReminderX"); put("Occurrence",
 * "XOccurrenceX"); put("EditExisting", "XEdit ExistingX"); put("CreateNew",
 * "XCreate NewX");
 * 
 * put("Feature_AlreadyExists", "XXFeatureX already exists.X");
 * put("Checklist_DefectTypeFeatureCannotBeSelected",
 * "XXDefectX type feature can't be selected.X");
 * put("Checklist_DefectiveTypeFeatureCannotBeSelected",
 * "XXDefectiveX type feature can't be selected.X");
 * put("Checklist_VariableTypeFeatureCannotBeSelected",
 * "XXVariableX type feature can't be selected.X"); put("ColumnName_None",
 * "XNoneX"); put("Checklist_AlreayExists", "XChecklist already exists.X");
 * put("Checklist_Role", "XRoleX"); put("Checklist_User", "XUserX");
 * put("Checklist_Workstation", "XWorkstationX"); put("Months", "XMonthsX");
 * put("Weeks", "XWeeksX"); put("Years", "XYearsX");
 * 
 * put("LotNotExistsValidationMessage", "XXLotX doesn't exist.X");
 * put("LotUniquenessValidationMessage",
 * "XLot Number already exists for this part.X");
 * put("MDC_DataCollectionType_PopupTitle", "XData Collection TypeX");
 * 
 * put("Checklist_RoleAlreadyExists", "XXRoleX already exists.X");
 * put("Checklist_UserAlreadyExists", "XXUserX already exists.X");
 * put("Checklist_WorkstationAlreadyExists", "XXWorkstationX already exists.X");
 * put("Checklist_RoleNotExists", "XXRoleX doesn't exist.X");
 * put("Checklist_UserNotExists", "XXUserX doesn't exist.X");
 * put("Checklist_WorkstationNotExists", "XXWorkstationX doesn't exist.X");
 * 
 * put("Checklist_PreviewHeader", "XPreview - <Element Name>X"); put("Preview",
 * "XPreviewX"); put("AccordionItem_ChecklistFeature",
 * "X<Element Name> - Feature assignmentX");
 * put("Checklist_DeleteConfirmaitonMessageWithAssociations",
 * "XOn removal of XchecklistX, following associations will also be removed:X");
 * put("DeleteConfirmaitonMessageWithOutAssociations",
 * "XDo you want to remove <Element Name>?X"); put("RemovalTitle",
 * "XRemove <Element Name>X"); put("Checklist_SingleTagPopUp_Header",
 * "XChecklistX: <ChecklistName> x(<Count> xtagx exists.)x");
 * 
 * put("Preview_Comment_Placeholder", "XEnter your comment hereX");
 * put("Preview_Response_Placeholder", "XEnter your response hereX");
 * put("User_Popup_Header", "XView UserX"); put("SelectProcesses",
 * "XSelect ProcessesX"); put("ConditionDoenstExist",
 * "XXConditionX doesn't exist.X"); put("LateTimeMustBeLessThanDeadline",
 * "XLate time must be less than deadline.X"); put("Conditions",
 * "XConditionsX"); put("USL_gt_LRL_ErrorMessage",
 * "XXUSLX must be greater than XLRLXX"); put("TSL_gt_LRL_ErrorMessage",
 * "XXTargetX must be greater than XLRLXX"); put("LWL_gt_LRL_ErrorMessage",
 * "XXLWLX must be greater than XLRLXX"); put("UWL_gt_LRL_ErrorMessage",
 * "XXUWLX must be greater than XLRLXX"); put("Target_gt_LSL_ErrorMessage",
 * "XXTargetX must be greater than XLSLXX"); put("UWL_gt_LSL_ErrorMessage",
 * "XXUWLX must be greater than XLSLXX"); put("LRL_lt_Target_ErrorMessage",
 * "XXLRLX must be less than XTargetXX"); put("USL_gt_Target_ErrorMessage",
 * "XXUSLX must be greater than XTargetXX"); put("URL_gt_Target_ErrorMessage",
 * "XXURLX must be greater than XTargetXX"); put("UWL_gt_Target_ErrorMessage",
 * "XXUWLX must be greater than XTargetXX");
 * 
 * put("DCRequirement_PageTitle", "XDefine XData CollectionX RequirementsX");
 * put("ContinueButton", "XContinueX"); put("SampleSize_SubTitle",
 * "XPlease enter a Sample SizeX");
 * 
 * put("ConfirmationMessageForTotalCountLessThanOrEqualTo999",
 * "XEntered value should be less than or equals to 100000000X");
 * put("ResponseGroup_OneActiveChoiceMessage",
 * "XAt least an active choice needs to be set.X");
 * put("ResponseGroup_FeaturePopUp_Title", "XView FeatureX");
 * put("ResponseGroup_SingleFeaturePopUp_Header",
 * "XResponse Group : <RespGroupName>X x(<Count> xfeaturex exists.)x");
 * put("ResponseGroup_RemovalMessage",
 * "XDo you want to remove <RespGroupName>?X");
 * put("ResponseGroup_RemovalTitle", "XRemove <RespGroupName>X");
 * put("ResponseGroup_RemovedSuccessfullyMessage",
 * "X<RespGroupName> removed successfully.X"); put("ColumnName_QuestionText",
 * "XQuestion TextX");
 * 
 * put("ResponseGroup_Header_Title", "XResponse GroupsX");
 * put("CreateResponseGroup_Header_Title", "XCreate Response GroupX");
 * put("EditResponseGroup_Header_Title", "XEdit Response GroupX");
 * put("ColumnName_ResponseType", "XResponse TypeX");
 * put("ColumnName_ResponseGroup", "XResponse GroupX"); put("ColumnName_Choice",
 * "XChoiceX"); put("ColumnName_Comment", "XCommentX"); put("ColumnName_Track",
 * "XTrackX"); put("RuleTemplateNotExists", "XRule Template doesn�t exist.X");
 * put("FeatureTypeNotApplicale", "XNot applicable for this feature type.X");
 * put("ProceesingTemplateNotExists", "XProcessing Template doesn�t exist.X");
 * put("ControlLimit_SaveSuccessfullyMessage",
 * "XControl limit of <Element Name> saved successfully.X");
 * put("ControlLimit_EffectiveDateMessage",
 * "XEffective From should be greater than <Date>X");
 * put("ControlLimit_EffectiveLesserDateMessage",
 * "XEffective From should be lesser than <Date>X");
 * put("ControlLimit_PopUpRemovalTitle", "XRemove Control LimitX");
 * put("ControlLimit_RemoveMessageAtEdit",
 * "XDo you want to remove control limit effective from <Date>?X");
 * 
 * put("Operation_Not_Exists", "XXOperationX doesn't exist.X");
 * put("ColumnName_EffectiveFrom", "XEffective FromX");
 * put("ColumnName_ProcessSigma", "XProcess SigmaX");
 * put("ColumnName_ProcessMean", "XProcess MeanX");
 * put("ColumnName_WithinPieceSigma", "XWithin Piece SigmaX");
 * put("ColumnName_RuleTemplate", "XRule TemplateX");
 * put("ColumnName_ProcessingTemplate", "XProcessing TemplateX");
 * put("CL_DataStream", "XData StreamX"); put("CL_AssociatedCLPopUp",
 * "XView Control LimitX");
 * 
 * put("ViewRequirementConditions", "XView Requirement ConditionsX");
 * put("Requirements", "XRequirementsX"); put("Active", "XActiveX");
 * put("DefectiveTypeFeatureCan'tBeSelected",
 * "XXDefectiveX type feature can't be selected.X");
 * put("DefectTypeFeatureCan'tBeSelected",
 * "XXDefectX type feature can't be selected.X");
 * put("ChecklistTypeFeatureCan'tBeSelected",
 * "XXChecklistX type feature can't be selected.X"); put("ColumnName_Shift",
 * "XShiftX"); put("ParameterSet_TagAlreadyExists", "XTag already exists.X");
 * put("PS_PartPopUpHeader_Title", "XSelected PartsX"); put("Shift_Exclude",
 * "XSelect XShiftsX (to XexcludeX)X"); put("Shift_Include",
 * "XSelect XShiftsX (to XincludeX)X"); put("ParameterSet_NoShiftMessage",
 * "XAny XShiftXX"); put("GridShiftSelectedEntity", "XShifts Selected:X");
 * put("SelectShiftEntity_Header_Title", "XSelect XShiftsXX");
 * put("Lot_Header_Title", "XLotsX"); put("SelectLot_Include",
 * "XSelect XLotsX (to XincludeX)X"); put("GridLotSelectedEntity",
 * "XLots Selected:X"); put("SelectLotEntity_Header_Title", "XSelect XLotsXX");
 * put("Criteria_LotStatus", "XLot StatusX"); put("Criteria_TagGroup",
 * "XTag GroupX"); put("ColumnName_Category", "XCategoryX");
 * put("LotStatusType_Created", "XCreatedX"); put("ColumnName_LotName",
 * "XLot NameX"); put("PS_SelectedLotPopUpHeader_Title", "XSelected LotsX");
 * put("PS_DeleteConfirmaitonMessageWithAssociations",
 * "XOn removal of parameter set, following associations will also be removed:X"
 * ); put("AccordionItem_AssignedToDashboard", "XAssigned to dashboardX");
 * put("PS_RemovedSuccessfullyMessage",
 * "X<ParameterSetName> removed successfully.X"); put("PS_RemovalMessage",
 * "XDo you want to remove <ParameterSetName>?X"); put("PS_RemovalTitle",
 * "XRemove <ParameterSetName>X");
 * put("EditKeyboardEnteredValuesDuringDataEntry",
 * "XEdit keyboard entered values during data entryX");
 * put("EditGaugeEnteredValuesDuringDataEntry",
 * "XEdit gauge entered values during data entryX"); put("DisplayScale",
 * "XViolation Highlight (Scale or Defective Label)X");
 * put("HighlightGridNotification", "XGrid HighlightX");
 * put("HighlightPopupNotification", "XViolation PopupX");
 * put("PlaySoundWhenAGaugeValueIsEntered",
 * "XPlay sound when a gauge value is enteredX");
 * put("SpecificationLimitNotification",
 * "XViolation Notification (Manufacturing Limit or Defective)X");
 * put("GaugeEnteredValueNotification", "XGauge Entered Value NotificationX");
 * put("Default", "XDefaultX"); put("Custom", "XCUSTOMX");
 * put("DcConfigSaveSuccessmsg",
 * "XData Collection Configuration for <Element Name> " +
 * "changes successfully.X"); put("DcConfigSaveSuccessmsg2",
 * "XData Collection Configuration for <Element Name> " +
 * "saved successfully.X"); put("ColumnName_ChildProcess",
 * "XInclude ChildrenX"); put("ShiftCountMessage",
 * "X<count> XShiftX SelectedX"); put("LotCountMessage",
 * "X<count> XLotX SelectedX");
 * 
 * put("DC_DataCollectionType_ChkBoxLabel", "XData collection typeX");
 * put("DC_AllowLotCreation_ChkBoxLabel", "XAllow lot creationX");
 * put("DC_InputPartFaimily1_ChkboxLabel", "<DC Test Name>_InputPartFamily1");
 * put("DCIndSetting_EntryMethod", "XEntry MethodX");
 * put("DCIndSetting_EntryMethod_NextValue", "XNext ValueX");
 * put("DCIndSetting_EntryMethod_CurrentValue", "XCurrent ValueX");
 * put("DCIndSetting_EntryMethod_NewestUnusedValue", "XNewest Unused ValueX");
 * put("DCIndSetting_EntryMethod_OldestUnusedValue", "XOldest Unused ValueX");
 * put("DCIndSetting_EntryMethod_DispListOfValues",
 * "XDisplay list of values to the userX");
 * put("DCSetting_Assignment_AllowOnly",
 * "XAllow only the following to perform the data collectionX");
 * put("GaugeDev_CurrentValue", "XCurrent ValueX"); put("DCIndSetting_Custom",
 * "XCustomX"); put("DCIndSetting_Default", "XDefaultX");
 * put("IndividualSettings_WithinPieceMeasurement",
 * "XWithin Piece MeasurementsX"); put("DCConfig_GlobalSampleSizeMessage",
 * "XSample size can not be greater than 200 for variable features. Sample size will be set to 200. Do you want to continue?X"
 * );
 * 
 * put("DataCollectionConfig_SaveSuccessfullyMessage",
 * "XData Collection Configuration for <Element Name> saved successfully.X");
 * 
 * put("AccordionItem_ResponseGroupFeature", "XAssigned to featureX");
 * put("ResponseGroup_DeleteConfirmaitonMessageWithAssociations",
 * "XOn removal of xresponse groupx, following associations will also be removed:X"
 * ); put("ColumnName_ControlLimit", "XControl LimitX");
 * put("SingleCLModalBoxMessage", "x(<Count> xcontrol limitx exists.)x");
 * put("EditControlLimit_Title", "XEdit Control LimitX");
 * put("AccordionItem_AssignedProcessStateMessage",
 * "XAssigned to current state of processX"); put("FeatureTypeDrpDwn_Variable",
 * "1 - XVariableX"); put("GaugeValue_ShowNewestOnTop", "XShow newest on topX");
 * put("GaugeValue_SpecifyMaximumNumberOfValuesIn the list",
 * "XSpecify maximum number of values in the listX");
 * put("GaugeValue_AllowPreviouslyUsedValuesToBeDisplayed",
 * "XAllow previously used values to be displayedX");
 * put("EntryMethod_NotificationMsgWhenBothCheckBoxUnchecked",
 * "XAt least one of the entry method needs to be selected.X");
 * put("DynamicLabel", "XDynamic selectionX"); put("GaugeDevice",
 * "XGauge DeviceX"); put("DCRequirementAlreadyExistsMessage",
 * "XDC requirement already exists.X"); put("NoNewChangeIsSaved",
 * "XNo new change is saved.X"); put("ResponseType_SingleAnswer_Checklist",
 * "XSingle AnswerX"); put("ColumnName_Requirements", "XRequirementsX");
 * put("Assignee_Role", "XRoleX"); put("Feature_DCModalBoxMessage",
 * "x(<Count> xdata collectionsx exist.)x");
 * put("Feature_SingleDCModalBoxMessage",
 * "x(<Count> xdata collectionx exists.)x");
 * put("ResponseType_MultipleAnswer_Checklist", "XMultiple AnswerX");
 * put("User_Status_Active", "1 - XActiveX"); put("User_Status_Inactive",
 * "0 - XInactiveX"); put("ShiftLandingPageTitle", "XShiftsX");
 * put("createShiftPageHeaderTitle", "XShiftsX"); put("ColumnShiftName",
 * "XShift NameX"); put("CreateShiftTitle", "XCreate ShiftX");
 * put("ProcessShiftSchedule_CreateShiftPage", "XProcess Shift ScheduleX");
 * put("ColumnName_Monday", "XMondayX"); put("ColumnName_Tuesday", "XTuesdayX");
 * put("ColumnName_Wednesday", "XWednesdayX"); put("ColumnName_Thursday",
 * "XThursdayX"); put("ColumnName_Friday", "XFridayX");
 * put("ColumnName_Saturday", "XSaturdayX"); put("ColumnName_Sunday",
 * "XSundayX"); put("lbl_Schedule", "XScheduleX"); put("lbl_DefineSchedule",
 * "XDefine ScheduleX"); put("lbl_DerivedFromParentProcess",
 * "XDerived from parent processX"); put("lbl_EffectiveFrom",
 * "XEffective FromX"); put("lbl_ViewProcesses", "XView ProcessesX");
 * put("lbl_SelectProcess", "XSelect ProcessX"); put("lbl_PlusOneDay",
 * "+1 XdayX"); put("error_TimeOverLapWithPreviousDay",
 * "XOverlaps with previous day.X"); put("error_TimeOverLapWithNextDay",
 * "XOverlaps with next day.X"); put("column_StartTime", "XStart TimeX");
 * put("column_EndTime", "XEnd TimeX"); put("ShiftAlreadyExists",
 * "XShift already exists.X");
 * put("createShift_MessageForAtleastOneProcessSelection",
 * "XAt least a process schedule needs to be defined to create a shift.X");
 * put("AccordionItem_AssignedShift", "XAssigned to shiftX");
 * put("AccordionItem_ShiftDeleteSingleProcess",
 * "XShift(s) having only one removed process schedule will also be removed. Impacted shiftX"
 * ); put("ShiftCantBeRemoved_Process",
 * "XShift can�t be removed as other process schedule is also defined. Process schedule associations of this shift will not be removed.X"
 * ); put("Part_Is_Inactive_PFDetail", "XPart is inactive.X");
 * put("Global_Configuration", "XGlobal ConfigurationX");
 * put("Label_SpecificationLimits", "XSpecification LimitsX");
 * put("Label_WarningLimit", "XWarning LimitX"); put("Label_ReasonableLimit",
 * "XReasonable LimitX"); put("Label_Auto-fill", "XAuto-fillX");
 * put("Label_%for'WarningLimits'", "% Xfor 'Warning Limits'X");
 * put("Label_xfor'ReasonableLimits'", "Xx for 'Reasonable Limits'X");
 * put("Label_DefaultCapabilityTargetValues",
 * "XDefault Capability Target ValuesX"); put("Label_CpTarget", "XCp TargetX");
 * put("Label_PpTarget", "XPp TargetX"); put("Label_CpkTarget", "XCpk TargetX");
 * put("Label_PpkTarget", "XPpk TargetX"); put("SecurityPolicyPageTitle",
 * "XSecurity PolicyX"); put("SecurityPolicyPageHeaderText",
 * "XConfigure Security PolicyX");
 * put("SecurityPolicyPage_UserloginSettingsTab", "XUser Login SettingsX");
 * put("SecurityPolicyPage_CredentialSettingsTab", "XCredential SettingsX");
 * put("SecurityPolicyPage_DataAuthenticationSettingsTab",
 * "XData Authentication SettingsX");
 * put("SecurityPolicyPage_UserNameValidation_LengthHigherThanAllowed",
 * "XMinimum username length can�t be greater thanX 90.");
 * put("SecurityPolicyPage_UserNameValidation_LengthLowerThanAllowed",
 * "XMinimum username length can�t be less thanX 5.");
 * put("SecurityPolicyPage_SaveSuccessMessage",
 * "XSecurity policy updated successfully.X"); put("Yes", "XYesX"); put("No",
 * "XNoX"); put("ManageSettingsPageTitle", "XSettingsX");
 * put("ManageSettingsPageHeaderText", "XSettingsX"); put("CPK_Target_Range",
 * "<LowerValue> <= XCpk TargetX <= <UpperValue>"); put("CP_Target_Range",
 * "<LowerValue> <= XCp TargetX <= <UpperValue>"); put("PP_Target_Range",
 * "<LowerValue> <= XPp TargetX <= <UpperValue>"); put("PPK_Target_Range",
 * "<LowerValue> <= XPpk TargetX <= <UpperValue>"); put("Warning_Limit_Range",
 * "XRange should be between <LowerValue>% to <UpperValue>%X");
 * put("Reasonable_Limit_Range",
 * "XRange should be between <LowerValue> to <UpperValue>X");
 * 
 * put("SecurityPolicy_Header_Title", "XSecurity PolicyX");
 * put("SecurityPolicy_IdleForOneDay", "X1 dayX");
 * put("SecurityPolicy_UseEmailIdNo", "XNoX"); put("GeneralSetting",
 * "XGeneral SettingsX"); put("UnitOfMeasurementAlreadyExists",
 * "XUnit of Measurement already exists.X"); put("AbbreviationAlreadyExists",
 * "XAbbreviation already exists.X"); put("GC_DataCollectionType_TabHeader",
 * "XData collection typeX"); put("Lbl_ChkBox_EnableDataCollectionType",
 * "XEnable Data collection typeX"); put("ColumnName_Type", "XTypeX");
 * put("GC_SaveSuccessMessage", "XGlobal Configuration saved successfully.X");
 * 
 * put("GC_DCType_AlreadyExistMessage",
 * "XData Collection Type already exists.X");
 * put("SecurityPolicy_MissingInfoMessage",
 * "XMissing/Incorrect Information | Correct or Cancel them before saving.X");
 * put("GlobalConfiguration_Header_Title", "XGlobal ConfigurationX");
 * put("ColumnName_Abbreviation", "XAbbreviationX");
 * put("ColumnName_Unit_Of_Measurement", "XUnit Of MeasurementX");
 * put("ColumnName_UnitType", "XUnit TypeX"); put("UnitType_Angle", "XAngleX");
 * put("UnitType_Area", "XAreaX"); put("UnitType_Count", "XCountX");
 * put("UnitType_Currency", "XCurrencyX"); put("UnitType_Current", "XCurrentX");
 * put("UnitType_Data", "XDataX"); put("UnitType_Density", "XDensityX");
 * put("UnitType_Energy", "XEnergyX"); put("UnitType_Force", "XForceX");
 * put("UnitType_Height", "XHeightX"); put("UnitType_Length", "XLengthX");
 * put("UnitType_Luminosity", "XLuminosityX"); put("UnitType_Mass", "XMassX");
 * put("UnitType_Power", "XPowerX"); put("UnitType_Pressure", "XPressureX");
 * put("UnitType_Speed", "XSpeedX"); put("UnitType_Temperature",
 * "XTemperatureX"); put("UnitType_Time", "XTimeX"); put("UnitType_Torque",
 * "XTorqueX"); put("UnitType_Viscosity", "XViscosityX"); put("UnitType_Volume",
 * "XVolumeX"); put("UnitType_Width", "XWidthX"); put("UnitType_Work",
 * "XWorkX"); put("UnitWillBeRemovedContinue",
 * "XUnit will be removed. Continue?X");
 * put("GC_RemoveDCType_ConfirmationMessage",
 * "XDo you want to remove <DCTypeName>?X");
 * 
 * put("Events", "XEvents?X"); put("Status_Removed", "2 - XRemovedX");
 * put("Status_All", "3 - XAllX");
 * 
 * put("GCAbbr_DeleteConfirmaitonMessageWithAssociations",
 * "XOn removal of Abbreviation, following associations will also be removed:X"
 * ); put("AccordionItem_Impacted_Lot", "XImpacted lotX");
 * 
 * put("SecurityPolicyPage_Forever", "XForeverX");
 * put("SecurityPolicy_IdleForFiveDay", "X5 daysX");
 * put("SecurityPolicy_IdleForThreeDay", "X3 daysX");
 * put("SecurityPolicy_IdleFor15Min", "X15 minutesX");
 * put("SecurityPolicy_IdleFor30Min", "X30 minutesX");
 * put("SecurityPolicy_IdleFor1Hour", "X1 hourX");
 * put("SecurityPolicy_IdleFor4Hour", "X4 hoursX");
 * put("SecurityPolicy_IdleFor8Hour", "X8 hoursX");
 * put("SecurityPolicy_IdleFor15Hour", "X15 hoursX"); put("Aggregated",
 * "XAggregatedX"); put("Raw", "XRawX"); put("URL_CreateSpecHelpLink",
 * "SpecLimits/CreatingSpecLimits.htm"); put("RequiredAnswersMissing",
 * "XRequired answers missing.X"); put("ConfirmationMessage_NoResponseEntered",
 * "XNo response entered. Checklist will be cancelled.X");
 * put("URL_SpecLimitLandingPageHelpLink", "SpecLimits/ManagingSpecLimits.htm");
 * put("URL_EditSpecLimitPageHelpLink", "SpecLimits/EditingSpecLimits.htm");
 * put("UserPage_UserNameValidation_LengthLowerThanAllowed",
 * "XMinimum username length can�t be less than <SetLength>.X");
 * put("uRL_SecurityPolicyPageHelpLink",
 * "Security/ConfiguringSecurityPolicy.htm");
 * put("SecurityPolicyPage_validationForPasswordLength_HigherThanAllowed",
 * "XMinimum password length can�t be greater thanX 20.");
 * put("SecurityPolicyPage_validationForPasswordLength_LowerThanAllowed",
 * "XMinimum password length can�t be less thanX 5.");
 * put("ManageSettingsPage_BasicInformation", "XBasic InformationX");
 * put("ManageSettingsPage_Notifications", "XNotificationsX"); put("Removed",
 * "XRemovedX");
 * 
 * put("AccordionItem_Impacted_Lot", "XImpacted lotX");
 * put("GC_ActiveDCToBeDefined",
 * "XAt least one active data collection type needs to be defined.X");
 * put("Role_Management", "XRole ManagementX"); put("Authentication",
 * "XAuthenticationX"); put("User_Management", "XUser ManagementX");
 * put("AccessDeniedText",
 * "XYou don't have permission for requested resource.X");
 * 
 * put("NoAccessLevelMessage",
 * "XNo access level has been assigned to you. Please contact system administrator.X"
 * ); put("InvalidPermissionMessage",
 * "XInvalid permissions. Please contact administrator.X");
 * put("FifteenMinutes", "X15 minutesX"); put("ThirtyMinutes", "X30 minutesX");
 * put("OneHour", "X1 hourX"); put("FourHours", "X4 hoursX"); put("EightHours",
 * "X8 hoursX"); put("FifteenHours", "X15 hoursX"); put("OneDay", "X1 dayX");
 * put("ThreeDays", "X3 daysX"); put("FiveDays", "X5 daysX");
 * put("RoleNameUniquenessValidationMessage", "XRole Name already exists.X");
 * put("ValidationMessage_PasswordAdvanceNotification",
 * "XAdvance notification days can�t be greater than or equal to Password expiry days.X"
 * ); put("NoSystemAccess", "XNo System AccessX"); put("LastLogin",
 * "XLast LoginX"); put("d", "XdX"); put("m", "XmX"); put("y", "XYX");
 * put("Ago", "XAGOX"); put("Count-TimeUnit-Ago", "X<count><TimeUnit> AGOX");
 * put("Today", "XTodayX"); put("w", "XWX"); put("ParameterSet",
 * "XParameter SetX"); put("NotificationRule", "XNotification RuleX");
 * put("PermissionTabText", "XPermissions - Keyword Oriented AlignmentX");
 * put("Role_AlreayExists", "XRole Name already exists.X"); put("GC_Chart",
 * "XChartX"); put("GC_CodeGroup", "XCode GroupX"); put("GC_Condition",
 * "XConditionX"); put("GC_ControlLimit", "XControl LimitX"); put("GC_Feature",
 * "XFeatureX"); put("GC_GaugeSetup", "XGauge SetupX");
 * put("GC_GlobalConfiguration", "XGlobal ConfigurationX"); put("GC_License",
 * "XLicenseX"); put("GC_MenuTemplate", "XMenu TemplateX");
 * put("GC_NotificationRule", "XNotification RuleX"); put("GC_ParameterSet",
 * "XParameter SetX"); put("GC_ShiftLog", "XShift LogX");
 * put("GC_StatisticalRule", "XStatistical RuleX");
 * 
 * put("ManageSettingsPageMessage", "xsettingsx"); put("MenuTemplate_Not_Exist",
 * "XXMenu TemplateX doesn't exist.X"); put("URL_CloneRolePageHelpLink",
 * "Roles/CloningRoles.htm"); put("URL_CreateRolePageHelpLink",
 * "Roles/CreatingRoles.htm"); put("URL_EditRolePageHelpLink",
 * "Roles/EditingRoles.htm"); put("URL_RoleLandingPageHelpLink",
 * "Roles/ManagingRoles.htm"); put("Roles_PopUp_AvailableUsers",
 * "XAvailable User(s)X"); put("Roles_PopUp_HelperMessage",
 * "XPlease select appropriate user(s) from left section and click on " + "\"" +
 * ">>" + "\"" + " to assign role to users and move them to Assigned Users.X");
 * put("Roles_PopUp_AssignedUsers", "XAssigned User(s)X");
 * put("Roles_PopUp_AssignRoleToUsers", "XAssign User to RoleX");
 * put("RolesLandingPage_RoleName", "XRole NameX");
 * put("RolesLandingPage_Users", "XUsersX"); put("RolesLandingPage_User",
 * "XUserX"); put("Roles_Permissions_ActionOrientedAlignment",
 * "XPermissions - Action Oriented AlignmentX");
 * 
 * put("Permissions_Authentication", "XAuthenticationX");
 * put("Permissions_ConfigureParameters", "XConfigure ParametersX");
 * put("ColumnName_FirstName", "XFirst NameX"); put("ColumnName_LastName",
 * "XLast NameX"); put("RolesLandingPage_UserPopUp_EntityHeading",
 * "XRole: <RoleName>X"); put("RolesLandingPage_UserPopUp_UsersCount",
 * "x(<count> x"); put("Roles_RemoveRole_ConfirmationMessage1",
 * "XDo you want to remove <RoleName> role?X");
 * put("Roles_RemoveRole_AssociationConfirmationMessage1",
 * "XOn removal of xrolex, following associations will also be removed:X");
 * put("Roles_AssignedToDcMessage", "XAssigned to data collection definitionX");
 * put("Roles_AssignedToCheckListMessage", "XAssigned to checklistX");
 * put("ProcessStateLandingPageTimeZoneLabel",
 * "XAll times are in local 'process' time zoneX");
 * put("Date&Time(Local)_Label", "XDate & TimeX X(Local)X");
 * put("ShowRemovedRecords", "XShow Removed RecordsX");
 * put("Permissions_Manage", "XManageX"); put("License", "XLicenseX");
 * put("MenuTemplate", "XMenu TemplateX"); put("Workstation", "XWorkstationX");
 * put("MenuTemplates_HeaderTitle", "XMenu TemplatesX");
 * put("CreateMenuTemplate_Title", "XCreate Menu TemplateX");
 * put("Create_Condition_PageTitle", "XCreate ConditionX");
 * 
 * put("Create_Gauge_Interface", "XCreate Gauge InterfaceX");
 * 
 * put("Gauge_Initialization", "XGauge InitializationX");
 * put("Measurement_Initialization", "XMeasurement InitializationX");
 * put("Measurement_Start ", "XMeasurement Start X"); put("Measurement_End",
 * "XMeasurement EndX"); put("Measurement_Read", "XMeasurement ReadX");
 * put("Measurement_Post", "XMeasurement PostX"); put("Measurement_Request",
 * "XMeasurement RequestX"); put("Data_Collection_Start",
 * "XData Collection StartX"); put("Data_Collection_End",
 * "XData Collection EndX"); put("RuleTemplateLandingPage_Header_Title",
 * "XRule TemplatesX"); put("ColumnName_Rule_Template_Name",
 * "XRule Template NameX"); put("ColumnName_TimeToTimeRule",
 * "XTime To Time RuleX"); put("ColumnName_BetweenPieceRule",
 * "XBetween Piece RuleX"); put("ColumnName_WithinPieceRule",
 * "XWithin Piece RuleX"); put("Create_RuleTemplate_Page_Title",
 * "XCreate Rule TemplateX");
 * 
 * put("AboveUpperControlLimit", "XAbove Upper Control LimitX");
 * 
 * put("LicenseManagement", "XLicense ManagementX"); put("AddLicenseAssignment",
 * "XAdd License AssignmentX"); put("UsernameAndWorkstation",
 * "XUsername/WorkstationX"); put("RemainingLicenses", "XRemaining licensesX");
 * put("Gauge_Interface", "XGauge InterfacesX");
 * 
 * put("Gauge_Devices", "XGauge DevicesX");
 * 
 * put("Agent", "XAgentX"); put("Gauge_Interface_Name",
 * "XGauge Interface NameX"); put("Data_Port_Configuration",
 * "XData Port ConfigurationX"); put("Port_Initialization",
 * "XPort InitializationX"); put("Port_Termination", "XPort TerminationX");
 * 
 * put("WorkstationLandingPageTitle", "XWorkstationsX");
 * 
 * put("ProcessModels", "XProcess ModelsX"); put("Security", "XSecurityX");
 * put("ShiftLogs", "XShift LogsX"); put("Calculations", "XCalculationsX");
 * put("Licenses", "XLicensesX"); put("Workstations", "XWorkstationsX");
 * put("NotificationRules", "XNotification RulesX"); put("StatisticalRules",
 * "XStatistical RulesX"); put("ProcessingTemplates", "XProcessing TemplatesX");
 * put("GaugeAgentInstaller", "XGauge Agent InstallerX"); put("Global",
 * "XGlobalX"); put("MenuTemplateName", "XMenu Template NameX");
 * put("NotificationRulesLandingPage_HeaderTitle", "XNotification RulesX");
 * put("CreateNotificationRulesPage_PageTitle", "XCreate Notification RuleX");
 * put("NCC_Violation", "XNCC ViolationX"); put("SpecificationViolation",
 * "XSpecification ViolationX"); put("StatisticalViolation",
 * "XStatistical ViolationX"); put("ChecklistViolation",
 * "XChecklist ViolationX"); put("Defective", "XDefectiveX");
 * put("NotificationRules_StatusTabHeading",
 * "XGenerate notifications when <Element Name> areX"); put("Due", "XDueX");
 * put("Late", "XLateX"); put("Missed", "XMissedX"); put("Success",
 * "XSuccessX"); put("AlarmType", "XAlarm TypeX"); put("DataStream",
 * "XXData StreamX(s)X"); put("Recipients", "XRecipientsX");
 * put("NotificationRules_RecipientsTabHeading", "XUserX/XWorkstationX/XRoleX");
 * put("Configuration", "XConfigurationX"); put("RealTimeAnalytics",
 * "XReal Time AnalyticsX"); put("Labels", "XLabelsX"); put("Downloads",
 * "XDownloadsX"); put("NotificationRuleName", "XNotification Rule NameX");
 * 
 * put("Username", "1 - XUsernameX"); put("License_Workstation",
 * "2 - XWorkstationX"); put("License_RemoveEntityPopupMessage",
 * "XAre you sure you want to remove license assigned to <Element Name>?X");
 * put("ModifyLicenseAssignment", "XModify License AssignmentX");
 * 
 * put("Gauge_Formats", "XGauge FormatsX"); put("Create_Gauge_Format",
 * "XCreate Gauge FormatX");
 * 
 * put("Port_Initialization", "XPort InitializationX");
 * 
 * put("Gauge_Format", "XGauge FormatX"); put("LotNumber", "XLot NumberX");
 * put("CurrentStatus", "XCurrent StatusX"); put("StatusTime", "XStatus TimeX");
 * 
 * put("Configure_Workstation_Page_Title", "XConfigure WorkstationsX");
 * put("ColumnName_Workstation_Name", "XWorkstation NameX");
 * put("Workstation_Configurations_Save_Successfully",
 * "XWorkstation configurations saved successfully.X"); put("Quantity",
 * "XQuantityX"); put("Sound", "XSoundX"); put("DefineNotificationPlatform",
 * "XDefine Notification PlatformX"); put("PlaySound",
 * "XPlay a sound when each new notification is received on headerX");
 * put("StatisticalRulesLandingPageTitle", "XStatistical RulesX");
 * put("ColumnName_Priority", "XPriorityX"); put("ColumnName_RuleType",
 * "XRule TypeX"); put("ColumnName_Hits", "XHitsX"); put("ColumnName_Count",
 * "XCountX"); put("ColumnName_Label", "XLabelX");
 * put("TimeToTimeRule_TabTitle", "XTime To TimeX");
 * put("BetweenPieceRule_TabTitle", "XBetween PieceX");
 * put("WithinPieceRule_TabTitle", "XWithin PieceX");
 * put("ProcessingTemplateLandingPage_Header_Title", "XProcessing TemplatesX");
 * put("ColumnName_Processing_Template_Name", "XProcessing Template NameX");
 * put("ColumnName_Feature_Type", "XFeature TypeX");
 * put("ColumnName_Normalization", "XNormalizationX");
 * put("ColumnName_Control_Limit_Confidence_Interval",
 * "XControl Limit Confidence IntervalX"); put("ColumnName_Processing_Option",
 * "XProcessing OptionX"); put("ColumnName_Initialize_on_Part_Change",
 * "XInitialize on Part ChangeX"); put("priority", "XPriorityX");
 * put("ruleType", "XRule TypeX"); put("hits", "XHitsX"); put("count",
 * "XCountX"); put("label", "XLabelX"); put("enabled", "XEnabledX");
 * 
 * put("Create_ProcessingTemplate_Page_Title", "XCreate Processing TemplateX");
 * put("Password_Guidelines_ChangePassword_ManageSettings", "XPassword RulesX" +
 * "\n" + "XMinimum Password Length (characters): 8X" + "\n" +
 * "XPassword must contain the following:X" + "\n" +
 * "XAt least one numeric characterX" + "\n" +
 * "XAt least one upper and lower case characterX" + "\n" +
 * "XAt least one of the following special charactersX [ ] ? / < > ~ # ` ! @ _ - $ % ^ & * ( ) + = { } | : \" ; ' ,"
 * + "\n" + "XSelected password cannot be reused before 365 daysX");
 * 
 * put("URL_WorkStationLandingPageHelpLink",
 * "Workstations/ManagingWorkstations.htm"); put("Workstation_AlreayExists",
 * "XWorkstation Name already exists.X"); put("Label_Already_Exists",
 * "XLabel already exists.X"); put("CountGreaterThanHits", "XCount>=HitsX");
 * put("HitsLessThanCount", "XHits<=CountX");
 * put("Statistical_Rule_Delete_Message",
 * "XDo you want to remove <Element Name>?" + "\n" + "\n" +
 * "On removal of statistical rule, all rule templates will be impacted.X");
 * put("HelperText_Date", "M/d/yyyy h:mm:ss tt");
 * put("CombinationAlreadyExists", "XThis combination already exists.X");
 * put("WorkStation_Header_AccessLevel_PopUp", "XView Access LevelX");
 * put("Workstation_AccessLevelCount_Title",
 * "x(<Element Name> xaccess levelx exists.)x");
 * put("Menu_Template_Name_already_exists",
 * "XMenu Template Name already exists.X");
 * 
 * put(
 * "Workstation_errorMsg_WorkStationNotAutothorizedAndUserNotAbleToAuthorize" ,
 * "XYou don't have permission to authenticate the workstation. Please contact system administrator.X"
 * ); put("GC_Workstation", "XWorkstationX"); put("View_Workstation_Page_Title",
 * "XView WorkstationsX");
 * 
 * put("Menu_Template_Name_already_exists.",
 * "XMenu Template Name already exists.X");
 * put("WorkstationSavedSuccessfullyMessage",
 * "X<Element Name> saved successfully.X");
 * put("WorkStation_Header_Checklist_PopUp", "XView ChecklistX");
 * put("Workstation_ChecklistCount_Title",
 * "x(<Element Name> xchecklistx exists.)x"); put("viewPopUpTitleWorkstation",
 * "XWorkstation : <Element Name>X"); put("Workstation_DCCount_Title",
 * "x(<Element Name> xdata collectionx exists.)x");
 * put("WorkStation_Header_NotificationRule_PopUp", "XView Notification RuleX");
 * put("Workstation_NotificationRuleCount_Title",
 * "x(<Element Name> xnotification rulex exists.)x");
 * put("Column_Assigned_License", "XAssigned LicenseX");
 * put("Column_Last_Authenticated_By", "XLast Authenticated byX");
 * put("View_Role", "XView RoleX"); put("View_User", "XView UserX");
 * put("Menu_Template", "XMenu TemplateX"); put("MenuTemplateViewPopUpHeading",
 * "XMenu TemplateX: <MenuTemplateName> x(<Count> <Module> exists.)x");
 * put("Search", "XSearchX"); put("StatisticalRule_HitsGreaterThanOne_Message",
 * "XHits>1X"); put("URL_StatisticalPageHelpLink",
 * "StatisticalRules/ManagingStatisticalRules.htm");
 * put("URL_MenuTemplatelandingPage_HelpLink",
 * "MenuTemplates/ManagingMenuTemplates.htm");
 * put("URL_CreateMenuTemplatePage_HelpLink",
 * "MenuTemplates/CreatingMenuTemplates.htm");
 * put("URL_EditMenuTemplatePage_HelpLink",
 * "MenuTemplates/EditingMenuTemplates.htm"); put("Qty", "XQty:X"); put("Lot",
 * "XLotX"); put("MenuTemplate_DeleteConfirmaitonMessage_WithAssociation",
 * "XDo you want " + "to remove <Element Name>?X" + "\n" + "\n" +
 * "XOn removal of menu template, following associations will also be removed:X"
 * ); put("AccordionItem_AssignedRoleMessage", "XAssigned to RoleX");
 * put("Process_ProcessWithSameNameMsg",
 * "XShort name already exists. Another record will be created with same name.X"
 * ); put("Shifts_ProcessDeletetionMsg_IfOnlyOneProcessAssigned",
 * "XShift(s) having only one removed process schedule will also be removed. Impacted shiftX"
 * ); put("URL_LotLandingPageHelpLink", "Lots/ManagingLots.htm");
 * put("URL_CreateLotPageHelpLink", "Lots/CreatingLots.htm");
 * put("URL_EditLotPageHelpLink", "Lots/EditingLots.htm");
 * put("Lot_LotAlreadyExistAsRemoved",
 * "XLot Number already exists for this part as removed record.X");
 * put("CurrentProcess", "XCurrent ProcessX"); put("Lot_LotAlreadyExistForPart",
 * "XLot Number already exists for this part.X");
 * put("NotificationRuleNameAlreadyExists",
 * "XNotification Rule Name already exists.X"); put("OnHold", "XOn HoldX");
 * put("TestingComplete", "XTesting - CompleteX");
 * put("ParameterSet_Time_InfoIconMessage",
 * "XCURRENT: Data up to end of current time period." + "\n" +
 * "EARLIER: Data up to end of previous time period." + "\n" +
 * "LATEST: Data up to the second.X");
 * 
 * put("StartDate&Time", "XStart Date/TimeX"); put("EndDate&Time",
 * "XEnd Date/TimeX"); put("DataCollectionS", "XXData CollectionX(s)X");
 * put("CheckListS", "XXChecklistX(s)X");
 * put("SelectCheckLlistsEntity_Header_Title", "XSelect XChecklistXX");
 * put("SelectDataCollectionEntity_Header_Title",
 * "XSelect XData CollectionsXX"); put("Above_T2_upper", "XAbove T2 upperX");
 * put("Below_T2_lower", "XBelow T2 lowerX"); put("Above_MAV_upper",
 * "XAbove MAV upperX"); put("Below_MAV_lower", "XBelow MAV lowerX");
 * put("Above_USL", "XAbove USLX"); put("Below_LSL", "XBelow LSLX");
 * put("Above_URL", "XAbove URLX"); put("Below_LRL", "XBelow LRLX");
 * put("Above_UWL", "XAbove UWLX"); put("Below_LWL", "XBelow LWLX");
 * put("Above_UWP", "XAbove UWPX"); put("Below_LWP", "XBelow LWPX");
 * put("Above_USG", "XAbove USGX"); put("Below_LSG", "XBelow LSGX");
 * put("Notify_When", "XNotify WhenX"); put("Upper", "XUpperX"); put("Lower",
 * "XLowerX"); put("Below_Lower_Control_Limit", "XBelow Lower Control LimitX");
 * put("In_or_Above_Upper_Zone_A", "XIn or Above Upper Zone AX");
 * put("In_or_Below_Lower_Zone_A", "XIn or Below Lower Zone AX");
 * put("In or_Above_Upper_Zone_B", "XIn or Above Upper Zone BX");
 * put("In_or_Below_Lower_Zone_B", "XIn or Below Lower Zone BX");
 * put("Run_Above_Centerline", "XRun Above CenterlineX");
 * put("Run_Below_Centerline", "XRun Below CenterlineX"); put("Others",
 * "XOthersX"); put("Run_within_Zone_C", "XRun within Zone CX");
 * put("Avoidance_of_Zone_C", "XAvoidance of Zone CX");
 * put("Consecutive_Points_Rising", "XConsecutive Points RisingX");
 * put("Consecutive_Points_Falling", "XConsecutive Points FallingX");
 * put("Oscillating_Up_and_Down", "XOscillating Up and DownX");
 * put("No_Variation_in_Values", "XNo Variation in ValuesX");
 * put("DC_Assigned_Users", "XDC Assigned UsersX");
 * put("Error_AtleastOneSelect_NotificationRule",
 * "XSelect at least one <element> to generate notifications.X");
 * put("Error_ExistingSelectLost_NotificationRule",
 * "XExisting selections will be lost. Are you sure you want to switch category?X"
 * ); put("Lot_ClosedAccepted", "XClosed - AcceptedX");
 * put("Lot_ClosedRejected", "XClosed - RejectedX");
 * put("Notification_Rule_Any_Data_Collection", "XAny XData CollectionXX");
 * put("Lots_Association_Message",
 * "XOn removal of lot, following associations will also be removed:X");
 * put("No_License_Available_Message_For_User",
 * "XYou do not have a valid license to login on this machine, please contact your system administrator.X"
 * ); put("NotificationRule_NoDcMessage", "XAny XData CollectionXX");
 * put("AnyCheckList", "XAny XChecklistXX"); put("RecipientDoesNotExist",
 * "XXRecipientX doesn't exist.X");
 * put("WorkstationLicenseAssociatedConfirmationMessage",
 * "XWorkstation license is associated with it. Do you still want to authenticate this workstation?X"
 * ); put("No_License_Available_Message_For_Machine",
 * "XThere is no license available to authenticate this machine, please contact your system administrator.X"
 * ); put("Username/Workstation_doesn't_exist",
 * "XXUsername/WorkstationX doesn't exist.X"); put("License_already_exists.",
 * "XLicense already exists.X");
 * 
 * put("You_have_been_logged_out_from_this_session.",
 * "XYou have been logged out from this session.X");
 * 
 * put("NotInListMessage", "XNot In ListX");
 * 
 * put("Change", "XChangeX"); put("URL_NotificationLandingPageHelpLink",
 * "NotificationRules/ManagingNotificationRules.htm");
 * put("URL_CreateNotificationPageHelpLink",
 * "NotificationRules/CreatingNotificationRules.htm");
 * put("URL_EditNotificationPageHelpLink",
 * "NotificationRules/EditingNotificationRules.htm"); put("TrackCountExceeded",
 * "XTrack count exceededX"); put("NotificationRules_ChecklistTabHeading",
 * "XGenerate Notifications forX");
 * put("NotificationRules_Checklist_Pageheader",
 * "XSelect XChecklistX (to XincludeX)X");
 * put("NotificationRules_DataCollection_Pageheader",
 * "XSelect XData CollectionsX (to XincludeX)X");
 * put("Workstation_doesn�t_exist", "XWorkstation doesn�t exist.X");
 * put("URL_LicenseLandingPageHelpLink", "Licenses/AssigningLicenses.htm");
 * put("EntityCountMessage", "X<count> <entity> SelectedX");
 * 
 * put("NotificationRule_UpdateSuccessMessage",
 * "XNotification rules updated successfully.X");
 * put("NotificationRule_AlreadyExistAsRemoved",
 * "XNotification Rule Name already exists as removed record.X");
 * 
 * put("ViewRequirements", "XView RequirementsX"); put("CreateRequirements",
 * "XCreate RequirementX"); put("MoreRequirements", "XMore Requirement(s)X");
 * put("Create_Calculation", "XCreate CalculationX"); put("Calculation_Name",
 * "XCalculation NameX"); put("Save_as_Feature", "XSave as FeatureX");
 * put("Initiators", "XInitiatorsX"); put("Add_Below", "XAdd BelowX");
 * put("Add_Above", "XAdd AboveX"); put("Calculation", "XCalculationX");
 * put("Calculation_RemoveStepMessage",
 * "XRemoving Step <StepNumber> will create error in following steps. Do you want to continue?X"
 * ); put("Calculation_StepNumber", "XStep <StepNumber>X");
 * put("Calculation_RemovePopUptTitle", "XRemove Step <StepNumber>X");
 * 
 * put("RuleTemplateNameAlreadyExistsErrorMsg",
 * "XRule Template Name already exists.X");
 * put("RuleTemplateNameAlreadyExistsAsRemoveRecordErrorMsg",
 * "XRule Template Name already exists as removed record.X");
 * put("URL_RuleTemplateLandingPageHelpLink",
 * "RuleTemplates/ManagingRuleTemplates.htm");
 * put("URL_CreateRuleTemplatePageHelpLink",
 * "RuleTemplates/CreatingRuleTemplates.htm");
 * put("URL_EditRuleTemplatePageHelpLink",
 * "RuleTemplates/EditingRuleTemplates.htm");
 * put("RuleTemplate_ViewPopUp_SubHeading", "XRule TemplateX: <Element Name>");
 * put("RuleTemplate_ViewPopUp_SubHeadingWithOneCount",
 * "x(<Count> xrulex exists.)x");
 * put("RuleTemplate_ViewPopUp_SubHeadingWithMoreThanOneCount",
 * "x(<Count> xrulesx exist.)x"); put("RuleTemplate_TimeToTimeViewPopUpHeader",
 * "XView Time To Time RuleX"); put("RuleTemplate_BetweenPieceViewPopUpHeader",
 * "XView Between Piece RuleX"); put("RuleTemplate_WithinPieceViewPopUpHeader",
 * "XView Within Piece RuleX");
 * 
 * put("Tag_Group_Name_already exists_as_removed_record",
 * "XXTag Group NameX already exists as removed record.X");
 * put("Tag_already exists_as_removed_record",
 * "XTag already exists as removed record.X");
 * 
 * put("CodeGroupRemoval_Success",
 * "XCode Group <Element Name> removed successfully.X");
 * put("CodeGroupRemoval_ConfirmationWithoutAssociation",
 * "XDo you want to remove <Element Name> Code Group?X" + "\n" + "\n" +
 * "XOn removal of code group, following associations will also be removed:X");
 * put("Condition_Name", "XCondition NameX");
 * put("SettingSaveSuccessfullyMessage",
 * "X<Element Name> xsettingsx saved successfully.X");
 * put("Condtions_DeleteConfirmaitonMessage_WithAssociation", "XDo you want " +
 * "to remove <Element Name>?X" + "\n" + "\n" +
 * "XOn removal of condition, following associations will also be removed:X");
 * 
 * put("AssignedToDcRequirementMessage", "XAssigned to DC requirementsX");
 * put("Day_of_week", "XDay of weekX");
 * put("Gauge_Interface_Connection_saved_successfully.",
 * "XGauge Interface Connection saved successfully.X"); put("TCP/IP",
 * "XTCP/IPX"); put("Com_Port", "XCom PortX"); put("Gauge_Format_Name",
 * "XGauge Format NameX");
 * 
 * put("RuleTemplate_Association_Message",
 * "XOn removal of rule template, following associations will also be removed:X"
 * ); put("Associated_ControlLimit_ConfirmationMessage",
 * "XAssociated control limit records will be impactedX");
 * 
 * put("ProcessingTemplateNameAlreadyExistsAsRemoveRecordErrorMsg",
 * "XProcessing Template Name already exists as removed record.X");
 * 
 * put("URL_CreateProcessPageHelpLink", "Processes/CreatingProcesses.htm");
 * put("message_RestoreConfirmation_WithoutAssociation",
 * "XDo you want to restore <Element Name>?" + "\n\n" +
 * "On restoration of process, impacted associations will also be restored.X");
 * put("RestoredSuccessfullyMessage",
 * "X<Element Name> restored successfully.X");
 * 
 * put("RestorePopUpTitle", "XRestore <Element Name>X");
 * put("Create_Gauge_Device", "XCreate Gauge DeviceX"); put("Gauge_Device_Name",
 * "XGauge Device NameX");
 * put("DeleteConfirmaitonMessageWithAssociationsForGaugeInterface",
 * "XDo you want " + "to remove <Element Name>?X" + "\n" + "\n" +
 * "XOn removal of xgauge interfacex, following associations will also be impacted:X"
 * );
 * 
 * put("AccordionItem_AssignedGaugeFormat", "XRemoved XGauge FormatXX");
 * 
 * put("AccordionItem_AssignedGaugeDevice", "XRemoved XGauge DeviceXX");
 * 
 * put("ProcessingOption_ShewhartCUSUM", "XShewhart CUSUMX");
 * 
 * put("ProcessingOption_CoefficientOfVariation",
 * "XCoefficient of Variation (%CV)X");
 * 
 * put("Modifying_a_gauge_interface_connection_will_affect_1_gauge_device.",
 * "XModifying a gauge interface connection will affect 1 gauge device.X");
 * put("Modifying_a_gauge_interface_connection_will_affect_N_gauge_devices.",
 * "XModifying a gauge interface connection will affect <count> gauge devices.X"
 * );
 * 
 * put("Part - Feature combination already exists as removed record",
 * "XPart - Feature combination already exists as removed record.X");
 * 
 * put("SelectParentProcess", "XSelect Parent ProcessX");
 * put("Msg_ParentProcessWithSameChildName",
 * "XParent process already contains a child process with same short name.X");
 * put("Msg_ProcesslAlreadyContainsChildAsRemovedRecord",
 * "XThis process already contains a child process as removed record with same short name.X"
 * ); put("Msg_ResponseAlreadyExistAsRemovedRecord",
 * "XXResponse GroupX already exists as removed record.X");
 * put("Msg_ChoiceAlreadyExistAsRemovedRecord",
 * "XChoice already exists as removed record.X");
 * 
 * put("Restore_Confirmation_Message_For_PartRevision",
 * "XDo you want to restore <Element Name>?" + "\n" + "\n" +
 * "On restoration of part revision, impacted associations will also be restored.X"
 * );
 * 
 * put("message_SpecLimitRestoreConfirmation_WithoutAssociation",
 * "XDo you want to restore manufacturing limit record for <Element Name> combination?"
 * + "\n\n" +
 * "On restoration of manufacturing limit, impacted associations will also be restored.X"
 * );
 * 
 * put("message_RestoreConfirmation_WithoutAssociation_Feature",
 * "XDo you want to restore <Element Name>?" + "\n\n" +
 * "On restoration of feature, impacted associations will also be restored.X");
 * 
 * put("message_RestoreConfirmation_WithoutAssociation_Process",
 * "XDo you want to restore <Element Name>?" + "\n\n" +
 * "On restoration of process, impacted associations will also be restored.X");
 * 
 * put("Msg_ChecklistAlreadyExistAsRemovedRecord",
 * "XChecklist already exists as removed record.X");
 * put("Msg_LabelAlreadyExistAsRemovedRecord",
 * "XLabel already exists as removed record.X");
 * 
 * put("ProcessingOption_Exponentially_Weighted_Moving_Average",
 * "XExponentially Weighted Moving Average (EWMA)X");
 * put("ProcessingOption_EconomicControlLimit",
 * "XEconomic Control Limit (ECL)X"); put("ProcessingOption_TabularCUSUM",
 * "XTabular CUSUMX");
 * 
 * put("ShortName_AlreadyExistAsRemoved",
 * "XShort name already exists as removed record.X");
 * 
 * put("NormalizationOption_Nominal", "XNominalX");
 * put("NormalizationOption_Target", "XTargetX");
 * put("NormalizationOption_ProcessMean", "XProcess MeanX");
 * put("NormalizationOption_Standardized", "XStandardizedX");
 * put("AtLeastOneMeanShiftDetectionLimit_ErrorMessage",
 * "XAt least one Mean Shift Detection Limit is required.X");
 * put("ProcessingTemplateNameAlreadyExistsErrorMsg",
 * "XProcessing Template Name already exists.X"); put("FeatureType_Attribute",
 * "XAttributeX"); put("AccessLevelPopUp", "XAccess Level(s)X");
 * put("ToolTip_ControlLimitConfidenceInterval_Probability",
 * "XMinimum ValueX = 90%" + "\n" + "XMaximum ValueX = 99.999%");
 * put("ToolTip_WaitingFactor", "XMinimum Value = 0" + "\n" +
 * "Maximum Value = 1X"); put("ToolTip_FastInitialResponse",
 * "XMinimum Value = 0 %" + "\n" + "Maximum Value = 99 %X");
 * put("URL_ProcessingTemplateLandingPageHelpLink",
 * "ProcessingTemplates/ManagingProcessingTemplates.htm");
 * put("errorMessage_MSZLGreaterThanMSZU",
 * "Xmszl value should always be less than or equal to mszu value.X");
 * put("errorMessage_MSZULessThanMSZL",
 * "Xmszu value should always be greater than or equal to mszl value.X");
 * put("ProcessingTemplate_Association_Message",
 * "XOn removal of processing template, following associations will also be removed:X"
 * ); put("URL_CalculationsLandingPageHelpLink",
 * "Calculations/ManagingCalculations.htm");
 * put("URL_CreateCalculationPageHelpLink",
 * "Calculations/CreatingCalculations.htm");
 * put("URL_EditCalculationPageHelpLink",
 * "Calculations/EditingCalculations.htm"); put("SelectAnOutputOption",
 * "XSelect an output optionX"); put("ConfigureOutput", "XConfigure OutputX");
 * put("Collect_Data", "XCollect DataX"); put("ChecklistRequirement_PageTitle",
 * "XDefine XChecklistX RequirementsX");
 * put("URL_GlobalConfigurationPageHelpLink",
 * "GlobalConfiguration/ConfiguringGlobalSettings.htm");
 * put("Workstation_doesn't_exist", "XWorkstation doesn�t exist.X");
 * 
 * put("ErrorMessage_InputAlreadyExistsInEquation",
 * "XInput already exists in the Equation.X");
 * put("View_CollectionAids_Page_Title", "XView Part Feature DetailsX");
 * put("Static_NoEntitySelected", "XAny X<entity>XX");
 * put("ConfirmationMessage_Static_StaticToDynamic",
 * "XExisting X<entity>X selections will be lost. Are you sure you want to switch selection mode to X<StaticOrDynamic>X?X"
 * );
 * 
 * put("Static_xpathProcess", "XSearch Process NameX"); put("Static_xpathPart",
 * "XSearch Part NameX"); put("Static_xpathFeature", "XSearch Feature NameX");
 * put("Static_xpathCheckList", "XSearch Checklist NameX");
 * put("Static_xpathDC", "XSearch Data Collection NameX");
 * put("FeatureUpdate_ConfirmationMessageHeader",
 * "XOn updating feature type, the following associations will also be impacted.X"
 * ); put("AccordionItem_AssignedControlLimit_Feature",
 * "XAssigned to control limitX");
 * put("AccordionItem_AssignedPartFeature_Feature",
 * "XAssigned to part feature detailsX"); put("FeatureUpdate_PopUpTitle",
 * "XUpdate feature typeX"); put("WarningLimitToolTip",
 * "XRange should be between 1% to 99%X"); put("ReasonableLimitToolTip",
 * "XRange should be between 1.01 to 50X"); put("StaticEntityPage_PageTitle",
 * "XSelect X<EntityName>"); put("DynamicEntity_PageTitle",
 * "XSelect X<EntityName>X (to X<Condition>X)X"); put("ValueAlreadySelected",
 * "XValue already selected.X"); put("Entity_DoesNot_Exist",
 * "XX<EntityName>X doesn't exist.X"); put("NoTagAvailableForSelection",
 * "XNo tag available for selectionX"); put("CountSelectedMessage",
 * "X<count> X<EntityName>X SelectedX"); put("label_EntitySelected",
 * "X<EntityName> Selected:X"); put("dynamicCriteria_DefaultMessage",
 * "XClick/Tap X" + "\n" + "X<CriteriaName>X" + "\n" + "X or X" + "\n" +
 * "XTag GroupX" + "\n" + "X to add selection criteria.X");
 * 
 * put("CalculationNameAlreadyExists", "XCalculation name already exists.X");
 * put("AddInput", "XAdd InputX"); put("Alert", "XAlertX");
 * put("UsedEntityCantBeChangedInEquationMessage",
 * "X<Entity Name> can�t be changed as it is used in the equation.X");
 * put("UsedEntityCantBeDeletedInEquationMessage",
 * "X<Entity Name> can�t be removed as it is used in the equation.X");
 * put("viewPopUpTitleCalculation", "XCalculation: <Entity Name>X");
 * put("lbl_ViewProcess", "XView ProcessX");
 * put("ViewProcessModalBoxMoreThanOneCountMessage",
 * "x(<Count> xprocessesx exist.)x");
 * put("ViewPartModalBoxMoreThanOneCountMessage", "x(<Count> xpartsx exist.)x");
 * put("lbl_ViewPart", "XView PartX"); put("CalculationViewPopUpModalBoxTitle",
 * "XCalculation: <Entity Name>X");
 * put("CalculationNameAlreadyExistsAsRemovedRecord",
 * "XCalculation name already exists as removed record.X");
 * put("SAYT_NoRecordFoundMessage", "XNO RECORD FOUNDX");
 * put("ErrorMessage_FeatureDoesntExists", "XFeature doesn't exist.X");
 * put("ErrorMessage_FeatureUsedAsOutput", "XFeature used as an OutputX");
 * put("ColumnName_Output", "XOutputX"); put("Initiators_Header_Title",
 * "XInitiatorsX"); put("lbl_ViewInitiator", "XView InitiatorX");
 * put("ViewInitiatorModalBoxMoreThanOneCountMessage",
 * "x(<Count> xinitiatorsx exist.)x");
 * put("ViewFeatureModalBoxMoreThanOneCountMessage",
 * "x(<Count> xfeaturesx exist.)x"); put("Step1", "XSTEP 1X"); put("Step2",
 * "XSTEP 2X"); put("errorMessage_AtLeastOneStepIsRequired",
 * "XAt least one step is required.X");
 * put("errorMessage_AllInitiatorsMustBeDefined",
 * "XAll initiators must be defined.X");
 * put("errorMessage_AtLeastOneOutputMustBeDefined",
 * "XAt least one saved output must be defined.X");
 * put("toolTipOnlyOneOperatorIsAllowed", "XOnly one operator is allowed.X");
 * put("CalculationName_AlreayExists", "XCalculation name already exists.X");
 * put("ErrorMessage_NestedFunctionNotAllowedWithMoreButton",
 * "XNested functions will not be allowed.X");
 * put("ErrorMessage_NestedFunctionNotAllowed",
 * "XNested functions will not be allowed.X"); put("StepCount",
 * "XSTEP <count>X");
 * put("errorMessage_AtLeastOneStepIsRequiredWithOutMoreButton",
 * "XAt least one step is required.X"); put("ErrorMessage_OutputMustBeDefined",
 * "XOutput must be defined.X"); put("Long Name", "XLong NameX");
 * put("AccordionItem_AssignedChecklist",
 * "XChecklist(s) having only one removed feature assignment will also be removed. Impacted checklistX"
 * ); put("URL_FeatureLandingPageHelpLink", "Features/ManagingFeatures.htm");
 * put("URL_CreateFeaturePageHelpLink", "Features/CreatingFeatures.htm");
 * put("URL_EditFeaturePageHelpLink", "Features/EditingFeatures.htm");
 * put("ErrorMessage_ThisItemWasRemoved", "XThis item was removed.X");
 * put("FeatureAlreadyDefinedInOtherCalculation",
 * "<Entity Name> Xis also defined inX Xother CalculationsX.");
 * put("ErrorMessage_InvalidEntry", "XInvalid entryX");
 * put("ErrorMessage_OutputAlreadyDefinedInStep",
 * "XOutput already defined in Step <Count>.X");
 * put("toolTipParameterMustBeInputOrSavedFeature",
 * "XParameter must be an Input or a saved feature.X"); put("Backspace",
 * "XBackspaceX"); put("FeatureAlreadyDefinedInOtherCalculationInStep",
 * "<Entity Name> Xis also defined inX <Entity Name1> - XStep <Step Count>X.");
 * put("PopUp_RemoveStepTitle", "XRemove Step <Count>X");
 * put("PopUp_RemoveStepMessage", "XDo you want to remove step <Count>X");
 * put("ErrorMessage_FeatureAlsoDefinedInStep",
 * "X<Entity Name> is also defined in step <Count>.X");
 * put("productionAssignments", "XProduction AssignmentsX"); put("English - US",
 * "XEnglish - USX"); put("English - UK", "XEnglish - UKX");
 * put("German - Germany", "XGerman - GermanyX"); put("Spanish - Mexico",
 * "XSpanish - MexicoX"); put("Vietnamese - Vietnam", "XVietnamese - VietnamX");
 * put("Header_Purge", "XPurgeX"); put("Purge_HelperMessage",
 * "XATTENTIONXX: Purging will permanently delete all removed items.X");
 * put("Header_PurgeAllItems", "XPurge All ItemsX");
 * put("msg_PurgePopUp_ConfirmationMessage",
 * "XDo you want to permanently delete all removed item(s)?X" + "\n" + "\n" +
 * "XOn purging, following item(s) will be deleted:X");
 * 
 * put("Msg_NoRemovedItemAvailable",
 * "XNo removed item is available for purging.X");
 * put("GC_DCType_AlreadyExistAsRemovedMessage",
 * "XData Collection Type already exists as removed record.X");
 * put("UnitOfMeasurementAlreadyExistsAsRemovedRecord",
 * "XUnit of Measurement already exists as removed record.X");
 * put("AbbreviationAlreadyExistsAsRemovedRecord",
 * "XAbbreviation already exists as removed record.X"); put("msg_PurgeRunning",
 * "XPurge is running in the background. It may take some time to complete.X" +
 * "\n" + "XFeel free to navigate.X"); put("msg_CantRestoreMessage",
 * "X<EntityName> can�t be restored as it is going to be purged.X");
 * put("msg_PurgeFailed", "XLast purge failed at"); put("msg_PurgeSuccess",
 * "XLast purge successfully completed at"); put("lbl_AllRemovedItems",
 * "XAll Removed ItemsX"); put("lbl_ProcessCollection", "XProcess CollectionX");
 * put("lbl_Appearance", "XAppearanceX");
 * put("URL_CodeGroupLandingPageHelpLink", "CodeGroups/ManagingCodeGroups.htm");
 * put("URL_EditCodeGroupLandingPageHelpLink",
 * "CodeGroups/EditingCodeGroups.htm");
 * put("URL_CreateCodeGroupLandingPageHelpLink",
 * "CodeGroups/CreatingCodeGroups.htm"); put("CodeGrp_AlreadyExistAsRemoved",
 * "XXCode GroupX already exists as removed record.X");
 * put("CodeName_AlreadyExistAsRemoved",
 * "XCode Name already exists as removed record.X");
 * put("TagGrp_AlreadyAssigned", "XTag Group already assigned.X");
 * put("ErrorMessage_FeatureAlreadySelected", "XFeature already selected.X");
 * put("AccordionItem_AssignedControlLimitMessage",
 * "XAssigned to control limit data streamX");
 * put("AccordionItem_AssignedUserAccessLevelMessage",
 * "XAssigned as the only access level to userX");
 * put("AccordionItem_AssignedWorkstationAccessLevelMessage",
 * "XAssigned as the only access level to workstationX");
 * put("AccordionItem_AssignedGaugeDeviceMessage_Process",
 * "XAssigned as the only process to gauge deviceX");
 * put("AccordionItem_AssignedLotMessage", "XAssigned to lotX");
 * put("AccordionItem_AssignedCalculationMessage", "XAssigned to CalculationX");
 * put("AccordionItem_AssignedProductionAssignmentsWillBeImpacted",
 * "XAssociated production assignments will be impactedX");
 * put("txtPartProcessHeading", "XProcess & PartX");
 * put("Label_LimitParameterSet",
 * "XLimit parameter set to return XXLatestX\nXrecordsX");
 * put("lblFeatureInCapitals", "XFEATUREX"); put("lblTestCaluclationPopUpTitle",
 * "XTest CalculationX"); put("lblValues", "XValuesX");
 * put("txtMessageIsALsoDefinedInOtherCalculations",
 * "Xis also defined in other calculations:X"); put("Step1_InCamelLetters",
 * "XStep 1X"); put("Data Collection - Features",
 * "XData Collection - FeaturesX");
 * put("LandingPage_ContextMenu_LanguageIconText", "XLanguage LabelX");
 * put("Lbl_AssignedChecklist", "XAssigned to checklistX");
 * put("Lbl_ParentProcessUpdateConfirmationMessage",
 * "XOn changing the parent process, the following associations will also be removed:X"
 * ); put("Associated control limit records will be impacted",
 * "XAssociated control limit records will be impactedX");
 * put("lblWorkDashboard", "XWork DashboardX");
 * put("lblError_TestCalculationPopUp", "XError!X"); put("Static_xpathShift",
 * "XSearch Shift NameX"); put("ChecklistInCaps", "XCHECKLISTX");
 * put("lblEditSubGroup", "XEdit SubgroupX"); put("lblDataTable",
 * "XData TableX"); put("columnName_TimeZone", "XTime ZoneX");
 * put("msg_ParentAndChildCantExistWithSameName",
 * "XParent and child process can't exist with same short name.X");
 * put("msg_CantBeAssignedAsParentProcess",
 * "X<EntityName> can't be assigned as a parent process.X");
 * put("msg_ParentProcesslAlreadyContainsChildAsRemovedRecord",
 * "XParent process already contains a child process with same short name as removed record.X"
 * ); put("msg_ProcessCantBeRestoredUntilParentIsRestored",
 * "X<ChildProcessName> process can't be restored until the parent process <ParentProcessName> is restored.X"
 * ); put("user", "xuserx"); put("MenuTemplateName_AlreadyExistAsRemoved",
 * "XMenu Template Name already exists as removed record.X");
 * put("ParentProcessPopUp_CompanyDivisionCanNotSelect_Msg",
 * "XCompany and Division levels cannot be selected because data exists.X");
 * put("ResponseGroupAlreadyExists", "XResponse Group already exists.X");
 * put("ChoiceAlreadyExists", "XChoice already exists.X");
 * put("AccessCodeIsIncorrect", "XAccess code is incorrect.X");
 * put("AuthenticateWorkstation", "XAuthenticate WorkstationX");
 * put("PleaseEnterTheAccessCodeSentToYourEmailId",
 * "XPlease enter the access code sent to your email id.X");
 * put("Permissions_Assign", "XAssignX");
 * put("DC_Config_Common_NotificationMessage",
 * "XHighlighted Feature/Part Family/Operation notifies that no gauge device or item name/part/process is associated with it respectively.X"
 * ); put("ShowingResult_Lbl", "XShowing <count> XResultsXX");
 * 
 * put("LanguagelabelsSavedSuccesssfullyMessage",
 * "XLanguage labels of <languageLabel> saved successfully.X");
 * put("Lbl_SequenceRule", "XSequence RuleX");
 * put("WorkStation_RemoteAuthentication", "XRemote AuthenticationX");
 * put("WorkStation_LocalAuthentication", "XLocal AuthenticationX");
 * put("Lbl_Notification", "XNotificationX"); put("Lbl_PromptForSampleSize",
 * "XPrompt forX XSample SizeX"); put("Lbl_SampleTime", "XSample TimeX");
 * put("Lbl_RequiredInformation", "XRequired InformationX");
 * put("Lbl_Application", "XApplicationX"); put("Lbl_CodeType", "XCode TypeX");
 * put("Lbl_EventCode", "XEvent CodeX"); put("Lbl_EventCodes", "XEvent CodesX");
 * put("Error_NoAccess_DataEntry",
 * "X<EntityName> does not have access to data entry. Please re-enter.X");
 * put("OneProcessSelectedMessage", "X1 Process selectedX");
 * put("PartRecipe(s)SavedSuccessfullyMessage",
 * "XPart recipe(s) of <OutputPart> saved successfully.X"); put("PartRecipes",
 * "XPart RecipesX"); put("CreatePartRecipe", "XCreate Part RecipeX");
 * put("SelectProcessModel", "XSelect Process ModelX");
 * put("CreatePartRecipePageNoticiationMessage",
 * "XPlease add the part for corresponding part family. At least one input and one output part family must be assigned a part.X"
 * ); put("ProcessModelDoesntExist", "XXProcess ModelX doesn't exist.X");
 * put("EditTotalLicense_NotificationMessage",
 * "XModifying license count immediately impacts your bill.X");
 * put("License_ValidationMinCount", "XMinimum licenses must be <count>.X");
 * put("SelectPart&ItsRevisionToCopyPartRecipe(s)",
 * "XSelect Part & its revision to copy part recipe(s)X");
 * put("AccordionItem_AssignedParameterSet", "XAssigned to parameter setX");
 * put("Production_Assignments", "XProduction AssignmentsX");
 * put("CreateProductionAssignment", "XCreate Production AssignmentX");
 * put("EditProductionAssignment", "XEdit Production AssignmentX");
 * put("ActiveAssignments", "XActive AssignmentsX");
 * put("Assigments(Latest30Days)", "XAssigmentsX (XLatest 30 daysX)");
 * put("OverlappingCombinationWillNotBeAllowed",
 * "XOverlapping with same <part lot combination> combination will not be allowed.X"
 * ); put("ProductionAssignmentSavedSuccessfullyMessage",
 * "XProduction Assignment of <processName> saved successfully.X");
 * put("ProductionAssignmentDeleteConfirmationMessage",
 * "XProduction assignment of <processName> will be permanently deleted. Do you still want to remove?X"
 * ); put("ProductionAssignmentDeletePopUpTitle",
 * "XRemove <processName> Production AssignmentX");
 * put("ProductionAssignmentDeleteSuccessfullyMessage",
 * "XProduction Assignments of <processName> removed successfully.X");
 * put("Lbl_EventCodeName", "XEvent Code NameX"); put("Lbl_ConfigureCodeTypes",
 * "XConfigure Code TypesX"); put("LanguageLabelSavedSuccessfullyForCodeType",
 * "XLanguage labels of Xcode type(s)X saved successfully.X");
 * put("LanguageLabelSavedSuccessfullyForCode",
 * "XLanguage labels of Xevent code(s)X saved successfully.X"); put("Pareto",
 * "XParetoX"); put("Hierarchy", "XHierarchyX"); put("Violation",
 * "XViolationX"); put("CollectedDataType", "XCollected Data TypeX");
 * put("CollectionName", "XCollection NameX"); put("EventCodeType",
 * "XEvent Code TypeX"); put("CollectedData", "XCollected DataX");
 * put("ProcessEvents", "XProcess EventsX"); put("SubgroupData",
 * "XSubgroup DataX"); put("undefined", "XUndefinedX"); put("ParetoChart",
 * "XPareto ChartX"); put("Select View Type", "XSelect View TypeX");
 * put("Graph", "XGraphX"); put("GraphAndReport", "XGraph & ReportX");
 * put("Report", "XReportX"); put("Pieces", "XPiecesX"); put("SIGL", "XSIGLX");
 * put("Total", "XTotalX"); put("SystemAlerts", "XSystem AlertsX");
 * put("ToolTip_ControlLimitConfidenceInterval_Sigma", "XMinimum ValueX = 1.632"
 * + "\n" + "XMaximum ValueX = 4.417"); put("productionAssignment",
 * "XProduction AssignmentX"); put("PartNotExistsWithoutX",
 * "XPart doesn't exist.X"); put("Company", "XCompanyX");
 * put("ProductionAssignmentRemovalConfirmationMessage",
 * "XDo you want to remove production assignment of <PartLotName> combination of <StartEndTime>?X"
 * ); put("ProductionAssignmentRemovalConfirmationMessageWithoutTime",
 * "XDo you want to remove production assignment of <PartLotName>?X");
 * put("ProductionAssignmentRemovalConfirmationMessageBlankRow",
 * "XDo you want to remove XProduction AssignmentX?X");
 * put("ProductionAssignmentStartTimeCantGreaterMessage",
 * "XStart Date & Time can�t be greater than the End Date & Time.X");
 * put("ProductionAssignment_AtLeastOneAssingmentMessage",
 * "XAt least a production assignment needs to be defined.X");
 * put("ProductionAssignment_RemovePopUp_Header",
 * "XRemove Production AssignmentX"); put("ConfigureFilters",
 * "XConfigure FiltersX"); put("PartActiveAssignment",
 * "XPartX (XActive AssignmentsX)"); put("LotActiveAssignment",
 * "XLotX (XActive AssignmentsX)"); put("Percent of Total (Count)",
 * "XPercent of Total (Count)X"); put("Pareto Chart", "XPareto ChartX");
 * put("Chart Summary", "XChart SummaryX"); put("Total Subgroups",
 * "XTotal SubgroupsX"); put("Total Pieces", "XTotal PiecesX");
 * put("Date Range", "XDate RangeX"); put("Part(s)", "XPart(s)X");
 * put("Process(es)", "XProcess(es)X"); put("Feature(s)", "XFeature(s)X");
 * put("Total Events", "XTotal EventsX"); put("Portuguese_Brazil",
 * "XPortuguese - BrazilX"); put("Spanish_Spain", "XSpanish - SpainX");
 * put("Define Levels", "XDefine LevelsX"); put("No data to display. Please",
 * "XNo data to display. PleaseX"); put("select Parameter Set",
 * "Xselect Parameter Set.X"); put("Division", "XDivisionX"); put("Region",
 * "XRegionX"); put("Site", "XSiteX"); put("Department", "XDepartmentX");
 * put("Area", "XAreaX"); put("Process Unit", "XProcess UnitX"); put("Process",
 * "XProcessX"); put("Sub Process", "XSub ProcessX"); put("No data to display",
 * "XNo data to displayX"); put("Please select a chart to view details",
 * "XPlease select a chart to view detailsX"); put("Select Level",
 * "XSelect LevelX"); put("Manual", "XManualX"); put("EnterTag", "XEnter TagX");
 * put("TagValueCharacterLimitMessage",
 * "XText cannot exceed <limit> character(s).X");
 * put("TagValueMaximumValueMessage",
 * "XValue cannot be greater than maximum defined value.X");
 * put("errorMessage_AtLeastOneOutputMustBeDefinedWithoutMoreButton",
 * "XAt least one saved output must be defined.X");
 * 
 * put("Lot_DeleteConfirmation_Message",
 * "XDo you want to remove <Element Name>?X" + "\n" + "\n" +
 * "XOn removal of lot, following associations will also be removed:X");
 * 
 * put("ChangeHistory", "XChange HistoryX"); put("Assign/Unassign",
 * "XAssign/UnassignX"); put("ChangeType", "XChange TypeX"); put("Restore",
 * "XRestoreX"); put("Column_RecordDate", "XRecord DateX"); put("ASCII_LABEL",
 * "XASCIIX"); put("PreviousValue", "XPrevious ValueX"); put("LowerLSL",
 * "XLower (XLSLX)X"); put("UpperUSL", "XUpper (XUSLX)X"); put("Changes",
 * "XChangesX"); put("Collections", "XCollectionsX"); put("LowerToggleState",
 * "XLower (X<limit>X)X XEvents toggle stateX"); put("UpperToggleState",
 * "XUpper (X<limit>X)X XEvents toggle stateX"); put("LowerLimit",
 * "XLower (X<limit>X)X"); put("UpperLimit", "XUpper (X<limit>X)X");
 * put("MAVLSC", "MAVXMethodX - XLabel Stated Content (XLSCX)X"); put("T1T2LSC",
 * "T1T2XMethodX - XLabel Stated Content (XLSCX)X"); put("MAVUnitSameAsSpec",
 * "MAVXMethodX - XSame as Manufacturing Limit UnitsXXcheck-box stateX");
 * put("T1T2UnitSameAsSpec",
 * "T1T2XMethodX - XSame as Manufacturing Limit UnitsXXcheck-box stateX");
 * put("MAVUnit", "MAVXMethodX - XUnitsX"); put("T1T2Unit",
 * "T1T2XMethodX - XUnitsX"); put("MaxGreaterUpper", "XMax % > MAV UpperX");
 * put("MaxLessLower", "XMax % < MAV LowerX"); put("MAVUpperToggleState",
 * "XMAV UpperX XEvents toggle stateX"); put("MAVLowerToggleState",
 * "XMAV LowerX XEvents toggle stateX"); put("MAVUpper", "XMAV UpperX");
 * put("MAVLower", "XMAV LowerX"); put("MAXBetweenT1T2Upper",
 * "XMax % between T1T2 UpperX"); put("MAXBetweenT1T2Lower",
 * "XMax % between T1T2 LowerX"); put("View_Limit_Page_Title", "XView LimitX");
 * put("Default Name", "XDefault NameX");
 * put("Message_RestoreConfirmation_WithoutAssociation_SpecLimit",
 * "XDo you want to restore Manufacturing Limit record for <Element Name> combination?"
 * + "\n\n" +
 * "On restoration of Manufacturing Limit, impacted associations will also be restored.X"
 * );
 * 
 * put("Message_RestoreSuccess_SpecLimit",
 * "XLimit of <Element Name> restored successfully.X");
 * put("Message_SpecAlreadyExistForGivenCombination",
 * "XManufacturing Limit already exists as removed record for <Element Name> combination. Manufacturing Limit needs to be restored first before using it.X"
 * ); put("BulkDeleteSubgroupData", "XBulk Delete Subgroup DataX");
 * put("Prompt", "XPromptX"); put("Prompt (Limited)", "XPrompt (Limited)X");
 * put("No Prompt", "XNo PromptX"); put("DataCollectionTypeCountMessage",
 * "X<count> XData Collection TypeX SelectedX");
 * put("GaugeInterfaceNameAlreadyExists",
 * "XGauge Interface Name already exists.X");
 * put("GaugeInterfaceModifyMessageWhenDeviceIsAssociated",
 * "XModifying a gauge interface will affect all the gauge devices using this gauge interface.X"
 * + "\n" + "\n" + "XDo you still want to continue?X"); put("ViewGaugeDevice",
 * "XView Gauge DeviceX"); put("ViewGaugeDevicePopUpMessageForSingleDevice",
 * "XGauge Interface: <interfaceName>X x(1 xgauge devicex exists.)x");
 * put("ViewGaugeDevicePopUpMessageForMultipleDevices",
 * "XGauge Interface: <interfaceName>X x(<count> xgauge devicesx exist.)x");
 * put("ViewGaugeFormat", "XView Gauge FormatX");
 * put("ViewGaugeFormatPopUpMessageForSingleFormat",
 * "XGauge Interface: <interfaceName>X x(1 xgauge formatx exists.)x");
 * put("ViewGaugeFormatPopUpMessageForMultipleFormat",
 * "XGauge Interface: <interfaceName>X x(<count> xgauge formatsx exist.)x");
 * put("EntityAlreadyExistMessage", "XX<Entity Name>X already exists.X");
 * put("Permissions_Configure", "XConfigureX"); put("ASCIICharacterValues",
 * "XASCII Character ValuesX"); put("DataPurge", "XData PurgeX"); put("Odd",
 * "XOddX"); put("Even", "XEvenX"); put("Space", "XSpaceX"); put("Mark",
 * "XMarkX"); put("XON/XOFF", "XXON/XOFFX"); put("CTS/RTS", "XCTS/RTSX");
 * put("RTS=off/DTR=on", "XRTS=off/DTR=onX"); put("View_Code_Types",
 * "XView Code TypesX"); put("Configure_Code_Types", "XConfigure Code TypesX");
 * 
 * put("AccordionItem_AssignedEventCodes", "XAssigned event codesX");
 * put("RemoveConfirmationMessage_CodeTypeAssociatedWithEventCode",
 * "XCode type <CodeTypeName> can�t be removed as event codes are associated with it.X"
 * ); put("Message_AtleastOneRequired", "XAt least 1 <entity> required.X");
 * put("Entity_AlreadyExistAsRemoved",
 * "X<EntityName> already exists as removed record.X");
 * put("ValidationForGaugeAgentGaugeInterfaceAndComPortCombination",
 * "XCombination of same gauge interface and data port configuration already exists for this agent.X"
 * ); put("SubValidationForGaugeAgentGaugeInterfaceAndComPortCombination",
 * "XSame data port configuration settings are already assigned to another gauge interface for this agent.X"
 * ); put("Less", "XLessX"); put("LevelWithCount", "XLevel <Count>X");
 * put("Analysis", "XAnalysisX"); put("Data Management", "XData ManagementX");
 * 
 * put("BasicInformation", "XBasic InformationX"); put("Advanced",
 * "XAdvancedX"); put("FormatDescription", "XFORMAT DESCRIPTIONX");
 * put("RecordDescription", "XRECORD DESCRIPTIONX");
 * put("MultiFieldOutputSection", "XMULTI FIELD OUTPUT SECTIONX");
 * put("Port_Initialization_String", "XPort Initialization StringX");
 * put("Port_Termination_String", "XPort Termination StringX"); put("Delay(ms)",
 * "XDelay (ms)X"); put("OK", "XOKX");
 * put("GaugeIntefaceConnectionMsgForSingleGaugeDevice",
 * "XGauge Interface ConnectionX: <AgentName> - <InterfaceName> (<ComPortSetting>) x(<count> xgauge devicex exists.)x"
 * ); put("ModifyingAGaugeInterfaceConnectionWillAffect2GaugeDevices",
 * "XModifying a gauge interface connection will affect 2 gauge devices.X");
 * put("RawData", "XRaw DataX"); put("HexData", "XHex DataX");
 * put("SpecialCharacters", "XSpecial CharactersX"); put("CarriageReturn",
 * "XCarriage ReturnX"); put("LineFeed", "XLine FeedX");
 * put("SerialDataMonitor", "XSerial Data MonitorX"); put("Compliance",
 * "XComplianceX"); put("StreamSummary", "XStream SummaryX");
 * put("ControlCharts", "XControl ChartsX"); put("NetContent", "XNet ContentX");
 * put("Within", "XWithinX"); put("Deviation", "XDeviationX");
 * 
 * put("MDC_HelpSectionDefaultMessage",
 * "XMeasure the <FeatureName> of <PartName>.X"); put("MDC_DefectiveCount",
 * "X<count> DefectiveX"); put("MDC_DefectiveViolationHeader",
 * "XDefective: <PartFeatureName>X"); put("MDC_AddLotDetails_SubHeading",
 * "XSelect the lot for <partName> partX"); put("MDC_Piece_Info",
 * "XPiece <PieceNo> of <Total>X"); put("MDC_PieceNumber", "XPiece <PieceNo>X");
 * put("MDC_LotIsUnavailable", "XLot is unavailable for selection.X");
 * put("MDC_TotalCount_SummaryHeader", "X<FeatureName> - SummaryX");
 * put("MDC_TotalCount", "XTotalX : <count>");
 * put("ValidationForGaugeAgentGaugeInterfaceComPortCombinationAndGaugeFormat",
 * "XCombination of same gauge interface (with communication source) and gauge format already exists for this agent.X"
 * ); put("Gauge_Interface_Connection", "XGauge Interface ConnectionX");
 * 
 * put("Gauge_Agent", "XAgentX"); put("Process_Name", "XProcess NameX");
 * put("ProcessView_PopUp_Header",
 * "XGauge DeviceX: <GaugeDeviceName> x(<Count> xprocessx exists.)x");
 * put("ProcessView_PopUp_Header_For_Multiple_Process",
 * "XGauge DeviceX: <GaugeDeviceName> x(<Count> xprocessesx exist.)x");
 * put("Compliance_Values_Heading", "XComplianceX (XValuesX)");
 * put("ComplianceDataCollections_Heading",
 * "XComplianceX (XData CollectionsX)"); put("Received", "XReceivedX");
 * put("DeleteConfirmaitonMessageWhenProcessAssociationWillNotRemove",
 * "XGauge device can�t be removed as it is assigned to one or more other processes. Few process associations of this gauge device will be removed.X"
 * ); put("DeleteConfirmaitonMessageWhenProcessIsNotAssociate",
 * "XGauge device can�t be removed as it is assigned to one or more other processes. Process associations of this gauge device will not be removed.X"
 * ); put("DeleteConfirmaitonMessageWithAssociationswithDC", "XDo you want " +
 * "to remove <Element Name>?X" + "\n" + "\n" +
 * "XOn removal of gauge device, following associations will also be impacted:X"
 * ); put("AccordionItem_AssignedDC", "XImpacted data collectionX");
 * 
 * put("Gauge Initialization String", "XGauge Initialization StringX");
 * put("Measurement Initialization String",
 * "XMeasurement Initialization StringX"); put("Measurement Start String",
 * "XMeasurement Start StringX"); put("Measurement End String",
 * "XMeasurement End StringX"); put("Measurement Read String",
 * "XMeasurement Read StringX"); put("Measurement Post String",
 * "XMeasurement Post StringX"); put("Measurement Request String",
 * "XMeasurement Request StringX"); put("Data Collection Start String",
 * "XData Collection Start StringX"); put("Data Collection End String",
 * "XData Collection End StringX"); put("GaugeFormatNameAlreadyExists",
 * "XGauge Format Name already exists.X"); put("0 - ASCII/Text",
 * "0 - XASCII/TextX"); put("1 - ASCII (16 bit)", "1 - XASCII (16 bit)X");
 * put("2 - Binary (LSByte First)", "2 - XBinary (LSByte First)X");
 * put("3 - Binary (MSByte First)", "3 - XBinary (MSByte First)X");
 * put("ValidationForMultifieldSelectSendBox",
 * "XAt least a numeric type item needs to have send enabled in multi field output section grid.X"
 * ); put("ValidationForMultifieldNumericSelect",
 * "XAt least a numeric type item needs to be defined in multi field output section grid.X"
 * ); put("EntryMethodGDErrorMessage", "XNo <Element Name> availableX");
 * put("ValidationForGaugeDeviceGaugeAgentGaugeInterfaceComPortCombination",
 * "XCombination of same gauge device name and gauge interface connection (with communication source) already exists for this agent.X"
 * ); put("ManufacturingLimitViolation", "XManufacturing Limit ViolationX");
 * put("GaugeMultiFieldValidation",
 * "XItem is improperly configured in multi field output section grid.X");
 * put("EditGaugeFormatConfirmaitonMessageWhenAttachedToGaugeDevice",
 * "XModifying a gauge format will affect all the gauge devices using this gauge format.X"
 * + "\n" + "\n" + "XDo you still want to continue?X");
 * put("ViewGaugeDevicePopUpForGaugeFormat",
 * "XGauge Format: <formatName>X x(1 xgauge devicex exists.)x");
 * put("removeGaugeFormatConfirmaitonMessageWhenAttachedToGaugeDevice",
 * "XDo you want to remove <formatName>?X" + "\n" + "\n" +
 * "XOn removal of xgauge formatx, following associations will also be impacted:X"
 * );
 * 
 * put(
 * "DeleteConfirmaitonMessageWithAssociationsForGaugeInterfaceForNonRemovableGD"
 * , "XXGauge InterfaceX can't be removed " +
 * "as it is assigned to non removable gauge device(s).X");
 * put("AccordionItem_AssignedNonRemovableGaugeFormat",
 * "XGauge Format(s) can�t be removed as it is assigned to non removable Gauge Device(s). Associated Gauge FormatX"
 * ); put("AccordionItem_AssignedNonRemovableGaugeDevice",
 * "XGauge device(s) can�t be removed as it is assigned to one or more other processes. Process associations of the gauge device(s) will not be removed. Associated Gauge DeviceX"
 * );
 * 
 * put("Send", "XSendX");
 * 
 * put("= [Field]", "X= [Field]X"); put("<> [Field]", "X<> [Field]X");
 * put("> [Field]", "X> [Field]X"); put("< [Field]", "X< [Field]X");
 * put(">= [Field]", "X>= [Field]X"); put("<= [Field]", "X<= [Field]X");
 * put("Contains", "XContainsX"); put("ExclusionRule", "XExclusion RulesX");
 * 
 * put("AssociationMessage_RemovedSingleGaugeDevice",
 * "XRemoved XGauge DeviceXX (1)"); put("GaugeFormatTesting_TestText",
 * "XThis section is for gauge format testing and it will only be enabled during gauge device setup.X"
 * ); put("GaugeFormatTesting_TestingArea",
 * "XInitialize Gauge or Initialize Port must be pressed before any changes go into effect.X"
 * ); put("Field# = ", "XFieldX# ="); put("Start Position = ",
 * "XStart PositionX ="); put("Length = ", "XLengthX =");
 * put("URL_CreateProcessingTemplatePageHelpLink",
 * "ProcessingTemplates/CreatingProcessingTemplates.htm");
 * put("URL_EditProcessingTemplatePageHelpLink",
 * "ProcessingTemplates/EditingProcessingTemplates.htm");
 * 
 * put("WorkFlow_Header_Title", "XWorkflowsX"); put("CreateWorkFlow_Page_Title",
 * "XCreate WorkflowX"); put("Lbl_EventCategory", "XEvent CategoryX");
 * put("Msg_WorkFlow_CodeTypehaveAtleastOneEventCode",
 * "XAll required/optional event code types should have at least one event code assigned to it.X"
 * ); put("Msg_WorkFlow_AtLeastOneCodeTypeInOptionalRequiredPanel",
 * "XAt least one item must be available in either required or optional column.X"
 * ); put("WorkFlow_Status_Active", "0 - XActiveX");
 * put("WorkFlow_Status_Inactive", "1 - XInactiveX");
 * put("WorkFlow_Status_Disabled", "2 - XDisabledX");
 * put("columnName_WorkflowName", "XWorkflow NameX");
 * put("WorkFlowAssignment_Header_Title", "XWorkflow AssignmentsX");
 * put("CreateWorkFlowAssignment_Page_Title", "XCreate Workflow AssignmentX");
 * put("EditWorkFlowAssignment_Page_Title", "XEdit Workflow AssignmentX");
 * put("AccessCode", "XAccess codeX"); put("DataView", "XData ViewX"); put("CL",
 * "XCLX"); put("UCL", "XUCLX"); put("LCL", "XLCLX"); put("Histogram Chart",
 * "XHistogram ChartX"); put("Maximum Value", "XMaximum ValueX");
 * put("Minimum Value", "XMinimum ValueX"); put("Mean", "XMeanX");
 * put("Mean - 3SD (lt)", "XMean - 3SD (lt)X"); put("Mean + 3SD (lt)",
 * "XMean + 3SD (lt)X"); put("Short term SD", "XShort term SDX");
 * put("Long term SD", "XLong term SDX"); put("Robustness", "XRobustnessX");
 * put("CoVar", "XCoVarX"); put("Z-bench", "XZ-benchX"); put("Target ratio",
 * "XTarget ratioX"); put("Specification", "XSpecificationX"); put("Z USL",
 * "XZ USLX"); put("Z Target", "XZ TargetX"); put("Z LSL", "XZ LSLX");
 * put("Actual Above", "XActual AboveX"); put("Actual Below", "XActual BelowX");
 * put("Actual Total", "XActual TotalX"); put("Actual PPM", "XActual PPMX");
 * put("Expected Above", "XExpected AboveX"); put("Expected Below",
 * "XExpected BelowX"); put("Expected Total", "XExpected TotalX");
 * put("Expected PPM", "XExpected PPMX"); put("Potential Indices",
 * "XPotential IndicesX"); put("Cp", "XCpX"); put("Cr (1/Cp)", "XCr (1/Cp)X");
 * put("Pp", "XPpX"); put("Pr (1/Pp)", "XPr (1/Pp)X");
 * put("Performance Indices", "XPerformance IndicesX"); put("Cpk", "XCpkX");
 * put("Cpk Upper", "XCpk UpperX"); put("Cpk Lower", "XCpk LowerX"); put("Cpm",
 * "XCpmX"); put("SIGL (st)", "XSIGL (st)X"); put("Ppk", "XPpkX");
 * put("Ppk Upper", "XPpk UpperX"); put("Ppk Lower", "XPpk LowerX"); put("Ppm",
 * "XPpmX"); put("SIGL (lt)", "XSIGL (lt)X"); put("Moments of Distribution",
 * "XMoments of DistributionX"); put("Avg Deviation", "XAvg DeviationX");
 * put("Std Deviation", "XStd DeviationX"); put("Variance", "XVarianceX");
 * put("Skewness", "XSkewnessX"); put("Kurtosis", "XKurtosis");
 * put("Chi squared Goodness of Fit", "XChi squared Goodness of FitX");
 * put("Chi-Squared", "XChi-SquaredX"); put("DF", "XDFX"); put("Chi Sq Prob",
 * "XChi Sq ProbX"); put("Analysis of Variance", "XAnalysis of VarianceX");
 * put("d.f", "Xd.fX"); put("Plot Point Value", "XPlot Point ValueX");
 * 
 * put("French - France", "XFrench - FranceX"); put("SubGroupSize",
 * "XSubgroup SizeX"); put("Defectives", "XDefectivesX"); put("Defects",
 * "XDefectsX"); put("Spec_Limit_Value", "XManufacturing LimitsX");
 * put("delay(ms)", "Xdelay(ms)X"); put("exclude", "XexcludeX"); put("include",
 * "XincludeX"); put("ColumnName_Reason", "XReasonX");
 * put("ColumnName_Assigned_Work_Dashboard", "XAssigned Work DashboardX");
 * put("ColumnName_Assigned_License", "XAssigned LicenseX");
 * put("Static_xpathDCType", "XSearch Data Collection TypeX");
 * put("MostRecentRecord", "XMost Recent RecordX"); put("EventReviews",
 * "XEvent ReviewsX"); put("ProcessInformation", "XProcess InformationX");
 * put("EventDetails", "XEvent DetailsX"); put("label_SelectEventCodeType",
 * "XSelect Event Code TypeX"); put("label_AddEventCode", "XAdd Event CodeX");
 * put("MDC_PartPopUp_SelectThePartMakingFromOD",
 * "XSelect the part you are making from <ODName>X");
 * put("MDC_ProcessPopUp_SelectTheProcessForOP",
 * "XSelect the process for <OpName> operationX");
 * put("Restore Manufacturing Limit", "XRestore Manufacturing LimitX");
 * put("DataCollectionTypes", "XData Collection TypesX"); put("Day", "XDayX");
 * put("DatCollectionType_Exclude",
 * "XSelect XData Collection TypesX (to XexcludeX)X");
 * put("UserReactivationConfirmationMessageWithSingleReason",
 * "XAre you sure you want to re-activate this user?X" + "\n" + "\n" +
 * "X<UserFullName> is inactive as of <DateTimeStamp> with reason '<ReasonName>'.X"
 * ); put("NoRecentLogins", "XNo recent loginsX");
 * put("ReActivationSuccessMessage",
 * "X<UserFullName> has been re-activated successfully.X");
 * put("msg_bulkDeleteSubgroupDataSuccess",
 * "XLast subgroup deletion successfully completed at <entityTime>X");
 * put("ManageLicenseReport", "XManage License ReportX");
 * 
 * put("Language_labels_of_process_state(s)_saved_successfully",
 * "XLanguage labels of process state(s) saved successfully.X");
 * put("ViewReport", "XView ReportX"); put("ControlChart", "XControl ChartX");
 * put("NoItemsFound", "XNo items foundX"); put("Label_All", "XAllX");
 * put("ConfirmationMessageForLicenseAssignment",
 * "XAssigning a license may impact your bill. Are you sure?X");
 * put("CodeType_Camera", "XCameraX"); put("Danish - Denmark",
 * "XDanish - DenmarkX"); put("Swedish - Sweden", "XSwedish - SwedenX");
 * put("CodeList", "XCode ListX"); put("CodeGridIncrement",
 * "XCode Grid: IncrementX"); put("CodeGridNumeric", "XCode Grid: Numeric");
 * put("RequireCodeforEachPiece", "XRequire a Code for Each PieceX");
 * put("BoxAndWhiskerChart", "XBox and Whisker ChartX"); }
 * 
 * };
 * 
 * }
 */