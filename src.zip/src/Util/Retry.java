package Util;

import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;

public class Retry implements IRetryAnalyzer {

	private int retryCount = 0;
	private int maxRetryCount = 0;

	@Override
	public boolean retry(ITestResult result) {

		// Below method returns 'true' if the test method has to be retried else
		// 'false'
		// and it takes the 'Result' as parameter of the test method that just
		// ran
		if (retryCount < maxRetryCount) {
			System.out.println("Retrying test " + result.getName() + " for the " + (retryCount + 1) + " time(s).");
			retryCount++;
			return true;
		}
		return false;

	}
}
