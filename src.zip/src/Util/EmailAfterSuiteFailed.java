package Util;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Hashtable;
import java.util.Properties;
import java.util.TimeZone;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import Base.BasePage;

public class EmailAfterSuiteFailed {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// java -jar mail7.jar fatestuser_nagarro pwdsendgridnagarro1
		// smtp.sendgrid.com 587 rakesh.sharma02@nagarro.com
		// rakesh.sharma02@nagarro.com,yogendra.rathore@nagarro.com

		// set username, pwd
		// set username, pwd
		final String username = BasePage.TestConfiguration.getProperty("SendGridUserName");
		final String password = BasePage.TestConfiguration.getProperty("SendGridPassword");
		final String stmpHost = BasePage.TestConfiguration.getProperty("SendGridHostName");
		final String portNumber = BasePage.TestConfiguration.getProperty("SendGridPortNumber");
		final String fromMail = BasePage.TestConfiguration.getProperty("FromMailUser");
		final String recipientsList = BasePage.TestConfiguration.getProperty("RecipientsList");
		String deploymentName = BasePage.TestConfiguration.getProperty("DeploymentName");
		;
		if (username != "") {
			// set properties
			Properties props = new Properties();
			props.put("mail.smtp.auth", "true");
			props.put("mail.smtp.starttls.enable", "true");
			props.put("mail.smtp.host", stmpHost);
			props.put("mail.smtp.port", portNumber);

			Session session = Session.getInstance(props, new javax.mail.Authenticator() {
				protected PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication(username, password);
				}
			});

			try {
				String location = System.getProperty("user.dir") + "\\..\\..";
				String commonRepositoryFolderForParallelExecution = BasePage.commonRepositoryFolderForParallelExecution;
				Thread.sleep(5000);
				if (UtilityFunctions.checkFolderExistsAtGivenLocation(location,
						commonRepositoryFolderForParallelExecution)) {

					System.out.println(location);
					UtilityFunctions.deleteFolderAtGivenLocation(location,
							BasePage.commonRepositoryFolderForParallelExecution);
					String dateInString = null;

					TimeZone tz = Calendar.getInstance().getTimeZone();

					SimpleDateFormat simpleDateFormat = BasePage.simpleDateFormat_Standard;
					Date date = new Date();
					dateInString = simpleDateFormat.format(date);

					Message msg = new MimeMessage(session);

					SimpleDateFormat sdf = BasePage.simpleDateFormat_27;

					// set from name
					msg.setFrom(new InternetAddress(fromMail));

					// set recipients
					String recipientsTo = recipientsList;

					msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipientsTo));
					deploymentName = "(" + deploymentName + ")";
					// Set subject line
					msg.setSubject("Sanity suite " + deploymentName + " stopped as health check scearnio failed."
							+ dateInString + " in time zone " + tz.getDisplayName());

					// prepare body text

					StringBuilder sb = new StringBuilder();
					sb.append("Hi Team,").append(System.lineSeparator()).append(System.lineSeparator());

					sb.append("Sanity suite stopped as health check scearnio failed.").append(System.lineSeparator())
							.append(System.lineSeparator());
					sb.append("Thanks").append(System.lineSeparator()).append(System.lineSeparator());
					sb.append("Automation Team").append(System.lineSeparator());

					// set body and attachment

					// set body and attachment

					// Set text
					BodyPart messageBodyPart1 = new MimeBodyPart();
					messageBodyPart1.setText(sb.toString());

					// messageBodyPart2.setContent(message, "text/plain");

					// Copy exeuction folder to above created folder. it to
					// BasePage.executionFolderHistory

					Multipart multipart = new MimeMultipart();
					multipart.addBodyPart(messageBodyPart1);

					msg.setContent(multipart);

					// send message
					Transport.send(msg);
					System.out.println("Mail Sent for :  Sanity suite stopped as health check scearnio failed. ");
					// end of sending mail.
					// kill chrome driver.exe and chome if any existing.
					UtilityFunctions.deleteFolderAtGivenLocation(location,
							BasePage.commonRepositoryFolderForParallelExecution);
					UtilityFunctions.deleteFolderAtGivenLocation(location, "FlagToStartExcelSeparation");
					UtilityFunctions.killProcess(BasePage.broswerExe);

					UtilityFunctions.killProcess(BasePage.broswerDriverExe);

				} else
					System.out.println("Not sending Health check mail, as sent by another thread.");
			} catch (Exception e) {
				e.printStackTrace();

			}
		} else {
			System.out.println("Email Details Not set in TestExecutionInputSheet");
		}
	}
}
