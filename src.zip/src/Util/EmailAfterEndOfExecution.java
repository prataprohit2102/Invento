package Util;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Hashtable;
import java.util.Properties;
import java.util.TimeZone;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import Base.BasePage;

public class EmailAfterEndOfExecution {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// java -jar mail7.jar fatestuser_nagarro pwdsendgridnagarro1
		// smtp.sendgrid.com 587 rakesh.sharma02@nagarro.com
		// rakesh.sharma02@nagarro.com,yogendra.rathore@nagarro.com

		// set username, pwd
		// set username, pwd

		final String username = BasePage.TestConfiguration.getProperty("SendGridUserName");
		final String password = BasePage.TestConfiguration.getProperty("SendGridPassword");
		final String stmpHost = BasePage.TestConfiguration.getProperty("SendGridHostName");
		final String portNumber = BasePage.TestConfiguration.getProperty("SendGridPortNumber");
		final String fromMail = BasePage.TestConfiguration.getProperty("FromMailUser");
		final String recipientsList = BasePage.TestConfiguration.getProperty("RecipientsList");
		String deploymentName = BasePage.TestConfiguration.getProperty("DeploymentName");
		;

		// set properties
		Properties props = new Properties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", stmpHost);
		props.put("mail.smtp.port", portNumber);

		Session session = Session.getInstance(props, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(username, password);
			}
		});

		try {
			String parentFolderForFinalRun = "";
			String userDirectory = System.getProperty("user.dir");
			String location = userDirectory + "\\..\\..";

			String commonRepositoryFolderForParallelExecution = BasePage.commonRepositoryFolderForParallelExecution;
			int numberOfParallelExecutions = BasePage.numberOfParallelExecution;

			String excelName = BasePage.excelNameForCombinedTestResultsOfParralExecution;
			// check to shoot mail for sanity status.

			if (UtilityFunctions.checkToShootMailAtEndOfExecutions(
					location + "\\" + commonRepositoryFolderForParallelExecution, excelName)) {

				// check for folder in which final combined run will start.
				File file = new File(userDirectory);
				parentFolderForFinalRun = file.getParentFile().getName();
				System.out.println("Execution For Failed testcases will be in folder : " + parentFolderForFinalRun);

				String dateInString = null, directorypath = "";
				directorypath = userDirectory + "\\resources\\Exceution Folder";

				TimeZone tz = Calendar.getInstance().getTimeZone();

				SimpleDateFormat simpleDateFormat = BasePage.simpleDateFormat_Standard;
				Date date = new Date();
				dateInString = simpleDateFormat.format(date);

				Message msg = new MimeMessage(session);

				// set from name
				msg.setFrom(new InternetAddress(fromMail));

				// set recipients
				String recipientsTo = recipientsList;

				msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipientsTo));
				deploymentName = "(" + deploymentName + ")";
				// Set subject line
				msg.setSubject("Sanity Execution " + deploymentName + " report at " + dateInString + " in time zone "
						+ tz.getDisplayName());

				// prepare body text

				Hashtable<String, String> results = new Hashtable<String, String>();
				results = UtilityFunctions.combineTestSheetsAndGetStatus(numberOfParallelExecutions,
						location + "\\" + commonRepositoryFolderForParallelExecution, excelName,
						parentFolderForFinalRun);

				StringBuilder sb = new StringBuilder();
				sb.append("Hi Team,").append(System.lineSeparator());
				sb.append("Please find below the execution report on " + BasePage.appURL + " :")
						.append(System.lineSeparator()).append(System.lineSeparator());
				sb.append("  Total Test Cases    : " + results.get("Total_TestCases")).append(System.lineSeparator());
				sb.append("  Passed : " + results.get("Passed_TestCases")).append(System.lineSeparator());
				sb.append("  Failed : " + results.get("Failed_TestCases")).append(System.lineSeparator());
				sb.append("  Skipped : " + results.get("Skipped_TestCases")).append(System.lineSeparator());
				sb.append("  NoStatus : " + results.get("NoStatus_TestCases")).append(System.lineSeparator())
						.append(System.lineSeparator());
				// add start and end time of execution.
				sb.append(UtilityFunctions.getStartTimeAndEndTimeOfExecution(
						location + "\\" + commonRepositoryFolderForParallelExecution, excelName))
						.append(System.lineSeparator()).append(System.lineSeparator());

				// added line in mail , if executing failed test case again.
				if (BasePage.executeFailedTestCasesOfAllFolderInSingleSuite) {
					sb.append("Note :Automation execution of failed test cases is started again in folder :-"
							+ parentFolderForFinalRun).append(System.lineSeparator()).append(System.lineSeparator());

					sb.append("	   Reason of test cases in SKIPPED is given in Excel attached (if any).")
							.append(System.lineSeparator()).append(System.lineSeparator());
				} else {
					sb.append("Note :Reason of test cases in SKIPPED is given in Excel attached.")
							.append(System.lineSeparator()).append(System.lineSeparator());
				}

				sb.append("Thanks").append(System.lineSeparator()).append(System.lineSeparator());
				sb.append("Automation Team").append(System.lineSeparator());

				// set body and attachment

				// Set text
				BodyPart messageBodyPart1 = new MimeBodyPart();
				messageBodyPart1.setText(sb.toString());

				// attachement
				MimeBodyPart messageBodyPart2 = new MimeBodyPart();

				// messageBodyPart2.setContent(message, "text/plain");

				String filepath = location + "\\" + commonRepositoryFolderForParallelExecution + "\\" + excelName;

				String filename = excelName;

				DataSource source = new FileDataSource(filepath);
				messageBodyPart2.setDataHandler(new DataHandler(source));
				messageBodyPart2.setFileName(filename);

				Multipart multipart = new MimeMultipart();
				multipart.addBodyPart(messageBodyPart1);
				multipart.addBodyPart(messageBodyPart2);
				msg.setContent(multipart);

				// send message
				Transport.send(msg);

				// run execution if required.
				if (BasePage.executeFailedTestCasesOfAllFolderInSingleSuite) {

					// start execution of failed test cases
					StringBuilder command = new StringBuilder("cmd /c start /wait " + System.getProperty("user.dir")
							+ "//resources//sanity_reRun_FailedTestCases.bat");
					// hit batch file.
					Process failedTestCaseExecutionProcess = Runtime.getRuntime().exec(command.toString());
					int failedTestCaseExecutionProcessExitCode = failedTestCaseExecutionProcess.waitFor();
					System.out.println("Exited with code :" + failedTestCaseExecutionProcessExitCode);

				} else {
					// end of sending mail.
					// kill chrome driver.exe and chome if any existing.
					UtilityFunctions.deleteFolderAtGivenLocation(location,
							BasePage.commonRepositoryFolderForParallelExecution);
					UtilityFunctions.deleteFolderAtGivenLocation(location, "FlagToStartExcelSeparation");
					UtilityFunctions.killProcess(BasePage.broswerExe);
					UtilityFunctions.killProcess(BasePage.broswerDriverExe);
					UtilityFunctions.killProcess("WinAppDriver.exe");

				}

			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}