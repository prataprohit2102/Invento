package Util;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.TimeZone;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import Base.BasePage;

public class EmailBeforeStartExecution {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// java -jar mail7.jar fatestuser_nagarro pwdsendgridnagarro1
		// smtp.sendgrid.com 587 rakesh.sharma02@nagarro.com
		// rakesh.sharma02@nagarro.com,yogendra.rathore@nagarro.com

		// set username, pwd
		final String username = BasePage.TestConfiguration.getProperty("SendGridUserName");
		final String password = BasePage.TestConfiguration.getProperty("SendGridPassword");
		final String stmpHost = BasePage.TestConfiguration.getProperty("SendGridHostName");
		final String portNumber = BasePage.TestConfiguration.getProperty("SendGridPortNumber");
		final String fromMail = BasePage.TestConfiguration.getProperty("FromMailUser");
		final String recipientsList = BasePage.TestConfiguration.getProperty("RecipientsList");
		String deploymentName = BasePage.TestConfiguration.getProperty("DeploymentName");
		;
		// set properties
		Properties props = new Properties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", stmpHost);
		props.put("mail.smtp.port", portNumber);

		Session session = Session.getInstance(props, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(username, password);
			}
		});

		try {
			String parentFolderForFinalRun = "";
			String userDirectory = System.getProperty("user.dir");
			File file = new File(userDirectory);
			parentFolderForFinalRun = file.getParentFile().getName();

			// check email trigger conditions
			String location = System.getProperty("user.dir") + "\\..\\..";
			String commonRepositoryFolderForParallelExecution = BasePage.commonRepositoryFolderForParallelExecution;
			String excelName = BasePage.excelNameForCombinedTestResultsOfParralExecution;

			List<String> sheetName = new ArrayList<String>();
			sheetName.add("TestCases");
			sheetName.add("Summary");
			sheetName.add("ExecutionTime");
			sheetName.add("NumberOfExecutions");

			if (!UtilityFunctions.checkFolderExistsAtGivenLocation(location,
					commonRepositoryFolderForParallelExecution)) {

				System.out.println("Sending Email");
				System.out.println(location);
				int numberOfParallelExecution = BasePage.numberOfParallelExecution;

				// create common repository folder
				UtilityFunctions.createFolderAtGivenLocation(location, commonRepositoryFolderForParallelExecution);

				// create excel for combined executions status, combined
				// execution time, total number of parallel execution.
				UtilityFunctions.createCombinedSummaryExcelAndSetStartExecutionTime(
						location + "\\" + commonRepositoryFolderForParallelExecution, numberOfParallelExecution,
						excelName, sheetName);

				String dateInString = null;
				SimpleDateFormat simpleDateFormat = BasePage.simpleDateFormat_Standard;
				Date date = new Date();
				dateInString = simpleDateFormat.format(date);

				TimeZone tz = Calendar.getInstance().getTimeZone();
				System.out.println(tz.getDisplayName());

				Message msg = new MimeMessage(session);

				// set from name
				msg.setFrom(new InternetAddress(fromMail));

				// set recipients
				String recipientsTo = recipientsList;

				msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipientsTo));

				deploymentName = "(" + deploymentName + ")";
				// Set subject line
				msg.setSubject("Sanity suite Execution " + deploymentName + " Starts at " + dateInString
						+ " in time zone " + tz.getDisplayName());

				// set body text
				String message;

				message = "Hi All, \n\n Automated sanity execution started on " + BasePage.appURL
						+ " successfully. \nThanks,\nTest Automation Team \n\n\n\n\n\n";
				message = message.concat(System.lineSeparator());

				// set body and attachment

				BodyPart messageBodyPart1 = new MimeBodyPart();
				messageBodyPart1.setText(message);

				Multipart multipart = new MimeMultipart();
				multipart.addBodyPart(messageBodyPart1);
				msg.setContent(multipart);

				// send message
				try {
					Transport.send(msg);
				} catch (Exception e) {
					try {
						Transport.send(msg);
					} catch (Exception e1) {
						try {
							Transport.send(msg);
						} catch (Exception e2) {
							e.printStackTrace();
						}
					}
				}

				System.out.println("Done");

			}
		} catch (MessagingException e) {
			// supress the exception if occurs.
			// throw new RuntimeException(e);
			e.printStackTrace();
		}
	}

}