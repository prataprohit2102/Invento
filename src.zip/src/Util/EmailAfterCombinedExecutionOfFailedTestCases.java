package Util;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;
import java.util.Properties;
import java.util.TimeZone;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import Base.BasePage;

public class EmailAfterCombinedExecutionOfFailedTestCases {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// java -jar mail7.jar fatestuser_nagarro pwdsendgridnagarro1
		// smtp.sendgrid.com 587 rakesh.sharma02@nagarro.com
		// rakesh.sharma02@nagarro.com,yogendra.rathore@nagarro.com

		// set username, pwd
		// set username, pwd
		final String username = BasePage.TestConfiguration.getProperty("SendGridUserName");
		final String password = BasePage.TestConfiguration.getProperty("SendGridPassword");
		final String stmpHost = BasePage.TestConfiguration.getProperty("SendGridHostName");
		final String portNumber = BasePage.TestConfiguration.getProperty("SendGridPortNumber");
		final String fromMail = BasePage.TestConfiguration.getProperty("FromMailUser");
		final String recipientsList = BasePage.TestConfiguration.getProperty("RecipientsList");
		String deploymentName = BasePage.TestConfiguration.getProperty("DeploymentName");
		;

		// set properties
		Properties props = new Properties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", stmpHost);
		props.put("mail.smtp.port", portNumber);

		Session session = Session.getInstance(props, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(username, password);
			}
		});
		String location = System.getProperty("user.dir");

		try {
			String dateInString = null;

			TimeZone tz = Calendar.getInstance().getTimeZone();

			SimpleDateFormat simpleDateFormat = BasePage.simpleDateFormat_Standard;
			Date date = new Date();
			dateInString = simpleDateFormat.format(date);

			Message msg = new MimeMessage(session);
			String filepath = location + "\\src\\Test Data\\TestSummarySheet\\ExecutionResultsSheet.xlsx";

			String filename = "ExecutionResultsSheet.xlsx";
			SimpleDateFormat sdf = BasePage.simpleDateFormat_27;
			String folderName = "ExecutionFolder_" + sdf.format(date);
			// copy execution folder in BasePage.executionFolderHistory
			// create execution backup folder for keeping backup of
			// execution failures (XSLT , and screenshots) date wise.
			if (!UtilityFunctions.checkFolderExistsAtGivenLocation(location + "\\..\\..",
					BasePage.executionFolderHistory))
				UtilityFunctions.createFolderAtGivenLocation(location + "\\..\\..", BasePage.executionFolderHistory);

			// create new folder in backup folder (append timestamp)
			UtilityFunctions.createFolderAtGivenLocation(location + "\\..\\..\\" + BasePage.executionFolderHistory,
					folderName);

			// set from name
			msg.setFrom(new InternetAddress(fromMail));

			// set recipients
			String recipientsTo = recipientsList;

			msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipientsTo));
			deploymentName = "(" + deploymentName + ")";
			// Set subject line
			msg.setSubject("Sanity Execution " + deploymentName + " for Failed Test Cases : " + dateInString
					+ " in time zone " + tz.getDisplayName());

			// prepare body text

			Hashtable<String, String> results = new Hashtable<String, String>();
			results = UtilityFunctions.getPassedFailedStatusFromSummarySheet();

			StringBuilder sb = new StringBuilder();
			sb.append("Hi Team,").append(System.lineSeparator());

			sb.append("Please find below the execution report for failed test cases on " + BasePage.appURL + " :")
					.append(System.lineSeparator()).append(System.lineSeparator());
			sb.append("  Total Test Cases    : " + results.get("Total_TestCases")).append(System.lineSeparator());
			sb.append("  Passed : " + results.get("Passed_TestCases")).append(System.lineSeparator());
			sb.append("  Failed : " + results.get("Failed_TestCases")).append(System.lineSeparator());
			sb.append("  Skipped : " + results.get("Skipped_TestCases")).append(System.lineSeparator());

			sb.append("  NoStatus : " + results.get("NoStatus_TestCases")).append(System.lineSeparator())
					.append(System.lineSeparator());
			sb.append("  Reason of test cases in SKIPPED is given in Excel attached (if any).")
					.append(System.lineSeparator()).append(System.lineSeparator());

			sb.append("You can find the screenshots at " + location + "\\..\\..\\" + BasePage.executionFolderHistory
					+ "\\" + folderName + " on respective VM.").append(System.lineSeparator())
					.append(System.lineSeparator());

			sb.append("Thanks").append(System.lineSeparator()).append(System.lineSeparator());
			sb.append("Automation Team").append(System.lineSeparator());

			// set body and attachment

			// Set text
			BodyPart messageBodyPart1 = new MimeBodyPart();
			messageBodyPart1.setText(sb.toString());

			// attachement
			MimeBodyPart messageBodyPart2 = new MimeBodyPart();

			// messageBodyPart2.setContent(message, "text/plain");

			// Copy exeuction folder to above created folder. it to
			// BasePage.executionFolderHistory

			UtilityFunctions.moveFileFromSrcToDest(location + "\\resources\\Exceution Folder",
					location + "\\..\\..\\" + BasePage.executionFolderHistory + "\\" + folderName + "\\", "");

			DataSource source = new FileDataSource(filepath);
			messageBodyPart2.setDataHandler(new DataHandler(source));
			messageBodyPart2.setFileName(filename);

			Multipart multipart = new MimeMultipart();
			multipart.addBodyPart(messageBodyPart1);
			multipart.addBodyPart(messageBodyPart2);
			msg.setContent(multipart);

			// send message
			Transport.send(msg);

			deleteBackUpFolderFromLast30Days(location + "\\..\\..\\" + BasePage.executionFolderHistory);
		} catch (Exception e) {
			e.printStackTrace();

		} finally {

			// end of sending mail.
			// kill chrome driver.exe and chome if any existing.
			UtilityFunctions.deleteFolderAtGivenLocation(location + "\\..\\..\\",
					BasePage.commonRepositoryFolderForParallelExecution);
			UtilityFunctions.deleteFolderAtGivenLocation(location + "\\..\\..\\", "FlagToStartExcelSeparation");

			UtilityFunctions.killProcess(BasePage.broswerExe);

			UtilityFunctions.killProcess(BasePage.broswerDriverExe);

			// get path of temp folder
			String pathOfTempFolder = System.getProperty("user.home") + "\\AppData\\Local\\Temp";
			// get all files and folders of temp folder
			List<String> listOfFilesAndFolders = UtilityFunctions.listFilesAndFolders(pathOfTempFolder);

			// delete all files and folders.
			for (int i = 0; i < listOfFilesAndFolders.size(); i++) {

				UtilityFunctions.deleteFolderAtGivenLocation(pathOfTempFolder, listOfFilesAndFolders.get(i));

			}

			// delete folders
			System.out.println("Files Deleted Successfully From Temp Folder");

			UtilityFunctions.killProcess("java.exe");
			UtilityFunctions.killProcess("conhost.exe");
			UtilityFunctions.killProcess("WinAppDriver.exe");
		}
	}

	// --------------------------------------------------------------------------------------
	// Author : Yogendra Rathore
	// This folder deletes 30 days old back up folders
	// And if total folder cound is more than 20
	public static void deleteBackUpFolderFromLast30Days(String location) {
		// TODO Auto-generated method stub
		try {
			int deletedCount = 0;
			System.out.println("Starting deleting 30 days old back up folders");
			List<String> foldersInDirectory = new ArrayList<String>();
			foldersInDirectory = UtilityFunctions.findFoldersInDirectory(location);

			int size = foldersInDirectory.size();
			String baseLinedDate = "";
			String otherDate = "";
			if (size < 20) {
				System.out.println("Not deleting any backup folders are count is less than 20");
				return;

			}
			for (int i = 0; i < size; i++) {
				String nameOfFolder = foldersInDirectory.get(i);

				String spiltArrary[] = new String[2];

				// get expected validation message
				spiltArrary = UtilityFunctions.splitString(nameOfFolder, "ExecutionFolder_");
				otherDate = spiltArrary[1];
				;

				if (i == 0)
					baseLinedDate = UtilityFunctions.getFutureOrPastTimeFromCurrentTime(-720, "HOUR",
							BasePage.simpleDateFormat_27);

				if (UtilityFunctions.compareTime(baseLinedDate, otherDate, BasePage.simpleDateFormat_27)
						.equals("GREATER")) {
					deletedCount++;
					UtilityFunctions.deleteFolderAtGivenLocation(location, foldersInDirectory.get(i));

				}
			}
			System.out.println("Deleted " + deletedCount + ", 30 days old back up folders");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
