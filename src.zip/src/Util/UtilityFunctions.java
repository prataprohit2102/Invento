package Util;

import java.awt.AWTException;
import java.awt.HeadlessException;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Writer;
import java.net.URL;
import java.sql.ResultSet;
import java.text.DateFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.TimeZone;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.testng.Reporter;

import com.opencsv.CSVReader;

import Base.BasePage;
import Pages.LandingPage;
import Pages.LoginPage;
//import io.appium.java_client.windows.WindowsDriver;
import io.appium.java_client.windows.WindowsDriver;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

public class UtilityFunctions {
	public static List<String> runStatusList = new ArrayList<String>();
	//private static final String xPath_btnLoginButton = "//*[@data-selector='btn-login']";
	// File Path
	public static String fileUploadPath = System.getProperty("user.dir")
			+ BasePage.TestConfiguration.getProperty("FileUploadPath");
	public static boolean setSkippedStatus = false;
	public static int skippedDueToTestCaseInDesignState = 0;
	public static int skippedDueToTestCaseInClosedState = 0;
	public static int skippedDueToTestCaseIsInScriptMaintenance = 0;
	public static int skippedDueToTestCaseIsNotAutomable = 0;
	public static int skippedDueToTestCaseIsNotAutomated = 0;
	public static int skippedDueToTestCaseIsNotInScope = 0;
	public static int skippedDueToTestCaseIsBlocked = 0;
	public static SimpleDateFormat dateFormatForWaitMethod = null;
	static final Logger log = Logger.getLogger("UtilityFunctions");
	static SimpleDateFormat dbDateFormat = BasePage.simpleDateFormat_4;

	// character Type constants
	public static String char_alphabets = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
	public static String char_digits = "0123456789";
	public static String char_alphanumeric = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

	public static String char_specialCharacters = "~`!@#$%^&*()-{}[]|:;<>,.?/+" + "\\" + "\"" + "\'";

	// To check whether a given test case is to be executed or not based on the
	// run mode set in the Test Suite excel
	public static boolean IsExecutable(String testName, ExcelUtility xls) {

		boolean isExecutable = false;
		int rNum;
		String title = "";

		for (rNum = 2; rNum <= xls.getRowCount("TestCases"); rNum++) {

			if (testName.equals(xls.getCellData("TestCases", "TCID", rNum))) {
				if (xls.getCellData("TestCases", "RunMode", rNum).equals("Y")) {
					isExecutable = true;
					break;
				} else {
					isExecutable = false;
					break;
				}

			} // end
		}

		if (BasePage.checkForTitle && isExecutable) {
			try {
				BasePage.columnTitleInTestInputSheet = BasePage.xls.getColumnNumber("TestCases", "Title");
			} catch (Exception e) {

			} finally {
				BasePage.checkForTitle = false;
			}

		}
		if (BasePage.columnTitleInTestInputSheet > 0)
			title = BasePage.xls.getCellData("TestCases", (BasePage.columnTitleInTestInputSheet + 1), rNum);

		BasePage.titleOfTestCase = title;
		return isExecutable;

	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// Read data from the excel file. Takes two arguments - Test Case Name and
	// XLS_Reader object. Reads the test data from the Test Data excel and
	// return the test data in 2 D object array form
	public static Object[][] getData(String TestCaseName, ExcelUtility xls) {
		// find test in the excel file
		// find number of columns in the test
		// find number of rows in the test
		// print the data of the test
		// put the data in object array

		// Get the start row index for the test data of the given Test Case name
		int testCaseStartIndex = 0;

		for (int rNum = 1; rNum <= xls.getRowCount("TestData"); rNum++) {
			if (TestCaseName.equals(xls.getCellData("TestData", 1, rNum))) {
				testCaseStartIndex = rNum;
				break;
			} // end of if
		} // end of for

		// Get the number of columns in the test data (which is available column
		// wise) for the given test case
		int testCaseDataColumnNamesStartIndex = testCaseStartIndex + 1;

		int Cols = 4;
		while (!(xls.getCellData("TestData", Cols, testCaseDataColumnNamesStartIndex).equals(""))) {
			Cols++;
		} // end of while

		int numberOfTestDataColumns = Cols - 4;

		int testCaseDataStartIndex = testCaseStartIndex + 2;

		int rows = 0;
		while (!xls.getCellData("TestData", 4, (testCaseDataStartIndex + rows)).equals("")) {
			rows++;
		} // end of while
		int numberofTestDataSets = rows;

		// Store the test data sets of a single test case in an array of
		// HashTable. Each HasTable will contain one test data set
		Object[][] dataSetCollection = new Object[numberofTestDataSets][1];

		Hashtable<String, String> TestDataSet = null;
		String Datakey = "'";
		String Keyvalue = "";
		int index = 0;
		for (int r = testCaseDataStartIndex; r < (testCaseDataStartIndex + numberofTestDataSets); r++) {
			TestDataSet = new Hashtable<String, String>();

			for (int c = 4; c < (numberOfTestDataColumns + 4); c++) {

				Datakey = xls.getCellData("TestData", c, testCaseDataColumnNamesStartIndex);
				Keyvalue = xls.getCellData("TestData", c, r);
				TestDataSet.put(Datakey, Keyvalue);

			} // end of for
				// Once all the Column Name Value pair is stored in the
				// HashTable for a row, add this Hash Table in the 2 D array of
				// Objects
			dataSetCollection[index][0] = TestDataSet;
			index++;
		} // end of for

		return dataSetCollection;

	}// end of function

	// --------------------------------------------------------------------------------------------------------------------------------

	// --------------------------------------------------------------------------------------------------------------------------------

	// Converts the ArrayList to comma separated string. Take argument as Array
	// List of type string and returns a comma separated string containing all
	// the values of the Array List
	public static String convertStringArrayListToCommaSeparatedString(List<String> arrList) {
		StringBuilder commaSepValueBuilder = new StringBuilder();
		int arrListSize = arrList.size();

		for (int i = 0; i < arrListSize; i++) {
			commaSepValueBuilder.append(arrList.get(i));
			// if the value is not the last element of the list
			// then append the comma(,) as well
			if (i != arrListSize - 1) {
				commaSepValueBuilder.append(", ");
			} // end of if
		} // end of for

		return commaSepValueBuilder.toString();
	}// end of function

	// --------------------------------------------------------------------------------------------------------------------------------
	// To convert a date into a format as per current browser culture
	// Parameter - DateString to be converted and timezone to be coverted
	//
	public static String getDateInBrowserFormat(String dateInString, String timeZone) {
		String date = null;
		try {
			if (timeZone.equalsIgnoreCase("UTC")) {
				dateInString = dateInString.replaceAll("-", "/");
				dateInString = dateInString + " UTC";
			}
			// Tanmay - This else condition shall be removed once the Filters
			// values are to be picked as per browser format.
			// Currently dates in filter are set in M/dd/yyyy hh:mm a format
			else {
				date = getDateForFilters();
				return date;
			}
			JavascriptExecutor jse = (JavascriptExecutor) BasePage.driver;
			String browserCulture = (String) jse
					.executeScript("var browserCulture = window.navigator.language || window.navigator.userlanguage;"
							+ "if (typeof (browserCulture) === 'undefined' || browserCulture==='') {"
							+ "browserCulture = \"en-us\";" + "}" + "return browserCulture;");

			date = (String) jse.executeScript(
					"var temp = arguments[0]; " + "var dateObject = new Date(temp);"
							+ "var dateString = dateObject.toLocaleString(arguments[1]);  return dateString; ",
					dateInString, browserCulture);
		} catch (Exception e) {

		}
		return date;

	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// To convert a date into a format as per current browser culture
	// Parameter - DateString in UTC format
	public static String getCurrentBrowserDate() {
		String date = null;
		try {
			JavascriptExecutor jse = (JavascriptExecutor) BasePage.driver;
			String browserCulture = (String) jse
					.executeScript("var browserCulture = window.navigator.language || window.navigator.userlanguage;"
							+ "if (typeof (browserCulture) === 'undefined' || browserCulture==='') {"
							+ "browserCulture = \"en-us\";" + "}" + "return browserCulture;");

			date = (String) jse.executeScript(
					"var dateObject = new Date();"
							+ "var dateString = dateObject.toLocaleString(arguments[0]);  return dateString; ",
					browserCulture);
		} catch (Exception e) {

		}
		return date;

	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// Get date for filters in required format
	// Author - Tanmay
	// Modified by : Yogendra Rathore
	// Action : updated date format as per current format in the application
	public static String getDateForFilters() throws Exception {
		String dateInString = null;
		SimpleDateFormat simpleDateFormat = BasePage.simpleDateFormat_Standard;
		if (!LibraryFunctions.isBrowserClosed()) {
			// Following Code to be uncommented if Filter DateControls accept
			// browser format instead of fixed format of M/dd/yyyy hh:mm a
			JavascriptExecutor jse = (JavascriptExecutor) BasePage.driver;
			dateInString = (String) jse.executeScript("var dateObject = new Date();"
					+ "var dateString = dateObject.toLocaleString(arguments[0]);  return dateString;dateString = dateString.replace(/:\\d\\d /, ''); ",
					"en-US");
			String browserCulture = (String) jse
					.executeScript("var browserCulture = window.navigator.language || window.navigator.userlanguage;"
							+ "if (typeof (browserCulture) === 'undefined' || browserCulture==='') {"
							+ "browserCulture = \"en-us\";" + "}" + "return browserCulture;");

			dateInString = (String) jse.executeScript(
					"var temp = arguments[0]; " + "var dateObject = new Date(temp);"
							+ "var dateString = dateObject.toLocaleString(arguments[1]);  return dateString; ",
					dateInString, browserCulture);
		}
		Date date = new Date();
		dateInString = simpleDateFormat.format(date);
		return dateInString;

	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// Method to get 'To' Date for filters based on from date
	// Parameter - DateString for 'From' date
	public static String getToDateForFilters(String fromDateString) throws Exception {
		String toDateInString = fromDateString;
		String[] time = fromDateString.split(" ");
		String[] minutes;
		String[] day;
		int hours = 0;
		int date = 0;
		minutes = time[1].split(":");
		hours = (Integer.parseInt(minutes[0]) + 1);
		day = time[0].split("/");
		date = (Integer.parseInt(day[1]));
		if (time[time.length - 1].equalsIgnoreCase("AM")) {
			if (hours >= 12) {
				toDateInString = toDateInString.replaceAll(minutes[0] + ":", (hours - 12) + ":");
				toDateInString = toDateInString.replaceAll("AM", "PM");
			} else
				toDateInString = fromDateString.replaceAll(minutes[0] + ":", (hours) + ":");
		} else {

			if (hours >= 12) {
				toDateInString = toDateInString.replaceAll(minutes[0] + ":", (hours - 12) + ":");
				toDateInString = toDateInString.replaceAll("PM", "AM");
				toDateInString = toDateInString.replaceAll(day[1] + "/", (date + 1) + "/");
			} else
				toDateInString = fromDateString.replaceAll(minutes[0] + ":", (hours) + ":");

		}
		return toDateInString;

	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// To convert a filter date value to UTC format
	// Parameter - DateString in UTC format
	public static String convertFilterDateToUTC(String filterDate) throws Exception {
		String dateInString = null;
		TimeZone utc = TimeZone.getTimeZone("UTC");
		SimpleDateFormat dbDateFormat = BasePage.simpleDateFormat_1;
		// Following Code to be uncommented if Filter DateControls accept
		// browser format instead of fixed format of M/dd/yyyy hh:mm a
		// JavascriptExecutor jse = (JavascriptExecutor) BasePage.driver;
		// filterDate =
		// (String)jse.executeScript("var dateObject = new Date(arguments[0]);"
		// +"var dateString = dateObject.toLocaleString(arguments[1]); return
		// dateString;dateString = dateString.replace(/:\\d\\d /, '');
		// ",filterDate,"en-US");
		SimpleDateFormat simpleDateFormat = BasePage.simpleDateFormat_14;
		Date date = simpleDateFormat.parse(filterDate);
		dbDateFormat.setTimeZone(utc);
		dateInString = dbDateFormat.format(date);
		return dateInString;

	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// To write a test case pass/fail,result in the excel sheet
	public static void reportDataSetResult(ExcelUtility xls, String testCaseName, int rowNum, String result) {
		xls.setCellData(testCaseName, "Results", rowNum, result);
	}

	// --------------------------------------------------------------------------------------------------------------------------------

	// Take screen shot of error
	// Modified By : Tanmay (Updated relative path for Reporter log)
	public static boolean takeScreenshot(String filename) {
		java.util.Date date = new java.util.Date();
		SimpleDateFormat sdf = BasePage.simpleDateFormat_26;
		// System.getProperty("user.dir") +

		String absoluteFileName = System.getProperty("user.dir")
				+ BasePage.TestConfiguration.getProperty("ScreenShotPath") + "\\" + BasePage.currentMethodName + "--"
				+ filename + sdf.format(date) + ".jpg";
		log.info("Screenshot Path : " + absoluteFileName);
		try {
			// Due to flickering issues we are using below code to capture
			// screenshot on IE Browser and Method captures full window
			// screenshot for Exec and Manual Environments
			if (BasePage.TestConfiguration.getProperty("Browser").equals("IE")
					|| BasePage.TestConfiguration.getProperty("TestSiteURL").contains("Exec")) {
				BufferedImage capture = null;
				capture = new Robot().createScreenCapture(new Rectangle(Toolkit.getDefaultToolkit().getScreenSize()));
				ImageIO.write(capture, "jpg", new File(absoluteFileName));
			} else {
				File scrFile = ((TakesScreenshot) BasePage.driver).getScreenshotAs(OutputType.FILE);
				FileUtils.copyFile(scrFile, new File(absoluteFileName));
			}
			Reporter.log(
					"<h1><br>" + BasePage.currentMethodName + "</h1></br> <h2><br>" + filename + ".jpg" + "</h2></br>");

			Reporter.log("<a href='" + absoluteFileName + "'>" + "<img src='" + absoluteFileName
					+ "' height='200' width='200'/> </a>");
			return true;
		} catch (IOException | HeadlessException | AWTException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// this method sets the Execution status in the test execution sheet.
	// Author :- Yogendra Rathore
	public static void setExecutionStatus(String status) {

		// Get test case name and get row number in sheet for that test cases.
		// get row number of cell whose
		int rowNumber = BasePage.xls.getCellRowNum("TestCases", "TCID", BasePage.currentMethodName);

		if (rowNumber < 1)
			log.error("test case id not found in input sheet for " + BasePage.currentMethodName);
		else
			BasePage.xls.setCellData("TestCases", "RunStatus", rowNumber, status);

	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// To wait for a specific time in seconds
	public static void applicationWait(int timeInMilliSeconds) {

		try {
			Thread.sleep(timeInMilliSeconds);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// --------------------------------------------------------------------------------------------------------------------
	// this method adds new column Status to TestExecutionInput.xlsm sheet and
	// sets status to Skipped or Passed as per run mode
	// Author : Yogendra Rathore
	// Modified By : Yogendra Rathore
	// Action 1* Added execution time column
	public static void getSuiteStatusInExcel() {
		String cellData = null;
		int rowCount = 0, i;
		int columnNumberStatus = -1;
		int columnNumberExecutionTime = -1;
		int columnNumberFailureCause = -1;
		int columnNumberStatusOld = -1;
		String columnName = "RunStatus";
		String columnNameForExecutionTimePerTestCase = "ExecutionTime(InMinutes)";
		String columnNameForFailureCausePerTestCase = "FailureCause";
		try {

			System.out.println("Started Accessing TestInputSheet.");

			// add run execution time if not present
			columnNumberFailureCause = BasePage.xls.getColumnNumber("TestCases", columnNameForFailureCausePerTestCase);
			if (columnNumberFailureCause == -1)
				BasePage.xls.addColumn("TestCases", columnNameForFailureCausePerTestCase);

			// Action 1*
			// add run execution time if not present
			columnNumberExecutionTime = BasePage.xls.getColumnNumber("TestCases",
					columnNameForExecutionTimePerTestCase);
			if (columnNumberExecutionTime == -1)

				BasePage.xls.addColumn("TestCases", columnNameForExecutionTimePerTestCase);
			// end of action 1
			// get number of test cases
			rowCount = BasePage.xls.getRowCount("TestCases");

			// remove status column if exists and delete old data:
			columnNumberStatus = BasePage.xls.getColumnNumber("TestCases", columnName);
			if (columnNumberStatus >= 0 && rowCount > 0)

				// set copy data to summary
				BasePage.copyDataToTestSummarySheet = false;

			// remove status column if exists and delete old data:
			columnNumberStatusOld = BasePage.xls.getColumnNumber("TestCases", columnName + "Old");

			if (columnNumberStatusOld != -1) {
				// copy runStatus to RunStatusOld
				for (i = 2; i <= rowCount; i++) {

					cellData = BasePage.xls.getCellData("TestCases",

							columnNumberStatus + 1, i);

					BasePage.xls.setCellData("TestCases", "RunStatusOld", i, cellData);
				}

			} else

				BasePage.xls.setCellData("TestCases", "RunStatus", 1, "RunStatusOld");

			// remove status column if exists and delete old data:
			columnNumberStatus = BasePage.xls.getColumnNumber("TestCases", columnName);

			if (columnNumberStatus != -1) {
				// delete column
				BasePage.xls.removeColumn("TestCases", columnNumberStatus);

			}
			// add new column Status in test Input Sheet.
			BasePage.xls.addColumn("TestCases", columnName);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// --------------------------------------------------------------------------------------------------------------------------------

	// Check whether test data for a test case is blank or not
	public static boolean checkInputDataIsNotBlank(Hashtable<String, String> TestDataSet) {
		boolean testDataIsNotBlank = true;

		Enumeration<String> values = TestDataSet.elements();
		while (values.hasMoreElements() && testDataIsNotBlank) {
			if (values.nextElement() == "") {
				testDataIsNotBlank = false;
			}

		}
		return testDataIsNotBlank;

	}

	// --------------------------------------------------------------------------------------------------------------------------------

	// To get all the column values of a given column based on the index of the
	// column from a 2 D arrray representing the grid of any landing page grid
	public static ArrayList<String> getAllColumnValuesFromTheGridForAGivenColumn(String[][] gridData, int columnIndex) {

		ArrayList<String> listOfDataForSorting = new ArrayList<String>();

		for (int i = 0; i < gridData.length; i++) {
			listOfDataForSorting.add((gridData[i][columnIndex]).toUpperCase());
		}

		return listOfDataForSorting;
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// To check the sorting of a column for both ascending and descending
	public static ArrayList<String> checkSortingOfColumn(

			ArrayList<String> dataForSorting, String sortType, String sortColumnName) throws Exception {

		ArrayList<String> returnValue = new ArrayList<String>();
		// Name of Columns which are in DATE format
		String DateColumn1 = UtilityFunctions.getMultilingualData("ColumnName_UpdatedDate");
		String DateColumn2 = UtilityFunctions.getMultilingualData("ColumnName_CreationDate");

		// Check If Column's are in date format - Go into If condition
		if (sortColumnName.equalsIgnoreCase(DateColumn1) || sortColumnName.equalsIgnoreCase(DateColumn2)) {
			// Logic for converting string array list into Date format
			for (int i = 0; i < dataForSorting.size() - 1; i++) {
				String dateString1 = dataForSorting.get(i);
				String dateString2 = dataForSorting.get(i + 1);
				SimpleDateFormat sdf = BasePage.simpleDateFormat_28;
				Date date1 = null;
				Date date2 = null;
				try {
					date1 = sdf.parse(dateString1);
					date2 = sdf.parse(dateString2);

					// Check Sorting for Ascending Order
					if (sortType.equalsIgnoreCase("ASC")) {

						// logic for sorting
						if (date1.compareTo(date2) > 0) {
							// Return false if data in not sorted
							returnValue.add("false");
							returnValue.add("Date1 " + String.valueOf(date1));
							returnValue.add("Date2 " + String.valueOf(date2));
							return returnValue;
						}
					}
					// Check Sorting for Descending Order
					else {
						// logic for sorting
						if (date1.compareTo(date2) < 0) {
							// Return false if data in not sorted
							returnValue.add("false");
							returnValue.add("Date1 " + String.valueOf(date1));
							returnValue.add("Date2 " + String.valueOf(date2));
							return returnValue;
						}

					}

					returnValue.add("true");
				} catch (Exception e) {
					throw e;
				}

			}
		}
		// Else condition - Check sorting for Column's are Not in date format -
		else {
			// Check Sorting for Ascending Order
			if (sortType.equalsIgnoreCase("ASC")) {
				// logic for sorting
				for (int i = 0; i < dataForSorting.size() - 1; i++) {
					if (dataForSorting.get(i).compareTo(dataForSorting.get(i + 1)) > 0) {
						System.out.println("1st element" + i + " " + dataForSorting.get(i));
						System.out.println("2st element" + i + 1 + " " + dataForSorting.get(i + 1));
						// Return false if data in not sorted
						returnValue.add("false");
						returnValue.add("Record1 " + dataForSorting.get(i));
						returnValue.add("Record2 " + dataForSorting.get(i + 1));
						return returnValue;
					}
				}
			}
			// Check Sorting for Descending Order
			else {
				// logic for sorting
				for (int i = 0; i < dataForSorting.size() - 1; i++) {
					if (dataForSorting.get(i).compareTo(dataForSorting.get(i + 1)) < 0) {
						// Return false if data in not sorted
						returnValue.add("false");
						returnValue.add("Record1 " + dataForSorting.get(i));
						returnValue.add("Record2 " + dataForSorting.get(i + 1));
						return returnValue;
					}
				}
			}
			returnValue.add("true");
		}
		return returnValue;
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// Creates a Fixed Size File. The size should be passed in MBs
	public static String createFixedSizeFile(String fileName, double fileSizeInMB) throws IOException {

		// Method Variable
		Writer output = null;
		double setFileSize;
		double currentFileSize;
		File file;

		// Convert FileSize From MB to Bytes(1048576)
		setFileSize = fileSizeInMB * 1048500;

		// Creating Absolute File Upload Location
		String filePath = fileUploadPath + "\\" + fileName;
		// Create file
		file = new File(filePath);
		file.createNewFile();
		// Write Data into File
		output = new BufferedWriter(new FileWriter(file, true));
		// Get file size in bytes
		currentFileSize = getFileSize(filePath);

		// Write file whilst the size is smaller than setSize
		while (currentFileSize < setFileSize) {
			output.write("Automation team is creating these files to");

			// flush for the file to get updated on size and content
			output.flush();
			currentFileSize = getFileSize(filePath);
		}
		output.close();
		return filePath;
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// Get File size in bytes
	public static long getFileSize(String filename) {
		File file = new File(filename);
		if (!file.exists() || !file.isFile()) {
			return -1;
		}
		return file.length();
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// Get File Name of uploaded Document
	public static String getFileName(String filePath) {
		// Method Variables
		File file;
		String fileName;

		// Creating Absolute File Upload Location
		// filePath = fileUploadPath + filePath;

		file = new File(filePath);
		fileName = file.getName();
		return fileName;
	}

	// --------------------------------------------------------------------------------------------------------------------------------

	// Get the document name and type
	// of a given document "documentName"
	public static ArrayList<String> getDocumentNameAndType(String documentName) {
		// ArrayList To Store The Parts Of A Document Name
		ArrayList<String> documentNameAndType = new ArrayList<String>();

		// Add name of the document after converting to lower case and removing
		// extension
		documentNameAndType.add(documentName.substring(0, documentName.lastIndexOf('.')));

		// Add the Type of the Document
		documentNameAndType.add(documentName.substring(documentName.lastIndexOf('.')));

		return documentNameAndType;
	}

	// Open virtual clip board and perform Copy Paste to the window box
	// Author : Bhupendra Singh Chauhan
	public static void sendKeysToWindowsDialogBox(String str) throws AWTException {

		Robot robot = new Robot();

		StringSelection stringSelection = new StringSelection(str);
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringSelection, null);

		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_V);
		robot.keyRelease(KeyEvent.VK_V);
		robot.keyRelease(KeyEvent.VK_CONTROL);

	}

	// --------------------------------------------------------------------------------------------------------------------------------

	// Execute AutoIt Script exe file
	public static void executeAutoITExeScript(ArrayList<String> fileList, String Type) throws Exception {
		try {
			BasePage.autoIT.winWait(BasePage.fileUploadDialogTitle);
			BasePage.autoIT.winActivate(BasePage.fileUploadDialogTitle);
			String files = "";

			if (Type.equalsIgnoreCase("Image")) {
				String fileUploadPath = System.getProperty("user.dir")
						+ BasePage.TestConfiguration.getProperty("ImagesFolder");

				// Select the default upload path
				sendKeysToWindowsDialogBox(fileUploadPath);
				BasePage.autoIT.sleep(1000);

				// Click on Open Button of File Upload Dialog Box
				BasePage.autoIT.controlClick(BasePage.fileUploadDialogTitle, "", "[CLASS:Button; INSTANCE:1]");

				BasePage.autoIT.sleep(1000);

				String fileToBeUploaded = "\"" + fileList.get(0).toString() + "\"";

				// Enter File name in the File Upload Dialog Box
				sendKeysToWindowsDialogBox(fileToBeUploaded);
			} else if (Type.equalsIgnoreCase("Document")) {
				String fileUploadPath = System.getProperty("user.dir")
						+ BasePage.TestConfiguration.getProperty("FileUploadPath");

				// Select the default upload path
				sendKeysToWindowsDialogBox(fileUploadPath);

				// Click on Open Button of File Upload Dialog Box
				BasePage.autoIT.controlClick(BasePage.fileUploadDialogTitle, "", "[CLASS:Button; INSTANCE:1]");

				BasePage.autoIT.sleep(1000);

				for (int i = 0; i < fileList.size(); i++) {
					files += "\"" + fileList.get(i).toString() + "\"";
				}

				// Enter File name in the File Upload Dialog Box
				sendKeysToWindowsDialogBox(files);

			}
			BasePage.autoIT.sleep(1000);
			// Click on Open Button of File Upload Dialog Box
			BasePage.autoIT.controlClick(BasePage.fileUploadDialogTitle, "", "[CLASS:Button; INSTANCE:1]");

			// Wait until File Upload dialog is closed
			for (int i = 1; i <= 1000 && BasePage.autoIT.winExists(BasePage.fileUploadDialogTitle); i++) {
				UtilityFunctions.applicationWait(10);
			}

		} catch (Exception e) {
			throw e;
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------------------------

	// Generate a random name
	public static String generateRandomString(int stringLength, String charSet) {
		// Method variables
		String stringText = "";
		int charPosition;

		Random random = new Random();

		for (int i = 0; i < stringLength; i++) {
			charPosition = random.nextInt(charSet.length());
			stringText = stringText + Character.toString(charSet.charAt((charPosition)));
		}
		return stringText;
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// need to check
	// To get number Data on landing page's
	public static int checkDataOnLandingPageFromDatabase(String landingPageName) {

		try {

			switch (landingPageName.toUpperCase()) {
			case "PART":
				return DataBaseFunctionsLibraray.getTableRowCount("Part");

			case "FEATURE":
				return DataBaseFunctionsLibraray.getTableRowCount("Feature");

			default:
				return 0;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		}
	}

	// --------------------------------------------------------------------------------------------------------------------------------

	// Generate random string with special characters and length
	public static String getRandomStringContainingSpecialCharacters(int wordlength) {

		if (wordlength < 1)
			wordlength = 1;

		String randomName = UtilityFunctions.generateRandomString(wordlength, char_specialCharacters);
		return randomName;
	}

	// --------------------------------------------------------------------------------------------------------------------------------

	// Generate random string with digits and length
	public static String getRandomStringContainingDigits(int wordlength) {

		if (wordlength < 1)
			wordlength = 1;

		String randomName = UtilityFunctions.generateRandomString(wordlength, char_digits);
		return randomName;
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// Generate random alphanumeric string with a given size
	public static String getRandomStringContainingAlphanumericWithSpaceAndUnderscore(int wordLength) {

		wordLength = wordLength - 4;

		if (wordLength < 4)
			wordLength = 4;

		String randomName = "test" + UtilityFunctions.generateRandomString(wordLength / 4, char_alphabets)
				+ UtilityFunctions.generateRandomString(wordLength / 4, char_digits)
				+ UtilityFunctions.generateRandomString(wordLength / 4, " ")
				+ UtilityFunctions.generateRandomString((wordLength / 4) + (wordLength % 4), "_");
		return randomName;

	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// Generate random alphabets string with a given size
	public static String getRandomStringContainingAlphabets(int wordLength) {

		String randomName = UtilityFunctions.generateRandomString(wordLength, char_alphabets);
		return randomName;

	}

	// --------------------------------------------------------------------------------------------------------------------------------

	// Generating Random String which is used as Record Name
	public static String getRandomRecordName() {
		// Variable declaration for short Name
		String recordName;

		// Random prefix for unique short Name
		Random prefixShortName = new Random();

		// Appending shortName with random digit's
		recordName = "FA Test Data" + prefixShortName.nextInt(9999);

		// Return - Record Name
		return recordName;
	}

	// --------------------------------------------------------------------------------------------------------------------------------

	// This method toggle the case of each character present in the given String
	// All upperCase changes to Lower and vice versa
	public static String toggleCharacterCaseInTheString(String inputString) {
		// Variable String To Store New Toggle String
		String result = "";

		// Logic Which Convert the Case of the string
		for (int i = 0; i < inputString.length(); i++) {
			// Variable to capture single Character
			char currentChar;

			// Capturing Character Of String At Particular Position
			currentChar = inputString.charAt(i);

			// Logic If Particular Character Is of Upper Case change it to Lower
			// Case
			if (Character.isUpperCase(currentChar)) {
				char currentCharToLowerCase = Character.toLowerCase(currentChar);
				result = result + currentCharToLowerCase;
			}
			// Logic If Particular Character Is of Lower Case change it to Upper
			// Case
			else {
				char currentCharToUpperCase = Character.toUpperCase(currentChar);
				result = result + currentCharToUpperCase;
			}
		}

		// Return the Toggled Value Of the Input string
		return result;
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// Method takes X and Y coordinates of Control
	// Left Click using Robot Class
	public static void leftClickUsingRobot(String xCoordinate, String yCoordinate) {
		// Provide wait of 2 Sec to display controls properly
		applicationWait(2000);
		BasePage.robot.mouseMove(Integer.parseInt(xCoordinate), Integer.parseInt(yCoordinate));
		BasePage.robot.mousePress(InputEvent.BUTTON1_MASK); // Left Click
		BasePage.robot.mouseRelease(InputEvent.BUTTON1_MASK);
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// Open Operation Details Panel
	public static void clickOnContextMnuOptions(String xCoordinate, String yCoordinate, String mnuXCoordinate,
			String mnuYCoordinate) {
		try {
			// Click on Context menu
			UtilityFunctions.leftClickUsingRobot(xCoordinate, yCoordinate);
			// Click on Sub menu
			UtilityFunctions.leftClickUsingRobot(mnuXCoordinate, mnuYCoordinate);
		} catch (Exception ex) {
			throw ex;
		}
	}

	// Split the string based on a character passed
	// modified by :Yogendra Rathore
	// action 1*- added logic of spilt array if size is 1;
	public static String[] splitString(String stringToSplit, String characterOnToSplit) {
		String spiltArrary[] = new String[2];
		String spiltArrary1[] = new String[2];
		try {

			spiltArrary = stringToSplit.split(characterOnToSplit);

			// action 1*- added logic of spilt array if size is 1;
			if (spiltArrary.length == 1) {
				spiltArrary1[0] = spiltArrary[0];
				spiltArrary1[1] = "";

				return spiltArrary1;
			}

		} catch (Exception e) {
			System.out.println("Exception in splitString method on UtilityFunctions Page.");

		}
		return spiltArrary;
	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// method to check is process running
	// Author: Yogendra Rathore
	public static boolean isProcessRunning(String serviceName) throws Exception {

		Process p = Runtime.getRuntime().exec("tasklist");
		BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
		String line;
		while ((line = reader.readLine()) != null) {

			// System.out.println(line);
			if (line.contains(serviceName)) {
				return true;
			}
		}

		return false;

	}

	// ---------------------------------------------------------------------------------------------------------------------------------
	// wait till a process is running
	// Author : Yogendra Rathore
	public static void waitTillAProcessIsRunning(String serviceName) {
		try {
			while (isProcessRunning(serviceName)) {

				applicationWait(10000);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------------------
	// method to kill process
	// Author : Yogendra Rathore
	public static void killProcess(String serviceName) {
		try {

			if (isProcessRunning(serviceName)) {
				Runtime.getRuntime().exec("taskkill /F /IM " + serviceName);
				applicationWait(10000);
				System.out.println("***********************************************************************");

				System.out.println("Killed " + serviceName);
				System.out.println("***********************************************************************");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// method to check number of times a service is running
	// Author: Yogendra Rathore
	public static int getNumberOfTimesAProcessIsRunning(String serviceName) throws Exception {

		Process p = Runtime.getRuntime().exec("tasklist");
		BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
		String line;
		int i = 0;
		while ((line = reader.readLine()) != null) {

			// System.out.println(line);
			if (line.contains(serviceName)) {
				i++;
			}
		}

		return i;

	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// method to check is number of times a process is running
	// Author: Yogendra Rathore
	public static int countOfProcessRunning(String serviceName) throws Exception {

		Process p = Runtime.getRuntime().exec("tasklist");
		BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
		String line;
		int i = 0;
		while ((line = reader.readLine()) != null) {

			if (line.contains(serviceName)) {
				i++;
			}
		}

		return i;

	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	/*
	 * Created By: Mohit Mahana Logic: This Method generates a unique string Return
	 * Type: String
	 */
	public static String getUniqueRecordName(LandingPage landingPage, String landingPageName) throws Exception {
		boolean flag = true;
		String shortName = "";
		// Use to Get a unique Short Name
		while (flag) {
			List<String> tempShortName = new ArrayList<String>();// Changed
																	// Reference
																	// from
																	// Array
																	// List
																	// to
																	// List

			// Method Call to generate random Data String
			tempShortName.add(UtilityFunctions.getRandomRecordName());

			// Verify If generated Data Record Already Exists or not
			// from
			// database
			if (!landingPage.checkParticularDataPresentOnLandingPage(tempShortName, landingPageName)) {
				shortName = tempShortName.get(0);// Removed type casting as
													// list already
													// generalized in String
				flag = false;
			}
		}
		return shortName;
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// Read data from the excel file. Takes one argument - Key
	// Reads the test data from the Test Data excel and
	// return the Multilingual in string
	// Author : Chanchal Jain
	// Modified by: Yogendra Rathore
	// Action: Added throw exception in case the value retrieved is blank.
	// Modified by: Yogendra Rathore
	// Action : added multi-lingual from multilingual java page.
	// Modified by: Yogendra Rathore <14-09-2017>
	// Action : added multi-lingual entries when localization is off and logic
	// when locatization is off or on.
	// change by Rakesh Sharma on 25-07-19
	// remove dependency on mapping sheet with XX

	public static String getMultilingualData(String key) {

		String value = "";
		try {
			value = MultiLingualMappingSheetWithLocalizationOff.mapMultiLingualSheet(key);

			if (value.equals("")) {
				System.out.println("Resoruce String not present for Automation Mappying key :" + key);
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.error(key + e.getMessage());
		}
		return value;

	}// end of function

	// --------------------------------------------------------------------------------------------------------------------------------
	// Modified by Rakesh Sharma on 30-07-19
	// updated code to handle seperate method for isLocalizationIsOn and
	// isLocalizationIsOff
	public static String getValueOnBasisOfUserPrefferedLanguageAndKey(int key) throws Exception {
		String value;
		try {
			if (BasePage.isLocalizationIsOn) {
				value = getValueOnBasisOfUserPrefferedLanguageAndKeyWithLocalizationON(key);
			} else {
				value = getValueOnBasisOfUserPrefferedLanguageAndKeyWithLocalizationOFF(key);
			}

			return value;
		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		} // end of function
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// Get value on basis of preffered language and key
	// Author : Yogendra Rathore
	// Modified by :Yogendra Rathore <24-01-2018>
	// Action: Changed column name on the basis of currentLogged in user
	// preffered language
	// Modified by :Yogendra Rathore <25-02-2019>
	// Action: Changed approach to pick data from Excel, now resoruce strings
	// are
	// picked from Jsons.
	// modified by rakesh on 18-04-19
	// change case for default
	// change by Rakesh on 04-06-19
	// handled case if excel language in default
	// change by Rakesh on 25-07-19
	// remove dependency on mapping sheet.
	public static String getValueOnBasisOfUserPrefferedLanguageAndKeyWithLocalizationON(int key) throws Exception {
		try {
			// hardcoded the columnName from excel
			String columnName = "";
			String excelLanugage = BasePage.TestConfiguration.getProperty("UserPrefferedLanguage");

			if (BasePage.current_LoggedIn_User.equals("")
					|| BasePage.current_LoggedIn_User_PrefferedLanugage.equals(excelLanugage))
				columnName = excelLanugage;
			else
				columnName = BasePage.current_LoggedIn_User_PrefferedLanugage;

			if (columnName.equals("Default") && !excelLanugage.equals("Default")) {
				// language would be as per browser's language
				columnName = excelLanugage;
			} else if (columnName.equals("Default")) {
				columnName = "en-US";
			}

			String value = "";

			value = getResourceStringOnBasisOfLanguageLocaleAndKey(columnName, key);
			value = "X" + value + "X";

			return value;
		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		} // end of function
	}

	public static String getValueOnBasisOfUserPrefferedLanguageAndKeyWithLocalizationOFF(int key) throws Exception {
		try {
			// hardcoded the columnName from excel
			String columnName = "";
			String excelLanugage = BasePage.TestConfiguration.getProperty("UserPrefferedLanguage");

			if (BasePage.current_LoggedIn_User.equals("")
					|| BasePage.current_LoggedIn_User_PrefferedLanugage.equals(excelLanugage))
				columnName = excelLanugage;
			else
				columnName = BasePage.current_LoggedIn_User_PrefferedLanugage;

			if (columnName.equals("Default") && !excelLanugage.equals("Default")) {
				// language would be as per browser's language
				columnName = excelLanugage;
			} else if (columnName.equals("Default")) {
				columnName = "en-US";
			}

			String value = "";

			value = getResourceStringOnBasisOfLanguageLocaleAndKey(columnName, key);
			return value;
		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		} // end of function
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// Method gets all configured values in TestExecutionInput.xls
	// @return Hashtable of all config parameters in excel
	// Author : Bhupendra Singh Chauhan
	// Modified By : YOgendra Rathore <30-08-2017>
	// added set email detials
	public static Hashtable<String, String> getConfigDetailsFromExcel() {

		Hashtable<String, String> configSet = new Hashtable<String, String>();

		configSet.put(ExcelUtility.CONFIG_TestSiteURL, BasePage.xls.getCellData("Config",
				ExcelUtility.CONFIG_VALUE_COLUMN, ExcelUtility.CONFIG_TestSiteURL_ROW));
		configSet.put(ExcelUtility.CONFIG_UserName,
				BasePage.xls.getCellData("Config", ExcelUtility.CONFIG_VALUE_COLUMN, ExcelUtility.CONFIG_UserName_ROW));
		configSet.put(ExcelUtility.CONFIG_Password,
				BasePage.xls.getCellData("Config", ExcelUtility.CONFIG_VALUE_COLUMN, ExcelUtility.CONFIG_Password_ROW));
		configSet.put(ExcelUtility.CONFIG_CompanyID, BasePage.xls.getCellData("Config",
				ExcelUtility.CONFIG_VALUE_COLUMN, ExcelUtility.CONFIG_CompanyID_ROW));
		configSet.put(ExcelUtility.CONFIG_Browser,
				BasePage.xls.getCellData("Config", ExcelUtility.CONFIG_VALUE_COLUMN, ExcelUtility.CONFIG_Browser_ROW));
		configSet.put(ExcelUtility.CONFIG_Device_ID, BasePage.xls.getCellData("Config",
				ExcelUtility.CONFIG_VALUE_COLUMN, ExcelUtility.CONFIG_Device_ID_ROW));
		configSet.put(ExcelUtility.CONFIG_DatabaseUrl, BasePage.xls.getCellData("Config",
				ExcelUtility.CONFIG_VALUE_COLUMN, ExcelUtility.CONFIG_DatabaseUrl_ROW));
		configSet.put(ExcelUtility.CONFIG_DatabaseUserName, BasePage.xls.getCellData("Config",
				ExcelUtility.CONFIG_VALUE_COLUMN, ExcelUtility.CONFIG_DatabaseUserName_ROW));
		configSet.put(ExcelUtility.CONFIG_DatabasePassword, BasePage.xls.getCellData("Config",
				ExcelUtility.CONFIG_VALUE_COLUMN, ExcelUtility.CONFIG_DatabasePassword_ROW));
		configSet.put(ExcelUtility.CONFIG_DatabaseName, BasePage.xls.getCellData("Config",
				ExcelUtility.CONFIG_VALUE_COLUMN, ExcelUtility.CONFIG_DatabaseName_ROW));
		configSet.put(ExcelUtility.CONFIG_DataBaseBackUP, BasePage.xls.getCellData("Config",
				ExcelUtility.CONFIG_VALUE_COLUMN, ExcelUtility.CONFIG_DataBaseBackUP_ROW));
		configSet.put(ExcelUtility.CONFIG_NumberOfRecordsInGenericData, BasePage.xls.getCellData("Config",
				ExcelUtility.CONFIG_VALUE_COLUMN, ExcelUtility.CONFIG_NumberOfRecordsInGenericData_ROW));
		configSet.put(ExcelUtility.CONFIG_UserEmail, BasePage.xls.getCellData("Config",
				ExcelUtility.CONFIG_VALUE_COLUMN, ExcelUtility.CONFIG_UserEmail_ROW));

		configSet.put(ExcelUtility.CONFIG_NumberOfCIParallelExecution, BasePage.xls.getCellData("Config",
				ExcelUtility.CONFIG_VALUE_COLUMN, ExcelUtility.CONFIG_NumberOfCIParallelExecution_ROW));

		configSet.put(ExcelUtility.CONFIG_UserPrefferedLanguage, BasePage.xls.getCellData("Config",
				ExcelUtility.CONFIG_VALUE_COLUMN, ExcelUtility.CONFIG_UserPrefferedLanguage_Row));

		// set Email detials from "EmailDetails"
		if (BasePage.xls.checkSheetExists("EmailDetails")) {
			// SendGridHostName
			configSet.put(ExcelUtility.CONFIG_SendGridHostName, BasePage.xls.getCellData("EmailDetails",
					ExcelUtility.CONFIG_VALUE_COLUMN, ExcelUtility.CONFIG_SendGridHostName_ROW));

			// SendGridPortNumbe
			configSet.put(ExcelUtility.CONFIG_SendGridPortNumber, BasePage.xls.getCellData("EmailDetails",
					ExcelUtility.CONFIG_VALUE_COLUMN, ExcelUtility.CONFIG_SendGridPortNumber_ROW));
			// SendGridUserName
			configSet.put(ExcelUtility.CONFIG_SendGridUserName, BasePage.xls.getCellData("EmailDetails",
					ExcelUtility.CONFIG_VALUE_COLUMN, ExcelUtility.CONFIG_SendGridUserName_ROW));
			// SendGridPassword
			configSet.put(ExcelUtility.CONFIG_SendGridPassword, BasePage.xls.getCellData("EmailDetails",
					ExcelUtility.CONFIG_VALUE_COLUMN, ExcelUtility.CONFIG_SendGridPassword_ROW));
			// FromMailUser
			configSet.put(ExcelUtility.CONFIG_FromMailUser, BasePage.xls.getCellData("EmailDetails",
					ExcelUtility.CONFIG_VALUE_COLUMN, ExcelUtility.CONFIG_FromMailUser_ROW));
			// RecipientsList
			configSet.put(ExcelUtility.CONFIG_RecipientsList, BasePage.xls.getCellData("EmailDetails",
					ExcelUtility.CONFIG_VALUE_COLUMN, ExcelUtility.CONFIG_RecipientsList_ROW));
			// DeploymentName
			configSet.put(ExcelUtility.CONFIG_DeploymentName, BasePage.xls.getCellData("EmailDetails",
					ExcelUtility.CONFIG_VALUE_COLUMN, ExcelUtility.CONFIG_DeploymentName_ROW));
		}
		return configSet;
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// To extract the message without <Element Name placeholder> a
	// Author Name: Yogendra Rathore
	public static String extractMessageWithoutElementNamePlaceholder(String message, String elementName) {
		String[] extractedStringsWithoutElementNamePlaceholder;
		String messageWithElementName;
		extractedStringsWithoutElementNamePlaceholder = message.split("<Element Name>");
		messageWithElementName = extractedStringsWithoutElementNamePlaceholder[0] + elementName
				+ extractedStringsWithoutElementNamePlaceholder[1];
		return messageWithElementName;
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// To get absolute xPath from webelement.
	// Author Name: Yogendra Rathore
	// send current as "" blank .
	public static String generateXPATH(WebElement childElement, String current) {
		String childTag = childElement.getTagName();
		if (childTag.equals("html")) {
			return "/html[1]" + current;
		}
		WebElement parentElement = childElement.findElement(By.xpath(".."));
		List<WebElement> childrenElements = parentElement.findElements(By.xpath("*"));
		int count = 0;
		for (int i = 0; i < childrenElements.size(); i++) {
			WebElement childrenElement = childrenElements.get(i);
			String childrenElementTag = childrenElement.getTagName();
			if (childTag.equals(childrenElementTag)) {
				count++;
			}
			if (childElement.equals(childrenElement)) {
				return generateXPATH(parentElement, "/" + childTag + "[" + count + "]" + current);
			}
		}
		return null;
	}

	// --------------------------------------------------------------------------------------------------------------------
	// Set Run mode to No If any Pass Test case is present.
	// Author: Yogendra Rathore
	public static void changeRunModeInTestInputSheet() {
		String cellData = null;
		int rowCount, i;
		int columnNumberStatus = 0;

		try {

			// get column number of column "RunStatus":
			columnNumberStatus = BasePage.xls.getColumnNumber("TestCases", "RunStatusOld");
			if (columnNumberStatus != 0) {

				// get number of test cases
				rowCount = BasePage.xls.getRowCount("TestCases");

				for (i = 2; i <= rowCount; i++) {
					// get cell data for run status
					cellData = BasePage.xls.getCellData("TestCases", columnNumberStatus + 1, i);

					if (cellData.equalsIgnoreCase("PASSED")) {
						// set N for all passed test cases.
						BasePage.xls.setCellData("TestCases", "RunMode", i, "N");
					}

				}
				System.out.println("Completed Updation of Test Cases In Excel.");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// -------------------------------------------------------------------------------------------------------------------------------------
	// get time difference
	// Author :Chanchal Jain
	public static long getTimeDifferenceInMinutes(String date1, String date2) throws Exception {

		Date d1 = null;
		Date d2 = null;
		try {

			d1 = (Date) BasePage.simpleDateFormat_4.parse(date1);
			d2 = (Date) BasePage.simpleDateFormat_4.parse(date2);

			// Get msec from each, and subtract.
			long diff = d2.getTime() - d1.getTime();
			// long diffSeconds = diff / 1000;
			long diffMinutes = diff / (60 * 1000);
			// long diffHours = diff / (60 * 60 * 1000);

			return diffMinutes;
		} catch (Exception e) {
			throw e;
		}

	}

	// --------------------------------------------------------------------------------------------------------------------
	// get total number of test case in Y mode
	// Author : Yogendra Rathore
	public static int getTotalNumberOfTestCasesInYRunMode() {
		String cellData = null;
		int rowCount, i;
		int numberOfTestCases = 0;
		try {
			rowCount = BasePage.xls.getRowCount("TestCases");

			for (i = 2; i <= rowCount; i++) {
				// get cell data for run status
				cellData = BasePage.xls.getCellData("TestCases", "RunMode", i);

				if (cellData.equalsIgnoreCase("Y")) {
					numberOfTestCases++;
				}

			} // end of for

		} catch (Exception e) {
			e.printStackTrace();
		}
		return numberOfTestCases;
	}

	// --------------------------------------------------------------------------------------------------------------------
	// convert date in given timezone
	// Parameters : Time zone and date in "M/dd/yyyy hh:mm a" format
	// Author : Yogendra Rathore
	// modified by rakesh sharma
	// added current time zone as system default
	public static String convertDateInGivenTimeZone(String timezone, String dateInString) throws Exception {

		try {

			String DATE_FORMAT = "M/d/yyyy h:mm a";

			LocalDateTime ldt = LocalDateTime.parse(dateInString, DateTimeFormatter.ofPattern(DATE_FORMAT));

			ZoneId currentZoneId = ZoneOffset.systemDefault();

			// LocalDateTime + ZoneId = ZonedDateTime
			ZonedDateTime asiaZonedDateTime = ldt.atZone(currentZoneId);

			ZoneId newYokZoneId = ZoneId.of(timezone);

			ZonedDateTime nyDateTime = asiaZonedDateTime.withZoneSameInstant(newYokZoneId);

			DateTimeFormatter format1 = DateTimeFormatter.ofPattern(DATE_FORMAT);

			return format1.format(nyDateTime);

		} catch (Exception e) {
			throw e;

		}

	}

	// --------------------------------------------------------------------------------------------------------------------
	// copy "TestCases" sheet of TestExecutionInputSheet to TestSummarySheet
	// Author: Yogendra Rathore
	public static void copyTestCasesSheetToTestSummarySheetFromTestExecutionInputSheet() {
		String cellData = null;
		int rowCountInTestExecutionInputSheet = 0;
		int columnCountInTestExecutionInputSheet = 0;
		String spiltArrary[] = new String[2];

		try {

			// get number number of columns in Test execution sheet
			columnCountInTestExecutionInputSheet = BasePage.xls.getColumnCount("TestCases");
			// get number of rows in Test Input sheet.
			rowCountInTestExecutionInputSheet = BasePage.xls.getRowCount("TestCases");

			// set data in summary sheet.
			for (int i = 1; i <= columnCountInTestExecutionInputSheet; i++) {

				for (int j = 1; j <= rowCountInTestExecutionInputSheet; j++) {
					cellData = BasePage.xls.getCellData("TestCases", i, j);

					if (cellData.contains(".")) {

						spiltArrary = UtilityFunctions.splitString(cellData, "\\.");
						cellData = spiltArrary[0];

					}
					BasePage.xls_Summary.setCellData("TestCases", i, j, cellData);

				}

			}

			// set starting time of execution
			BasePage.xls_Summary.setCellData("ExecutionTime", 1, 2, "StartTime:-");
			BasePage.xls_Summary.setCellData("ExecutionTime", 2, 2, UtilityFunctions.getDateForFilters());

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// this method sets the Execution status in the test Summary sheet.
	// Author :- Yogendra Rathore
	public static void setExecutionStatusInSummarySheet(String status) {

		// Get test case name and get row number in sheet for that test cases.
		// get row number of cell whose
		int rowNumber = BasePage.xls_Summary.getCellRowNum("TestCases", "TCID", BasePage.currentMethodName);
		BasePage.xls_Summary.setCellData("TestCases", "RunStatus", rowNumber, status);

	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// this method sets the Error in the test Summary sheet.
	// Author :- Yogendra Rathore
	public static void setFailureCauseInSummarySheet(String error) {
		try {

			// xls summary
			// add run FailureCause if not present
			int columnNumberExecutionTime = BasePage.xls_Summary.getColumnNumber("TestCases", "FailureCause");
			if (columnNumberExecutionTime == -1)
				BasePage.xls_Summary.addColumn("TestCases", "FailureCause");
			// Get test case name and get row number in sheet for that test
			// cases.
			// get row number of cell whose
			int rowNumber = BasePage.xls_Summary.getCellRowNum("TestCases", "TCID", BasePage.currentMethodName);
			if (rowNumber != -1)
				BasePage.xls_Summary.setCellData("TestCases", "FailureCause", rowNumber, error);

			// / do for xls
			// add run FailureCause if not present
			columnNumberExecutionTime = BasePage.xls.getColumnNumber("TestCases", "FailureCause");
			if (columnNumberExecutionTime == -1)
				BasePage.xls.addColumn("TestCases", "FailureCause");
			// Get test case name and get row number in sheet for that test
			// cases.
			// get row number of cell whose
			rowNumber = BasePage.xls.getCellRowNum("TestCases", "TCID", BasePage.currentMethodName);
			if (rowNumber != -1) {
				BasePage.xls.setCellData("TestCases", "FailureCause", rowNumber, error);

			}

		} catch (Exception e) {
			e.printStackTrace();
			;
		}
	}

	// --------------------------------------------------------------------------------------------------------------------
	// get total number of passed and failed test cases from summary sheet
	// Author : Yogendra Rathore
	public static Hashtable<String, String> getPassedFailedStatusFromSummarySheet() {
		String cellData = null;
		int rowCount = 0, i;
		int failedCount = 0, passedCount = 0, skippedCount = 0, blankCount = 0;

		Hashtable<String, String> result = new Hashtable<String, String>();
		try {
			rowCount = BasePage.xls_Summary.getRowCount("TestCases");
			result.put("Total_TestCases", String.valueOf(rowCount - 1));

			for (i = 2; i <= rowCount; i++) {
				// get cell data for run status
				cellData = BasePage.xls_Summary.getCellData("TestCases", "RunStatus", i);

				if (cellData.equalsIgnoreCase("PASSED")) {
					passedCount++;
				} else if (cellData.equalsIgnoreCase("FAILED")) {
					failedCount++;
				} else if (cellData.equalsIgnoreCase("SKIPPED")) {
					skippedCount++;
				} else
					blankCount++;

			} // end of for

			result.put("Passed_TestCases", String.valueOf(passedCount));
			result.put("Failed_TestCases", String.valueOf(failedCount));
			result.put("Skipped_TestCases", String.valueOf(skippedCount));
			result.put("NoStatus_TestCases", String.valueOf(blankCount));

			// clear data in summary sheet if present.
			// delete sheet
			BasePage.xls_Summary.removeSheet("Summary");

			// create new sheet
			BasePage.xls_Summary.addSheet("Summary");

			// write status in excel sheet
			// Passed
			BasePage.xls_Summary.setCellData("Summary", 2, 1, "PASSED");
			// Failed
			BasePage.xls_Summary.setCellData("Summary", 3, 1, "FAILED");
			// Skipped
			BasePage.xls_Summary.setCellData("Summary", 4, 1, "SKIPPED");

			// No Status count
			BasePage.xls_Summary.setCellData("Summary", 5, 1, "BLANK");
			// Total count
			BasePage.xls_Summary.setCellData("Summary", 6, 1, "TOTAL");

			BasePage.xls_Summary.setCellData("Summary", 1, 2, "COUNT");

			// Passed count
			BasePage.xls_Summary.setCellData("Summary", 2, 2, String.valueOf(passedCount));
			// Failed count
			BasePage.xls_Summary.setCellData("Summary", 3, 2, String.valueOf(failedCount));
			// Skipped count
			BasePage.xls_Summary.setCellData("Summary", 4, 2, String.valueOf(skippedCount));

			// No Status count
			BasePage.xls_Summary.setCellData("Summary", 5, 2, String.valueOf(blankCount));
			// Total
			BasePage.xls_Summary.setCellData("Summary", 6, 2, String.valueOf(String.valueOf(rowCount - 1)));

			// set end time of execution
			BasePage.xls_Summary.setCellData("ExecutionTime", 1, 3, "EndTime:-");
			BasePage.xls_Summary.setCellData("ExecutionTime", 2, 3, UtilityFunctions.getDateForFilters());

			if (setSkippedStatus) {
				BasePage.xls_Summary.setCellData("Summary", 2, 5, "SKIPPED DETAILED STATUS");

				// skippedDueToTestCaseInDesignState

				BasePage.xls_Summary.setCellData("Summary", 3, 6, "Test Case In Design State");

				BasePage.xls_Summary.setCellData("Summary", 4, 6, String.valueOf(skippedDueToTestCaseInDesignState));

				// skippedDueToTestCaseInClosedState);
				BasePage.xls_Summary.setCellData("Summary", 3, 7, "Test Case In Closed State");

				BasePage.xls_Summary.setCellData("Summary", 4, 7, String.valueOf(skippedDueToTestCaseInClosedState));

				// skippedDueToTestCaseIsInScriptMaintenance);
				BasePage.xls_Summary.setCellData("Summary", 3, 8, "TestCase Is In Script Maintenance");

				BasePage.xls_Summary.setCellData("Summary", 4, 8,
						String.valueOf(skippedDueToTestCaseIsInScriptMaintenance));

				// skippedDueToTestCaseIsNotAutomable
				BasePage.xls_Summary.setCellData("Summary", 3, 9, "Test Case Is Not Automable");

				BasePage.xls_Summary.setCellData("Summary", 4, 9, String.valueOf(skippedDueToTestCaseIsNotAutomable));

				// skippedDueToTestCaseIsNotAutomated
				BasePage.xls_Summary.setCellData("Summary", 3, 10, "Test Case Is Not Automated ");

				BasePage.xls_Summary.setCellData("Summary", 4, 10, String.valueOf(skippedDueToTestCaseIsNotAutomated));

				// skippedDueToTestCaseIsNotInScope);
				BasePage.xls_Summary.setCellData("Summary", 3, 11, "Test Case Is Not In Scope");

				BasePage.xls_Summary.setCellData("Summary", 4, 11, String.valueOf(skippedDueToTestCaseIsNotInScope));

				// skippedDueToTestCaseIsBlocked);
				BasePage.xls_Summary.setCellData("Summary", 3, 12, "Test Case Is Blocked ");

				BasePage.xls_Summary.setCellData("Summary", 4, 12, String.valueOf(skippedDueToTestCaseIsBlocked));

			}
		} catch (Exception e) {
			log.error("Error in : getPassedFailedStatusFromSummarySheet-" + e);

		}
		return result;
	}

	// --------------------------------------------------------------------------------------------------------------------
	// check list of String type is sorted
	// Author : Yogendra Rathore
	public static boolean isSorted(List<String> list) {
		String previous = "";

		for (String current : list) {
			current = current.toLowerCase();

			if (current.compareTo(previous) < 0)

				return false;

			previous = current;

		}
		return true;
	}

	// --------------------------------------------------------------------------------------------------------------------
	// get focus back on browser winodw by opening alert and closing it.
	// Author : Yogendra Rathore
	public static void getFocusOnBrowserWindow() throws Exception {
		JavascriptExecutor javascript = (JavascriptExecutor) BasePage.driver;
		javascript.executeScript("alert('Focus Is On Broswer Window Now.');");

		UtilityFunctions.applicationWait(2000);
		Alert alert = BasePage.driver.switchTo().alert();
		// click on OK to accept
		alert.accept();
		try {
		} catch (Exception e) {
			throw new Exception("UtilityFunctions -  getFocusOnBrowserWindow " + e);
		}
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// this method throws the exception with standard syntax
	// Author :- Rakesh Kumar Sharma
	// added line number information. date: 29-01-2019. removed line number on
	// 15-03-19
	public static String throwException(Thread callingMethodThread, Exception e) throws Exception {

		throw new Exception("Error in method " + callingMethodThread.getStackTrace()[2].getMethodName() + " on page "
				+ callingMethodThread.getStackTrace()[2].getClassName() + " "
				/*
				 * + "on line number " + callingMethodThread.getStackTrace()[2].getLineNumber()
				 * + " "
				 */ + e);
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// this method creates a folder at given location.
	// Author :- Yogendra Rathore

	public static void createFolderAtGivenLocation(String location, String folderName) {

		try {

			final String srcFolder = location + "\\" + folderName;

			File theDir = new File(srcFolder);

			// if the directory does not exist, create it
			if (!theDir.exists())

				// make directory
				theDir.mkdir();

		} catch (Exception e) {
			log.error("createFolderAtGivenLocation :", e);

		}

	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// check folder exists at given location.
	// Author :- Yogendra Rathore

	public static boolean checkFolderExistsAtGivenLocation(String location, String folderName) {

		try {

			final String srcFolder = location + "\\" + folderName;

			File theDir = new File(srcFolder);

			// if the directory does not exist, create it
			return theDir.exists();

		} catch (Exception e) {
			log.error("checkFolderExistsAtGivenLocation :", e);

		}
		return false;

	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// delete folder at given location.
	// Author :- Yogendra Rathore

	public static void deleteFolderAtGivenLocation(String location, String folderName) {

		try {

			final String srcFolder = location + "\\" + folderName;

			File directory = new File(srcFolder);

			// make sure directory exists
			if (directory.exists())

				deleteFile(directory);
			else
				System.out.println("Folder doesnt exist to delete :" + srcFolder);

		} catch (Exception e) {
			log.error("deleteFolderAtGivenLocation :", e);

		}

	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// delete file
	// Author :- Yogendra Rathore
	public static void deleteFile(File file) throws IOException {

		if (file.isDirectory()) {

			// directory is empty, then delete it
			if (file.list().length == 0) {

				file.delete();

			} else {

				// list all the directory contents
				String files[] = file.list();

				for (String temp : files) {
					// construct the file structure
					File fileDelete = new File(file, temp);

					// recursive delete
					deleteFile(fileDelete);
				}

				// check the directory again, if empty then delete it
				if (file.list().length == 0) {
					file.delete();

				}
			}

		} else {
			// if file, then delete it
			file.delete();

		}

	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// move file from one location to another
	// Author :- Yogendra Rathore

	public static void moveFileFromSrcToDest(String source, String destination, String fileNameWithExtension) {

		try {
			File src = new File(source);
			File dest = new File(destination);

			FileUtils.copyDirectory(src, dest);

		} catch (Exception e) {
			log.error("moveFileFromSrcToDest  :", e);

		}

	}

	// ------------------------------------------------------------------------------------------------------------------------
	// create excel file at given location with sheets

	// Author :yogendra Rathore

	public static void createExlFileWithGivenSheetName(String fileName, List<String> sheetNames) {
		try {

			XSSFWorkbook workbook = new XSSFWorkbook();

			for (int i = 0; i < sheetNames.size(); i++)
				workbook.createSheet(sheetNames.get(i));

			FileOutputStream fileOut = new FileOutputStream(fileName);
			workbook.write(fileOut);
			fileOut.close();

		} catch (Exception ex) {
			log.error("createExlFile  :", ex);
		}

	}

	// ------------------------------------------------------------------------------------------------------------------------
	// combine test summary sheets to 1 combined sheet. .
	// Author :yogendra Rathore
	public static void combineExcelSheets(Hashtable<String, String> testData, int numberOfParallelExecutions) {
		try {
			System.out.println("Started combining " + numberOfParallelExecutions + " Sheets at "
					+ UtilityFunctions.getDateForFilters());
			String combinedExcel = testData.get("combinedExcel");
			String sheet = "";
			String cellData = null;
			int rowCountInCombinedExcel = 0, rowCountInTestSummarySheet = 0, rowNumberOfCombinedExcel = 0;
			int columnCountInSheet = 0;
			String spiltArrary[] = new String[2];
			ExcelUtility xls_combinedExcel = new ExcelUtility(combinedExcel);
			ExcelUtility xls_testSummarySheet;

			// copy firs sheet directly.
			// get column number of first sheet., column numbers should be same
			// in all the sheets.
			// intialize variable of xls
			sheet = testData.get("sheet1");
			xls_testSummarySheet = new ExcelUtility(sheet);

			// get number number of columns in test summary sheet
			columnCountInSheet = xls_testSummarySheet.getColumnCount("TestCases");

			// get number of rows in Test Input sheet.
			rowCountInTestSummarySheet = xls_testSummarySheet.getRowCount("TestCases");

			// set data in summary sheet for first excel.
			for (int columnNumber = 1; columnNumber <= columnCountInSheet; columnNumber++) {

				for (int rowNumber = 1; rowNumber <= rowCountInTestSummarySheet; rowNumber++) {
					cellData = xls_testSummarySheet.getCellData("TestCases", columnNumber, rowNumber);

					if (cellData.contains(".")) {

						spiltArrary = UtilityFunctions.splitString(cellData, "\\.");
						cellData = spiltArrary[0];

					}
					// set cell data in main excel.
					rowNumberOfCombinedExcel = rowCountInCombinedExcel + rowNumber;
					xls_combinedExcel.setCellData("TestCases", columnNumber, rowNumberOfCombinedExcel, cellData);

				}

			}

			// assing row count in combined excel
			rowCountInCombinedExcel = rowNumberOfCombinedExcel;

			// copy excel in combined excel if more than 2

			for (int i = 2; i <= numberOfParallelExecutions; i++) {
				// intialize variable of xls
				sheet = testData.get("sheet" + i);
				xls_testSummarySheet = new ExcelUtility(sheet);

				// get number of rows in Test Input sheet.
				rowCountInTestSummarySheet = xls_testSummarySheet.getRowCount("TestCases");

				// set data in summary sheet for first excel.
				for (int columnNumber = 1; columnNumber <= columnCountInSheet; columnNumber++) {
					// skip 1st row as it column headers which already taken in
					// first sheet. so rowNumber=2
					for (int rowNumber = 2; rowNumber <= rowCountInTestSummarySheet; rowNumber++) {
						cellData = xls_testSummarySheet.getCellData("TestCases", columnNumber, rowNumber);

						if (cellData.contains(".")) {

							spiltArrary = UtilityFunctions.splitString(cellData, "\\.");
							cellData = spiltArrary[0];

						}
						// set cell data in main excel.
						rowNumberOfCombinedExcel = rowCountInCombinedExcel + rowNumber - 1;
						xls_combinedExcel.setCellData("TestCases", columnNumber, rowNumberOfCombinedExcel, cellData);

					}

				}

				// assing row count in combined excel
				rowCountInCombinedExcel = rowNumberOfCombinedExcel;
				System.out.println("Combined result for " + i + " Sheets at " + UtilityFunctions.getDateForFilters());
			}

		} catch (Exception ex) {

			log.error("combineTestSheetsAndGetStatus  :", ex);
		}

	}

	// ------------------------------------------------------------------------------------------------------------------------
	// create combinedTestSummaryExcel , set start time, number of parrallel
	// executions in it.
	// Author :yogendra Rathore

	public static void createCombinedSummaryExcelAndSetStartExecutionTime(String folderNameWithPath,
			int numberOfExecutions, String excelName, List<String> sheetName) {
		try {

			// create excel for combined executions status, combined
			// execution time, total number of parrallel execution.

			UtilityFunctions.createExlFileWithGivenSheetName(folderNameWithPath + "\\" + excelName, sheetName);

			ExcelUtility xls = new ExcelUtility(folderNameWithPath + "\\" + excelName);

			// set starting time of execution
			xls.setCellData("ExecutionTime", 1, 1, "StartTime:-");
			xls.setCellData("ExecutionTime", 2, 1, UtilityFunctions.getDateForFilters());

			// set number of executions.
			xls.setCellData("NumberOfExecutions", 1, 1, "NumberOfExecutions");
			xls.setCellData("NumberOfExecutions", 2, 1, String.valueOf(numberOfExecutions));

		} catch (Exception ex) {

			log.error("createCombinedSummaryExcelAndSetStartExecutionTime  :", ex);
		}

	}

	// ------------------------------------------------------------------------------------------------------------------------
	// check to shoot mail at end of CI execution.and decrease the humber of
	// executions by 1 and set end time of execution.
	// Author :yogendra Rathore

	public static boolean checkToShootMailAtEndOfExecutions(String folderNameWithPath, String excelName) {
		try {
			int numberOfExecutions = 0;
			String executionResultsSheet = "ExecutionResultsSheet.xlsx";
			ExcelUtility xls = new ExcelUtility(folderNameWithPath + "\\" + excelName);

			numberOfExecutions = Integer.parseInt(xls.getCellData("NumberOfExecutions", 2, 1));

			// copy executionResults sheet from CI folder to common replository
			// so that other can
			// access it.
			UtilityFunctions
					.moveFileFromSrcToDest(
							System.getProperty("user.dir")
									+ BasePage.TestConfiguration.getProperty("TestSummarySheetPath") + "\\..",
							folderNameWithPath, executionResultsSheet);

			// rename file.
			UtilityFunctions.renameFile(folderNameWithPath + "\\" + executionResultsSheet,
					folderNameWithPath + "\\" + "ExecutionResultsSheet" + numberOfExecutions + ".xlsx");

			if (numberOfExecutions == 1) {
				// set end time of execution
				xls.setCellData("ExecutionTime", 1, 2, "EndTime:-");
				xls.setCellData("ExecutionTime", 2, 2, UtilityFunctions.getDateForFilters());

				// kill chrome driver
				UtilityFunctions.killProcess("chromedriver.exe");

				return true;

			} else {
				// set number of executions.
				xls.setCellData("NumberOfExecutions", 1, 1, "NumberOfExecutions");
				xls.setCellData("NumberOfExecutions", 2, 1, String.valueOf(numberOfExecutions - 1));

				return false;

			}

		} catch (Exception ex) {

			log.error("checkToShootMailAtEndOfExecutions  :", ex);
		}
		return false;

	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// rename file
	// Author :- Yogendra Rathore

	public static void renameFile(String oldName, String newName) {

		try {
			File file = new File(oldName);

			// File (or directory) with new name
			File file2 = new File(newName);

			if (file2.exists())
				throw new java.io.IOException("file exists");

			// Rename file (or directory)
			boolean success = file.renameTo(file2);

			if (!success) {
				System.out.println("File not renamed:");
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("renameFileFromSrcToDest  :", e);

		}

	}

	// ------------------------------------------------------------------------------------------------------------------------
	// combine test summary sheets and get status
	// Author :yogendra Rathore
	// Modifed By : Yogendra Rathore
	// Action1*
	// Modifed By : Yogendra Rathore <19-04-2019>
	// Action1*-- added code to copy blank and skipped test cases also in final
	// mail
	// Modifed By : Yogendra Rathore <13-06-2019>
	// Action-- added code to copy header
	// Modified By: Neha Goyal <28-08-2019>
	// Action--Change row count mapping for Blank status
	public static Hashtable<String, String> combineTestSheetsAndGetStatus(int numberOfParallelExecutions,
			String folderNameWithPath, String excelName, String parentFolderForFinalRun) {
		String cellData = null;
		int rowCount = 0, i;
		int failedCount = 0, passedCount = 0, skippedCount = 0, blankCount = 0;
		int rowCount1 = 1;
		Hashtable<String, String> result = new Hashtable<String, String>();
		String cellData1 = "";
		int columnCount = 0;
		List<String> sheetNames = new ArrayList<String>();
		sheetNames.add("TestCases");

		try {
			boolean copyHeader = true;
			Hashtable<String, String> testData = new Hashtable<String, String>();

			// Action 1* remove "TestCases" sheet of TestExecutionInput Sheet of
			// parentFolderForFinalRun folder and create copy failed test cases
			// data in new
			// TestCases Sheet.

			ExcelUtility xls_1 = new ExcelUtility(folderNameWithPath + "\\..\\" + parentFolderForFinalRun
					+ "\\framework\\src\\Test Data\\TestExecutionInput.xlsm");

			// delete sheet
			xls_1.removeSheet("TestCases");

			// make connection again.
			xls_1 = new ExcelUtility(folderNameWithPath + "\\..\\" + parentFolderForFinalRun
					+ "\\framework\\src\\Test Data\\TestExecutionInput.xlsm");

			UtilityFunctions.applicationWait(2000);
			// add sheet
			xls_1.addSheet("TestCases");

			// combine excel
			testData.put("combinedExcel", folderNameWithPath + "\\" + excelName);

			// set location of sheets as per number of parrallel execution.
			for (i = 1; i <= numberOfParallelExecutions; i++) {
				testData.put("sheet" + i, folderNameWithPath + "\\" + "ExecutionResultsSheet" + i + ".xlsx");
			}

			// combine excel sheets
			combineExcelSheets(testData, numberOfParallelExecutions);

			UtilityFunctions.applicationWait(2000);
			ExcelUtility xls = new ExcelUtility(folderNameWithPath + "\\" + excelName);
			// create summary sheet.
			rowCount = xls.getRowCount("TestCases");
			columnCount = xls.getColumnCount("TestCases");
			result.put("Total_TestCases", String.valueOf(rowCount - 1));

			for (i = 2; i <= rowCount; i++) {

				// get cell data for run status
				cellData = xls.getCellData("TestCases", "RunStatus", i);

				if (cellData.equalsIgnoreCase("PASSED")) {
					passedCount++;
				} else if (cellData.equalsIgnoreCase("FAILED")) {
					// set flag to true
					BasePage.executeFailedTestCasesOfAllFolderInSingleSuite = true;

					failedCount++;

					// Action 1* copy data to TestExecutionInput of CI1 folder.

					// copy header first
					if (copyHeader) {
						cellData1 = xls_1.getCellData("TestCases", 1, 1);
						if (cellData1.equals("")) {

							for (int j = 1; j < columnCount; j++) {
								cellData1 = xls.getCellData("TestCases", j, 1);

								if (cellData1.contains(".")) {
									String spiltArrary[] = new String[2];
									spiltArrary = UtilityFunctions.splitString(cellData1, "\\.");
									cellData1 = spiltArrary[0];

								}
								xls_1.setCellData("TestCases", j, rowCount1, cellData1);

							} // end of for loop
								// increase row count by 1
							rowCount1++;
						} // Header copied
						copyHeader = false;
					}
					// copy data to new excel for failed test cases
					// j is less then ColumnCount as we don't want to copy
					// RunStatus and it is the last column of the sheet.
					for (int j = 1; j < columnCount; j++) {

						// set cell data
						cellData1 = xls.getCellData("TestCases", j, i);

						if (cellData1.contains(".")) {
							String spiltArrary[] = new String[2];
							spiltArrary = UtilityFunctions.splitString(cellData1, "\\.");
							cellData1 = spiltArrary[0];

						}
						xls_1.setCellData("TestCases", j, rowCount1, cellData1);

					}
					// increase row count by one.
					rowCount1++;

				} else if (cellData.equalsIgnoreCase("SKIPPED")) {
					skippedCount++;

					// copy header first
					if (copyHeader) {
						cellData1 = xls_1.getCellData("TestCases", 1, 1);
						if (cellData1.equals("")) {

							for (int j = 1; j < columnCount; j++) {
								cellData1 = xls.getCellData("TestCases", j, 1);

								if (cellData1.contains(".")) {
									String spiltArrary[] = new String[2];
									spiltArrary = UtilityFunctions.splitString(cellData1, "\\.");
									cellData1 = spiltArrary[0];

								}
								xls_1.setCellData("TestCases", j, rowCount1, cellData1);

							} // end of for loop
								// increase row count by 1
							rowCount1++;
						} // Header copied
						copyHeader = false;
					}

					for (int j = 1; j < columnCount; j++) {

						// set cell data
						cellData1 = xls.getCellData("TestCases", j, i);

						if (cellData1.contains(".")) {
							String spiltArrary[] = new String[2];
							spiltArrary = UtilityFunctions.splitString(cellData1, "\\.");
							cellData1 = spiltArrary[0];

						}
						xls_1.setCellData("TestCases", j, rowCount1, cellData1);

					}
					// increase row count by one.
					rowCount1++;

				} else {
					blankCount++;
					// copy header first
					if (copyHeader) {
						cellData1 = xls_1.getCellData("TestCases", 1, 1);
						if (cellData1.equals("")) {

							for (int j = 1; j < columnCount; j++) {
								cellData1 = xls.getCellData("TestCases", j, 1);

								if (cellData1.contains(".")) {
									String spiltArrary[] = new String[2];
									spiltArrary = UtilityFunctions.splitString(cellData1, "\\.");
									cellData1 = spiltArrary[0];

								}
								xls_1.setCellData("TestCases", j, rowCount1, cellData1);

							} // end of for loop
								// increase row count by 1
							rowCount1++;
						} // Header copied
						copyHeader = false;
					}
					for (int j = 1; j < columnCount; j++) {

						// set cell data
						cellData1 = xls.getCellData("TestCases", j, i);

						if (cellData1.contains(".")) {
							String spiltArrary[] = new String[2];
							spiltArrary = UtilityFunctions.splitString(cellData1, "\\.");
							cellData1 = spiltArrary[0];

						}
						xls_1.setCellData("TestCases", j, rowCount1, cellData1);

						// increase row count by one.

					}
					rowCount1++;
				}

			} // end of for

			result.put("Passed_TestCases", String.valueOf(passedCount));
			result.put("Failed_TestCases", String.valueOf(failedCount));
			result.put("Skipped_TestCases", String.valueOf(skippedCount));
			result.put("NoStatus_TestCases", String.valueOf(blankCount));

			// write status in excel sheet
			// Passed
			xls.setCellData("Summary", 2, 1, "PASSED");
			// Failed
			xls.setCellData("Summary", 3, 1, "FAILED");
			// Skipped
			xls.setCellData("Summary", 4, 1, "SKIPPED");

			// No Status count
			xls.setCellData("Summary", 5, 1, "BLANK");
			// Total count
			xls.setCellData("Summary", 6, 1, "TOTAL");

			xls.setCellData("Summary", 1, 2, "COUNT");

			// Passed count
			xls.setCellData("Summary", 2, 2, String.valueOf(passedCount));
			// Failed count
			xls.setCellData("Summary", 3, 2, String.valueOf(failedCount));
			// Skipped count
			xls.setCellData("Summary", 4, 2, String.valueOf(skippedCount));

			// No Status count
			xls.setCellData("Summary", 5, 2, String.valueOf(blankCount));
			// Total
			xls.setCellData("Summary", 6, 2, String.valueOf(String.valueOf(rowCount - 1)));

		} catch (Exception ex) {

			log.error("combineTestSheetsAndGetStatus  :", ex);
		}
		return result;
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// this method returns Starts time and end time of execution.
	// Author :- Yogendra Rathore
	// this method supress exception as we dont want this to stop from sending
	// report.
	public static String getStartTimeAndEndTimeOfExecution(String folderNameWithPath, String excelName) {
		String timeSpan = "";

		try {
			ExcelUtility xls = new ExcelUtility(folderNameWithPath + "\\" + excelName);
			timeSpan = xls.getCellData("ExecutionTime", 1, 1) + xls.getCellData("ExecutionTime", 2, 1) + "      "
					+ xls.getCellData("ExecutionTime", 1, 2) + xls.getCellData("ExecutionTime", 2, 2);

		} catch (Exception e) {
			log.error("Not able to get Execution Time :", e);
			return "";
		}
		return timeSpan;
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// kick of execution and wait till execution is in progress
	// Author :- Yogendra Rathore
	// this method supress exception as we dont want this to stop from sending
	// report.
	public static String kickOfExecution(String folderNameWithPath, String excelName) {
		String timeSpan = "";

		try {
			ExcelUtility xls = new ExcelUtility(folderNameWithPath + "\\" + excelName);
			timeSpan = xls.getCellData("ExecutionTime", 1, 1) + xls.getCellData("ExecutionTime", 2, 1) + "      "
					+ xls.getCellData("ExecutionTime", 1, 2) + xls.getCellData("ExecutionTime", 2, 2);

		} catch (Exception e) {
			log.error("Not able to get Execution Time :", e);
			return "";
		}
		return timeSpan;
	}

	// -----------------------------------------------------------------------------------------------------
	// Get list of files and folders of a directory
	// Author: Yogendra Rathore

	public static List<String> listFilesAndFolders(String directoryName) {
		List<String> listOfFilesAndFolders = new ArrayList<String>();
		File directory = new File(directoryName);
		// get all the files from a directory
		File[] fList = directory.listFiles();
		for (File file : fList) {
			listOfFilesAndFolders.add(file.getName());
		}
		return listOfFilesAndFolders;
	}

	// ------------------------------------------------------------------------------------------------------------------------
	// getDataForSharedStepsReRun
	// Author :yogendra Rathore

	public static void getDataForSharedStepsReRun() {
		String cellData = null, cellData1 = null;
		int rowCount = 0, i;

		try {
			// get shared steps list of test cases as keys and FailedSteps as
			// values.
			// get row and column count
			rowCount = BasePage.xls_Summary.getRowCount("SharedSteps");

			for (i = 2; i <= rowCount; i++) {

				// get cell data for run status
				cellData = BasePage.xls_Summary.getCellData("SharedSteps", "TestCases", i);
				cellData1 = BasePage.xls_Summary.getCellData("SharedSteps", "FailedSteps", i);

				BasePage.sharedStepsPassFailStatus.put(cellData, cellData1);

			} // end of for

		} catch (Exception ex) {

			log.error("getDataForSharedStepsReRun  :", ex);
		}

	}

	// ------------------------------------------------------------------------------------------------------------------------
	// setDataForSharedStepsReRun
	// Author :yogendra Rathore

	public static void setDataForSharedStepsReRun() {
		String cellData = null, cellData1 = null;

		try {

			// delete sheet for "SharedSteps" time
			BasePage.xls_Summary.removeSheet("SharedSteps");

			// Action 1* : added shared Steps sheet
			// create new sheet
			BasePage.xls_Summary.addSheet("SharedSteps");

			// add new columns "TestCases" and "FailedSteps" in test Input
			// Sheet.
			BasePage.xls_Summary.addColumn("SharedSteps", "TestCases");

			BasePage.xls_Summary.addColumn("SharedSteps", "FailedSteps");

			// get shared steps list of test cases as keys and FailedSteps as
			// values.
			// get row and column count

			Set<String> keys = BasePage.sharedStepsPassFailStatus.keySet();
			int row = 2;
			// set cell data
			for (String key : keys) {

				cellData = key;
				cellData1 = BasePage.sharedStepsPassFailStatus.get(key);

				// set cell data
				BasePage.xls_Summary.setCellData("SharedSteps", 1, row, cellData);
				BasePage.xls_Summary.setCellData("SharedSteps", 2, row, cellData1);
				row++;
			}

		} catch (Exception ex) {

			log.error("setDataForSharedStepsReRun :", ex);
		}

	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// set licnese count
	// Author : Yogendra Rathore
	// modified by : Yogendra Rathore <26-07-18>
	// commented the code as this fucntionality is not loger valid

	public static void setLicenseCount(int numberOfLicenses) {
		try {

			/*
			 * String deleteLotStatusDetailQuery =
			 * "update licenseinfo set NumberOfLicenses=" + numberOfLicenses; // execute
			 * delete feature query DataBaseFunctionsLibraray
			 * .executeDeleteUpdatedAndInsertQuery(deleteLotStatusDetailQuery);
			 */

		} catch (Exception e) {
			e.printStackTrace();
		}

	}// end of function

	// --------------------------------------------------------------------------------------------------------------------------------
	// get Current Date In Given Format
	// Author - Yogendra Rathore

	public static String getCurrentDateInGivenFormat(SimpleDateFormat simpleDateFormat) throws Exception {

		try {
			Date date = new Date();
			return simpleDateFormat.format(date);

		} catch (Exception e) {

			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));

		}

	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// this method sets the Execution time in the test input and test Summary
	// sheet.
	// Author :- Yogendra Rathore
	public static void setExecutionTimeInExcelSheet(String time, ExcelUtility xls_object) {

		// Get test case name and get row number in sheet for that test cases.
		// get row number of cell whose
		int rowNumber = xls_object.getCellRowNum("TestCases", "TCID", BasePage.currentMethodName);
		xls_object.setCellData("TestCases", "ExecutionTime(InMinutes)", rowNumber, time);

	}

	// -------------------------------------------------------------------------------------------------------------------------------------
	// get time difference in seconds
	// Author :Yogendra
	// modified by: rakesh sharma
	// check for null date
	public static long getTimeDifferenceInSeconds(String date1, String date2) throws Exception {
		SimpleDateFormat dbDateFormat = BasePage.simpleDateFormat_1;
		Date d1 = null;
		Date d2 = null;
		long diffSeconds = 0;
		try {
			if (!date1.equals("")) {
				d1 = (Date) dbDateFormat.parse(date1);
				d2 = (Date) dbDateFormat.parse(date2);

				// Get msec from each, and subtract.
				long diff = d2.getTime() - d1.getTime();
				diffSeconds = diff / 1000;
			}
			return diffSeconds;
		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}

	}

	// -------------------------------------------------------------------------------------------------------------------------------------
	// set Caps lock key and return true if On
	// Author :Yogendra
	public static void setCapsLockKey(boolean state) throws Exception {

		try {

			Toolkit.getDefaultToolkit().setLockingKeyState(KeyEvent.VK_CAPS_LOCK, state);

		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}

	}

	// -------------------------------------------------------------------------------------------------------------------------------------
	// check password expiration date is surpased
	// Author :Yogendra
	public static boolean checkPasswordExpirationDateSurpassed(String userName) throws Exception {

		try {
			SimpleDateFormat simpleDateFormat = BasePage.simpleDateFormat_1;
			// 2016-12-20 01:38:51.293
			String queryToGetUserStartDate = "select lastPasswordSetTimestamp from useraccount where userid=(select id from [user]"
					+ " where name='" + userName + "')";
			String queryToGetMaxPasswordPage = "select maxPasswordAge from securityconfiguration";

			String startDate = "";
			String currentDate;
			int maxPasswordAge = 0;

			ResultSet resultSet;

			// get start date
			resultSet = DataBaseFunctionsLibraray.executeSelectQuery(queryToGetUserStartDate);

			if (resultSet.next()) {
				UtilityFunctions.applicationWait(500);
				startDate = resultSet.getString("lastPasswordSetTimestamp");
			}

			// get end date
			resultSet = DataBaseFunctionsLibraray.executeSelectQuery(queryToGetMaxPasswordPage);

			if (resultSet.next()) {
				UtilityFunctions.applicationWait(500);
				maxPasswordAge = resultSet.getInt("maxPasswordAge");
			}
			// check if password expiration check box is not checked
			if (maxPasswordAge == 0)
				return false;

			currentDate = UtilityFunctions.getCurrentDateInGivenFormat(simpleDateFormat);

			long diffSeconds = UtilityFunctions.getTimeDifferenceInSeconds(startDate, currentDate);
			int numberOfDays = (int) (diffSeconds / 60 / 60 / 24);

			// set max password age = max password age -5 , to reset password 5
			// days before expiration
			maxPasswordAge = maxPasswordAge - 5;
			return (numberOfDays >= maxPasswordAge);

		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}

	}

	// --------------------------------------------------------------------------------------------------------------------------------

	// Converts the comma separated string to a list
	// Author : Yogendra Ratore
	public static List<String> convertCommaSeparatedStringToList(String commaSeparatedString) {

		List<String> items = Arrays.asList(commaSeparatedString.split(","));

		return items;
	}// end of function

	// --------------------------------------------------------------------------------------------------------------------------------

	// gives month name on basis of index
	// Author : Yogendra Ratore
	// month index starts from 0 - 11
	public static String getMonthForInt(int num) {
		String month = "wrong";
		DateFormatSymbols dfs = new DateFormatSymbols();
		String[] months = dfs.getMonths();
		if (num >= 0 && num <= 11) {
			month = months[num];
		}
		return month;
	}

	// --------------------------------------------------------------------------------------------------------------------------------

	// get current month name
	// Author : Yogendra Ratore
	// month index starts from 0 - 11
	public static String getCurrentMonthName() {
		Calendar now = Calendar.getInstance();
		//
		return getMonthForInt(now.get(Calendar.MONTH));
	}

	// --------------------------------------------------------------------------------------------------------------------------------

	// get current year
	// Author : Yogendra Ratore

	public static int getCurrentYear() {
		Calendar now = Calendar.getInstance();
		//
		return now.get(Calendar.YEAR);
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// check given is String is in given date format or not
	// Author : Yogendra Rathore
	public static boolean checkGivenDateIsInGivenFormat(String date, String format) throws Exception {

		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
		simpleDateFormat.setLenient(false);
		try {

			simpleDateFormat.parse(date);
			return true;
		} catch (Exception e) {

			return false;
		}

	}

	// --------------------------------------------------------------------------------------------------------------------------------

	// get current day name
	// Author : Yogendra Ratore

	public static String getCurrentDayName() {
		Calendar now = Calendar.getInstance();
		return getDayForInt(now.get(Calendar.DAY_OF_WEEK));
	}

	// --------------------------------------------------------------------------------------------------------------------------------

	// gives day name on basis of index
	// Author : Yogendra Ratore
	// day index starts from 0 - 6
	public static String getDayForInt(int num) {

		String[] strDays = new String[] { "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday",
				"Saturday" };
		// Day_OF_WEEK starts from 1 while array index starts from 0
		return strDays[num - 1];
	}

	// --------------------------------------------------------------------------------------------------------------------------------

	// spilts the given excel sheet test cases in number given
	// Author : Yogendra Ratore

	public static void spiltExcel(String pathOfExcel, int numberOfSheets, String sheetNameToBeSpilted) {

		try {
			// get object of all excel

			ExcelUtility objectOfExcel = new ExcelUtility(pathOfExcel);

			// get row count
			int rowCount = objectOfExcel.getRowCount(sheetNameToBeSpilted);
			int columnCount = objectOfExcel.getColumnCount(sheetNameToBeSpilted);
			int counterForRows = 2;

			if (rowCount > 1) {

				// copy first row in all 4 sheets.
				for (int j = 1; j <= columnCount; j++) {
					String value = objectOfExcel.getCellData(sheetNameToBeSpilted, j, 1);

					for (int i = 1; i <= numberOfSheets; i++) {
						// set in all sheets first row
						objectOfExcel.setCellData(String.valueOf(i), j, 1, value);
					}
				}

				// now copy rest of the data 1 by 1 in all the sheets.
				int k = 2;
				while (k <= rowCount) {
					System.out.println("Row :" + k + " Out of :" + rowCount);

					for (int n = 1; n <= numberOfSheets; n++) {

						for (int m = 1; m <= columnCount; m++) {
							String value = objectOfExcel.getCellData(sheetNameToBeSpilted, m, k);

							if (value.contains("."))
								value = value.split("\\.")[0];

							objectOfExcel.setCellData(String.valueOf(n), m, counterForRows, value);

						} // end of third for loop.
						k++;
					} // end of second for loop
					counterForRows++;
				} // end of first for loop

				// set data
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// wait till given time is not equal to time passed as paramater
	// this method doesn't take past date as parameter
	// Author - Yogendra Rathore
	// Action : updated date format as per current format in the application

	public static void waitTillGivenTimeIsNotEqualToGivenTime(String time) throws Exception {

		System.out.println("******** Holding execution  till " + time + "  ******** ");
		SimpleDateFormat format = null;
		if (dateFormatForWaitMethod == null)
			format = BasePage.simpleDateFormat_29;
		else
			format = dateFormatForWaitMethod;
		Date d2 = new Date();

		Date d1 = null;

		d1 = format.parse(time);

		// in milliseconds
		long diff = d1.getTime() - d2.getTime();

		while (diff > 0) {
			applicationWait(1000);
			d2 = new Date();
			diff = d1.getTime() - d2.getTime();
		}
		System.out.println("******** Resuming execution  ******** ");
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// get current time zone
	// Action : updated date format as per current format in the application

	public static String getCurrentTimeZone() throws Exception {
		Calendar now = Calendar.getInstance();

		// get current TimeZone using getTimeZone method of Calendar class
		TimeZone timeZone = now.getTimeZone();
		return timeZone.getDisplayName();
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// get resource string from json files on basis of key and language locale
	// Author : Yogendra Rathore
	// modified by: rakesh sharma
	// updated handling of json reader for encoding
	// change by Rakesh Sharma on 05-08-2019
	// changed the approach to find the resource string
	public static String getResourceStringOnBasisOfLanguageLocaleAndKey(String languageLocale, int key)
			throws Exception {
		String value = "";
		try {
			JSONParser parser = new JSONParser();
			String src = System.getProperty("user.dir");
			ArrayList<String> path = new ArrayList<String>();

			// check setup configuration.json
			String basePath = src + "\\resources\\ResourceStringJson\\Resources\\" + languageLocale;

			/*
			 * String basePath = src+"\\.."+"\\.." + "\\Resources\\" + languageLocale;
			 */
			path.add(basePath + "\\Account.json");
			path.add(basePath + "\\Email.json");
			path.add(basePath + "\\Menu.json");
			path.add(basePath + "\\SetupConfiguration.json");
			path.add(basePath + "\\SplashScreen.json");

			for (int i = 0; i < 5; i++) {
				Object object = parser.parse(new InputStreamReader(new FileInputStream(path.get(i)), "UTF-8"));

				// convert Object to JSONObject
				JSONObject jsonObject = (JSONObject) object;

				// Reading the String
				value = (String) jsonObject.get(String.valueOf(key));

				if (value != null) {
					break;
				}
			}

			if (value == null) {
				System.out.println("String not found for given key " + key);
				return "";
			} else
				return value;

		} catch (Exception e) {
			System.out.println("In Catch Statement of getResourceStringOnBasisOfLanguageLocaleAndKey");

			System.out.println(" for language: " + languageLocale + " and key: " + key);
			e.printStackTrace();
		}
		return value;

	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// get current time of a given time zone when time zone name is given
	// Author : Rakesh Sharma
	public static LocalTime getCurrentTimeForGivenTimeZone(String timeZoneName) {
		// timeZoneName="Asia/Kolkata" for india time zone
		ZoneId zoneId = ZoneId.of(timeZoneName);
		LocalTime localTimeInGivenZone = LocalTime.now(zoneId);
		return localTimeInGivenZone;
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// for debug purpose only
	// Rakesh Sharma

	public static void startBrowserForDebug() {

		String value = "";
		try {
			BasePage.dr = new ChromeDriver();
			BasePage.driver = new EventFiringWebDriver(BasePage.dr);

		} catch (Exception e) {

		}

	}// end of function

	// --------------------------------------------------------------------------------------------------------------------
	// Set Run mode to No If any test case is not in Ready state and
	// automation status is not
	// "Automated" or "Partial Automated"
	// Author: Yogendra Rathore
	public static void changeRunModeInTestInputSheetIfTestCaseIsNotReadyToBeExecuted() {

		String cellData = null;
		int rowCount, i;
		int columnNumberState = 0;
		int columnNumberAutomationStatus = 0;
		int columnNumberRunMode = 0;
		String columnNameForState = "State";
		String columnNameForRunMode = "RunMode";

		String columnNameForAutomationStatus = "Automation Status";

		boolean setNo = false;
		try {

			// Run Mode
			columnNumberRunMode = BasePage.xls.getColumnNumber("TestCases", columnNameForRunMode);

			if (columnNumberRunMode != -1) {
				// check for State
				columnNumberState = BasePage.xls.getColumnNumber("TestCases", columnNameForState);
				if (columnNumberState != -1) {

					// get number of test cases
					rowCount = BasePage.xls.getRowCount("TestCases");

					for (i = 2; i <= rowCount; i++) {
						// get cell data for State
						cellData = BasePage.xls.getCellData("TestCases", columnNumberState + 1, i);
						setNo = false;
						switch (cellData) {
						case "Design":
							skippedDueToTestCaseInDesignState++;
							setNo = true;
							break;
						case "Closed":
							skippedDueToTestCaseInClosedState++;
							setNo = true;
							break;

						}
						if (setNo) {
							// set N for all passed test cases.
							BasePage.xls.setCellData("TestCases", "RunMode", i, "N");

						}

					}

				} else {
					System.out.println("'State' column is not present in Test Execution Input Sheet.");
				}

				// check for automation status

				columnNumberAutomationStatus = BasePage.xls.getColumnNumber("TestCases", columnNameForAutomationStatus);
				if (columnNumberAutomationStatus != 0) {

					// get number of test cases
					rowCount = BasePage.xls.getRowCount("TestCases");
					String runMode = "";
					for (i = 2; i <= rowCount; i++) {
						// get cell data for AutomationStatus
						cellData = BasePage.xls.getCellData("TestCases", columnNumberAutomationStatus + 1, i);

						runMode = BasePage.xls.getCellData("TestCases", columnNumberRunMode + 1, i);
						setNo = false;
						cellData = cellData.toLowerCase();
						if (!runMode.equals("N")) {
							switch (cellData) {

							case "not automated":
								skippedDueToTestCaseIsNotAutomated++;
								setNo = true;
								break;
							case "blocked":
								skippedDueToTestCaseIsBlocked++;
								setNo = true;
								break;
							case "not automable":
								skippedDueToTestCaseIsNotAutomable++;
								setNo = true;
								break;
							case "not in scope":
								skippedDueToTestCaseIsNotInScope++;
								setNo = true;
								break;
							case "script maintenance":
								skippedDueToTestCaseIsInScriptMaintenance++;
								setNo = true;
								break;
							case "planned":
								skippedDueToTestCaseIsNotAutomated++;
								setNo = true;
								break;

							}
							if (setNo) {
								// set N for all passed test cases.
								BasePage.xls.setCellData("TestCases", "RunMode", i, "N");
							}
						}
					}

				} else
					System.out.println("'Automation Status' column is not present in Test Execution Input Sheet.");

			} else
				System.out.println("'RunMode' column is not present in Test Execution Input Sheet.");

			int total = skippedDueToTestCaseInDesignState + skippedDueToTestCaseInClosedState
					+ skippedDueToTestCaseIsInScriptMaintenance + skippedDueToTestCaseIsNotAutomable
					+ skippedDueToTestCaseIsNotAutomated + skippedDueToTestCaseIsNotInScope
					+ skippedDueToTestCaseIsBlocked;
			if (total > 0)
				setSkippedStatus = true;

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// spilts the master sheet into given number of sheets and set config.
	// Author : Yogendra Ratore
	// sent dbURL in this format -<URL:Port> . for example "104.45.174.123:1433"
	public static void spiltMasterSheetAndSetConfig(String pathOfMasterExcel, String nameOfMasterExcel,
			int numberOfSheets, List<String> tenantList, List<String> companyIdList, String dbURL, String dbUserName,
			String dbPassword, String userPrefferedLanguage) {

		try {
			System.out.println(
					"Started Creating " + numberOfSheets + " sheets at " + UtilityFunctions.getDateForFilters());
			boolean setConfig = true;
			int tenantListSize = tenantList.size();
			int companyIdListSize = companyIdList.size();

			// check, number of sheets should be equal to tenant list size and
			// company id list
			if (tenantListSize != companyIdListSize || tenantListSize != numberOfSheets || dbURL.equals("")
					|| dbPassword.equals("") || dbUserName.equals(""))
				setConfig = false;

			String pathOfMasterExcelWithName = pathOfMasterExcel + "\\" + nameOfMasterExcel;
			String sheetNameToBeSpilted = "TestCases";
			String configSheet = "Config";
			// create xls variable for master sheet.
			ExcelUtility xls_Mastersheet = new ExcelUtility(pathOfMasterExcelWithName);
			int rowCountInMasterSheet_TestCases = xls_Mastersheet.getRowCount(sheetNameToBeSpilted);
			int columnCountInMasterSheet_TestCases = xls_Mastersheet.getColumnCount(sheetNameToBeSpilted);

			// delete folder is already present
			deleteFolderAtGivenLocation(pathOfMasterExcel, "SepartedSheets");
			UtilityFunctions.applicationWait(2000);
			// create new folder
			UtilityFunctions.createFolderAtGivenLocation(pathOfMasterExcel, "SepartedSheets");

			// copy master sheet into number of given sheets
			for (int ii = 1; ii <= numberOfSheets; ii++) {
				UtilityFunctions.moveFileFromSrcToDest(pathOfMasterExcel, pathOfMasterExcel + "\\SepartedSheets", "");

				UtilityFunctions.renameFile(pathOfMasterExcel + "\\SepartedSheets\\" + nameOfMasterExcel,
						pathOfMasterExcel + "\\SepartedSheets\\" + "TestExecutionInput" + ii + ".xlsm");
				String path = pathOfMasterExcel + "\\SepartedSheets\\" + "TestExecutionInput" + ii + ".xlsm";

				ExcelUtility xls_temp = new ExcelUtility(path);
				UtilityFunctions.applicationWait(2000);
				xls_temp.removeSheet(sheetNameToBeSpilted);
				xls_temp = new ExcelUtility(path);
				UtilityFunctions.applicationWait(2000);

				xls_temp.addSheet(sheetNameToBeSpilted);
				String userName = "AutomationUser" + ii;

				int rowForConfigSheet;
				// set config.
				if (setConfig) {
					int index = ii - 1;
					String tenantName = tenantList.get(index);
					String companyId = companyIdList.get(index);

					String dbURLProper = "jdbc:sqlserver://" + dbURL + ";databaseName=" + tenantName;

					// set tenant Name
					rowForConfigSheet = xls_temp.getCellRowNum(configSheet, 1, "DatabaseName");
					xls_temp.setCellData(configSheet, 2, rowForConfigSheet, tenantName);
					// set company id
					rowForConfigSheet = xls_temp.getCellRowNum(configSheet, 1, "CompanyID");
					xls_temp.setCellData(configSheet, 2, rowForConfigSheet, companyId);

					// set dbURLProper
					rowForConfigSheet = xls_temp.getCellRowNum(configSheet, 1, "DatabaseUrl");
					xls_temp.setCellData(configSheet, 2, rowForConfigSheet, dbURLProper);
					// set dbusername
					rowForConfigSheet = xls_temp.getCellRowNum(configSheet, 1, "DatabaseUserName");
					xls_temp.setCellData(configSheet, 2, rowForConfigSheet, dbUserName);
					// set dbPassword
					rowForConfigSheet = xls_temp.getCellRowNum(configSheet, 1, "DatabasePassword");
					xls_temp.setCellData(configSheet, 2, rowForConfigSheet, dbPassword);

					// set UserPrefferedLanguage
					rowForConfigSheet = xls_temp.getCellRowNum(configSheet, 1, "UserPrefferedLanguage");
					xls_temp.setCellData(configSheet, 2, rowForConfigSheet, userPrefferedLanguage);

					// set NumberOfCIParallelExecution
					rowForConfigSheet = xls_temp.getCellRowNum(configSheet, 1, "NumberOfCIParallelExecution");
					xls_temp.setCellData(configSheet, 2, rowForConfigSheet, String.valueOf(numberOfSheets));
				}
				// keeping set username out of check set config as username
				// set username
				rowForConfigSheet = xls_temp.getCellRowNum(configSheet, 1, "UserName");
				xls_temp.setCellData(configSheet, 2, rowForConfigSheet, userName);
			}
			deleteFolderAtGivenLocation(pathOfMasterExcel + "\\SepartedSheets", "SepartedSheets");

			int sheetIndex = 1;
			// get logic for sepearting test cases.
			// create given number of sheets in mastersheet and spilt sheet.
			for (int i = 1; i <= numberOfSheets; i++) {
				int row = 2;
				sheetIndex++;
				int m = sheetIndex;

				UtilityFunctions.applicationWait(2000);
				ExcelUtility xls_temp = new ExcelUtility(
						pathOfMasterExcel + "\\SepartedSheets\\" + "TestExecutionInput" + i + ".xlsm");

				// copy first row in all sheets.
				for (int j = 1; j <= columnCountInMasterSheet_TestCases; j++) {
					String value = xls_Mastersheet.getCellData(sheetNameToBeSpilted, j, 1);

					// set in all sheets first row
					xls_temp.setCellData(sheetNameToBeSpilted, j, 1, value);

				}

				// copy data from master sheet to sheet created by login row +
				// number of sheets.

				for (int k = 2; k <= rowCountInMasterSheet_TestCases; k++) {

					if (k == m) {
						for (int j = 1; j <= columnCountInMasterSheet_TestCases; j++) {

							String value = xls_Mastersheet.getCellData(sheetNameToBeSpilted, j, k);
							if (value.contains("."))
								value = value.split("\\.")[0];
							// set in all sheets first row
							xls_temp.setCellData(sheetNameToBeSpilted, j, row, value);

						}
						row++;
						m = m + numberOfSheets;
					}
				}
				System.out.println("Completed Creating " + i + " sheet at " + UtilityFunctions.getDateForFilters());
			}
			System.out.println("Completed Creating All (" + numberOfSheets + ") sheets");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// convert csv file into excel and add 2 column TCID and RUNMode as these
	// are not provided
	// by dev ops team.
	// Author : Yogendra Ratore

	public static void readCSVFileAndConvertIntoExcelWithRunModeAndTCID(String pathOfCSVFileWithName,
			String pathOfMasterExcelWithName) {
		System.out.println("Started Converting CSV file into Sanity Master Sheet.");

		try {

			String sheetName = "TestCases";

			ExcelUtility xls = new ExcelUtility(pathOfMasterExcelWithName);

			xls.removeSheet(sheetName);
			xls = new ExcelUtility(pathOfMasterExcelWithName);

			xls.addSheet(sheetName);

			String column1 = "RunMode", column2 = "TCID", prefix = "TC_", runMode = "Y";

			// Create an object of filereader class
			// with CSV file as a parameter.

			FileReader filereader = new FileReader(pathOfCSVFileWithName);

			// create csvReader object passing
			// filereader as parameter
			CSVReader csvReader = new CSVReader(filereader);
			String[] nextRecord;
			int row = 1;
			int column = 1;
			// we are going to read data line by line
			while ((nextRecord = csvReader.readNext()) != null) {

				if (row == 1) {
					xls.setCellData(sheetName, column, row, column1);
					column++;
					xls.setCellData(sheetName, column, row, column2);
					column++;
				} else {
					xls.setCellData(sheetName, column, row, runMode);
					column++;

				}

				for (String cell : nextRecord) {

					if (column == 2) {
						xls.setCellData(sheetName, column, row, prefix + cell);
						column++;
					}
					xls.setCellData(sheetName, column, row, cell);
					column++;
				}
				column = 1;
				row++;

			}
			System.out.println("Completed Converting CSV file into Sanity Master Sheet.");

		} catch (Exception e) {
			System.out.println("Issue In Converting CSV file into Sanity Master Sheet.");

			e.printStackTrace();
		}
	}

	// --------------------------------------------------------------------------------------------------------------------
	// convert date to given timezone where date is in gigen time zone
	// rakesh sharma
	public static String convertDateInGivenTimeZone(ZoneId timeZoneId1, DateTimeFormatter dateTimeFormatter1,
			String dateTime1, ZoneId timeZoneId2, SimpleDateFormat simpleDateFormatter2) throws Exception {
		try {
			LocalDateTime ldt1 = LocalDateTime.parse(dateTime1, dateTimeFormatter1);
			ZonedDateTime zdt1 = ldt1.atZone(timeZoneId1);

			ZonedDateTime dateTime2 = zdt1.withZoneSameInstant(timeZoneId2);
			Instant instant = dateTime2.toInstant();
			// Convert Instant to Date.
			Date date = Date.from(instant);
			return simpleDateFormatter2.format(date);

		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// --------------------------------------------------------------------------------------------------------------------
	// convert date to given timezone where date is in given time zone
	// rakesh sharma
	// it is not working for time stamp.use datetimeformatter method for time
	// stamp
	public static String convertDateInGivenTimeZone(ZoneId timeZoneId1, SimpleDateFormat dateTimeFormatter1,
			String dateTime1, ZoneId timeZoneId2, SimpleDateFormat simpleDateFormatter2) throws Exception {
		try {
			Date date1 = dateTimeFormatter1.parse(dateTime1);
			ZonedDateTime zdt1 = date1.toInstant().atZone(timeZoneId1);

			ZonedDateTime dateTime2 = zdt1.withZoneSameInstant(timeZoneId2);
			Instant instant = dateTime2.toInstant();
			// Convert Instant to Date.
			Date datetime2 = Date.from(instant);

			return simpleDateFormatter2.format(datetime2);

		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// -------------------------------------------------------------------------------------------------------------------------------------
	// get before \ after time
	// Author :Yogendra athore
	public static String getFutureOrPastTimeFromCurrentTime(int difference, String unit,
			SimpleDateFormat simpleDateFormat) throws Exception {
		String fromDate = "";

		try {

			Calendar cal = Calendar.getInstance();
			Date myDate = new Date(System.currentTimeMillis());
			cal = Calendar.getInstance();
			cal.setTime(myDate);

			// set future past as per unit
			if (unit.equalsIgnoreCase("HOUR"))
				cal.add(Calendar.HOUR, difference);
			else if (unit.equalsIgnoreCase("MINUTE"))
				cal.add(Calendar.MINUTE, difference);
			else if (unit.equalsIgnoreCase("YEAR"))
				cal.add(Calendar.YEAR, difference);

			fromDate = simpleDateFormat.format(cal.getTime());

		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
		return fromDate;
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// compare time
	// both the parameters should be in same format
	// Time1 will be takes as first parameter
	// Author - Yogendra Rathore

	public static String compareTime(String time1, String time2, SimpleDateFormat format) throws Exception {

		try {
			String result = "";

			Date d1 = null;

			d1 = format.parse(time1);

			Date d2 = new Date();
			d2 = format.parse(time2);

			// in milliseconds
			long diff = d1.getTime() - d2.getTime();

			if (diff == 0) {
				result = "EQUAL";
			} else if (diff > 0) {
				result = "GREATER";
			} else
				result = "SMALLER";

			return result;
		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// find all folders in a directory
	// Author - Yogendra Rathore

	public static List<String> findFoldersInDirectory(String directoryPath) throws Exception {
		try {
			File directory = new File(directoryPath);

			FileFilter directoryFileFilter = new FileFilter() {
				public boolean accept(File file) {
					return file.isDirectory();
				}
			};

			File[] directoryListAsFile = directory.listFiles(directoryFileFilter);
			List<String> foldersInDirectory = new ArrayList<String>(directoryListAsFile.length);
			for (File directoryAsFile : directoryListAsFile) {
				foldersInDirectory.add(directoryAsFile.getName());
			}

			return foldersInDirectory;
		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// ------------------------------------------------------------------------------------------------------------------------
	// combine test summary sheets to 1 combined sheet and skip passed test
	// cases. .
	// Author :yogendra Rathore
	public static void combineExcelSheetsAndSkipPassedTestCases(Hashtable<String, String> testData,
			int numberOfParallelExecutions) {
		try {
			System.out.println("Started combining " + numberOfParallelExecutions + " Sheets at "
					+ UtilityFunctions.getDateForFilters());
			String combinedExcel = testData.get("combinedExcel");
			String sheet = "";
			String cellData = null;
			int rowCountInCombinedExcel = 0, rowCountInTestSummarySheet = 0, rowNumberOfCombinedExcel = 0;
			int columnCountInSheet = 0;
			String spiltArrary[] = new String[2];
			ExcelUtility xls_combinedExcel = new ExcelUtility(combinedExcel);

			xls_combinedExcel.removeSheet("TestCases");

			xls_combinedExcel = new ExcelUtility(combinedExcel);

			xls_combinedExcel.addSheet("TestCases");

			ExcelUtility xls_testSummarySheet;
			// get cell data for run status

			// copy firs sheet directly.
			// get column number of first sheet., column numbers should be same
			// in all the sheets.
			// intialize variable of xls
			sheet = testData.get("sheet1");
			xls_testSummarySheet = new ExcelUtility(sheet);

			// get number number of columns in test summary sheet
			columnCountInSheet = xls_testSummarySheet.getColumnCount("TestCases");

			// get number of rows in Test Input sheet.
			rowCountInTestSummarySheet = xls_testSummarySheet.getRowCount("TestCases");

			// set data in summary sheet for first excel.

			for (int rowNumber = 1; rowNumber <= rowCountInTestSummarySheet; rowNumber++) {
				// get cell data for run status
				String columnStatusValue = xls_testSummarySheet.getCellData("TestCases", "RunStatus", rowNumber);
				rowNumberOfCombinedExcel++;
				if (rowNumber != 1 && columnStatusValue.equalsIgnoreCase("PASSED")) {
					rowNumberOfCombinedExcel--;
				} else {
					for (int columnNumber = 1; columnNumber <= columnCountInSheet; columnNumber++) {
						cellData = xls_testSummarySheet.getCellData("TestCases", columnNumber, rowNumber);

						if (cellData.contains(".")) {

							spiltArrary = UtilityFunctions.splitString(cellData, "\\.");
							cellData = spiltArrary[0];

						}

						// set cell data in main excel.

						xls_combinedExcel.setCellData("TestCases", columnNumber, rowNumberOfCombinedExcel, cellData);

					}
				}

			}

			// copy excel in combined excel if more than 2

			for (int i = 2; i <= numberOfParallelExecutions; i++) {
				// intialize variable of xls
				sheet = testData.get("sheet" + i);
				xls_testSummarySheet = new ExcelUtility(sheet);

				// get number of rows in Test Input sheet.
				rowCountInTestSummarySheet = xls_testSummarySheet.getRowCount("TestCases");

				// set data in summary sheet for first excel.
				// skip 1st row as it column headers which already taken in
				// first sheet. so rowNumber=2
				for (int rowNumber = 2; rowNumber <= rowCountInTestSummarySheet; rowNumber++) {
					String columnStatusValue = xls_testSummarySheet.getCellData("TestCases", "RunStatus", rowNumber);
					rowNumberOfCombinedExcel++;

					if (rowNumber != 1 && columnStatusValue.equalsIgnoreCase("PASSED")) {
						rowNumberOfCombinedExcel--;
					} else {
						for (int columnNumber = 1; columnNumber <= columnCountInSheet; columnNumber++) {

							cellData = xls_testSummarySheet.getCellData("TestCases", columnNumber, rowNumber);

							if (cellData.contains(".")) {

								spiltArrary = UtilityFunctions.splitString(cellData, "\\.");
								cellData = spiltArrary[0];

							}
							// set cell data in main excel.
							xls_combinedExcel.setCellData("TestCases", columnNumber, rowNumberOfCombinedExcel,
									cellData);

						}
					}

				}

				// assing row count in combined excel
				rowCountInCombinedExcel = rowNumberOfCombinedExcel;
				System.out.println("Combined result for " + i + " Sheets at " + UtilityFunctions.getDateForFilters());
			}

		} catch (Exception ex) {

			log.error("combineTestSheetsAndGetStatus  :", ex);
		}

	}

	// ----------------------------------------------------------------------------------
	// this method checks is day light saving is On, by given logic
	// Author:Yogendra Rathore

	public static boolean checkIsDayLightSavingIsOnGivenTimeZone(String timeZone) throws Exception {
		try {
			TimeZone.setDefault(TimeZone.getTimeZone(timeZone));
			String temp = TimeZone.getDefault().toString();

			temp = temp.split("useDaylight=")[1];
			temp = temp.split(",")[0];

			if (temp.equalsIgnoreCase("false"))
				return false;

			return true;
		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// wait till given time is not equal to time passed as paramater
	// this method doesn't take past date as parameter
	// Author - Yogendra Rathore
	// Action : updated date format as per current format in the application

	public static void waitTillGivenTimeIsNotEqualToGivenTimeForSpecificTimeZone(String time, String timeZone,
			SimpleDateFormat format) throws Exception {

		try {
			System.out.println("******** Holding execution  till " + time + " for " + timeZone + " ******** ");

			Date d2 = new Date();
			String timeOfZone = format.format(d2);
			timeOfZone = UtilityFunctions.convertDateInGivenTimeZone(timeZone, timeOfZone);
			Date d1 = null;

			d1 = format.parse(time);

			// in milliseconds
			long diff = d1.getTime() - d2.getTime();

			while (diff > 0) {
				applicationWait(1000);
				d2 = new Date();
				diff = d1.getTime() - d2.getTime();
			}
			System.out.println("******** Resuming execution  ******** ");
		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// -------------------------------------------------------------------------------------------------------------------------------------
	// get before \ after time
	// Author :Yogendra athore
	public static String getFutureOrPastTimeFromCurrentTimeForSpecificTimeZone(int difference, String unit,
			SimpleDateFormat simpleDateFormat, String timeZone) throws Exception {
		String fromDate = "";

		try {

			TimeZone.setDefault(TimeZone.getTimeZone(timeZone));

			Calendar cal = Calendar.getInstance();
			Date myDate = new Date();
			System.out.println(myDate);
			cal = Calendar.getInstance();
			cal.setTime(myDate);

			// set future past as per unit
			if (unit.equalsIgnoreCase("HOUR"))
				cal.add(Calendar.HOUR, difference);
			else if (unit.equalsIgnoreCase("MINUTE"))
				cal.add(Calendar.MINUTE, difference);
			else if (unit.equalsIgnoreCase("YEAR"))
				cal.add(Calendar.YEAR, difference);

			fromDate = simpleDateFormat.format(cal.getTime());
			System.out.println(fromDate);
		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
		return fromDate;
	}

	// --------------------------------------------------------------------------------------------------------------------------------

	// get one day next to current day name
	// Author : Yogendra Ratore

	public static String getDayNextToCurrentDayName(int index) {
		Calendar now = Calendar.getInstance();
		now.add(Calendar.DAY_OF_WEEK, index);
		return getDayForInt(now.get(Calendar.DAY_OF_WEEK));
	}

	// --------------------------------------------------------------------------------------------------------------------------------

	// get multilingual day as per day name
	// Author : Yogendra Ratore

	public static String getMultilingualDayAsPerDayName(String day) {

		String result = "Wrong Day Sent As Input";

		if (day.equalsIgnoreCase("Sunday")) {
			result = UtilityFunctions.getMultilingualData("ColumnName_Sunday");
		} else if (day.equalsIgnoreCase("Monday")) {
			result = UtilityFunctions.getMultilingualData("ColumnName_Monday");
		} else if (day.equalsIgnoreCase("Tuesday")) {
			result = UtilityFunctions.getMultilingualData("ColumnName_Tuesday");
		} else if (day.equalsIgnoreCase("Wednesday")) {
			result = UtilityFunctions.getMultilingualData("ColumnName_Wednesday");
		} else if (day.equalsIgnoreCase("Thursday")) {
			result = UtilityFunctions.getMultilingualData("ColumnName_Thursday");
		} else if (day.equalsIgnoreCase("Friday")) {
			result = UtilityFunctions.getMultilingualData("ColumnName_Friday");
		} else if (day.equalsIgnoreCase("Saturday")) {
			result = UtilityFunctions.getMultilingualData("ColumnName_Saturday");
		}
		return result;

	}

	// -------------------------------------------------------------------------------------------------------------------------------------
	// start any exe using JAVA
	// Author :Yogendra athore
	// Path of the file should not have any space in between
	public static void startAnyExeThroughJAVA(String pathWithName) throws Exception {

		try {

			Runtime runtime = Runtime.getRuntime();

			runtime.exec("cmd /c start " + pathWithName);
			System.out.println("***********************************************************************");
			System.out.println("Started " + pathWithName);
			System.out.println("***********************************************************************");
		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}

	}

	// -------------------------------------------------------------------------------------------------------------------------------------
	// get windows app driver instance
	// Author :Yogendra athore
	// Windows App driver should be in running state for this method
	public static WindowsDriver<WebElement> getDriverForSpecificDesktopWindow(String name) throws Exception {
		WindowsDriver<WebElement> appDriver = null;
		try {

			DesiredCapabilities desktopCapabilities = new DesiredCapabilities();
			desktopCapabilities.setCapability("app", "Root");
			WindowsDriver<WebElement> desktopSession = new WindowsDriver<WebElement>(new URL("http://127.0.0.1:4723"),
					desktopCapabilities);

			WebElement appWindow = desktopSession.findElementByName(name);

			String windowHandle = Integer.toHexString(Integer.parseInt(appWindow.getAttribute("NativeWindowHandle")))
					.toUpperCase();

			DesiredCapabilities appCapabilities = new DesiredCapabilities();
			appCapabilities.setCapability("appTopLevelWindow", "0x" + windowHandle);
			appDriver = new WindowsDriver<WebElement>(new URL("http://127.0.0.1:4723"), appCapabilities);

		} catch (Exception e) {
			// suppress exception
		}
		return appDriver;
	}

	// ----------------------------------------------------------------------------------------------------------
	// Author : Yogendra Rathore
	// Starts gauge installer
	public static void startGaugeInstaller(String pathOfGaugeInstaller) {
		try {
			System.out.println(pathOfGaugeInstaller);
			DesiredCapabilities capabilities = new DesiredCapabilities();
			capabilities.setCapability("app", pathOfGaugeInstaller);
			capabilities.setCapability("platormName", "Windows");
			capabilities.setCapability("deviceName", "WindowsPC");

			new WindowsDriver(new URL("http://127.0.0.1:4723"), capabilities);

			Thread.sleep(5000);
			System.out.println("Gauge Started");
		} catch (Exception e) {
			System.out.println("Gauge Started With Suppressed Exception ");

		}

	}
	// ----------------------------------------------------------------------------------------------------------
	// Author : Yogendra Rathore
	// Uninstall a program from control panel

	public static void uninstallAnApplicationFromControlPanel(String name) throws Exception {
		try {

			// open control panel

			DesiredCapabilities desktopCapabilities = new DesiredCapabilities();
			desktopCapabilities.setCapability("app", "Root");
			WindowsDriver<WebElement> desktopSession = new WindowsDriver<WebElement>(new URL("http://127.0.0.1:4723"),
					desktopCapabilities);
			// Type here to search
			// search Control Panel
			// click enter

			WebElement appWindow = desktopSession.findElementByName("Type here to search");

			appWindow.click();
			Thread.sleep(2000);
			appWindow.sendKeys("Control Panel");

			;
			Thread.sleep(1000);
			appWindow.sendKeys(Keys.ENTER);
			Thread.sleep(5000);

			WindowsDriver<WebElement> appDriver = getDriverForSpecificDesktopWindow("Control Panel");

			// click on unistall
			appDriver.findElementByName("Uninstall a program").click();
			Thread.sleep(5000);
			appDriver = getDriverForSpecificDesktopWindow("Programs and Features");

			if (appDriver.findElementsByName(name).size() > 0) {
				// click on unistall
				appDriver.findElementByName(name).click();
				Thread.sleep(2000);
				appDriver.findElementByName("Uninstall").click();

				Thread.sleep(4000);
				appDriver.findElementByName("Yes").click();

			}

			Thread.sleep(7000);
			appDriver.findElementByName("Close").click();

		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));

		}
	}

	// ----------------------------------------------------------------------------------------------------------
	// Author : Yogendra Rathore
	// connect VPN

	public static void connectVPNFromUI(String nameOfVPNForAlpha) throws Exception {
		try {
			System.out.println("Attempting to connect VPN :"+ nameOfVPNForAlpha);
			DesiredCapabilities desktopCapabilities = new DesiredCapabilities();
			desktopCapabilities.setCapability("app", "Root");
			WindowsDriver<WebElement> desktopSession = new WindowsDriver<WebElement>(new URL("http://127.0.0.1:4723"),
					desktopCapabilities);
			// Type here to search
			// search Control Panel
			// click enter

			WebElement appWindow = desktopSession.findElementByName("Type here to search");

			appWindow.click();

			appWindow.sendKeys("Settings");
			Thread.sleep(2000);
			appWindow.sendKeys(Keys.ENTER);
			Thread.sleep(10000);

			desktopSession = getDriverForSpecificDesktopWindow("Settings");

			desktopSession.findElementByName("Network & Internet").click();
			;
			Thread.sleep(2000);
			desktopSession.findElementByName("VPN").click();

			Thread.sleep(5000);
			if (desktopSession.findElementsByName(nameOfVPNForAlpha + " Connected ").size() > 0) {
				System.out.println("VPN already connected");
			} else if (desktopSession.findElementsByName(nameOfVPNForAlpha + " ").size() == 0) {
				System.out.println(nameOfVPNForAlpha +" not present in VPN Settings");

			} else {
				Thread.sleep(2000);
				desktopSession.findElementByName(nameOfVPNForAlpha + " ").click();
				Thread.sleep(5000);

				desktopSession.findElementByName("Connect").click();
				Thread.sleep(7000);

				desktopSession = getDriverForSpecificDesktopWindow(nameOfVPNForAlpha);

				desktopSession.findElementByName("Connect").click();
				Thread.sleep(10000);
				desktopSession = getDriverForSpecificDesktopWindow("Settings");

				if (desktopSession.findElementsByName(nameOfVPNForAlpha + " Connected ").size() > 0) {
					System.out.println("VPN connected Successfully");
				} else

					System.out.println("VPN not connected Successfully");
			}

			// close setting window
			desktopSession.findElementByName("Close Settings").click();
			System.out.println("Closed Settings Window");

		} catch (Exception e) {
			System.out.println("Not able to connect VPN "+ nameOfVPNForAlpha);
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));

		}
	}

}// end of class
