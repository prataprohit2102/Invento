package Util;

import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.SkipException;

import com.thoughtworks.selenium.webdriven.commands.IsElementPresent;

import Base.BasePage;
import Pages.*;
import io.appium.java_client.windows.WindowsDriver;
//import io.appium.java_client.windows.WindowsDriver;

public class TestLibrary {
		public static String temp = "";

	
	// Check Test Case is executable
	public static void verifyTestIsExecutable(String testCaseName) {
		// If run mode set to "No" in Test Suite sheet then test will not
		// execute
		if (UtilityFunctions.IsExecutable(testCaseName, BasePage.xls) != true) {
			throw new SkipException("Run Mode Set to No");
		} else {
			// this code is for all those test cases which are run twice on
			// single call.

			if (temp != BasePage.currentMethodName) {
				BasePage.numberOfTestCaseExecuted++;
				temp = BasePage.currentMethodName;
			}

			// close browser in case error page is displayed.
			LibraryFunctions.logoutOnErrorPage();

			log.info("Current Method " + BasePage.currentMethodName);
			System.out.println();
			System.out.println();
			System.out.println("----------------------------------------------------------------");
			System.out.println("Current Method :" + BasePage.currentMethodName);
			if (!BasePage.titleOfTestCase.equals(""))
				System.out.println("Title :" + BasePage.titleOfTestCase);
			System.out.println("Executing TC: " + BasePage.numberOfTestCaseExecuted + " Out Of : "
					+ BasePage.totalNumberOfTestCaseExecuted);
			log.info("Executing TC: " + BasePage.numberOfTestCaseExecuted + " Out Of : "
					+ BasePage.totalNumberOfTestCaseExecuted);

			try {
				System.out.println("Number Of Chrome.exe running ="
						+ UtilityFunctions.getNumberOfTimesAProcessIsRunning("chrome.exe"));

				SimpleDateFormat simpleDateFormat = BasePage.simpleDateFormat_1;

				BasePage.startTimeOfTestCase = UtilityFunctions.getCurrentDateInGivenFormat(simpleDateFormat);
				System.out.println("Start Time Of TestCase: " + BasePage.startTimeOfTestCase);
				System.out.println("User Preffered Language In Excel: "
						+ BasePage.TestConfiguration.getProperty("UserPrefferedLanguage"));

				if (BasePage.current_LoggedIn_User.equals(""))
					System.out.println("Current Logged In User :- " + "No User Logged In");
				else
					System.out.println("Current Logged In User :- " + BasePage.current_LoggedIn_User);
			} catch (Exception e) {
			}
		}

	}

	// ----------------------------------------------------------------------------------------------------------------------------
	// Verify that input data is not blank
	public static void verifyInputDataIsNotBlank(Hashtable<String, String> TestDataSet) {
		if (UtilityFunctions.checkInputDataIsNotBlank(TestDataSet) == false)
			Assert.assertEquals(ConstantsUtility.errTestDataIsBlank, ConstantsUtility.msgTestDataShouldNotBeBlank);

	}

	// ----------------------------------------------------------------------------------------------------------------------------

	// Navigates to login page. If user has already logged in then logout. If
	// browser id not opened then open the browser and login
	// Modified By: Yogendra Rathore
	// Modified By : HArshita Shaktawat
	// Added condition to close the pop up if pop up is present
	// Modified By: Yogendra Rathore (20-07-2017)
	// Action 2* :Handled OK confirmation
	public static LoginPage navigateToLoginPageAndVerifyLoginPageIsDisplayed() throws Exception {
		try {
			PageHeader pageHeader = new PageHeader();
			// if browser closed then open broswer and hit test site url

			if (LibraryFunctions.isBrowserClosed())

				// Open Browser and Url of application
				BasePage.login = new LoginPage(BasePage.TestConfiguration.getProperty("Browser"),
						BasePage.TestConfiguration.getProperty("TestSiteURL"));

			// if already logged in then log out
			else {
				if (LibraryFunctions.isElementDisplayed(PageHeader.xPath_btnBackButton, 1)) {
					LibraryFunctions.handlingConfirmationBoxMessage("OK");
					pageHeader.logout();
				} else
				// refresh to removed dirty data
				{// Action 2* :
					LibraryFunctions.handlingConfirmationBoxMessage("CROSS");
					LibraryFunctions.refresh();
				}
			}

			if (BasePage.login.checkLoginPageIsDisplayed() == false) {
				try {
					Assert.assertEquals(ConstantsUtility.errSomeErrorOccured,
							"Appliction url should open and Login Page should displayed");
				} catch (Throwable t) {
					reportErrorAndtakeScreenshot(t, "Application_Url_did_not_open");
					log.error("Application URL is not opened for " + BasePage.currentMethodName);
				} // End of catch
			} // End of If
		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));

		}
		return new LoginPage();
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Verify that Dashboard page is displayed
	// Modified By : Rakesh Kumar Sharma
	// Changed Assert statement
	public static void verifyDashboardPageIsDisplayed(DashboardPage dashboardpage) throws Exception {
		if (dashboardpage.checkDashboardPageIsDisplayed() == true) {
			// Once logged in, set the IsLoggedIn variable to true
			BasePage.IsLoggedIn = true;
		} else {
			try {
				// If login failed with valid credentials fail the
				// assertion
				Assert.assertEquals("System did not navigate to Dashboard page",
						"System should navigate to Dashboard Page");
			} catch (Throwable t) {

				reportErrorAndtakeScreenshot(t, "Dashboard_Page_not_displayed");
				throw new Exception("TestLibrary - error in verifyDashboardPageIsDisplayed method " + t);
			}
		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check user is logged in
	// Modified By - Chnanchal Jain
	// Modified By - Tanmay
	// Modified by : Yogendra Rathore
	// Modified bt - Chanchal Jain
	// applied handlingConfirmationBoxMessage in function before enter username
	// and password

	public static void loginIfNotLoggedInAndVerifyUserIsLoggedIn() throws Exception {
		try {
			if (BasePage.isBrowserClosed()) {

				// Open Browser and Url of application
				BasePage.login = new LoginPage(BasePage.TestConfiguration.getProperty("Browser"),
						BasePage.TestConfiguration.getProperty("TestSiteURL"));

				TestLibrary.verifyLoginPageIsDisplayed();

			} // End of If

			LibraryFunctions.handlingConfirmationBoxMessage("OK");
			UtilityFunctions.applicationWait(2000);
			LibraryFunctions.checkLoadingIconIsDisplayed("SpinningLoadingIcon", 60);
			// check user is not already logged in.
			if (!LibraryFunctions.isElementDisplayed(PageHeader.xPath_btnBackButton, 5)) {
				LibraryFunctions.handlingConfirmationBoxMessage("CROSS");
				UtilityFunctions.applicationWait(1000);
				dashboardPage = BasePage.login.doLogin(BasePage.TestConfiguration.getProperty("UserName"),
						BasePage.TestConfiguration.getProperty("Password"),
						BasePage.TestConfiguration.getProperty("CompanyID"));

				TestLibrary.verifyDashboardPageIsDisplayed(dashboardPage);
			}

		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));

		}

	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check Part Landing Page display PartLandingPage partLandingPage12
	public static void verifyPartLandingPageIsDisplayed(PartLandingPage partLandingPage) throws Exception {
		// Verify PartLanding page
		if (partLandingPage.checkPartLandingPageIsDisplayed() == false)

		{
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " PartLanding Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + "PartLanding Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_partlanding_page");
				log.error("Error occured - Not able to Navigate to PartLanding Page for " + BasePage.currentMethodName);
				return;
			}

		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------

	// Verify Create part page is displayed
	public static void verifyCreatePartPageIsDisplayed(CreatePartPage createPartpage) {
		// Verify Create New Part Page is displayed
		if (createPartpage.checkCreatePartPageIsDisplayed() == false) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " CreatePart Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " CreatePart Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_Create_Part_page");
				log.error("Error occured - Not able to Navigate to Create Part Page for " + BasePage.currentMethodName);
				return;
			}
		} // end of if
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------

	// Verify Edit part page is displayed
	public static void verifyEditPartPageIsDisplayed(EditPartPage editPartpage, String selectedPart,
			String partRevision) throws Exception {

		// check in progress text and wait till 15 secs if Inprogress is
		// displayed.
		UtilityFunctions.applicationWait(2000);
		int index = 0;
		while ((LibraryFunctions.isElementPresent(BasePage.xPath_InProgressImage, 1)
				|| LibraryFunctions.isElementPresent(BasePage.xPath_InProgressText, 1)) && index < 15) {
			UtilityFunctions.applicationWait(1000);
			index++;

		}
		// Verify Edit Part Page is displayed
		if (!editPartpage.checkEditPartPageIsDisplayed(selectedPart, partRevision)) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " EditPart Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " EditPart Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_To_Navigate_To_Edit_Part_Page");
				log.error("Error occured - Not able to Navigate to Edit Part Page for " + BasePage.currentMethodName);
				throw new Exception();
			}
		} // end of if
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------

	// Verify Create Specification Limit Page is displayed
	public static void verifyCreateSpecificationLimitPageIsDisplayed(
			CreateSpecificationLimitPage createSpecificationLimitPage) throws Exception {
		// Verify Create New Part Page is displayed
		if (createSpecificationLimitPage.checkCreateSpecificationLimitPageIsDisplayed() == false) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " CreateSpecificationLimit Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " CreateSpecificationLimit Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_Create_SpecificationLimit_page");
				log.error("Error occured - Not able to Navigate to Create SpecificationLimit Page for "
						+ BasePage.currentMethodName);

			}
		} // end of if
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check Specification Landing Page is displayed
	public static void verifySpecificationLimitLandingPageIsDisplayed(
			SpecificationLimitLandingPage specificationLimitLandingPage) throws Exception {
		// Verify PartLanding page
		if (specificationLimitLandingPage.checkSpecificationLandingPageIsDisplayed() == false) {
			try {
				Assert.assertEquals(
						ConstantsUtility.errApplicationPageNotDisplayed + " Specification Limit Landing Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Specification Limit Landing Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_specificationLimitLanding_page");
				log.error("Error occured - Not able to Navigate to SpecificationLimit Landing Page for "
						+ BasePage.currentMethodName);
			}

		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------

	// Reports the error in the error listener and creates and file for the
	// screenshot and adds it into the TestNG report
	// Modified by: Yogendra Rathore
	public static void reportErrorAndtakeScreenshot(Throwable t, String screenShotFileName) {
		ErrorUtility.addVerificationFailure(t);
		UtilityFunctions.applicationWait(500);
		if (screenShotFileName != "")
			UtilityFunctions.takeScreenshot(screenShotFileName);

	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Verify Create Feature page is displayed
	public static void verifyCreateFeaturePageIsDisplayed(CreateFeaturePage createFeaturepage) {
		// Verify Create Part Page is displayed
		if (createFeaturepage.checkCreateFeaturePageIsDisplayed() == false) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Create Feature Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Create Feature Page");
			} catch (Throwable t) {

				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_Create_Feature_page");
				log.error("Error occured - Not able to Navigate to Create Feature Page for "
						+ BasePage.currentMethodName);
			}
		} // end of if
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Verify Create User page is displayed
	public static void verifyCreateUserPageIsDisplayed(CreateUserPage createUserpage) {
		// Verify Create User Page is displayed
		if (createUserpage.checkCreateUserPageIsDisplayed() == false) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Create User Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Create User Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_Create_User_page");
				log.error("Error occured - Not able to Navigate to Create User Page for " + BasePage.currentMethodName);

			}
		} // end of if
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Verify Edit User page is displayed
	public static void verifyEditUserPageIsDisplayed(EditUserPage editUserpage, String fullName) {
		// check in progress text and wait till 15 secs if Inprogress is
		// displayed.
		UtilityFunctions.applicationWait(2000);
		int index = 0;
		while ((LibraryFunctions.isElementPresent(BasePage.xPath_InProgressImage, 1)
				|| LibraryFunctions.isElementPresent(BasePage.xPath_InProgressText, 1)) && index < 15) {
			UtilityFunctions.applicationWait(1000);
			index++;

		}
		if (editUserpage.checkEditUserPageIsDisplayedForUser(fullName) == false) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Edit User Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Edit User Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_Edit_User_page");

			}
		} // end of if
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check Feature Landing Page display FeatureLandingPage
	public static void verifyFeatureLandingPageIsDisplayed(FeatureLandingPage featureLandingPage) throws Exception {
		// Verify FeatureLanding page
		if (featureLandingPage.checkFeatureLandingPageIsDisplayed() == false)

		{
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " FeatureLanding Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " FeatureLanding Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_featurelanding_page");
				log.error("Error occured - Not able to Navigate to Feature landing Page for "
						+ BasePage.currentMethodName);
			}

		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check Edit Feature Page is displayed

	public static void verifyEditFeaturePageIsDisplayed(EditFeaturePage editFeaturePage, String editFeatureName) {
		// check in progress text and wait till 15 secs if Inprogress is
		// displayed.
		UtilityFunctions.applicationWait(2000);
		int index = 0;
		while ((LibraryFunctions.isElementPresent(BasePage.xPath_InProgressImage, 1)
				|| LibraryFunctions.isElementPresent(BasePage.xPath_InProgressText, 1)) && index < 15) {
			UtilityFunctions.applicationWait(1000);
			index++;

		}
		// Verify Edit Feature Page
		if (editFeaturePage.checkEditFeaturePageIsDisplayed(editFeatureName) == false) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " EditFeature Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " EditFeature Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_editfeature_page");
				log.error(
						"Error occured - Not able to Navigate to Edit Feature Page for " + BasePage.currentMethodName);
			}
		} // end of if

	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check Edit SpecificationLimit Page is displayed
	public static void verifyEditSpecificationLimitPageIsDisplayed(
			EditSpecificationLimitPage editSpecificationLimitPage) {
		// check in progress text and wait till 15 secs if Inprogress is
		// displayed.
		UtilityFunctions.applicationWait(2000);
		int index = 0;
		while ((LibraryFunctions.isElementPresent(BasePage.xPath_InProgressImage, 1)
				|| LibraryFunctions.isElementPresent(BasePage.xPath_InProgressText, 1)) && index < 15) {
			UtilityFunctions.applicationWait(1000);
			index++;

		}
		if (!editSpecificationLimitPage.checkEditSpecificationLimitPageIsDisplayed()) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Edit Spec Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Edit Spec Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_editSpecificationLimit_page");
				log.error("Error occured - Not able to Navigate to Edit SpecificationLimit Page for "
						+ BasePage.currentMethodName);
			}
		} // end of if

	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check Process Landing Page display Process Landing Page
	public static void verifyProcessLandingPageIsDisplayed(ProcessLandingPage processLandingPage) throws Exception {
		// Verify Process Landing page
		if (processLandingPage.checkProcessLandingPageIsDisplayed() == false) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Process Landing Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Process Landing Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_process_landing_page");
				log.error("Error occured - Not able to Navigate to Process Landing Page for "
						+ BasePage.currentMethodName);
			}
		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check User Landing Page display User Landing Page
	public static void verifyUserLandingPageIsDisplayed(UserLandingPage userLandingPage) throws Exception {
		// Verify User Landing page
		if (userLandingPage.checkUserLandingPageIsDisplayed() == false) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " User Landing Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " User Landing Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_user_landing_page");
				log.error(
						"Error occured - Not able to Navigate to User Landing Page for " + BasePage.currentMethodName);
			}
		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Verify Create Feature page is displayed
	public static void verifyCreateProcessPageIsDisplayed(CreateProcessPage createProcesspage) {
		// Verify Create Part Page is displayed
		if (createProcesspage.checkCreateProcessPageIsDisplayed() == false) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Create Process Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Create Process Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_Create_process_page");
				log.error("Error occured - Not able to Navigate to Create Process Page for "
						+ BasePage.currentMethodName);

			}
		} // end of if
	}

	// ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Verify User Landing On Correct Edit Feature Page as per the index
	public static void veirfyEditFeaturePageIsDisplayedAsPerIndex(String editFeatureName) {
		EditFeaturePage editFeaturePage = new EditFeaturePage();

		if (!editFeaturePage.checkEditFeaturePageIsDisplayed(editFeatureName)) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Edit Feature Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " EditFeature Page");

			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_EditFeature_page");
				log.error(
						"Error occured - Not able to Navigate to Edit Feature Page for " + BasePage.currentMethodName);

			}
		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	/*
	 * Created By: Mohit Mahana Logic: This Method verifies that after uploading the
	 * document the uploaded document is at the top of the list Return Type: Void
	 */
	public static void verifyDocumentExistsOnTopOfTheList(String fileName, boolean ignoreDuplicate) throws Exception {
		// Verify document uploaded on Screen
		if (!DocumentUploadLibrary.isLastUploadedDocumentPresentOnTopOfList(fileName, ignoreDuplicate)) {
			try {
				Assert.assertEquals(
						ConstantsUtility.errUploadedDocumentIsMissing + " and not exist on the top of list" + fileName,
						ConstantsUtility.msgUploadDocumentShouldBeDisplayed + " at the top of the list");
			} catch (Throwable t) {
				TestLibrary.reportErrorAndtakeScreenshot(t, "Document_Did_Not_Get_Uploaded_Successfully");
				log.error("Error occured - while checking document is Exist for " + BasePage.currentMethodName);
			}
		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	/*
	 * Created By: Amit Logic: This Method verifies that after uploading the invalid
	 * document the uploaded document is at the top of the list Return Type: Void
	 */
	public static void verifyInvalidDocumentExistsOnTopOfTheList(String fileName, boolean ignoreDuplicate)
			throws Exception {
		// Verify document uploaded on Screen
		if (DocumentUploadLibrary.isLastUploadedDocumentPresentOnTopOfList(fileName, ignoreDuplicate)) {
			try {
				Assert.assertEquals(
						ConstantsUtility.errInvalidDocumentIsUploaded + " and exist on the top of list" + fileName,
						ConstantsUtility.msgInvalidDocumentShouldNotUploaded + " at the top of the list");
			} catch (Throwable t) {
				TestLibrary.reportErrorAndtakeScreenshot(t, "Invalid_Document_Uploaded");
				log.error("Error occured - while checking invalid document is Exist for " + BasePage.currentMethodName);
			}
		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	/*
	 * Created By: Mohit Mahana Logic: This Method verifies that the record is saved
	 * and shown on landing page Return Type: Void
	 */
	public static void verifyRecordsSavedSuccessfullyAndDisplayedOnLandingPage(LandingPage landingPage,
			String shortName, String columnName, String recordType, String saveMode) throws Exception {
		if (!landingPage.checkRecordSavedSuccessfullyAndDisplayedOnLandingPage(shortName, columnName, recordType,
				saveMode)) {
			try {
				Assert.assertEquals(ConstantsUtility.errDataIsNotSavedSuccessfully + " for " + recordType,
						ConstantsUtility.msgDataShouldBeSavedSuccessfully + " for " + recordType);
			} catch (Throwable t) {
				TestLibrary.reportErrorAndtakeScreenshot(t, "Data_Did_Not_Saved_Successfully_" + "for_" + recordType);
				log.error("Error occured - Checking record saved successfully and displayed on Landing Page "
						+ BasePage.currentMethodName);
			} // End of catch
		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	/*
	 * Created By: Mohit Mahana Logic: This Method tell us about whether the file
	 * which is uploaded is present in the Feature or not Return: Boolean
	 */
	public static Boolean checkDocumentUploadedSuccessfullyInDatabase(String shortName, String uploadedDocument,
			String landingPageType) throws Exception {
		String documentName = "";

		ResultSet rs = null;
		try {
			switch (landingPageType.toUpperCase()) {
			case "FEATURE":

				rs = DataBaseFunctionsLibraray.executeSelectQuery(
						"select ff.FeatureFileName from Feature f Inner join FeatureFile ff on f.id = ff.FeatureId where f.isDeleted = 0 and f.ShortName ='"
								+ shortName + "'");
				if (rs != null && rs.next())
					documentName = rs.getString("FeatureFileName");
				// We are matching exact string of file name uploaded on UI and
				// from Database
				if (uploadedDocument
						.equals(documentName.substring(0, 5) + documentName.substring(documentName.lastIndexOf("."))))
					return true;

			case "PROCESS":

				rs = DataBaseFunctionsLibraray.executeSelectQuery(
						"select pf.ProcessFileName from Process p Inner join ProcessFile pf on p.id = pf.ProcessId where p.isDeleted = 0 and p.ShortName ='"
								+ shortName + "'");
				if (rs != null && rs.next())
					documentName = rs.getString("ProcessFileName");
				// We are matching exact string of file name uploaded on UI and
				// from Database
				if (uploadedDocument
						.equals(documentName.substring(0, 5) + documentName.substring(documentName.lastIndexOf("."))))
					return true;

			}
		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
		return false;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// use to verify that document is exist in the list or not
	// Parameter fileName: is the name of file which we need to search in the
	// list
	// ignoreDuplicate : use to check duplicate
	// hardAssersion : It is used for the check document after save or before
	// save
	// present : it is used for valid document upload or invalid document upload
	// Author Name: Chanchal Jain
	public static void verifyDocumentExists(String fileName, boolean ignoreDuplicate, Boolean present,
			Boolean hardAssersion) throws Exception {
		// Verify document uploaded on Screen
		if (present) {
			if (DocumentUploadLibrary.isDocumentExistInList(fileName, true) == -1) {
				try {
					Assert.assertEquals(ConstantsUtility.errUploadedDocumentIsMissing
							+ " and not displaying in the list: " + fileName,
							ConstantsUtility.msgUploadDocumentShouldBeDisplayed + " in the list");
				} catch (Throwable t) {
					TestLibrary.reportErrorAndtakeScreenshot(t, "Document_Does_Not_Exist_In_The_List");
					if (hardAssersion)
						return;
				}
			}
		} else {
			if (DocumentUploadLibrary.isDocumentExistInList(fileName, true) != -1) {
				try {
					Assert.assertEquals(ConstantsUtility.errDocumentGetUploaded + fileName,
							ConstantsUtility.msgDocumentShouldNotUploaded + " in the list");
				} catch (Throwable t) {
					TestLibrary.reportErrorAndtakeScreenshot(t, "Document_Should_Not_Get_Uploaded");

					if (hardAssersion)
						return;
				}
			}
		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// use to verify that invalid document is exist in the list or not
	// Parameter fileName: is the name of file which we need to search in the
	// list
	// ignoreDuplicate : use to check duplicate
	// Author Name: Chanchal Jain
	public static void verifyInvalidDocumentExists(String fileName, boolean ignoreDuplicate) throws Exception {
		// Verify document uploaded on Screen
		if (DocumentUploadLibrary.isDocumentExistInList(fileName, true) != -1) {
			try {
				Assert.assertEquals(
						ConstantsUtility.errInvalidDocumentIsUploaded + " and displaying in the list: " + fileName,
						ConstantsUtility.msgInvalidDocumentShouldNotUploaded + " in the list");
			} catch (Throwable t) {
				TestLibrary.reportErrorAndtakeScreenshot(t, "Invalid_Document_Uploaded");
				return;
			}
		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// use to verify that image is exist in the list or not
	// Parameter imageName: is the name of file which we need to search in the
	// list
	// Author Name: Amit Kumar
	public static void verifyImageExists(String imageName) throws Exception {

		for (int i = 0; i < 60; i++) {
			if (ImageUploadLibrary.checkImageUploadedSuccessfully(imageName))
				break;
			else
				UtilityFunctions.applicationWait(1000);
		}
		// Verify document uploaded on Screen
		if (!ImageUploadLibrary.checkImageUploadedSuccessfully(imageName)) {
			try {
				Assert.assertEquals(ConstantsUtility.errImageIsNotSavedSuccessfully + imageName,
						ConstantsUtility.msgImageShouldBeSavedSuccessfully);
			} catch (Throwable t) {
				TestLibrary.reportErrorAndtakeScreenshot(t, "Image_Is_Not_Saved_Successfully");
				return;
			}
		}

	}

	// check that image is uploaded after click on save
	// Author Name: Chanchal Jain
	public static void verifyInvalidImageExists(String imageName) throws Exception {
		// Verify document uploaded on Screen
		if (ImageUploadLibrary.checkImageUploadedSuccessfully(imageName)) {
			try {
				Assert.assertEquals(ConstantsUtility.errInvalidImageIsUploaded + " Image is : " + imageName,
						ConstantsUtility.msgInvalidImageShouldNotUploaded);
			} catch (Throwable t) {
				TestLibrary.reportErrorAndtakeScreenshot(t, "Invalid_Image_Is_uploaded");
				return;
			}
		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	/*
	 * Author: Mohit Mahana Logic: Verify Whether Edit Process Page is Displayed or
	 * not Return type: Void
	 */
	// Verify Edit process page is displayed
	public static void verifyEditProcessPageIsDisplayed(EditProcessPage editProcesspage, String selectedProcess)
			throws Exception {
		// check in progress text and wait till 15 secs if Inprogress is
		// displayed.
		UtilityFunctions.applicationWait(2000);
		int index = 0;
		while ((LibraryFunctions.isElementPresent(BasePage.xPath_InProgressImage, 1)
				|| LibraryFunctions.isElementPresent(BasePage.xPath_InProgressText, 1)) && index < 15) {
			UtilityFunctions.applicationWait(1000);
			index++;

		}
		// Verify Edit Part Page is displayed
		if (!editProcesspage.checkEditProcessPageIsDisplayed(selectedProcess)) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " EditProcess Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " EditProcess Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_To_Navigate_To_Edit_Process_Page");
				log.error(
						"Error occured - Not able to Navigate to Edit Process Page for " + BasePage.currentMethodName);
			}
		} // end of if
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	/*
	 * Created By : Mohit Mahana Logic: This method navigates us from login page to
	 * create Feature page Return: Object of OdCreate Page
	 */
	public static CreateFeaturePage navigateToCreateFeaturePage() throws Exception {

		if (!BasePage.isBrowserClosed() && UtilityFunctions.getMultilingualData("Feature_Header_Title")
				.equalsIgnoreCase(LibraryFunctions.getPageName())) {
			// Click on Back button
			BasePage.pageHeaderNavigation.clickOnCancelButton();
			featureLandingPage = new FeatureLandingPage();
			// Verify Feature Landing Page
			TestLibrary.verifyFeatureLandingPageIsDisplayed(featureLandingPage);
		} else {

			// If Browser is not open then Open browser and if User in not
			// Logged In then Login
			TestLibrary.loginIfNotLoggedInAndVerifyUserIsLoggedIn();
			// Navigate to Feature Landing Page
			featureLandingPage = BasePage.pageHeaderNavigation.navigateToFeatureLandingPage();

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

			// Verify Feature Landing Page
			TestLibrary.verifyFeatureLandingPageIsDisplayed(featureLandingPage);
		}

		// Navigate to Create Feature Page
		createFeaturePage = featureLandingPage.navigateToCreateFeaturePage();

		// Verify Create Feature Page
		TestLibrary.verifyCreateFeaturePageIsDisplayed(createFeaturePage);

		return createFeaturePage;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	/*
	 * This method navigates us from login page to create User page Return: Object
	 * of User Create Page Author - Tanmay
	 */
	public static CreateUserPage navigateToCreateUserPage() throws Exception {

		if (!BasePage.isBrowserClosed() && UtilityFunctions.getMultilingualData("UserLandingPageTitle")
				.equalsIgnoreCase(LibraryFunctions.getPageName())) {
			// Click on Back button
			BasePage.pageHeaderNavigation.clickOnCancelButton();
			userLandingPage = new UserLandingPage();
			// Verify UserLanding Page
			TestLibrary.verifyUserLandingPageIsDisplayed(userLandingPage);
		} else {

			// If Browser is not open then Open browser and if User in not
			// Logged In then Login
			TestLibrary.loginIfNotLoggedInAndVerifyUserIsLoggedIn();
			// Method call for navigation to UserLanding Page
			userLandingPage = BasePage.pageHeaderNavigation.navigateToUserLandingPage();

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

			// Verify UserLanding Page
			TestLibrary.verifyUserLandingPageIsDisplayed(userLandingPage);
		}

		// Navigate to Create User Page
		createUserPage = userLandingPage.navigateToCreateUserPage();

		// Verify Create User Page
		TestLibrary.verifyCreateUserPageIsDisplayed(createUserPage);

		return createUserPage;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	/*
	 * This method navigates us from login page to Edit User page Return: Object of
	 * User EditPage Author - Tanmay
	 */
	public static EditUserPage navigateToEditUserPage(String userName, String fullName) throws Exception {

		if (!BasePage.isBrowserClosed() && UtilityFunctions.getMultilingualData("UserLandingPageTitle")
				.equalsIgnoreCase(LibraryFunctions.getPageName())) {
			// Click on Back button
			BasePage.pageHeaderNavigation.clickOnCancelButton();
			userLandingPage = new UserLandingPage();
			// Verify UserLanding Page
			TestLibrary.verifyUserLandingPageIsDisplayed(userLandingPage);
		} else {

			// If Browser is not open then Open browser and if User in not
			// Logged In then Login
			TestLibrary.loginIfNotLoggedInAndVerifyUserIsLoggedIn();
			// Method call for navigation to UserLanding Page
			userLandingPage = BasePage.pageHeaderNavigation.navigateToUserLandingPage();

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

			// Verify UserLanding Page
			TestLibrary.verifyUserLandingPageIsDisplayed(userLandingPage);
		}
		// Navigate to edit User Page
		Hashtable<String, String> testCaseData = new Hashtable<String, String>();
		testCaseData.put(UserPage.filter_UserUserName, userName);
		editUserPage = userLandingPage.navigateToEditUserPage(testCaseData);

		// Verify Edit User Page
		TestLibrary.verifyEditUserPageIsDisplayed(editUserPage, fullName);

		return editUserPage;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	/*
	 * Created By : Mohit Mahana Logic: This method navigates us from login page to
	 * create Feature page Return: Object of OdCreate Page
	 */
	public static EditFeaturePage navigateToEditFeaturePage(int index) throws Exception {

		String featureNameToBeEdited = "";
		if (!BasePage.isBrowserClosed() && UtilityFunctions.getMultilingualData("Feature_Header_Title")
				.equalsIgnoreCase(LibraryFunctions.getPageName())) {
			// Click on Back button
			BasePage.pageHeaderNavigation.clickOnCancelButton();
			featureLandingPage = new FeatureLandingPage();
			// Verify Feature Landing Page
			TestLibrary.verifyFeatureLandingPageIsDisplayed(featureLandingPage);
		} else {

			// If Browser is not open then Open browser and if User in not
			// Logged In then Login
			TestLibrary.loginIfNotLoggedInAndVerifyUserIsLoggedIn();
			// Navigate to Feature Landing Page
			featureLandingPage = BasePage.pageHeaderNavigation.navigateToFeatureLandingPage();

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

			// Verify Feature Landing Page
			TestLibrary.verifyFeatureLandingPageIsDisplayed(featureLandingPage);
		}

		// get name of record to be edited
		featureNameToBeEdited = featureLandingPage.getRecordNameOfGivenIndex(index);

		// Go to the Edit Feature Page of The Selected Feature and verify
		// user is on correct page
		editFeaturePage = featureLandingPage.navigateToEditFeaturePageWithGivenRowIndex(index);

		// verify correct edit feature page is dispalyed
		TestLibrary.verifyEditFeaturePageIsDisplayed(editFeaturePage, featureNameToBeEdited);
		return editFeaturePage;
	}

	// -------------------------------------------------------------------------------------------------------------------
	// Navigate to edit process page as per record name
	// Author: Yogendra Rathore
	public static EditProcessPage navigateToEditProcessPageForTheGivenProcess(String processName) throws Exception {

		try {

			if (!BasePage.isBrowserClosed() && UtilityFunctions.getMultilingualData("Process_Header_Title")
					.equalsIgnoreCase(LibraryFunctions.getPageName())) {
				// Click on Back button
				BasePage.pageHeaderNavigation.clickOnCancelButton();
				processLandingPage = new ProcessLandingPage();
				// Verify ProcessLanding page
				TestLibrary.verifyProcessLandingPageIsDisplayed(processLandingPage);
			} else {

				// If Browser is not open then Open browser and if User in not
				// Logged In then Login
				TestLibrary.loginIfNotLoggedInAndVerifyUserIsLoggedIn();
				// Navigate to Process Landing Page
				processLandingPage = BasePage.pageHeaderNavigation.navigateToProcessLandingPage();

				// Check To handle Confirmation Message - If appears
				LibraryFunctions.handlingConfirmationBoxMessage("ok");

				// Verify ProcessLanding page
				TestLibrary.verifyProcessLandingPageIsDisplayed(processLandingPage);
			}

			// Method call for navigation to Create Process Page
			editProcessPage = processLandingPage.navigateToSpecificEditProcess(processName);

			// Verify edit Process Page is displayed
			TestLibrary.verifyEditProcessPageIsDisplayed(editProcessPage, processName);

			return editProcessPage;
		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	/*
	 * Created By : Mohit Mahana Logic: This method navigates us from login page to
	 * create Spec page Return: Object of OdCreate Page
	 */
	public static CreateSpecificationLimitPage navigateToCreateSpecPage() throws Exception {
		try {
			if (!BasePage.isBrowserClosed() && UtilityFunctions.getMultilingualData("Spec_Header_Title")
					.equalsIgnoreCase(LibraryFunctions.getPageName())) {
				// Click on Back button
				BasePage.pageHeaderNavigation.clickOnCancelButton();
				specificationLimitLandingPage = new SpecificationLimitLandingPage();
				// Verify Specification Landing page
				TestLibrary.verifySpecificationLimitLandingPageIsDisplayed(specificationLimitLandingPage);
			} else {

				// If Browser is not open then Open browser and if User in not
				// Logged In then Login
				TestLibrary.loginIfNotLoggedInAndVerifyUserIsLoggedIn();
				// Navigate to Specification Landing Page
				specificationLimitLandingPage = BasePage.pageHeaderNavigation.navigateToSpecificationLimitLandingPage();

				// Check To handle Confirmation Message - If appears
				LibraryFunctions.handlingConfirmationBoxMessage("ok");

				// Verify Specification Landing page
				TestLibrary.verifySpecificationLimitLandingPageIsDisplayed(specificationLimitLandingPage);
			}

			// Method call for navigation to Create Specification Limit Page
			createSpecificationLimitPage = specificationLimitLandingPage.navigateToCreateSpecificationLimitPage();

			// Verify Create Specification Limit Page
			TestLibrary.verifyCreateSpecificationLimitPageIsDisplayed(createSpecificationLimitPage);
			return createSpecificationLimitPage;

		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));

		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	/*
	 * Created By : Chanchal Jain Logic: This function is use to check numeric field
	 * validation.
	 */
	public static void verifyNumericFieldValidation(Hashtable<String, String> resultValue, String sharedStepId,
			String columnName) {
		Enumeration<String> e = resultValue.keys();
		while (e.hasMoreElements()) {
			String key = (String) e.nextElement();
			if (key.contains(sharedStepId)) {
				try {
					Assert.assertEquals(
							"Following business rules failed - " + resultValue.get(key) + " on field " + columnName,
							"All the business rules should pass");
				} catch (Throwable t) {
					TestLibrary.reportErrorAndtakeScreenshot(t,
							resultValue.get(key) + "_Business_Rule_Faile_On_" + columnName);
					return;
				} // End of catch
			}
		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to process landing page and return object of
	// process landing page.
	// Author : Yogendra Rathore
	public static ProcessLandingPage navigateToProcessLandingPage() throws Exception {

		try {
			loginIfNotLoggedInAndVerifyUserIsLoggedIn();

			// Navigate to Process Landing Page
			processLandingPage = BasePage.pageHeaderNavigation.navigateToProcessLandingPage();

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

			// Verify ProcessLanding page
			verifyProcessLandingPageIsDisplayed(processLandingPage);

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
		return processLandingPage;
	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to edit spec page and returns object of edit
	// spec page.
	// Author: Yogendra Rathore
	public static EditSpecificationLimitPage navigateToEditSpecificationLimitPage() throws Exception {
		try {
			if (!BasePage.isBrowserClosed() && UtilityFunctions.getMultilingualData("Spec_Header_Title")
					.equalsIgnoreCase(LibraryFunctions.getPageName())) {
				// Click on Back button
				BasePage.pageHeaderNavigation.clickOnCancelButton();
				specificationLimitLandingPage = new SpecificationLimitLandingPage();
				// Verify Specification Landing page
				TestLibrary.verifySpecificationLimitLandingPageIsDisplayed(specificationLimitLandingPage);
			} else {

				// If Browser is not open then Open browser and if User in not
				// Logged In then Login
				TestLibrary.loginIfNotLoggedInAndVerifyUserIsLoggedIn();
				// Navigate to Specification Landing Page
				specificationLimitLandingPage = BasePage.pageHeaderNavigation.navigateToSpecificationLimitLandingPage();

				// Check To handle Confirmation Message - If appears
				LibraryFunctions.handlingConfirmationBoxMessage("ok");

				// Verify Specification Landing page
				TestLibrary.verifySpecificationLimitLandingPageIsDisplayed(specificationLimitLandingPage);
			}

			// Navigation to Edit SpecificationLimit Page
			editSpecificationLimitPage = specificationLimitLandingPage.navigateToEditSpecificationLimit();

			// Verifying Edit SpecificationLimit Page
			TestLibrary.verifyEditSpecificationLimitPageIsDisplayed(editSpecificationLimitPage);
			return editSpecificationLimitPage;
		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to particular edit spec page and returns
	// object of edit
	// spec page.
	// Author: Yogendra Rathore
	// Modified by : Chanchal Jain
	public static EditSpecificationLimitPage navigateToSpecificEditSpecificationLimitPage(
			Hashtable<String, String> testCaseData) throws Exception {
		try {

			if (!BasePage.isBrowserClosed() && UtilityFunctions.getMultilingualData("Spec_Header_Title")
					.equalsIgnoreCase(LibraryFunctions.getPageName())) {
				// Click on Back button
				BasePage.pageHeaderNavigation.clickOnCancelButton();
				specificationLimitLandingPage = new SpecificationLimitLandingPage();
				// Verify Specification Landing page
				TestLibrary.verifySpecificationLimitLandingPageIsDisplayed(specificationLimitLandingPage);
			} else {

				// If Browser is not open then Open browser and if User in not
				// Logged In then Login
				TestLibrary.loginIfNotLoggedInAndVerifyUserIsLoggedIn();
				// Navigate to Specification Landing Page
				specificationLimitLandingPage = BasePage.pageHeaderNavigation.navigateToSpecificationLimitLandingPage();

				// Check To handle Confirmation Message - If appears
				LibraryFunctions.handlingConfirmationBoxMessage("ok");

				// Verify Specification Landing page
				TestLibrary.verifySpecificationLimitLandingPageIsDisplayed(specificationLimitLandingPage);
			}

			// Method call for navigation to Create Specification Limit Page
			editSpecificationLimitPage = specificationLimitLandingPage.navigateToSpecRecord(testCaseData);

			// Verify Create Specification Limit Page
			TestLibrary.verifyEditSpecificationLimitPageIsDisplayed(editSpecificationLimitPage);
			return editSpecificationLimitPage;
		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to create part page and return createPartPage
	// object.
	// Author: Yogendra Rathore
	public static CreatePartPage navigateToCreatePartPage() throws Exception {

		if (!BasePage.isBrowserClosed() && UtilityFunctions.getMultilingualData("Part_Header_Title")
				.equalsIgnoreCase(LibraryFunctions.getPageName())) {
			// Click on Back button
			BasePage.pageHeaderNavigation.clickOnCancelButton();
			partLandingPage = new PartLandingPage();
			// Verify Part Landing Page
			TestLibrary.verifyPartLandingPageIsDisplayed(partLandingPage);
		} else {

			// If Browser is not open then Open browser and if User in not
			// Logged In then Login
			TestLibrary.loginIfNotLoggedInAndVerifyUserIsLoggedIn();
			// Navigate to PartLanding Page
			partLandingPage = BasePage.pageHeaderNavigation.navigateToPartLandingPage();

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

			// Verify Part Landing Page
			TestLibrary.verifyPartLandingPageIsDisplayed(partLandingPage);
		}

		// Method call for navigation to Create New Part Page
		createPartPage = partLandingPage.navigateToCreatePartPage();

		// Verify Create Part Page
		TestLibrary.verifyCreatePartPageIsDisplayed(createPartPage);
		return createPartPage;
	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to part landing page and return
	// partLandingPage
	// object.
	// Author: Yogendra Rathore
	public static PartLandingPage navigateToPartLandingPage() throws Exception {
		// If Browser is not open then Open browser and if User in not
		// Logged In then Login
		TestLibrary.loginIfNotLoggedInAndVerifyUserIsLoggedIn();

		// Check To handle Confirmation Message - If appears
		LibraryFunctions.handlingConfirmationBoxMessage("ok");

		// Navigate to PartLanding Page
		partLandingPage = BasePage.pageHeaderNavigation.navigateToPartLandingPage();

		// Check To handle Confirmation Message - If appears
		LibraryFunctions.handlingConfirmationBoxMessage("ok");

		// Verify PartLanding page
		TestLibrary.verifyPartLandingPageIsDisplayed(partLandingPage);

		return partLandingPage;
	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// ------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to edit part page on basis of Part name and
	// return editPartPage
	// object.
	// Author: Yogendra Rathore
	public static EditPartPage navigateToEditPartPage(String partName, String partRevision) throws Exception {
		if (!BasePage.isBrowserClosed() && UtilityFunctions.getMultilingualData("Part_Header_Title")
				.equalsIgnoreCase(LibraryFunctions.getPageName())) {
			// Click on Back button
			BasePage.pageHeaderNavigation.clickOnCancelButton();
			partLandingPage = new PartLandingPage();
			// Verify Part Landing Page
			TestLibrary.verifyPartLandingPageIsDisplayed(partLandingPage);
		} else {

			// If Browser is not open then Open browser and if User in not
			// Logged In then Login
			TestLibrary.loginIfNotLoggedInAndVerifyUserIsLoggedIn();
			// Navigate to PartLanding Page
			partLandingPage = BasePage.pageHeaderNavigation.navigateToPartLandingPage();

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

			// Verify Part Landing Page
			TestLibrary.verifyPartLandingPageIsDisplayed(partLandingPage);
		}

		// navigate to specific edit part page
		editPartPage = partLandingPage.navigateToSpecificEditPart(partName, partRevision);

		// Verify edit Part Page
		TestLibrary.verifyEditPartPageIsDisplayed(editPartPage, partName, partRevision);

		return editPartPage;
	}

	// -------------------------------------------------------------------------------------------------------------------
	// check upload image icon is present.
	public static boolean checkUploadImageIconIsPresent(ArrayList<String> listOfImageUploadContextMenuOptions) {
		if (!listOfImageUploadContextMenuOptions.get(0)
				.equals(UtilityFunctions.getMultilingualData("ContextMenuUploadImage"))) {
			try {
				Assert.assertEquals(
						listOfImageUploadContextMenuOptions.get(0) + " "
								+ ConstantsUtility.errIconsOnContextualMenuIsNotDisplayedCorrectly,
						ConstantsUtility.msgIconsOnContextualMenuShouldBeDisplayedCorrectly);
			} catch (Throwable t) {
				TestLibrary.reportErrorAndtakeScreenshot(t, "Upload_Image_Contextual_Menu_Is_Not_Displayed");

			} // End of catch
		}
		return true;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Verify test data is generated for test case
	public static int insertAndVerifyTestDataIsGenerated(String pageName, Hashtable<String, String> testData) {
		int Id = 0;
		try {
			switch (pageName) {
			case "FeaturePage":
				Id = FeaturePage.insertTestData(testData);
				break;
			case "PartPage":
				Id = PartPage.insertTestData(testData);
				break;
			case "ProcessPage":
				Id = ProcessPage.insertTestData(testData);
				break;
			case "SpecificationLimit":
				Id = SpecificationLimit.insertTestData(testData);
				break;
			case "LotPage":
				Id = LotPage.insertTestData(testData);
				break;
			case "UserPage":
				UserPage.insertTestData(testData);
				Id = Integer.parseInt(testData.get(UserPage.db_User_ID));
				break;
			case "RolePage":
				UserPage.insertTestDataForRole(testData);
				Id = Integer.parseInt(testData.get(UserPage.db_Role_Id));
			case "TagPage":
				TagGroupPage.insertTestData(testData);
				Id = Integer.parseInt(testData.get(TagGroupPage.db_Tag_Id));
				break;
			case "CollectionAidPage":
				CollectionAidPage.insertTestData(testData);
				Id = Integer.parseInt(testData.get(CollectionAidPage.db_CollectionAid_ID));
				break;

			case "ParameterSet":
				ParameterSetPage.insertTestData(testData);
				Id = Integer.parseInt(testData.get(ParameterSetPage.db_ParameterSet_Id));
				break;
			case "ControlLimitPage":
				ControlLimitPage.insertTestData(testData);
				Id = Integer.parseInt(testData.get(ControlLimitPage.db_ControlLimit_Id));
				break;

			case "ResponseGroupPage":
				ResponseGroupPage.insertTestData(testData);
				Id = Integer.parseInt(testData.get(ResponseGroupPage.db_ResponseGroup_Id));
				break;

			case "ChecklistPage":
				ChecklistPage.insertTestData(testData);
				Id = Integer.parseInt(testData.get(ChecklistPage.db_Checkist_Id));
				break;

			case "CalculationPage":
				Id = CalculationsPage.insertTestData(testData);
				break;

			}
		} catch (Exception e1) {
			try {
				e1.printStackTrace();
				Assert.assertEquals(ConstantsUtility.errTestDataIsNotInsertedForTestCase + BasePage.currentMethodName,
						ConstantsUtility.msgTestDataShouldBeInsertedForTestCase);
			} catch (Throwable t) {
				TestLibrary.reportErrorAndtakeScreenshot(t, "");
				log.error("Error occured - while Insertion and Verification test data into Database "
						+ BasePage.currentMethodName);
				return 0;
			}
		}
		return Id;
	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to edit feature page on basis of feature name
	// and
	// return editFeaturePage
	// object.
	// Author: Bhupendra Singh Chauhan
	public static EditFeaturePage navigateToEditFeaturePage(String featureName) throws Exception {
		if (!BasePage.isBrowserClosed() && UtilityFunctions.getMultilingualData("Feature_Header_Title")
				.equalsIgnoreCase(LibraryFunctions.getPageName())) {
			// Click on Back button
			BasePage.pageHeaderNavigation.clickOnCancelButton();
			featureLandingPage = new FeatureLandingPage();
			// Verify Feature Landing Page
			TestLibrary.verifyFeatureLandingPageIsDisplayed(featureLandingPage);
		} else {

			// If Browser is not open then Open browser and if User in not
			// Logged In then Login
			TestLibrary.loginIfNotLoggedInAndVerifyUserIsLoggedIn();
			// Navigate to Feature Landing Page
			featureLandingPage = BasePage.pageHeaderNavigation.navigateToFeatureLandingPage();

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

			// Verify Feature Landing Page
			TestLibrary.verifyFeatureLandingPageIsDisplayed(featureLandingPage);
		}

		// navigate to specific edit feature page
		Hashtable<String, String> testCaseData = new Hashtable<String, String>();
		testCaseData.put(FeaturePage.filter_FeatureName, featureName);
		editFeaturePage = featureLandingPage.navigateToSpecificEditFeature(testCaseData);

		// Verify edit feature Page
		TestLibrary.verifyEditFeaturePageIsDisplayed(editFeaturePage, featureName);

		return editFeaturePage;
	}

	// ------------------------------------------------------------------------------------------------------------------------

	// this method takes screen shot of some error occur
	// Author : Yogendra Rathore
	// Modified By: Bhupendra Singh
	public static void assertForSomeErrorOccur(String actualErrorMsg) {
		// In case of any error message. Fail the test case
		try {
			log.error("Error Occurred while executing test cases " + BasePage.currentMethodName + actualErrorMsg);
			Assert.assertEquals(ConstantsUtility.errSomeErrorOccured + " " + actualErrorMsg,
					ConstantsUtility.msgTestCaseShouldExecutionSuccessfully);
		} catch (Throwable t) {
			TestLibrary.reportErrorAndtakeScreenshot(t, "Some_Error_Occured");
			return;
		} // End of catch
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check Code group Landing Page display
	// Author: Yogendra Rathore
	public static void verifyCodeGroupLandingPageIsDisplayed(CodeGroupLandingPage codeGroupLandingPage)
			throws Exception {
		// Verify PartLanding page
		if (codeGroupLandingPage.checkCodeGroupLandingPageIsDisplayed() == false)

		{
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Code group Landing Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Code group Landing Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_Code_Group_landing_page");
				log.error("Error occured - Not able to Navigate to CodeGroup Landing Page for "
						+ BasePage.currentMethodName);
			}

		}
	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to code group landing page
	// and
	// return codeGroupLandingPage
	// object.
	// Author: Yogendra Rathore
	public static CodeGroupLandingPage navigateToCodeGroupLandingPage() throws Exception {

		// Verify whether Browser Is Closed
		TestLibrary.loginIfNotLoggedInAndVerifyUserIsLoggedIn();
		LibraryFunctions.handlingConfirmationBoxMessage("ok");

		// Check To handle Confirmation Message - If appears
		LibraryFunctions.handlingConfirmationBoxMessage("ok");

		// Navigate to Code group Landing Page
		codeGroupLandingPage = BasePage.pageHeaderNavigation.navigateToCodeGroupLandingPage();

		// Check To handle Confirmation Message - If appears
		LibraryFunctions.handlingConfirmationBoxMessage("ok");

		// Verify code group Landing page
		TestLibrary.verifyCodeGroupLandingPageIsDisplayed(codeGroupLandingPage);

		return codeGroupLandingPage;
	}

	// ---------------------------------------------------------------------------------------------------------------------------
	// Check Edit code group Page is displayed
	// Author: Yogendra Rathore
	public static void verifyEditCodeGroupPageIsDisplayed(EditCodeGroupPage editCodeGroupPage, String codeGroupName)
			throws Exception {
		// check in progress text and wait till 15 secs if Inprogress is
		// displayed.
		UtilityFunctions.applicationWait(2000);
		int index = 0;
		while ((LibraryFunctions.isElementPresent(BasePage.xPath_InProgressImage, 1)
				|| LibraryFunctions.isElementPresent(BasePage.xPath_InProgressText, 1)) && index < 15) {
			UtilityFunctions.applicationWait(1000);
			index++;

		}
		// Verify Edit code group Page
		if (!editCodeGroupPage.checkEditCodeGroupPageIsDisplayed(codeGroupName)) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Edit Code group Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Edit Code group Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_To_Navigate_To_Edit_Code_Group_Page");
				log.error("Error occured - Not able to Navigate to Edit CodeGroup Page for "
						+ BasePage.currentMethodName);

			}
		} // end of if

	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to edit code group page on basis of code name
	// and code group name
	// and
	// return editCodeGroupPage
	// object.
	// Author: Yogendra Rathore
	public static EditCodeGroupPage navigateToEditCodeGroupPage(String codeGroupName) throws Exception {
		if (!BasePage.isBrowserClosed() && UtilityFunctions.getMultilingualData("CodeGroup_Header_Title")
				.equalsIgnoreCase(LibraryFunctions.getPageName())) {
			// Click on Back button
			BasePage.pageHeaderNavigation.clickOnCancelButton();
			codeGroupLandingPage = new CodeGroupLandingPage();
			// Verify Code Group Landing Page
			TestLibrary.verifyCodeGroupLandingPageIsDisplayed(codeGroupLandingPage);
		} else {

			codeGroupLandingPage = TestLibrary.navigateToCodeGroupLandingPage();
		}

		Hashtable<String, String> testCaseData = new Hashtable<String, String>();
		testCaseData.put(CodeGroupPage.filter_CodeGroupName, codeGroupName);
		// navigate to specific edit code group page
		editCodeGroupPage = codeGroupLandingPage.navigateToEditCodeGroupPage(testCaseData);

		// Verify edit code group Page
		TestLibrary.verifyEditCodeGroupPageIsDisplayed(editCodeGroupPage, codeGroupName);

		return editCodeGroupPage;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to Manual DC landing page and return object of
	// Manual DC landing page.
	// Author : Bhupendra Singh Chuahan
	// modified by: rakesh sharma
	// updating the method because mdc url is not accessible now. user will
	// naviate to datacollection tile view all page
	// Modified by :Yogendra Rathore
	// //action*1 : check dc tile displayed then dont do any thing.
	// modified by Rakesh. Refresh page after creating dashboard thrugh DB
	// Modified by :Yogendra Rathore <23th July 19>
	// //action*2 : check dc tile displayed then click on view all

	public static DCLandingPage navigateAndVerifyManualDCLandingPage() throws Exception {
		try {
			loginIfNotLoggedInAndVerifyUserIsLoggedIn();

			// check if user has any dashboard assinged? and if datacollection
			// tile is present on that dashboard?
			// action*1
			String xPath_inputSearchDC = "//*[@data-selector='search-dc']";

			if (!LibraryFunctions.isElementDisplayed(xPath_inputSearchDC, 5)) {
				if (!LibraryFunctions.isElementDisplayed("//*[@data-selector='view-all-dc']", 5)) {
					// insert data for dashboard
					if (!isDashboardCreated) {
						try {
							Hashtable<String, String> testData = new Hashtable<String, String>();
							isDashboardCreated = TestLibrary.createGenericDashboardWithTile(testData);
							LibraryFunctions.refreshPage();
							LibraryFunctions.handlingConfirmationBoxMessage("OK");
						} catch (Exception e) {
							isDashboardCreated = false;
						}
					}

					dashboardPage = TestLibrary.navigateToDashboardPage();
					dashboardPage.searchAndNavigateToDashboardPage("FA_" + "TC_TestData" + "_DashBoard");

					UtilityFunctions.applicationWait(3000);
				}
				dashboardPage.navigateToDCTileViewAllPage();
			}
			manualDCLandingPage = new DCLandingPage();

		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
		return manualDCLandingPage;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check Manual DC Landing Page display
	public static void verifyManualDCLandingPageIsDisplayed(DCLandingPage manualDCLandingPage) throws Exception {
		// Verify Manual Landing page
		if (!manualDCLandingPage.checkManualDCLandingPageIsDisplayed()) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Manual DC Landing Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Manual DC Landing Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_ManualDC_landing_page");
				log.error("Error occured - Not able to Navigate to Manual DC Landing Page for "
						+ BasePage.currentMethodName);
				throw t;
			}
		}
	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to create part revision on basis of Part name
	// and
	// return
	// object.
	// Author: Yogendra Rathore
	public static CreatePartRevisionPage navigateToCreateRevisonForSpecificPartAndPartRevision(String partName,
			String partRevision) throws Exception {

		if (!BasePage.isBrowserClosed() && UtilityFunctions.getMultilingualData("Part_Header_Title")
				.equalsIgnoreCase(LibraryFunctions.getPageName())) {
			// Click on Back button
			BasePage.pageHeaderNavigation.clickOnCancelButton();
			partLandingPage = new PartLandingPage();
			// Verify Part Landing Page
			TestLibrary.verifyPartLandingPageIsDisplayed(partLandingPage);
		} else {

			// If Browser is not open then Open browser and if User in not
			// Logged In then Login
			TestLibrary.loginIfNotLoggedInAndVerifyUserIsLoggedIn();
			// Navigate to PartLanding Page
			partLandingPage = BasePage.pageHeaderNavigation.navigateToPartLandingPage();

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

			// Verify Part Landing Page
			TestLibrary.verifyPartLandingPageIsDisplayed(partLandingPage);
		}

		// navigate to create new part revision screen of specific part
		createPartRevisionPage = partLandingPage.navigateToCreateRevisonForSpecificPartAndPartRevision(partName,
				partRevision);

		// Verify create Part revision Page
		TestLibrary.verifyCreatePartRevisionPageIsDisplayed(createPartRevisionPage);

		return createPartRevisionPage;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------

	// Verify create part revision page is displayed
	// Author : Yogendra Rathore
	public static void verifyCreatePartRevisionPageIsDisplayed(CreatePartRevisionPage createPartRevisionPage)
			throws Exception {

		if (!createPartRevisionPage.checkCreatePartRevisionPageIsDisplayed()) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Create Part Revision Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Create Part Revision Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_To_Navigate_To_Create_Part_Revision_Page");
				log.error("Error occured - Not able to Navigate to Create Part Revision Page for "
						+ BasePage.currentMethodName);
			}
		} // end of if
	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to create part revision page
	// object.
	// Author: Yogendra Rathore
	public static CreatePartRevisionPage navigateToCreateRevisonPage() throws Exception {

		if (!BasePage.isBrowserClosed() && UtilityFunctions.getMultilingualData("Part_Header_Title")
				.equalsIgnoreCase(LibraryFunctions.getPageName())) {
			// Click on Back button
			BasePage.pageHeaderNavigation.clickOnCancelButton();
			partLandingPage = new PartLandingPage();
			// Verify Part Landing Page
			TestLibrary.verifyPartLandingPageIsDisplayed(partLandingPage);
		} else {

			// If Browser is not open then Open browser and if User in not
			// Logged In then Login
			TestLibrary.loginIfNotLoggedInAndVerifyUserIsLoggedIn();
			// Navigate to PartLanding Page
			partLandingPage = BasePage.pageHeaderNavigation.navigateToPartLandingPage();

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

			// Verify Part Landing Page
			TestLibrary.verifyPartLandingPageIsDisplayed(partLandingPage);
		}

		// navigate to create new part revision screen of specific part
		createPartRevisionPage = partLandingPage.navigateToCreateRevison();

		// Verify create Part revision Page
		TestLibrary.verifyCreatePartRevisionPageIsDisplayed(createPartRevisionPage);

		return createPartRevisionPage;
	}

	// ---------------------------------------------------------------------------------------------------------------------
	// Assertion for Required field validation
	// Author: Yogendra Rathore
	// Modified By Tanmay
	public static void assertForRequiredFieldValidation(Hashtable<String, String> resultSet, String fieldName) {
		// for validation occurs
		if (resultSet.containsKey("Is_Validation_Occurs")) {
			try {
				Assert.assertEquals(fieldName + ConstantsUtility.errIsNotRequired,
						fieldName + ConstantsUtility.msgShouldBeRequired);
			} catch (Throwable t) {

				TestLibrary.reportErrorAndtakeScreenshot(t, fieldName + "_Is_Not_Required");
				return;
			} // End of catch

		}
		// for correct validation message
		if (resultSet.containsKey("Is_Validation_Message_Correct")) {
			try {
				Assert.assertEquals(ConstantsUtility.errValidationMessageIsNotCorrect,
						ConstantsUtility.msgValidationMessageShouldBeCorrect);
			} catch (Throwable t) {

				TestLibrary.reportErrorAndtakeScreenshot(t, fieldName + "_Is_Required_Validation_Message_Is_Incorrect");
				return;
			} // End of catch

		}
		// for cross icon present
		if (resultSet.containsKey("Is_Cross_Icon_Present")) {
			try {
				Assert.assertEquals(ConstantsUtility.errValidationMessageCrossIconIsNotPresent,
						ConstantsUtility.msgValidationMessageCrossIconIsNotPresent);
			} catch (Throwable t) {

				TestLibrary.reportErrorAndtakeScreenshot(t,
						"Cross_Icon_Is_Not_Present_For_Required_Validation_Message_For_" + fieldName);
				return;
			} // End of catch

		}
		// Modified By Tanmay : Validation for Missing Field presence is
		// commented as the functionality has been removed
		// for missing field appears
		/*
		 * if (resultSet.containsKey("Is_Missing_Field_Present")) { try {
		 * Assert.assertEquals( ConstantsUtility.errMissignFieldLegendDoesNotAppear,
		 * ConstantsUtility.msgMissignFieldLegendShouldAappear); } catch (Throwable t) {
		 * 
		 * TestLibrary.reportErrorAndtakeScreenshot(t,
		 * "Missing_Field_Doesn't_Appear_On_Required_Validation_Message_For_" +
		 * fieldName); return; }// End of catch
		 * 
		 * }
		 */
		// for validation message disappears on clicking [x] icon
		if (resultSet.containsKey("Is_Validation_Closed")) {
			try {
				Assert.assertEquals("Validation Message Is Not Closed.", "Validation Message Should Be Closed.");
			} catch (Throwable t) {

				TestLibrary.reportErrorAndtakeScreenshot(t, "Validation_Message_Doesn't_Disappear" + fieldName);
				return;
			} // End of catch

		}
		// for missing field disappears on clicking [x] icon
		if (resultSet.containsKey("Is_Missing_Field_Disappear")) {
			try {
				Assert.assertEquals(ConstantsUtility.errMissignFieldLegendDoesNotDissappear,
						ConstantsUtility.msgMissignFieldLegendShouldDissappear);
			} catch (Throwable t) {

				TestLibrary.reportErrorAndtakeScreenshot(t,
						"Missing_Field_Doesn't_Dissappear_On_Clicking_Cross_Button_Of_Required_Validation_Message_For_"
								+ fieldName);
				return;
			} // End of catch

		}
	}

	// ---------------------------------------------------------------------------------------------------------------------
	// Assertion for unique field validation
	// Author: Yogendra Rathore
	// modofied by : rakesh sharma
	// added check for tab errors
	public static void assertForUniqueFieldValidation(Hashtable<String, String> resultSet, String fieldName) {
		// for validation occurs
		if (resultSet.containsKey("Is_Validation_Occurs")) {
			try {
				Assert.assertEquals(fieldName + ConstantsUtility.errIsNotUnique,
						fieldName + ConstantsUtility.msgShouldBeUnique);
			} catch (Throwable t) {

				TestLibrary.reportErrorAndtakeScreenshot(t, fieldName + "_Is_Not_Unique");
				return;
			} // End of catch

		}
		// for correct validation message
		if (resultSet.containsKey("Is_Validation_Message_Correct")) {
			try {
				Assert.assertEquals(ConstantsUtility.errValidationMessageIsNotCorrect,
						ConstantsUtility.msgValidationMessageShouldBeCorrect);
			} catch (Throwable t) {

				TestLibrary.reportErrorAndtakeScreenshot(t, fieldName + "_Is_Unique_Validation_Message_Is_Incorrect");
			} // End of catch

		}
		// for cross icon present
		if (resultSet.containsKey("Is_Cross_Icon_Present")) {
			try {
				Assert.assertEquals(ConstantsUtility.errValidationMessageCrossIconIsNotPresent,
						ConstantsUtility.msgValidationMessageCrossIconIsNotPresent);
			} catch (Throwable t) {

				TestLibrary.reportErrorAndtakeScreenshot(t,
						"Cross_Icon_Is_Not_Present_For_Unique_Validation_Message_For_" + fieldName);
			} // End of catch

		}

		// for validation message disappears on clicking [x] icon
		if (resultSet.containsKey("Is_Validation_Closed") && !fieldName.equalsIgnoreCase("TagValue_CodeGrp")) {
			try {
				Assert.assertEquals(ConstantsUtility.errValidationMessageNotDisappearOnClickingXbutton,
						ConstantsUtility.msgValidationMessageShouldDisappearOnClickingXbutton);
			} catch (Throwable t) {

				TestLibrary.reportErrorAndtakeScreenshot(t,
						"Validation_Message_Doesn't_Disappear_On_Clicking_Cross_Button_For" + fieldName);
			} // End of catch

		}

		// for tab error not present with error message
		if (resultSet.containsKey("Tab_Error_Present_WithErrorMessage")) {
			try {
				Assert.assertEquals("tab is not red marked with error", "tab should be red marked with error");
			} catch (Throwable t) {

				TestLibrary.reportErrorAndtakeScreenshot(t, "TabError_NotPresent" + fieldName);
			} // End of catch
		}

		// for tab error present without error message
		if (resultSet.containsKey("Tab_Error_Present_WithoutErrorMessage")) {
			try {
				Assert.assertEquals("tab is red marked without error", "tab should not be red marked without error");
			} catch (Throwable t) {

				TestLibrary.reportErrorAndtakeScreenshot(t, "TabError_Present" + fieldName);
			} // End of catch
		}

	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Verify that DataCollection Configuration Screen page is displayed

	// Check user is logged in
	public static void verifyDCConfigurationPageIsDisplayed(DCConfigurationPage dataCollectionConfigurationPage)
			throws Exception {

		if (dataCollectionConfigurationPage.checkDCConfigurationPageIsDisplayed() == true) {
			// Once logged in, set the IsLoggedIn variable to true
			BasePage.IsLoggedIn = true;
		} else {
			try {
				Assert.assertEquals(
						ConstantsUtility.errApplicationPageNotDisplayed + " Data Collection Configuration Screen page",
						ConstantsUtility.msgApplicationPageShouldDisplay
								+ " Data Collection Configuration Screen page");

			} catch (Exception t) {
				TestLibrary.reportErrorAndtakeScreenshot(t,
						"Data_Collection_Configuration_Screen_Page_Did_not_Display");
				log.error("Error occured - Not able to Navigate to DataCollection Configuration Page for "
						+ BasePage.currentMethodName);
				throw t;
			}

		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Verify that DataCollection Settings page is displayed
	public static void verifyDCSettingPageIsDisplayed(DCConfigurationSettingsPage dataCollectionSettingsPage) {
		UtilityFunctions.applicationWait(1000);
		if (dataCollectionSettingsPage.checkDCSettingsPageIsDisplayed() == true) {
			// Once logged in, set the IsLoggedIn variable to true
			BasePage.IsLoggedIn = true;
		} else {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Data Collection Settings page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Data Collection Settings page");

			} catch (Exception t) {
				TestLibrary.reportErrorAndtakeScreenshot(t, "Data_Collection_Settings_page_Did_not_Display");
				log.error("Error occured - Not able to Navigate to DataCollection Settings Page for "
						+ BasePage.currentMethodName);
				throw t;
			}
		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Verify that DataCollection Configuration page is displayed

	// Check user is logged in
	public static void verifyDCLandingPageIsDisplayed(DCConfigurationLandingPage dataCollectionLandingPage)
			throws Exception {
		if (dataCollectionLandingPage.checkDCLandingPageisDisplayed() == true) {
			// Once logged in, set the IsLoggedIn variable to true
			BasePage.IsLoggedIn = true;
		} else {
			try {
				Assert.assertEquals("Data Collection Landing Page is not dispolayed",
						"Data Collection Landing Page should display");
			} catch (Throwable t) {
				TestLibrary.reportErrorAndtakeScreenshot(t, "Data_Collection_Landing_Page_Did_not_Display");
				log.error("Error occured - Not able to Navigate to DataCollection Landing Page for "
						+ BasePage.currentMethodName);
				throw t;
			}
		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Verify that Navigation to DataCollection Setting page is Successful
	public static DCConfigurationSettingsPage navigateToDCSettingsPage(int DCConfiguration_Id) throws Exception {

		try {

			DCConfigurationPage dcConfigurationPage = new DCConfigurationPage();

			navigateToDCConfigurationPage(DCConfiguration_Id);
			UtilityFunctions.applicationWait(4000);
			dcSettingsPage = dcConfigurationPage.navigateToDCSettingsPage();
			// Verify whether DataCollection Setting page displayed
			// or not
			UtilityFunctions.applicationWait(4000);
			TestLibrary.verifyDCSettingPageIsDisplayed(dcSettingsPage);

		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}

		return dcSettingsPage;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Navigate To Individual DC Setting page
	// Author: Yogendra Rathore
	public static DCIndividualSettingsPage navigateToDCIndividualSettingsPage(int dCConfiguration_Id,
			boolean isGlobalCheckBoxChecked, List<String> featureNameList) throws Exception {

		try {
			DCConfigurationPage dcConfigurationPage = new DCConfigurationPage();
			if (BasePage.isBrowserClosed() || !dcConfigurationPage.checkDCConfigurationPageIsDisplayed())
				navigateToDCConfigurationPage(dCConfiguration_Id);

			BasePage.dr.manage().window().maximize();
			dCIndividualSettingsPage = dcConfigurationPage.navigateToEntryRulePage(isGlobalCheckBoxChecked,
					featureNameList);

			UtilityFunctions.applicationWait(2000);
			verifyDCIndividualSettingPageIsDisplayed(dCIndividualSettingsPage);

		} catch (Exception e) {
			log.error("Error occured - Not able to Navigate DC individual setting Page for "
					+ BasePage.currentMethodName);
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));

		}
		return dCIndividualSettingsPage;

	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Verify that DataCollection Settings page is displayed
	// Author : Priyanka Kundu
	public static void verifyDCIndividualSettingPageIsDisplayed(
			DCIndividualSettingsPage dataCollectionIndividualSettingsPage) {
		if (!dataCollectionIndividualSettingsPage.checkDataCollectionIndividualSettingsPageIsDisplayed()) {

			try {
				Assert.assertEquals(
						ConstantsUtility.errApplicationPageNotDisplayed + " Data Collection Individual Settings page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Data Collection Individual Settings page");

			} catch (Exception t) {
				TestLibrary.reportErrorAndtakeScreenshot(t, "Data_Collection_Individual_Settings_Page_Did_not_Display");
				log.error("Error occured - Not able to Navigate to DataCollection Settings Page for "
						+ BasePage.currentMethodName);
			}
		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Verify that Navigation to DataCollection screen page is Successful
	public static DCConfigurationPage navigateToDCConfigurationPage(int DCConfiguration_Id) throws Exception {

		try {
			dcLandingPage = navigateToDCLandingPage();
			dcConfigurationPage = dcLandingPage.navigateToDCConfigurationPage(DCConfiguration_Id);
			UtilityFunctions.applicationWait(2000);
			// Verify whether DataCollection ConfigurationScreen page displayed
			// or not
			TestLibrary.verifyDCConfigurationPageIsDisplayed(dcConfigurationPage);
		} catch (Exception e) {
			log.error("Error occured - Not able to Navigate DC configration Page for " + BasePage.currentMethodName);
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
		return dcConfigurationPage;

	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Verify that Navigation to DataCollection configuration landing page is
	// Successful
	public static DCConfigurationLandingPage navigateToDCLandingPage() throws Exception {

		try {
			TestLibrary.loginIfNotLoggedInAndVerifyUserIsLoggedIn();

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

			dcLandingPage = BasePage.pageHeaderNavigation.navigateToDCLandingPage();

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

			// Verify whether DataCollection Landing page displayed
			// or not
			TestLibrary.verifyDCLandingPageIsDisplayed(dcLandingPage);

		} catch (Exception e) {
			log.error("Error occured - Not able to Navigate DC landing Page for " + BasePage.currentMethodName);
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}

		return dcLandingPage;

	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Assertion for Edit Allow Modification Tab
	// Author: Priyanka Kundu
	public static void assertForAllowModificationTabOnDCSettingsPage(Hashtable<String, String> resultSet) {

		if (resultSet.containsKey("ChkboxValueEditableDuringDC")) {
			try {
				Assert.assertEquals(resultSet.get("keysAllowModification_ValueEditableDuringDC"),
						"Checkbox should not be selected by default");

			} catch (Throwable t) {

				TestLibrary.reportErrorAndtakeScreenshot(t,
						"ChkboxValueEditableDuringDC Is" + resultSet.get("ChkboxValueEditableDuringDC"));
				return;
			} // End of catch

		}

	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Assertion for Edit Allow Modification Tab
	// Author: Priyanka Kundu
	public static void assertForSpecificationLimitNotificationTabOnDCSettingsPage(Hashtable<String, String> resultSet) {
		if (resultSet.containsKey("ChkboxDisplayScale")) {
			try {
				Assert.assertEquals(resultSet.get("resultSet.get(keysSpecificationNotification_DisplayScale  )"),
						resultSet.get("Checkbox should not be selected by default."));

			} catch (Throwable t) {

				TestLibrary.reportErrorAndtakeScreenshot(t,
						"ChkboxDisplayScale Is" + resultSet.get("ChkboxDisplayScale"));
				return;
			} // End of catch

		}

		if (resultSet.containsKey("ChkboxGridNotification")) {
			try {
				Assert.assertEquals(
						resultSet.get("resultSet.get(keysSpecificationNotification_HighlightGridNotification  )"),
						resultSet.get("Checkbox should not be selected by default."));

			} catch (Throwable t) {

				TestLibrary.reportErrorAndtakeScreenshot(t,
						"ChkboxGridNotification" + resultSet.get("ChkboxGridNotification"));
				return;
			} // End of catch

		}

		if (resultSet.containsKey("ChkboxPopupNotification")) {
			try {
				Assert.assertEquals(
						resultSet.get("resultSet.get(keysSpecificationNotification_Highlight_Popup_Notification )"),
						resultSet.get("Checkbox should not be selected by default."));

			} catch (Throwable t) {

				TestLibrary.reportErrorAndtakeScreenshot(t,
						"ChkboxPopupNotification" + resultSet.get("ChkboxPopupNotification"));
				return;
			} // End of catch

		}

	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Assertion for Edit Allow Modification Tab
	// Author: Priyanka Kundu
	public static void assertForEntryRuleLinkIsDisabled(Hashtable<String, String> resultSet) {

		if (resultSet.containsKey("CheckBox")) {
			try {
				Assert.assertEquals(resultSet.get("CheckBox"), "No Checkbox should be selected");

			} catch (Throwable t) {

				TestLibrary.reportErrorAndtakeScreenshot(t, resultSet.get("CheckBox"));
				return;
			} // End of catch

		} else if (resultSet.containsKey("EntryRuleLink")) {
			try {
				Assert.assertEquals(resultSet.get("EntryRuleLink"), "EntryRule Link should be disabled");

			} catch (Throwable t) {

				TestLibrary.reportErrorAndtakeScreenshot(t, resultSet.get("EntryRuleLink"));
				return;
			} // End of catch

		}

	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// verify that Specification Limit Notification Tab is active
	// Check user is logged in
	// Author: Priyanka Kundu
	public static void assertForConfirmationMessage() throws Exception {
		try {
			Assert.assertEquals("Confirmation Message is not displayed", "Confirmation Message should be displayed");
		} catch (Throwable t) {
			TestLibrary.reportErrorAndtakeScreenshot(t, "Confirmation_Message_Is_Not_Displayed");
			return;
		}
	}

	// ------------------------------------------------------------------------------------------------
	// verifySuccessMessageIsDisplayed(editPartPage,partNamepartRevision
	// Author: Yogendra Rathore
	public static void verifySaveSuccessfullyNotificationIsDisplayed(String expectedValidationMessage)
			throws Exception {

		try {
			if (!LibraryFunctions.verifySaveSuccessfullyNotificationIsDisplayed(expectedValidationMessage)) {
				try {
					Assert.assertEquals(ConstantsUtility.errSavedSuccessfullyNotificatioinNotDisplayed,
							ConstantsUtility.msgSavedSuccessfullyNotificatioinShouldDisplay);
				} catch (Throwable t) {
					TestLibrary.reportErrorAndtakeScreenshot(t, "Saved_Successfully_Message_Not_Displayed");
					return;
				} // End
			}
		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// This method navigates user to Specification Limit Landing Page and
	// returns object of Specification Limit Landing Page
	// Author: Bhupendra Singh Chauhan
	public static SpecificationLimitLandingPage navigateToSpecificationLimitLandingPage() throws Exception {
		try {
			// If Browser is not open then Open browser and if User in not

			// Logged In then Login
			TestLibrary.loginIfNotLoggedInAndVerifyUserIsLoggedIn();

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

			// Navigate to SpecificationLimitLanding Page
			specificationLimitLandingPage = BasePage.pageHeaderNavigation.navigateToSpecificationLimitLandingPage();

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

			// Verify SpecificationLimitLanding Page
			TestLibrary.verifySpecificationLimitLandingPageIsDisplayed(specificationLimitLandingPage);

			return specificationLimitLandingPage;
		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to create Process page
	// and return create Process page object.
	// Author: Bhupendra Singh Chauhan
	public static CreateProcessPage navigateToCreateProcessPage() throws Exception {
		if (!BasePage.isBrowserClosed() && UtilityFunctions.getMultilingualData("Process_Header_Title")
				.equalsIgnoreCase(LibraryFunctions.getPageName())) {
			// Click on Back button
			BasePage.pageHeaderNavigation.clickOnCancelButton();
			processLandingPage = new ProcessLandingPage();
			// Verify ProcessLanding page
			TestLibrary.verifyProcessLandingPageIsDisplayed(processLandingPage);
		} else {

			// If Browser is not open then Open browser and if User in not
			// Logged In then Login
			TestLibrary.loginIfNotLoggedInAndVerifyUserIsLoggedIn();
			// Navigate to Process Landing Page
			processLandingPage = BasePage.pageHeaderNavigation.navigateToProcessLandingPage();

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

			// Verify ProcessLanding page
			TestLibrary.verifyProcessLandingPageIsDisplayed(processLandingPage);
		}

		// navigate to create process page
		createProcessPage = processLandingPage.navigateToCreateProcessPage();

		// Verify create Part revision Page
		TestLibrary.verifyCreateProcessPageIsDisplayed(createProcessPage);

		return createProcessPage;
	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to specific Process entity
	// and return edit Process page object.
	// Author: Bhupendra Singh Chauhan
	public static EditProcessPage navigateToEditProcessPage(String processName) throws Exception {
		if (!BasePage.isBrowserClosed() && UtilityFunctions.getMultilingualData("Process_Header_Title")
				.equalsIgnoreCase(LibraryFunctions.getPageName())) {
			// Click on Back button
			BasePage.pageHeaderNavigation.clickOnCancelButton();
			processLandingPage = new ProcessLandingPage();
			// Verify ProcessLanding page
			TestLibrary.verifyProcessLandingPageIsDisplayed(processLandingPage);
		} else {

			// If Browser is not open then Open browser and if User in not
			// Logged In then Login
			TestLibrary.loginIfNotLoggedInAndVerifyUserIsLoggedIn();
			// Navigate to Process Landing Page
			processLandingPage = BasePage.pageHeaderNavigation.navigateToProcessLandingPage();

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

			// Verify ProcessLanding page
			TestLibrary.verifyProcessLandingPageIsDisplayed(processLandingPage);
		}

		// navigate to edit process page
		editProcessPage = processLandingPage.navigateToSpecificEditProcess(processName);

		// Verify create Part revision Page
		TestLibrary.verifyEditProcessPageIsDisplayed(editProcessPage, processName);

		return editProcessPage;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Assertion for Columns Not Displayed On Grid Or Configure Column PopUp
	// Author: Priyanka Kundu
	// Modified by - Chanchal Jain
	// added one more condition
	public static void assertForFilteredColumns(ArrayList<String> result) {

		LandingPage landingPage = new LandingPage();
		int length = result.size();

		// check filter is applied or not
		if (landingPage.expectedCountOfAppliedFilter == "FilterNotApplied" && length == 0) {
			try {
				Assert.assertEquals("Not able to filter data ", "Filter should be working fine");
			} catch (Throwable t) {
				TestLibrary.reportErrorAndtakeScreenshot(t, "Filteration_Is_Not_Working_Properly");
				return;
			} // End of catch
		} else {
			// check count
			if (!result.get(length - 1).equals(landingPage.expectedCountOfAppliedFilter)) {
				try {
					Assert.assertEquals("Filter count not equal. Actual Count - "
							+ landingPage.expectedCountOfAppliedFilter + ", Expected Count - " + result.get(length - 1),
							"Filter count should be equal");
				} catch (Throwable t) {
					TestLibrary.reportErrorAndtakeScreenshot(t, "Filter_Count_Should_Be_Same");
					return;

				} // End of catch
			}

			if (length != 1) {

				if (result.get(0).equals(String.valueOf(false))) {
					try {
						Assert.assertEquals(
								ConstantsUtility.errGridDataAndDataBaseDataIsNotMatched
										+ " after applying Filter on Landing Page Column " + result.get(3) + " "
										+ result.get(1) + " DB Value " + result.get(2),
								ConstantsUtility.msgGridDataAndDataBaseDataShouldBeMatched);
					} catch (Throwable t) {
						TestLibrary.reportErrorAndtakeScreenshot(t, "Filteration_Is_Not_Working_Properly");
						return;

					} // End of catch
				}

			} else {

				try {
					Assert.assertEquals("Grid data is blank after applying filter.",
							"Grid data should not be blank after applying filter.");
				} catch (Throwable t) {
					TestLibrary.reportErrorAndtakeScreenshot(t, "Grid_Data_Should_Not_Be_Blank");
					return;

				} // End of catch
			}

		}

	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check Manual DC DataEntry Page display
	public static void verifyManualDCDataEntryPageIsDisplayed(BeginMeasurementPage manualDCDataEntryPage,
			String dcShortName) throws Exception {
		// Verify Manual DC DataEntry page or enter sample time pop up is
		// displayed.
		if (!manualDCDataEntryPage.checkEnterSampleTimePopUpIsDisplayed()
				&& !manualDCDataEntryPage.checkLotPopUpIsDisplayed()
				&& !manualDCDataEntryPage.checkDataCollectionTypePopUpIsDisplayed()) {
			if (!manualDCDataEntryPage.checkManualDCDataEntryPageIsDisplayed(dcShortName)) {
				try {
					Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Manual DC DataEntry Page",
							ConstantsUtility.msgApplicationPageShouldDisplay + " Manual DC DataEntry Page");
					return;
				} catch (Throwable t) {
					reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_ManualDC_DataEntry_page");
					log.error("Error occured - Not able to Navigate to Manual DC DataEntryPage for "
							+ BasePage.currentMethodName);
					throw t;
				}
			}

		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// navigate and verify ManualDCDataEntry Page is displayed
	// Author Name - Chanchal Jain
	// Modified by : Yogendra RATHORE
	// Action : added handling confirmation of dirty data.
	// Modified by : Yogendra Rathore<19-Feb_19>
	// changed return type to null
	public static Object navigateAndVerifyManualDCDataEntryPage(int DCConfiguration_Id, String dcShortName)
			throws Exception {

		try {

			// naviagte and Verify Manual DC Landing Page is Displayed
			manualDCLandingPage = TestLibrary.navigateAndVerifyManualDCLandingPage();
			LibraryFunctions.handlingConfirmationBoxMessage("Ok");
			UtilityFunctions.applicationWait(2000);

			// naviagte to manual DC Data entry page
			BeginMeasurementPage beginMeasurementPage = manualDCLandingPage.navigateToSpecificDC(dcShortName);

			LibraryFunctions.checkLoadingIconIsDisplayed("SpinningLoadingIcon", 60);
			if (!(manualDCLandingPage.checkPartPopUpIsDisplayed(dcShortName)
					|| manualDCLandingPage.checkProcessPopUpIsDisplayed(dcShortName))) {
				TestLibrary.verifyManualDCDataEntryPageIsDisplayed(beginMeasurementPage, dcShortName);

				return beginMeasurementPage;
			} else
				return beginMeasurementPage;
		} catch (Exception t) {

			log.error(
					"Error occured - Not able to Navigate to begin measurement page for " + BasePage.currentMethodName);
			throw new Exception("error in navigateAndVerifyManualDCDataEntryPage");
		}

	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// navigate and verify DCAddTagsPopUppPage is displayed.
	// Author Name - Yogendra Rathore
	public static DCAddTagsPopUppPage navigateAndVerifyDCAddTagsPopUppPage(int DCConfiguration_Id, String dcShortName)
			throws Exception {

		try {
			// navigate and Verify Manual DC Part Process Page is Displayed
			/*
			 * dCAddTagsPopUppPage = (DCAddTagsPopUppPage) TestLibrary
			 * .navigateAndVerifyManualDCDataEntryPage(DCConfiguration_Id, dcShortName);
			 * 
			 * UtilityFunctions.applicationWait(1000);
			 */

			// naviagte and Verify Manual DC Landing Page is Displayed
			manualDCLandingPage = TestLibrary.navigateAndVerifyManualDCLandingPage();

			UtilityFunctions.applicationWait(2000);

			// naviagte to manual DC Data entry page
			manualDCLandingPage.navigateToSpecificDC(dcShortName);
			dCAddTagsPopUppPage = new DCAddTagsPopUppPage();

			UtilityFunctions.applicationWait(2000);

			TestLibrary.verifyDCAddTagsPopUppPageIsDisplayed(dCAddTagsPopUppPage);

			return dCAddTagsPopUppPage;
		} catch (Exception t) {

			log.error("Error occured - Not able to Navigate to DC Add Tags PopUpp page for "
					+ BasePage.currentMethodName);
			throw t;
		}

	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check DCAddTagsPopUppPage display
	// Author : Yogendra Rathore
	public static void verifyDCAddTagsPopUppPageIsDisplayed(DCAddTagsPopUppPage dCAddTagsPopUppPage) throws Exception {
		// Verify DCAddTagsPopUppPage
		if (!dCAddTagsPopUppPage.checkDCAddTagsPopUpPageIsDisplayed()) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " DCAddTagsPopUppPage",
						ConstantsUtility.msgApplicationPageShouldDisplay + " DCAddTagsPopUppPage");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_DCAddTagsPopUppPage");
				log.error("Error occured - Not able to Navigate to DCAddTagsPopUppPage for "
						+ BasePage.currentMethodName);
				throw t;
			}
		}
	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to Feature landing page and return
	// FeatureLandingPage
	// object.
	// Author: Ashish Saxena

	public static FeatureLandingPage navigateToFeatureLandingPage() throws Exception {
		FeatureLandingPage featureLandingPage;
		// If Browser is not open then Open browser and if User in not
		// Logged In then Login
		TestLibrary.loginIfNotLoggedInAndVerifyUserIsLoggedIn();

		// Check To handle Confirmation Message - If appears
		LibraryFunctions.handlingConfirmationBoxMessage("ok");

		// Navigate to FeatureLanding Page
		featureLandingPage = BasePage.pageHeaderNavigation.navigateToFeatureLandingPage();

		// Check To handle Confirmation Message - If appears
		LibraryFunctions.handlingConfirmationBoxMessage("ok");
		// verify feature lanfing page is displayed

		TestLibrary.verifyFeatureLandingPageIsDisplayed(featureLandingPage);

		return featureLandingPage;

	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Assertion for Columns Not Displayed On Grid Or Configure Column PopUp
	// Author: Priyanka Kundu
	public static void assertForColumnsNotDisplayedOnGridOrConfigureColumnPopUp(Hashtable<String, String> resultSet) {

		// columns which are not present in Grid
		if (resultSet.get("columnsNotPresentInGrid").length() != 0) {
			try {
				Assert.assertEquals(resultSet.get("columnsNotPresentInGrid") + " Not present on Grid",
						resultSet.get("columnsNotPresentInGrid") + " Should be present on Grid");
			} catch (Throwable t) {
				TestLibrary.reportErrorAndtakeScreenshot(t, "Some_Columns_Missing_on_Landingpage");
			}
		}

		// columns which are not present in Configure Column Popover
		if (resultSet.get("columnsNotPresentInConfigureColumnPopover").length() != 0) {
			try {
				Assert.assertEquals(
						resultSet.get("columnsNotPresentInConfigureColumnPopover")
								+ " Not present on Configure Column Popover",
						resultSet.get("columnsNotPresentInConfigureColumnPopover")
								+ " Should be present on Configure Column Popover");
			} catch (Throwable t) {
				TestLibrary.reportErrorAndtakeScreenshot(t,
						"Some_Columns_Missing_on_ConfigureColumnPopover_on_Landingpage");

			}
		}

		// columns which are not selected in Configure Column Popover
		if (resultSet.get("columnsNotSelectedInConfigureColumnPopover").length() != 0) {

			try {
				Assert.assertEquals(
						resultSet.get("columnsNotSelectedInConfigureColumnPopover")
								+ " Not Selected on Configure Column Popover",
						resultSet.get("columnsNotSelectedInConfigureColumnPopover")
								+ " Should be Selected on Configure Column Popover");
			} catch (Throwable t) {
				TestLibrary.reportErrorAndtakeScreenshot(t,
						"Some_Columns_Not_Selected_on_ConfigureColumnPopover_on_Landingpage");

			}

		}

	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Assertion for Columns Not Displayed On Grid Or Configure Column PopUp
	// Author: Priyanka Kundu
	public static void assertForColumnsDisplayedOnGridOrConfigureColumnPopUp(Hashtable<String, String> resultSet) {

		// columns which are not present in Grid
		if (resultSet.containsKey("dirtyColumnsPresentInGrid")) {
			if (resultSet.get("dirtyColumnsPresentInGrid").length() != 0) {
				try {
					Assert.assertEquals(resultSet.get("dirtyColumnsPresentInGrid") + " Present on Grid",
							resultSet.get("dirtyColumnsPresentInGrid") + " Should not present on Grid");
				} catch (Throwable t) {
					TestLibrary.reportErrorAndtakeScreenshot(t, "Some_Dirty_Columns_Present_on_Landingpage");
				}
			}
		}
		if (resultSet.containsKey("dirtycolumnsNotPresentInConfigureColumnPopover")) {
			// columns which are not present in Configure Column Popover
			if (resultSet.get("dirtycolumnsNotPresentInConfigureColumnPopover").length() != 0) {
				try {
					Assert.assertEquals(
							resultSet.get("dirtycolumnsNotPresentInConfigureColumnPopover")
									+ " Not present on Configure Column Popover",
							resultSet.get("dirtycolumnsNotPresentInConfigureColumnPopover")
									+ " Should be present on Configure Column Popover");
				} catch (Throwable t) {
					TestLibrary.reportErrorAndtakeScreenshot(t,
							"Some_Columns_Missing_on_ConfigureColumnPopover_on_Landingpage");

				}
			}
		}
		if (resultSet.containsKey("dirtycolumnsNotPresentInConfigureColumnPopover")) {

			// columns which are not selected in Configure Column Popover
			if (resultSet.get("dirtycolumnsSelectedInConfigureColumnPopover").length() != 0) {
				try {
					Assert.assertEquals(
							resultSet.get("dirtycolumnsSelectedInConfigureColumnPopover")
									+ " Selected on Configure Column Popover",
							resultSet.get("dirtycolumnsSelectedInConfigureColumnPopover")
									+ " Should not be Selected on Configure Column Popover");
				} catch (Throwable t) {
					TestLibrary.reportErrorAndtakeScreenshot(t,
							"Some_Dirty_Columns_Selected_on_ConfigureColumnPopover_on_Landingpage");

				}
			}
		}

	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Assert for Configure Column Popover is not closed
	// Author: Priyanka Kundu
	public static void assertForConfigureColumnPopOverClosed(Hashtable<String, String> resultSet) {

		// Configure Column Popover is not closed
		if (resultSet.get("configureColumnPopOverNotCLosed") == "True") {
			try {
				Assert.assertEquals("Configure Column Popover is not closed",
						"Configure Column Popover should be closed");
			} catch (Throwable t) {
				TestLibrary.reportErrorAndtakeScreenshot(t, "ConfigureColumnPopover_Is_Not_CLosed");

			}
		}

	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Assertion for Columns Not Displayed On Grid Or Configure Column PopUp
	// Author: Priyanka Kundu
	public static void assertForFrozenColumnsInConfigureColumnPopUp(Hashtable<String, String> resultSet) {

		// columns which are not present in Configure Column Popover
		if (resultSet.get("columnsNotPresentInConfigureColumnPopover").length() != 0) {
			try {
				Assert.assertEquals(
						resultSet.get("columnsNotPresentInConfigureColumnPopover")
								+ " Not present on Configure Column Popover",
						resultSet.get("columnsNotPresentInConfigureColumnPopover")
								+ " Should be present on Configure Column Popover");
			} catch (Throwable t) {
				TestLibrary.reportErrorAndtakeScreenshot(t,
						"Some_Columns_Missing_on_ConfigureColumnPopover_on_Landingpage");

			}
		}

		// columns which are not selected in Configure Column Popover
		if (resultSet.get("columnsNotSelectedInConfigureColumnPopover").length() != 0) {

			try {
				Assert.assertEquals(
						resultSet.get("columnsNotSelectedInConfigureColumnPopover")
								+ " Not Selected on Configure Column Popover",
						resultSet.get("columnsNotSelectedInConfigureColumnPopover")
								+ " Should be Selected on Configure Column Popover");
			} catch (Throwable t) {
				TestLibrary.reportErrorAndtakeScreenshot(t,
						"Some_Columns_Not_Selected_on_ConfigureColumnPopover_on_Landingpage");

			}

		}

		// columns which are not selected in Configure Column Popover
		if (resultSet.get("listOfColumnsEnabled").length() != 0) {
			try {
				Assert.assertEquals(resultSet.get("listOfColumnsEnabled") + " Enabled on Configure Column Popover",
						resultSet.get("listOfColumnsEnabled") + " Should not be Enabled on Configure Column Popover");
			} catch (Throwable t) {
				TestLibrary.reportErrorAndtakeScreenshot(t,
						"Some_Columns_Enabled_on_ConfigureColumnPopover_on_Landingpage");

			}
		}

	}

	// ---------------------------------------------------------------------------------------------------------------------
	// Assertion for delete record
	// Author: Yogendra Rathore
	// Modified by: rakesh sharma
	// added condition to check if no sucess message is expected
	public static void assertForDeleteRecord(Hashtable<String, String> result) throws Exception {
		String expectedConfirmationMessage = "", actualConfirmationMessage = "", expectedDeletePopUpTitle = "";
		String expectedDeletedSuccessfullyMessage = "", actualDeletedSuccessfullyMessage = "",
				actualDeletedPopupTitle = "";
		String expectedMessageWithAssociationUsersText = "", expectedMessageWithAssociationRoleText = "";

		if (result.containsKey("expectedConfirmationMessage")) {
			expectedConfirmationMessage = result.get("expectedConfirmationMessage");
		}

		if (result.containsKey("expectedDeletedSuccessfullyMessage")) {
			expectedDeletedSuccessfullyMessage = result.get("expectedDeletedSuccessfullyMessage");
		}

		if (result.containsKey("expectedPopUpTitle")) {
			expectedDeletePopUpTitle = result.get("expectedPopUpTitle");
		}

		if (result.containsKey("removePopUpMessageWithAssociationUsersText")) {
			expectedMessageWithAssociationUsersText = result.get("removePopUpMessageWithAssociationUsersText");
		}
		if (result.containsKey("removePopUpMessageWithAssociationRolesText")) {
			expectedMessageWithAssociationRoleText = result.get("removePopUpMessageWithAssociationUsersText");
		}

		// check confirmation displayed
		if (result.containsKey("Confirmation Message Displayed")) {

			try {
				Assert.assertEquals(ConstantsUtility.errNoConfirmationMessageDispalyedOnDeletingRecord,
						ConstantsUtility.msgConfirmationMessageShouldBeDisplayed);
			} catch (Throwable t) {
				TestLibrary.reportErrorAndtakeScreenshot(t,
						"No_Confirmation_Message_Is_Displayed_On_Deleting_A_Record");
				return;
			} // End of catch
		}
		// check confirmation cross [X] button is present
		if (result.containsKey("Pop Up Close Button Present")) {
			try {
				Assert.assertEquals(ConstantsUtility.errValidationMessageCrossIconIsNotPresent,
						ConstantsUtility.msgValidationMessageCrossIconIsNotPresent);
			} catch (Throwable t) {
				TestLibrary.reportErrorAndtakeScreenshot(t,
						"No_Cross[X]_Button_Is_Present_On_Confirmation_Message_Displayed_On_Deleting_A_Record");

			} // End of catch
		}
		// get actual Confirmation message
		if (result.containsKey("Confirmation Message")) {
			actualConfirmationMessage = result.get("Confirmation Message");

			if (!expectedConfirmationMessage.equals(actualConfirmationMessage)) {
				System.out.println(expectedConfirmationMessage + "-- Exepcted Confirmation message");
				System.out.println(actualConfirmationMessage + "-- Actual Confirmation message");

				try {
					Assert.assertEquals(ConstantsUtility.errConfirmationMessageDispalyedOnDeletingRecordIsNotCorrect,
							ConstantsUtility.msgCorrectConfirmationMessageShouldBeDisplayed);
				} catch (Throwable t) {
					TestLibrary.reportErrorAndtakeScreenshot(t,
							"Correct_Confirmation_Message_Is_Not_Displayed_On_Deleting_A_Record");
				} // End of catch
			}
		}

		// get actual delete successfully message
		{
			if (result.containsKey("Removed successfully Message"))
				actualDeletedSuccessfullyMessage = result.get("Removed successfully Message");

			if (result.containsKey("expectedDeletedSuccessfullyMessage")
					|| result.containsKey("Removed successfully Message")) {
				if (!expectedDeletedSuccessfullyMessage.equals(actualDeletedSuccessfullyMessage)) {
					System.out.println(expectedDeletedSuccessfullyMessage + "-- Exepcted message");
					System.out.println(actualDeletedSuccessfullyMessage + "-- Actual message");
					try {
						Assert.assertEquals(
								ConstantsUtility.errDeletedSuccessfullyMessageDispalyedOnDeletingRecordIsNotCorrect,
								ConstantsUtility.msgCorrectDeletedSuccessfullyMessageShouldBeDisplayed);
					} catch (Throwable t) {
						TestLibrary.reportErrorAndtakeScreenshot(t,
								"Correct_Delete_Successfully_Message_Is_Not_Displayed_On_Deleting_A_Record");
					} // End of catch
				}
			}
		}

		// get actual delete popup title
		if (result.containsKey("PopupHeaderTitle")) {
			actualDeletedPopupTitle = result.get("PopupHeaderTitle");

			if (!expectedDeletePopUpTitle.equals(actualDeletedPopupTitle)) {
				System.out.println(expectedDeletePopUpTitle);
				System.out.println(actualDeletedPopupTitle);
				try {
					Assert.assertEquals("Delete popup title is not correct.", "Delete popup title should be correct.");
				} catch (Throwable t) {
					TestLibrary.reportErrorAndtakeScreenshot(t, "Delete_Popup_Title_Is_Not_Correct");
				} // End of catch
			}
		}
		// check accordion body by default collapsed

		if (result.containsKey("Collapsed_By Default")) {
			try {
				Assert.assertEquals("Accordion Item body is not Collapsed By default",
						"Accordion Item body should be Collapsed By default");
			} catch (Throwable t) {
				TestLibrary.reportErrorAndtakeScreenshot(t, "Accordion_Item_Body_Is_Not_Collapsed_By_Default");
			} // End of catch
		}

		// check on clicking expandcollapse button body is expaned (when
		// collapsed)if data count is less than 21

		if (result.containsKey("Expanded")) {
			try {
				Assert.assertEquals("Accordion Item body is not Expanded on clicking ExpandCollapse Button",
						"Accordion Item body should be Expanded on clicking ExpandCollapse Button");
			} catch (Throwable t) {
				TestLibrary.reportErrorAndtakeScreenshot(t,
						"Accordion_Item_Body_Is_Not_Expanded_On_Clicking_ExpandCollapse_Button");
			} // End of catch
		}

		// check on clicking expandcollapse button body is collapsed (when
		// expaned)

		if (result.containsKey("Collapsed")) {
			try {
				Assert.assertEquals("Accordion Item body is not Collapsed on clicking ExpandCollapse Button",
						"Accordion Item body should be Collapsed on clicking ExpandCollapse Button");
			} catch (Throwable t) {
				TestLibrary.reportErrorAndtakeScreenshot(t,
						"Accordion_Item_Body_Is_Not_Collapsed_On_Clicking_ExpandCollapse_Button");
			} // End of catch
		}
		if (result.containsKey("OK_Button_Present")) {
			// check ok button present
			if (result.get("OK_Button_Present").equals(String.valueOf(false))) {
				try {
					Assert.assertEquals("Ok button is not present", "Ok button should be present");
				} catch (Throwable t) {
					TestLibrary.reportErrorAndtakeScreenshot(t, "OK_Button_Is_Not_Present");
				} // End of catch
			}
		}
		if (result.containsKey("Cancel_Button_Present")) {
			// check cancel button present
			if (result.get("Cancel_Button_Present").equals(String.valueOf(false))) {
				try {
					Assert.assertEquals("Cancel button is not present", "Cancel button should be present");
				} catch (Throwable t) {
					TestLibrary.reportErrorAndtakeScreenshot(t, "Cancel_Button_Is_Not_Present");
				} // End of catch
			}
		}

		// check cross button present
		if (result.containsKey("Cross_Button_Present"))
			if (result.get("Cross_Button_Present").equals(String.valueOf(false))) {
				try {
					Assert.assertEquals("Cross button is not present", "Cross button should be present");
				} catch (Throwable t) {
					TestLibrary.reportErrorAndtakeScreenshot(t, "Cross_Button_Is_Not_Present");
				} // End of catch
			}
		// check default Focus on Cancelcbutton
		if (result.containsKey("DefaultFocusOnCancel")) {
			try {
				Assert.assertEquals("Default focus is not on cancel button",
						"Default focus should be on cancel button");
			} catch (Throwable t) {
				TestLibrary.reportErrorAndtakeScreenshot(t, "Default_Focus_Is_Not_On_Cancel_Button");
			} // End of catch
		}

		// get actual delete popup title with associated users
		if (result.containsKey("removePopUpMessageWithAssociationUsersText")) {
			actualDeletedPopupTitle = result.get("AccordionItem0");

			if (!expectedMessageWithAssociationUsersText.equalsIgnoreCase(actualDeletedPopupTitle)
					|| !(result.get("DataCount").equalsIgnoreCase(result.get("Count"))
							|| !result.get("NameUser").equalsIgnoreCase(result.get("AccordionMessage0")))) {
				try {
					Assert.assertEquals("Incorrect message for associated users",
							"Correct message should be displayed for associated users");
				} catch (Throwable t) {
					TestLibrary.reportErrorAndtakeScreenshot(t, "Delete_Popup_Associated_Users_Message_Is_Not_Correct");
				} // End of catch
			}
		}

		// get actual delete popup title with associated roles
		if (result.containsKey("removePopUpMessageWithAssociationRolesText")) {
			actualDeletedPopupTitle = result.get("AccordionItem1");

			if (!expectedMessageWithAssociationRoleText.equalsIgnoreCase(actualDeletedPopupTitle)
					|| !(result.get("DataCount").equalsIgnoreCase(result.get("Count"))
							|| !result.get("NameRole").equalsIgnoreCase(result.get("AccordionMessage1")))) {
				try {
					Assert.assertEquals("Incorrect message for associated roles",
							"Correct message should be displayed for associated roles");
				} catch (Throwable t) {
					TestLibrary.reportErrorAndtakeScreenshot(t, "Delete_Popup_Associated_Users_Message_Is_Not_Correct");
				} // End of catch
			}
		}
		if (result.containsKey("removePopUpMessageWithSubGroupAssociation")) {
			actualDeletedPopupTitle = result.get("AccordionItem0");
			if (!actualDeletedPopupTitle.equalsIgnoreCase(result.get("removePopUpMessageWithSubGroupAssociation"))) {
				try {
					Assert.assertEquals(
							"Incorrect message for associated subgroup. actual is" + actualDeletedPopupTitle,
							"Correct message should be displayed for associated subgroup. expected is "
									+ result.get("removePopUpMessageWithSubGroupAssociation"));
				} catch (Throwable t) {
					TestLibrary.reportErrorAndtakeScreenshot(t,
							"Delete_Popup_Associated_SubGroup_Message_Is_Not_Correct");
				} // End of catch
			}
		}

	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Assert for components missing
	// Author: Priyanka Kundu
	public static void assertForComponentMissing(String elementsNotPresent) {

		try {
			Assert.assertEquals(ConstantsUtility.errSomeComponentsAreMissing + elementsNotPresent,
					ConstantsUtility.msgAllComponentsShouldBeDisplayed);

		} catch (Throwable t) {
			TestLibrary.reportErrorAndtakeScreenshot(t, "Some_components_missing");
		}

	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Assert for if Grid cell value not equal as expected
	// Author: Priyanka Kundu
	public static void assertForGridCellCountNotEqual(Hashtable<String, String> resultSet) {

		if (resultSet.containsKey("GridCellCountNotEqual")) {
			try {
				Assert.assertEquals(resultSet.get("GridCellCountNotEqual"), " Grid Cell Count should be equal");
			} catch (Throwable t) {
				TestLibrary.reportErrorAndtakeScreenshot(t, "Grid_Cell_Count_Is_Not_Equal");

			}
		}

	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Assert for Modal box if Grid cell value not equal as expected or modal
	// box does not open
	// Author: Priyanka Kundu
	public static void assertForOpeningModalBox(Hashtable<String, String> resultSet) {

		if (resultSet.containsKey("GridCellCountNotEqual")) {
			try {
				Assert.assertEquals(resultSet.get("GridCellCountNotEqual"), " Grid Cell Count should be equal");
			} catch (Throwable t) {
				TestLibrary.reportErrorAndtakeScreenshot(t, "Grid_Cell_Count_Is_Not_Equal");

			}

			if (resultSet.containsKey("ModalBoxNotOpened")) {
				try {
					Assert.assertEquals(" Modal box is not opened.", " Modal box should be opened.");
				} catch (Throwable t) {
					TestLibrary.reportErrorAndtakeScreenshot(t, "Modal_Box_Is_Not_Opened");
					return;
				}
			}
		}

	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Assert for if Modal Box is not Closed
	// Author: Priyanka Kundu
	public static void assertForModalBoxNotClosed() {
		try {
			Assert.assertEquals(" Modal box is not closed.", " Modal box should be closed.");
		} catch (Throwable t) {
			TestLibrary.reportErrorAndtakeScreenshot(t, "Modal_Box_Is_Not_Closed");
			return;
		}

	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// navigate to Part Recipe Quick Addition grid.
	// Author: Yogendra Rathore
	public static PartRecipeQuickAdditionPage navigateToPartRecipeQuickAdditionPage(String ODId) throws Exception {
		PartRecipeQuickAdditionPage partRecipeQuickAdditionPage;
		TestLibrary.loginIfNotLoggedInAndVerifyUserIsLoggedIn();

		// Check To handle Confirmation Message - If appears
		LibraryFunctions.handlingConfirmationBoxMessage("ok");

		// navigate to PartRecipeQuickAdditionPage
		partRecipeQuickAdditionPage = DashboardPage.navigateToPartRecipeQuickAdditionPage(ODId);
		// Check To handle Confirmation Message - If appears
		LibraryFunctions.handlingConfirmationBoxMessage("ok");
		UtilityFunctions.applicationWait(4000);
		// Verify PartRecipeQuickAdditionPage
		TestLibrary.verifyPartRecipeQuickAdditionPageIsDisplayed(partRecipeQuickAdditionPage);

		return partRecipeQuickAdditionPage;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------

	// Verify PartRecipeQuickAdditionPage page is displayed
	// Author: Yogendra Rathore
	public static void verifyPartRecipeQuickAdditionPageIsDisplayed(
			PartRecipeQuickAdditionPage partRecipeQuickAdditionPage) throws Exception {
		// Verify PartRecipeQuickAdditionPage is displayed.
		if (!partRecipeQuickAdditionPage.checkPartRecipeQuickAdditionPageIsDisplayed()) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " partRecipeQuickAdditionPage",
						ConstantsUtility.msgApplicationPageShouldDisplay + " partRecipeQuickAdditionPage");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_To_Navigate_To_Part_Recipe_Quick_Addition_Page");
				log.error("Error occured - Not able to Navigate to PartRecipeQuickAddition Page for "
						+ BasePage.currentMethodName);
			}
		} // end of if
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Verify whether DC Tab is active or not
	// Author: Priyanka Kundu
	public static void verifyDCTabIsActive(EditFeaturePage editFeaturePage) {
		// Verify Create New Part Page is displayed
		if (!editFeaturePage.checkForActiveTab("DC_Tab"))
			try {
				Assert.assertEquals("Data Collection Tab is not active", "Data Collection Tab should be active");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Data_Collection_Tab_Is_Not_Active");

			}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Verify whether Spec Limit Tab is active or not
	// Author: Priyanka Kundu
	public static void verifySpecLimitTabIsActive(EditFeaturePage editFeaturePage) {
		// Verify Create New Part Page is displayed
		if (!editFeaturePage.checkForActiveTab("SpecLimit_Tab"))
			try {
				Assert.assertEquals("Specification Limit Tab is not active",
						"Specification Limit Tab should be active");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Specification_Limit_Tab_Is_Not_Active");

			}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to User landing page and return object of
	// User landing page.
	// Author : Tanmay Bhatnagar
	public static UserLandingPage navigateToUserLandingPage() throws Exception {

		try {
			loginIfNotLoggedInAndVerifyUserIsLoggedIn();

			// Navigate to User Landing Page
			userLandingPage = BasePage.pageHeaderNavigation.navigateToUserLandingPage();

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

			// Verify UserLanding page
			verifyUserLandingPageIsDisplayed(userLandingPage);

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
		return userLandingPage;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Navigate to create code group page
	// Author: Yogendra Rathore
	public static CreateCodeGroupPage navigateToCreateCodeGroupPage() throws Exception {

		if (!BasePage.isBrowserClosed() && UtilityFunctions.getMultilingualData("CodeGroup_Header_Title")
				.equalsIgnoreCase(LibraryFunctions.getPageName())) {
			// Click on Back button
			BasePage.pageHeaderNavigation.clickOnCancelButton();
			codeGroupLandingPage = new CodeGroupLandingPage();
			// Verify Code Group Landing Page
			TestLibrary.verifyCodeGroupLandingPageIsDisplayed(codeGroupLandingPage);
		} else {

			codeGroupLandingPage = TestLibrary.navigateToCodeGroupLandingPage();
		}

		// Navigate to Create CodeGroup Page
		createCodeGroupPage = codeGroupLandingPage.navigateToCreateCodeGroupPage();

		// Verify Create Feature Page
		TestLibrary.verifyCreateCodeGroupPageIsDisplayed(createCodeGroupPage);

		return createCodeGroupPage;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Verify Create CodeGroup page is displayed
	// Author: Yogendra Rathore
	public static void verifyCreateCodeGroupPageIsDisplayed(CreateCodeGroupPage createCodeGroupPage) {
		// Verify Create CodeGroup Page is displayed
		if (!createCodeGroupPage.checkCreateCodeGroupPageIsDisplayed()) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Create Code Group Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Create Code Group Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_Create_Code_Group_Feature_page");
				log.error("Error occured - Not able to Navigate to Create Code Group Page for "
						+ BasePage.currentMethodName);

			}
		} // end of if
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to Tag landing page and return object of
	// Tag landing page.
	// Author : Bhupendra Singh
	public static TagGroupLandingPage navigateToTagGroupLandingPage() throws Exception {

		try {
			loginIfNotLoggedInAndVerifyUserIsLoggedIn();

			// Navigate to Tag Landing Page
			tagGroupLandingPage = BasePage.pageHeaderNavigation.navigateToTagGroupLandingPage();

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

			// Verify Tag Landing page
			verifyTagGroupLandingPageIsDisplayed(tagGroupLandingPage);

		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
		return tagGroupLandingPage;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Navigate to create Tag group page
	// Author: Bhupendra Singh
	public static CreateTagGroupPage navigateToCreateTagGroupPage() throws Exception {

		if (!BasePage.isBrowserClosed() && UtilityFunctions.getMultilingualData("TagGroup_Header_Title")
				.equalsIgnoreCase(LibraryFunctions.getPageName())) {
			// Click on Back button
			BasePage.pageHeaderNavigation.clickOnCancelButton();
			tagGroupLandingPage = new TagGroupLandingPage();
			// Verify Tag Group Landing Page
			TestLibrary.verifyTagGroupLandingPageIsDisplayed(tagGroupLandingPage);
		} else {

			tagGroupLandingPage = TestLibrary.navigateToTagGroupLandingPage();
		}

		// Navigate to Create Tag Group Page
		createTagGroupPage = tagGroupLandingPage.navigateToCreateTagGroupPage();

		// Verify Create Tag group Page
		TestLibrary.verifyCreateTagGroupPageIsDisplayed(createTagGroupPage);

		return createTagGroupPage;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Verify Create Tag Group page is displayed
	// Author: Bhupendra Singh
	public static void verifyCreateTagGroupPageIsDisplayed(CreateTagGroupPage createTagGroupPage) {
		// Verify Create Tag Group Page is displayed
		if (!createTagGroupPage.checkCreateTagGroupPageIsDisplayed()) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Create Tag Group Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Create Tag Group Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_Create_Tag_Group_Feature_page");
				log.error("Error occured - Not able to Navigate to Create Tag Group Page for "
						+ BasePage.currentMethodName);

			}
		} // end of if
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check User Landing Page display Tag Group Landing Page
	// Author: Bhupendra Singh
	public static void verifyTagGroupLandingPageIsDisplayed(TagGroupLandingPage tagGroupLandingPage) throws Exception {
		// Verify Tag Group Landing page

		if (!tagGroupLandingPage.checkTagGroupLandingPageIsDisplayed()) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Tag Group Landing Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Tag Group Landing Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_Tag_Group_landing_page");
				log.error("Error occured - Not able to Navigate to Tag Group Landing Page for "
						+ BasePage.currentMethodName);
			}
		}

	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to edit TagGroup page on basis of TagGroupName
	// and
	// return editTagGroupPage
	// object.
	// Author: Ashish
	// modified by: rakesh
	// filter approach to navigate to edit page
	public static EditTagGroupPage navigateToEditTagGroupPage(String TagGroupName) throws Exception {

		if (!BasePage.isBrowserClosed() && UtilityFunctions.getMultilingualData("TagGroup_Header_Title")
				.equalsIgnoreCase(LibraryFunctions.getPageName())) {
			// Click on Back button
			BasePage.pageHeaderNavigation.clickOnCancelButton();
			tagGroupLandingPage = new TagGroupLandingPage();
			// Verify Tag Group Landing Page
			tagGroupLandingPage = TestLibrary.navigateToTagGroupLandingPage();
			TestLibrary.verifyTagGroupLandingPageIsDisplayed(tagGroupLandingPage);
		} else {

			tagGroupLandingPage = TestLibrary.navigateToTagGroupLandingPage();

		}

		// navigate to specific edit Tag Group page
		editTagGroupPage = tagGroupLandingPage.navigateToEditTagGroupPage(TagGroupName);

		// Verify edit Tag Group Page
		TestLibrary.verifyEditTagGroupPageIsDisplayed(editTagGroupPage, TagGroupName);

		return editTagGroupPage;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Verify Edit Tag Group page is displayed
	// Author: Ashish
	public static void verifyEditTagGroupPageIsDisplayed(EditTagGroupPage editTagGroupPage, String TagGroupName)
			throws Exception {
		// check in progress text and wait till 15 secs if Inprogress is
		// displayed.
		UtilityFunctions.applicationWait(2000);
		int index = 0;
		while ((LibraryFunctions.isElementPresent(BasePage.xPath_InProgressImage, 1)
				|| LibraryFunctions.isElementPresent(BasePage.xPath_InProgressText, 1)) && index < 15) {
			UtilityFunctions.applicationWait(1000);
			index++;

		}
		// Verify Edit Tag Group Page is displayed
		if (!editTagGroupPage.checkEditTagGroupPageIsDisplayed(TagGroupName)) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Edit TagGroup Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Edit TagGroup Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_Edit_TagGroup_page");

			}
		} // end of if
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------

	// Verify Add Tag Pop Up Page is displayed
	// author: Priyanka kundu
	public static void verifyAddTagPopIsDisplayed(AddTagPopUpPage addTagPopUpPage) {
		// Verify Create New Part Page is displayed
		try {
			if (addTagPopUpPage.checkAddTagPopIsDisplayed() == false) {

				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Add Tag PopUp",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Add Tag PopUp");
			}
		} catch (Throwable t) {
			reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_Add_Tag_PopUp");
			log.error("Error occured - Not able to Navigate to Add Tag PopUp for " + BasePage.currentMethodName);
		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------

	// assert when tag is not Displayed successfully
	// Author: Priyanka kundu
	public static void assertTagNotDisplayedExpected() {

		try {
			Assert.assertEquals("Tag is not displayed as expected", "Tag should be displayed as expected");
		} catch (Throwable t) {
			TestLibrary.reportErrorAndtakeScreenshot(t, "Tag_Is_Not_Displayed_As_Expected");
		} // End of catch
	}

	// --------------------------------------------------------------------------------------
	// Verify Configure User Tags page is displayed
	// Author: Ashish
	public static void verifyConfigureUserTagsPageIsDisplayed(ConfigureUserTagsPage configureUserTagsPage) {
		// Verify Configure User Tags Page is displayed
		if (!configureUserTagsPage.checkconfigureUserTagsPageIsDisplayed()) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Configure User Tags Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Configure User Tags Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_Configure_User_Tags_Page");
				log.error("Error occured - Not able to Navigate to Configure User Tags Page for "
						+ BasePage.currentMethodName);

			}
		}

	}

	// --------------------------------------------------------
	// Method to Navigate on Configure User Tags Page
	// Author:Ashish
	public static ConfigureUserTagsPage navigateToConfigureUserTagsPage() throws Exception {
		userLandingPage = TestLibrary.navigateToUserLandingPage();
		configureUserTagsPage = userLandingPage.navigateToConfigureUserTagsPage();

		// Verify Create Tag group Page
		TestLibrary.verifyConfigureUserTagsPageIsDisplayed(configureUserTagsPage);

		return configureUserTagsPage;

	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check forgot password popup page is displayed.
	// Author: Yogendra Rathore
	public static void verifyForgotPasswordPopUpIsDisplayed(ForgotPasswordPage forgotPasswordPage) throws Exception {
		// Verify forgot password pop up page
		if (!forgotPasswordPage.checkForgotPasswordPopIsDisplayed())

		{
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Forgot Password Pop Up",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Forgot Password Pop Up");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_To_Navigate_To_Forgot_Password_Pop_Up_Page");
				log.error("Error occured - Not able to Navigate to Forgot Password Pop Up Page for "
						+ BasePage.currentMethodName);
			}

		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check create\reset password page is displayed
	// Author: Yogendra Rathore
	public static void verifyCreateOrResetPasswordPageIsDisplayed(CreateOrResetPasswordPage createOrResetPasswordPage)
			throws Exception {
		// Verify create reset password page dispalyed
		if (!createOrResetPasswordPage.checkCreateOrResetPasswordPopIsDisplayed())

		{
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Create Or Reset Password Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Create Or Reset Password Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_To_Navigate_To_Create_Or_Reset_Password_Page");
				log.error("Error occured - Not able to Navigate to Create Or Reset Password Page for "
						+ BasePage.currentMethodName);
			}

		}
	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to ResetPasswordPage and returns
	// object of CreateOrResetPasswordPage.
	// Author: Yogendra Rathore
	public static CreateOrResetPasswordPage navigateToResetPasswordPage(String userName, String companyId)
			throws Exception {
		CreateOrResetPasswordPage createOrResetPasswordPage;
		LoginPage loginPage;
		ForgotPasswordPage forgotPasswordPage;

		try {

			// Navigate to login page.
			loginPage = TestLibrary.navigateToLoginPageAndVerifyLoginPageIsDisplayed();

			// click on forgot password
			forgotPasswordPage = loginPage.clickOnForgotPasswordButton();

			// verify pop up displayed
			TestLibrary.verifyForgotPasswordPopUpIsDisplayed(forgotPasswordPage);

			// navigate to createOrReset password link
			createOrResetPasswordPage = forgotPasswordPage.navigateToCreateOrResetPasswordPage(userName, companyId,
					false);

			// verify page displayed
			TestLibrary.verifyCreateOrResetPasswordPageIsDisplayed(createOrResetPasswordPage);

			return createOrResetPasswordPage;
		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to CreatePasswordPage and returns
	// object of CreateOrResetPasswordPage.
	// Author: Yogendra Rathore
	public static CreateOrResetPasswordPage navigateToCreatePasswordPage(String userName) throws Exception {
		CreateUserPage createUserPage;
		CreateOrResetPasswordPage createOrResetPasswordPage;
		ForgotPasswordPage forgotPasswordPage = new ForgotPasswordPage();
		Hashtable<String, String> testData = new Hashtable<String, String>();

		try {
			testData.put(UserPage.field_User_FirstName, "firstName");
			testData.put(UserPage.field_User_LastName, "lastName");
			testData.put(UserPage.field_User_Email,
					UtilityFunctions.getRandomStringContainingAlphabets(6) + "@gmail.com");
			testData.put(UserPage.field_User_UserName, userName);

			createUserPage = TestLibrary.navigateToCreateUserPage();

			createUserPage.saveUser(testData, "Save");

			// navigate to createOrReset password link
			createOrResetPasswordPage = forgotPasswordPage.navigateToCreateOrResetPasswordPage(userName, "", true);

			// verify page displayed
			TestLibrary.verifyCreateOrResetPasswordPageIsDisplayed(createOrResetPasswordPage);

			return createOrResetPasswordPage;
		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to ForgotPasswordPage and returns
	// object of ForgotPasswordPage.
	// Author: Yogendra Rathore
	public static ForgotPasswordPage navigateToForgotPasswordPage() throws Exception {
		LoginPage loginPage;
		ForgotPasswordPage forgotPasswordPage;

		try {

			// Navigate to login page.
			loginPage = TestLibrary.navigateToLoginPageAndVerifyLoginPageIsDisplayed();

			// click on forgot password
			forgotPasswordPage = loginPage.clickOnForgotPasswordButton();

			// verify pop up displayed
			TestLibrary.verifyForgotPasswordPopUpIsDisplayed(forgotPasswordPage);

			return forgotPasswordPage;
		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to DashBoard Page and returns
	// object of DashBoardPage.
	// Author: Bhupendra Singh
	// updated by : Chanchal Jain
	// added wait for tile loading
	// Updated by : Yogendra Rathore <24-05-2018>
	// Updated by : Yogendra Rathore <13-03-2019>
	// Added if condition to navigate to dashboard from hamburger if already on
	// dashboard
	public static DashboardPage navigateToDashboardPage() throws Exception {
		try {
			TestLibrary.loginIfNotLoggedInAndVerifyUserIsLoggedIn();

			if (!LibraryFunctions.isElementDisplayed(
					BasePage.pageHeaderNavigation.xPath_btnBackButton + "[contains(@class,'logo')]", 2)) {
				// Method call for navigation to DashBoard Page
				dashboardPage = BasePage.pageHeaderNavigation.navigateToDashboardPage();

				// Check To handle Confirmation Message - If appears
				LibraryFunctions.handlingConfirmationBoxMessage("ok");

				UtilityFunctions.applicationWait(1000);
				LibraryFunctions.checkLoadingIconIsDisplayed("SpinningLoadingIcon", 60);
				LibraryFunctions.checkLoadingIconIsDisplayed("TileLoading", 60);
				// Verify DashBoard is displayed
				TestLibrary.verifyDashboardPageIsDisplayed(dashboardPage);
			} else
				dashboardPage = new DashboardPage();
			return dashboardPage;
		} catch (Exception e) {
			log.error("Error Occurred: While navigating to DashBoard Page " + BasePage.currentMethodName);
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check Unauthorized Page display
	// Author: Yogendra Rathore
	public static void verifyUnauthorizedAccessPageIsDisplayed(UnauthorizedAccessPage unauthorizedAccessPage)
			throws Exception {
		// Verify PartLanding page
		if (!unauthorizedAccessPage.checkUnauthorizedAccessPageIsDisplayed())

		{
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " UnauthorizedAccessPage ",
						ConstantsUtility.msgApplicationPageShouldDisplay + " UnauthorizedAccessPage");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_UnauthorizedAccessPage");
				log.error("Error occured - Not able to Navigate to UnauthorizedAccessPage for "
						+ BasePage.currentMethodName);
			}

		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check Unauthorized Page text message for permission
	// Author: Yogendra Rathore
	public static void verifyUnauthorizedAccessTextMessageIsDisplayed(UnauthorizedAccessPage unauthorizedAccessPage)
			throws Exception {
		// Verify PartLanding page
		if (!unauthorizedAccessPage.checkUnauthorizedAccessPageTextIsDisplayed())

		{
			try {
				Assert.assertEquals("Unauthorzied Access Page Text Is not Displayed.",
						"Unauthorzied Access Page Text Should be Displayed.");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Unauthorzied_Access_Page_Text_Is_not_Displayed.");
				log.error("Error occured - Not able to Unauthorzied Access Page Text Is not Displayed. for "
						+ BasePage.currentMethodName);
			}

		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to Collection Aids landing page and return
	// object of
	// Collection Aids landing page.
	// Author : Ashish Saxena
	public static CollectionAidLandingPage navigateToCollectionAidsLandingPage() throws Exception {

		try {
			loginIfNotLoggedInAndVerifyUserIsLoggedIn();

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

			// Navigate to Collection Aids Landing Page
			collectionAidLandingPage = BasePage.pageHeaderNavigation.navigateToCollectionAidsLandingPage();

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

			// Verify Collection Aid Landing page
			verifyCollectionAidLandingPageIsDisplayed(collectionAidLandingPage);

		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
		return collectionAidLandingPage;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check Collection Aid Landing Page display
	// Author: Ashish Saxena
	public static void verifyCollectionAidLandingPageIsDisplayed(CollectionAidLandingPage collectionAidLandingPage)
			throws Exception {
		// Verify Collection Aid Landing page
		if (collectionAidLandingPage.checkCollectionAidLandingPageIsDisplayed() == false) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Collection Aid Landing Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Collection Aid Landing Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_collection_Aid_landing_page");
				log.error("Error occured - Not able to Navigate to Collection Aid Landing Page for "
						+ BasePage.currentMethodName);
			}
		}
	}

	// -------------------------------------------------------------------------------------------------------------------
	// Navigate to Process States Landing Page and return object of the page
	// Author: Yogendra Rathore
	public static ProcessStatesLandingPage navigateToProcessStatesLandingPage() throws Exception {

		try {
			TestLibrary.loginIfNotLoggedInAndVerifyUserIsLoggedIn();

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

			// Navigate to Process States Landing Page
			processStatesLandingPage = BasePage.pageHeaderNavigation.navigateToProcessStatesLandingPage();

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

			// Verify ProcessStatesLanding page
			TestLibrary.verifyProcessStatesLandingPageIsDisplayed(processStatesLandingPage);

			return processStatesLandingPage;
		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check Process States Landing Page display Process Landing Page
	// Author: Yogendra Rathore
	public static void verifyProcessStatesLandingPageIsDisplayed(ProcessStatesLandingPage processStatesLandingPage)
			throws Exception {
		// Verify Process States Landing page
		if (!processStatesLandingPage.checkProcessStatesLandingPageIsDisplayed()) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Process States Landing Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Process States Landing Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_To_Navigate_To_Process_States_Landing_Page");
				log.error("Error occured - Not able to Navigate to Process States Landing Page for "
						+ BasePage.currentMethodName);
			}
		}
	}

	// -------------------------------------------------------------------------------------------------------------------
	// Navigate to Configure Process States and return object of the page
	// Author: Yogendra Rathore
	public static ConfigureProcessStatesPage navigateToConfigureProcessStatesPage() throws Exception {

		try {
			TestLibrary.loginIfNotLoggedInAndVerifyUserIsLoggedIn();

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

			// Navigate to Process States Landing Page
			processStatesLandingPage = BasePage.pageHeaderNavigation.navigateToProcessStatesLandingPage();

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

			// Verify ProcessStatesLanding page
			TestLibrary.verifyProcessStatesLandingPageIsDisplayed(processStatesLandingPage);

			ConfigureProcessStatesPage configureProcessStatesPage = processStatesLandingPage
					.navigateToConfigureProcessStatesPage();

			TestLibrary.verifyConfigureProcessStatesPageIsDisplayed(configureProcessStatesPage);

			return configureProcessStatesPage;
		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check Configure Process States Page display Process Landing Page
	// Author: Yogendra Rathore
	public static void verifyConfigureProcessStatesPageIsDisplayed(
			ConfigureProcessStatesPage configureProcessStatesPage) throws Exception {
		// Verify configure process states page
		if (!configureProcessStatesPage.checkConfigureProcessStatesPageIsDisplayed()) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Configure Process States Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Configure States Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_To_Navigate_To_Configure_Process_States_Page");
				log.error("Error occured - Not able to Navigate to Configure Process States Page for "
						+ BasePage.currentMethodName);
			}
		}
	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to create Collection Aid page
	// and return create Collection Aid page object.
	// Author: Priyanka Kundu
	public static CreateCollectionAidPage navigateToCreateCollectionAidPage() throws Exception {

		if (!BasePage.isBrowserClosed() && UtilityFunctions.getMultilingualData("CollectionAids_Page_Title")
				.equalsIgnoreCase(LibraryFunctions.getPageName())) {
			// Click on Back button
			BasePage.pageHeaderNavigation.clickOnCancelButton();
			collectionAidLandingPage = new CollectionAidLandingPage();
			// Verify Tag Group Landing Page
			TestLibrary.verifyCollectionAidLandingPageIsDisplayed(collectionAidLandingPage);
		} else {

			collectionAidLandingPage = TestLibrary.navigateToCollectionAidsLandingPage();
		}

		// navigate to create Collection Aid page
		createCollectionAidPage = collectionAidLandingPage.navigateToCreateCollectionAidPage();

		// Verify create Collection Aid Page
		TestLibrary.verifyCreateCollectionAidPageIsDisplayed(createCollectionAidPage);

		return createCollectionAidPage;
	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to Edit Collection Aid page
	// and return Edit Collection Aid page object.
	// Author: Priyanka Kundu
	public static EditCollectionAidPage navigateToEditCollectionAidPage(Hashtable<String, String> testData)
			throws Exception {

		if (!BasePage.isBrowserClosed() && UtilityFunctions.getMultilingualData("CollectionAids_Page_Title")
				.equalsIgnoreCase(LibraryFunctions.getPageName())) {
			// Click on Back button
			BasePage.pageHeaderNavigation.clickOnCancelButton();
			collectionAidLandingPage = new CollectionAidLandingPage();
			// Verify Tag Group Landing Page
			TestLibrary.verifyCollectionAidLandingPageIsDisplayed(collectionAidLandingPage);
		} else {

			collectionAidLandingPage = TestLibrary.navigateToCollectionAidsLandingPage();
		}

		editCollectionAidPage = collectionAidLandingPage.navigateToEditCollectionAidPage(testData);

		// verify correct edit Collection Aid page is dispalyed
		TestLibrary.verifyEditCollectionAidPageIsDisplayed(editCollectionAidPage);

		return editCollectionAidPage;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Verify Create Collection Aid page is displayed
	// Author: Priyanka Kundu
	public static void verifyCreateCollectionAidPageIsDisplayed(CreateCollectionAidPage createCollectionAidPage) {
		// Verify Create User Page is displayed
		if (createCollectionAidPage.checkCreateCollectionAidPageIsDisplayed() == false) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Create Collection Aid Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Create Collection Aid Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_To_Navigate_To_Create_Collection_Aid_Page");
				log.error("Error occured - Not able to Navigate to Create Collection Aid Page for "
						+ BasePage.currentMethodName);

			}
		} // end of if
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Verify Edit Collection Aid page is displayed
	// Author: Priyanka Kundu
	public static void verifyEditCollectionAidPageIsDisplayed(EditCollectionAidPage editCollectionAidPage)
			throws Exception {
		// check in progress text and wait till 15 secs if Inprogress is
		// displayed.
		UtilityFunctions.applicationWait(2000);
		int index = 0;
		while ((LibraryFunctions.isElementPresent(BasePage.xPath_InProgressImage, 1)
				|| LibraryFunctions.isElementPresent(BasePage.xPath_InProgressText, 1)) && index < 15) {
			UtilityFunctions.applicationWait(1000);
			index++;

		}
		// Verify Create User Page is displayed
		if (editCollectionAidPage.checkEditCollectionAidIsDisplayed() == false) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Edit Collection Aid Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Edit Collection Aid Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_To_Navigate_To_Edit_Collection_Aid_Page");
				log.error("Error occured - Not able to Navigate to Edit Collection Aid Page for "
						+ BasePage.currentMethodName);

			}
		} // end of if
	}

	// -------------------------------------------------------------------------------------------------------------------
	// Navigate toSet Process State and return object of the page
	// Author: Yogendra Rathore
	public static SetProcessStatePopUpPage navigateToSetProcessStatePopUpPage(String processName) throws Exception {

		try {
			TestLibrary.loginIfNotLoggedInAndVerifyUserIsLoggedIn();

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

			// Navigate to Process States Landing Page
			processStatesLandingPage = BasePage.pageHeaderNavigation.navigateToProcessStatesLandingPage();

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

			// Verify ProcessStatesLanding page
			TestLibrary.verifyProcessStatesLandingPageIsDisplayed(processStatesLandingPage);

			SetProcessStatePopUpPage setProcessStatePopUpPage = processStatesLandingPage
					.navigateToSetProcessStatePopUpPage(processName);

			TestLibrary.verifySetProcessStatePopUpPageIsDisplayed(setProcessStatePopUpPage);

			return setProcessStatePopUpPage;
		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check Set Process State Page display Process Landing Page
	// Author: Yogendra Rathore
	public static void verifySetProcessStatePopUpPageIsDisplayed(SetProcessStatePopUpPage setProcessStatePopUpPage)
			throws Exception {
		// Verify configure process states page
		if (!setProcessStatePopUpPage.checkSetProcessStatePopUpPageIsDisplayed()) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Set Process State Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Set Process State Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_To_Navigate_To_Set_Process_State_Page");
				log.error("Error occured - Not able to Navigate to Set Process State Page for "
						+ BasePage.currentMethodName);
			}
		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Assertion for add tag Group With DC
	// Author: Yogendra Rathore
	public static void assertForAddTagGroupWithDC(List<String> errorList) {

		try {
			Assert.assertEquals(errorList,
					"User Should Be Able To Navigate To Additional Info Tab And Add Tag Group To DC.");

		} catch (Throwable t) {

			TestLibrary.reportErrorAndtakeScreenshot(t,
					UtilityFunctions.convertStringArrayListToCommaSeparatedString(errorList));
			return;
		} // End of catch

	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Assertion for DC Add Tag Pop Type displayed
	// Author: Yogendra Rathore
	public static void assertForDCAddTagPopTypeDisplayed(String tagGroup_Level) {

		try {
			Assert.assertEquals(tagGroup_Level + " is Not Displayed.", tagGroup_Level + " is Should Be Displayed.");

		} catch (Throwable t) {

			TestLibrary.reportErrorAndtakeScreenshot(t, tagGroup_Level + "_Is_Not_Displayed.");
			return;
		} // End of catch

	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Assertion for select radio button on Individual Settingm Page With DC
	// Author: Chanchal Jain
	public static void assertForSelectRadioButtonOnIndividualSettingPage(List<String> errorList) {

		try {
			Assert.assertEquals(errorList,
					"Radio Button List Should be displayed As Per The Feature Type and user should be able to select Radio button.");

		} catch (Throwable t) {

			TestLibrary.reportErrorAndtakeScreenshot(t,
					UtilityFunctions.convertStringArrayListToCommaSeparatedString(errorList));
			return;
		} // End of catch

	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Assert for fields not disabled on Begin measeurement page
	// Author: Yogendra Rathore
	public static void assertForTextFieldsNotDisabledOnBeginMeasurementPage() {

		try {
			Assert.assertEquals("Text Fields On Begin Measurement Page Are Not Disabled.",
					"Text Fields On Begin Measurement Page Should Be Disabled.");
		} catch (Throwable t) {
			TestLibrary.reportErrorAndtakeScreenshot(t, "Text_Fields_On_Begin_Measurement_Page_Are_Not_Disabled.");

		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Assert for spec limit validation , when no validation pop up displayed on
	// Begin measeurement page
	// Author: Yogendra Rathore
	public static void assertForOutOfSpecLimitNotificationsWhenNoPopUpDisplayedOnBeginMeasurementPage(
			Hashtable<String, String> testData, BeginMeasurementPage beginMeasurementPage) throws Exception {
		// check pop up not displayed
		if (testData.containsKey("PopUp_Title")) {
			try {
				Assert.assertEquals("Spec Limit Validation Pop Up Displayed.",
						"Spec Limit Validation Pop Up Should Not Be Displayed.");

			} catch (Throwable t) {

				TestLibrary.reportErrorAndtakeScreenshot(t, "Spec_Limit_Validation_Pop_Up_Displayed.");

			} // End of catch

		}
		// check user navigatet to next piece
		if (!beginMeasurementPage.checkPieceOfGivenIndexIsSelected(2)) {
			try {
				Assert.assertEquals("User Is Not Able To Move To Next Piece.",
						"User Should Able To Move To Next Piece.");

			} catch (Throwable t) {

				TestLibrary.reportErrorAndtakeScreenshot(t, "User_Is_Not_Able_To_Move_To_Next_Piece.");

			} // End of catch

		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Assert for out of Spec limit Notifications Pop Up on Begin Measurement
	// Page
	// Author: Yogendra Rathore
	public static void assertForOutOfSpecLimitNotificationsPopUpOnBeginMeasurementPage(
			Hashtable<String, String> dataSet) throws Exception {

		// check pop up was dispalyed
		if (dataSet.containsKey("PopUp_Message")) {
			String expectedTitle = "", expectedMessage = "", limitValueType = "",
					expectedSubHeading = UtilityFunctions.getMultilingualData("Would_You_Like_To_Continue");
			String spiltArrary[] = new String[2];

			limitValueType = dataSet.get("LimitValueType");
			// get expected Title and expected message for Resasonable limit
			boolean checkForCancelButton = true;

			if (limitValueType.equalsIgnoreCase("GreaterThanURL")) {

				if (dataSet.containsKey(DCIndividualSettingsPage.individualSetting_AllowedValues)
						&& dataSet.get(DCIndividualSettingsPage.individualSetting_AllowedValues).equals(
								UtilityFunctions.getMultilingualData("IndividualSettings_ReasonableValuesOnly")))

				{ // make checkforcancelbutton= false as cancel button is not
					// present in this case.
					checkForCancelButton = false;
					expectedTitle = UtilityFunctions.getMultilingualData("UnreasonableValueEntered");
					expectedSubHeading = UtilityFunctions.getMultilingualData("ValueMustBeWithinResonableLimit");

					expectedMessage = "X" + dataSet.get("GreaterThanURL") + " > "
							+ dataSet.get(SpecificationLimit.db_LimitValue_URL) + " ("
							+ UtilityFunctions.getMultilingualData("ColumnName_URL") + ")X";

				} else {
					expectedTitle = UtilityFunctions.getMultilingualData("ValueAboveReasonableLimit_Title");

					expectedMessage = "";
				}
			}

			if (limitValueType.equalsIgnoreCase("LesserThanLRL")) {

				if (dataSet.containsKey(DCIndividualSettingsPage.individualSetting_AllowedValues)
						&& dataSet.get(DCIndividualSettingsPage.individualSetting_AllowedValues).equals(
								UtilityFunctions.getMultilingualData("IndividualSettings_ReasonableValuesOnly")))

				{// make checkforcancelbutton= false as cancel button is not
					// present in this case.
					checkForCancelButton = false;

					expectedTitle = UtilityFunctions.getMultilingualData("UnreasonableValueEntered");

					expectedSubHeading = UtilityFunctions.getMultilingualData("ValueMustBeWithinResonableLimit");

					expectedMessage = "X" + dataSet.get("LesserThanLRL") + " < "
							+ dataSet.get(SpecificationLimit.db_LimitValue_LRL) + " ("
							+ UtilityFunctions.getMultilingualData("ColumnName_LRL") + ")X";

				} else {

					expectedTitle = UtilityFunctions.getMultilingualData("ValueBelowReasonableLimit_Title");

					expectedMessage = "";
				}
			}

			// get expected Title and expected message for greater than USL
			if (limitValueType.equalsIgnoreCase("GreaterThanUSL")) {
				expectedTitle = UtilityFunctions.getMultilingualData("OutOfSpecificationLimits_Title");
				spiltArrary = UtilityFunctions.splitString(expectedTitle, "<Part>");
				expectedTitle = spiltArrary[0] + dataSet.get("PartName") + spiltArrary[1];

				spiltArrary = UtilityFunctions.splitString(expectedTitle, "<Feature>");
				expectedTitle = spiltArrary[0] + dataSet.get("FeatureName") + spiltArrary[1];
				expectedMessage = "X" + dataSet.get("GreaterThanUSL") + " > "
						+ dataSet.get(SpecificationLimit.db_LimitValue_USL) + " ("
						+ UtilityFunctions.getMultilingualData("ColumnName_USL") + ")X";
			}

			// get expected Title and expected message for lesser than LSL
			if (limitValueType.equalsIgnoreCase("LesserThanLSL")) {
				expectedTitle = UtilityFunctions.getMultilingualData("OutOfSpecificationLimits_Title");
				spiltArrary = UtilityFunctions.splitString(expectedTitle, "<Part>");
				expectedTitle = spiltArrary[0] + dataSet.get("PartName") + spiltArrary[1];

				spiltArrary = UtilityFunctions.splitString(expectedTitle, "<Feature>");
				expectedTitle = spiltArrary[0] + dataSet.get("FeatureName") + spiltArrary[1];
				expectedMessage = "X" + dataSet.get("LesserThanLSL") + " < "
						+ dataSet.get(SpecificationLimit.db_LimitValue_LSL) + " ("
						+ UtilityFunctions.getMultilingualData("ColumnName_LSL") + ")X";
			}

			// get expected Title and expected message for greater than UWL
			if (limitValueType.equalsIgnoreCase("GreaterThanUWL")) {
				expectedTitle = UtilityFunctions.getMultilingualData("OutOfWarningLimits_Title");
				spiltArrary = UtilityFunctions.splitString(expectedTitle, "<Part>");
				expectedTitle = spiltArrary[0] + dataSet.get("PartName") + spiltArrary[1];

				spiltArrary = UtilityFunctions.splitString(expectedTitle, "<Feature>");
				expectedTitle = spiltArrary[0] + dataSet.get("FeatureName") + spiltArrary[1];
				expectedMessage = "X" + dataSet.get("GreaterThanUWL") + " > "
						+ dataSet.get(SpecificationLimit.db_LimitValue_UWL) + " ("
						+ UtilityFunctions.getMultilingualData("ColumnName_UWL") + ")X";
			}

			// get expected Title and expected message for lesser than LWL
			if (limitValueType.equalsIgnoreCase("LesserThanLWL")) {
				expectedTitle = UtilityFunctions.getMultilingualData("OutOfWarningLimits_Title");
				spiltArrary = UtilityFunctions.splitString(expectedTitle, "<Part>");
				expectedTitle = spiltArrary[0] + dataSet.get("PartName") + spiltArrary[1];

				spiltArrary = UtilityFunctions.splitString(expectedTitle, "<Feature>");
				expectedTitle = spiltArrary[0] + dataSet.get("FeatureName") + spiltArrary[1];
				expectedMessage = "X" + dataSet.get("LesserThanLWL") + " < "
						+ dataSet.get(SpecificationLimit.db_LimitValue_LWL) + " ("
						+ UtilityFunctions.getMultilingualData("ColumnName_LWL") + ")X";
			}

			// get expected Title and expected message for greater than UWP
			if (limitValueType.equalsIgnoreCase("GreaterThanUWP")) {
				expectedTitle = UtilityFunctions.getMultilingualData("OutOfWithInPieceLimits_Title");
				spiltArrary = UtilityFunctions.splitString(expectedTitle, "<Part>");
				expectedTitle = spiltArrary[0] + dataSet.get("PartName") + spiltArrary[1];

				spiltArrary = UtilityFunctions.splitString(expectedTitle, "<Feature>");
				expectedTitle = spiltArrary[0] + dataSet.get("FeatureName") + spiltArrary[1];
				expectedMessage = "X" + dataSet.get("GreaterThanUWP") + " > "
						+ dataSet.get(SpecificationLimit.db_LimitValue_UWP) + " ("
						+ UtilityFunctions.getMultilingualData("ColumnName_UWP") + ")X";
			}

			// get expected Title and expected message for greater than LWP
			if (limitValueType.equalsIgnoreCase("LesserThanLWP")) {
				expectedTitle = UtilityFunctions.getMultilingualData("OutOfWithInPieceLimits_Title");
				spiltArrary = UtilityFunctions.splitString(expectedTitle, "<Part>");
				expectedTitle = spiltArrary[0] + dataSet.get("PartName") + spiltArrary[1];

				spiltArrary = UtilityFunctions.splitString(expectedTitle, "<Feature>");
				expectedTitle = spiltArrary[0] + dataSet.get("FeatureName") + spiltArrary[1];
				expectedMessage = "X" + dataSet.get("LesserThanLWP") + " < "
						+ dataSet.get(SpecificationLimit.db_LimitValue_LWP) + " ("
						+ UtilityFunctions.getMultilingualData("ColumnName_LWP") + ")X";
			}

			// now apply assertions

			if (dataSet.containsKey("OK Button Present")) {
				try {
					Assert.assertEquals("OK Button Is Not Present On The Pop Up.",
							"OK Button Should Present On The Pop Up.");

				} catch (Throwable t) {

					TestLibrary.reportErrorAndtakeScreenshot(t, "OK_Button_Is_Not_Present_On_The_Pop_Up.");

				} // End of catch
			}
			if (checkForCancelButton) {
				if (dataSet.containsKey("Cancel Button Present")) {
					try {
						Assert.assertEquals("Cancel Button Is Not Present On The Pop Up.",
								"Cancel Button Should Present On The Pop Up.");

					} catch (Throwable t) {

						TestLibrary.reportErrorAndtakeScreenshot(t, "Cancel_Button_Is_Not_Present_On_The_Pop_Up.");

					} // End of catch
				}
			} else {

				if (!dataSet.containsKey("Cancel Button Present")) {
					try {
						Assert.assertEquals("Cancel Button Is Present On The Pop Up.",
								"Cancel Button Should Not Be Present On The Pop Up.");

					} catch (Throwable t) {

						TestLibrary.reportErrorAndtakeScreenshot(t, "Cancel_Button_Is_Present_On_The_Pop_Up.");

					} // End of catch
				}
			}

			if (!expectedMessage.equals(dataSet.get("PopUp_Message"))) {
				try {
					Assert.assertEquals(dataSet.get("PopUp_Message") + "_Message Is Not Correct On The Pop Up.",
							expectedMessage + "_Message Should Correct On The Pop Up.");

				} catch (Throwable t) {

					TestLibrary.reportErrorAndtakeScreenshot(t, "Message_Is_Not_Correct_On_The_Pop_Up.");

				} // End of catch
			}
			if (!expectedSubHeading.equals(dataSet.get("PopUp_SubTitle"))) {
				try {
					Assert.assertEquals("Sub Heading Is Not Correct On The Pop Up.",
							"Sub Heading Should Correct On The Pop Up.");

				} catch (Throwable t) {

					TestLibrary.reportErrorAndtakeScreenshot(t, "Sub_Heading_Is_Not_Correct_On_The_Pop_Up.");

				} // End of catch
			}

			if (!expectedTitle.equals(dataSet.get("PopUp_Title"))) {
				try {
					Assert.assertEquals(dataSet.get("PopUp_Title") + "_Title Is Not Correct On The Pop Up.",
							expectedTitle + "_Title Should Correct On The Pop Up.");

				} catch (Throwable t) {

					TestLibrary.reportErrorAndtakeScreenshot(t, "Title_Is_Not_Correct_On_The_Pop_Up.");

				} // End of catch
			}
		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Assert for text of text fields is not blank when fields are disabled on
	// Begin measeurement page
	// Author:Chanchal Jain
	public static void assertForTextOfTextFieldsIsNotBlankWhenFieldsDisabledOnBeginMeasurementPage(String fieldName) {

		try {
			Assert.assertEquals(fieldName + " Fields are not blank On Begin Measurement Page.",
					"Text Fields should be blank On Begin Measurement Page.");
		} catch (Throwable t) {
			TestLibrary.reportErrorAndtakeScreenshot(t, "Text_Fields_On_Begin_Measurement_Page_Are_Not_Blank.");

		}
	}

	// --------------------------------------------------------------------------------------------------------------------------------------------------
	// Assertion for Spec Validation messages
	// Author: Ashish
	public static void assertForSpecValidationMessage(String actualValue, String expectedMessage) {
		if (!actualValue.equals(expectedMessage)) {
			try {
				Assert.assertEquals(
						"Actual validation message is - " + actualValue + " it should be equal to " + expectedMessage,
						"Actual Validation message should be equal to Expected Validation message.");
			} catch (Throwable t) {
				TestLibrary.reportErrorAndtakeScreenshot(t,
						"Actual_Validation_message_is_not_equal_to_Expected_Validation_message.");

			}
		}

	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Navigate to create ParameterSet page
	// Author: Bhupendra Singh
	public static CreateParameterSetPage navigateToCreateParameterSetPage() throws Exception {

		if (!BasePage.isBrowserClosed() && UtilityFunctions.getMultilingualData("ParameterSet_Header_Title")
				.equalsIgnoreCase(LibraryFunctions.getPageName())) {
			// Click on Back button
			BasePage.pageHeaderNavigation.clickOnCancelButton();
			parameterSetLandingPage = new ParameterSetLandingPage();
			// Verify Parameter Set Landing Page
			TestLibrary.verifyParameterSetLandingPageIsDisplayed(parameterSetLandingPage);
		} else {

			parameterSetLandingPage = TestLibrary.navigateToParameterSetLandingPage();
		}

		// Navigate to Create Parameter Set Page
		createParameterSetPage = parameterSetLandingPage.navigateToCreateParameterSetPage();

		// Verify Create Parameter Page
		/*
		 * TestLibrary .verifyCreateParameterSetPageIsDisplayed(createParameterSetPage);
		 */
		TestLibrary.verifyCreateParameterSetPageIsDisplayed(createParameterSetPage);

		return createParameterSetPage;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check Parameter Set Landing Page display
	// Author: Bhupendra Singh
	public static void verifyParameterSetLandingPageIsDisplayed(ParameterSetLandingPage parameterSetLandingPage)
			throws Exception {
		// Verify PartLanding page
		if (parameterSetLandingPage.checkParameterSetLandingPageIsDisplayed() == false)

		{
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Parameter Set Landing Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Parameter Set Landing Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_Parameter_Set_landing_page");
				log.error("Error occured - Not able to Navigate to Parameter Set Landing Page for "
						+ BasePage.currentMethodName);
			}

		}
	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to Parameter Set landing page and return
	// ParameterSetLandingPage object.
	// Author: Bhupendra Singh
	public static ParameterSetLandingPage navigateToParameterSetLandingPage() throws Exception {

		// Verify whether Browser Is Closed
		TestLibrary.loginIfNotLoggedInAndVerifyUserIsLoggedIn();
		LibraryFunctions.handlingConfirmationBoxMessage("ok");
		UtilityFunctions.applicationWait(5000);

		// Navigate to Parameter Set Landing Page
		parameterSetLandingPage = BasePage.pageHeaderNavigation.navigateToParameterSetLandingPage();

		// Check To handle Confirmation Message - If appears
		LibraryFunctions.handlingConfirmationBoxMessage("ok");

		// Verify Parameter Set Landing page
		TestLibrary.verifyParameterSetLandingPageIsDisplayed(parameterSetLandingPage);

		return parameterSetLandingPage;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Verify Create Parameter Set page is displayed
	// Author: Bhupendra Singh
	public static void verifyCreateParameterSetPageIsDisplayed(CreateParameterSetPage createParameterSetPage) {
		// Verify Create Parameter Set Page is displayed
		if (!createParameterSetPage.checkCreateParameterSetPageIsDisplayed()) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Create Parameter Set Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Create Parameter Set Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_Create_Parameter_Set_page");
				log.error("Error occured - Not able to Navigate to Create Parameter Set Page for "
						+ BasePage.currentMethodName);

			}
		} // end of if
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Assert for if AddTagPopUp Box is not Closed
	// Author: Priyanka Kundu
	public static void assertForAddTagPopUpNotClosed() {
		try {
			Assert.assertEquals(" AddTagPopUp is not closed.", " AddTagPopUp should be closed.");
		} catch (Throwable t) {
			TestLibrary.reportErrorAndtakeScreenshot(t, "AddTagPopUp_Is_Not_Closed");
			return;
		}

	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to edit Parameter Set page on basis of
	// Parameter Set name and code group name and return editParameterSetPage
	// object.
	// Author: Bhupendra Singh
	public static EditParameterSetPage navigateToEditParameterSetPage(String parameterSetName) throws Exception {
		if (!BasePage.isBrowserClosed() && UtilityFunctions.getMultilingualData("ParameterSet_Header_Title")
				.equalsIgnoreCase(LibraryFunctions.getPageName())) {
			// Click on Back button
			BasePage.pageHeaderNavigation.clickOnCancelButton();
			parameterSetLandingPage = new ParameterSetLandingPage();
			// Verify Parameter Set Landing Page
			TestLibrary.verifyParameterSetLandingPageIsDisplayed(parameterSetLandingPage);
		} else {

			parameterSetLandingPage = TestLibrary.navigateToParameterSetLandingPage();
		}

		Hashtable<String, String> testCaseData = new Hashtable<String, String>();
		testCaseData.put(ParameterSetPage.filter_ParameterSetName, parameterSetName);
		// navigate to specific edit parameter Set page
		editParameterSetPage = parameterSetLandingPage.navigateToEditParameterSetPage(testCaseData);

		// Verify edit Parameter Set Page
		TestLibrary.verifyEditParameterSetPageIsDisplayed(editParameterSetPage, parameterSetName);

		return editParameterSetPage;
	}

	// ---------------------------------------------------------------------------------------------------------------------------
	// Check Edit Parameter Set Page is displayed
	// Author: Bhupendra Singh
	public static void verifyEditParameterSetPageIsDisplayed(EditParameterSetPage editParameterSetPage,
			String parameterSetName) throws Exception {
		// check in progress text and wait till 15 secs if Inprogress is
		// displayed.
		UtilityFunctions.applicationWait(2000);
		int index = 0;
		while ((LibraryFunctions.isElementPresent(BasePage.xPath_InProgressImage, 1)
				|| LibraryFunctions.isElementPresent(BasePage.xPath_InProgressText, 1)) && index < 15) {
			UtilityFunctions.applicationWait(1000);
			index++;

		}
		// Verify Edit Parameter Set Page
		if (!editParameterSetPage.checkEditParameterSetPageIsDisplayed(parameterSetName)) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Edit Parameter Set Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Edit Parameter Set Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_To_Navigate_To_Edit_Parameter_Set_Page");
				log.error("Error occured - Not able to Navigate to Edit Parameter Set Page for "
						+ BasePage.currentMethodName);

			}
		} // end of if

	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Verify Specific Tab Is Displayed on Create Parameter Set page
	// Author: Priyanka Kundu
	public static void verifySpecificTabIsDisplayedOnParameterSetBuilder(String tabName) throws Exception {
		// Verify Create Parameter Set Page is displayed
		if (!createParameterSetPage.checkSpecificTabDisplayed(tabName)) {
			try {
				Assert.assertEquals("Specific tab is not displayed :" + tabName, "Specific tab should be displayed");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, tabName + "_Tab_Is_Not_Displayed");
				log.error("Error occured - Not able to Navigate to specific tab for Parameter Set Page for "
						+ BasePage.currentMethodName);

			}
		} // end of if
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Verify Dynamic/Static Entity PageIs Displayed on Create Parameter Set
	// page
	// Author: Priyanka Kundu
	public static void verifySpecificEntityPageIsDislayed(ParametSetSelectEntityPage parametSetSelectEntityPage,
			String pageType) throws Exception {
		// Verify Create Parameter Set Page is displayed
		if (!parametSetSelectEntityPage.checkSpecificEntityPageIsDislayed(pageType)) {
			try {
				Assert.assertEquals(pageType + " Entity Page is not displayed", "Entity Page should be displayed");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, pageType + "_EntityPage_Is_Not_Displayed");
				log.error("Error occured - Not able to Navigate to Specific Entity Page for Parameter Set Page for "
						+ pageType + "for" + BasePage.currentMethodName);

			}
		} // end of if
	}

	// ------------------------------------------------------------------------------------------------------------------------
	// this method gives assert for save disabled
	// Created By: Priyanka Kundu
	public static void assertForIsSaveDisabled() {
		try {
			Assert.assertEquals("Save Button is not enabled", "Save Button should be enabled");
		} catch (Throwable t) {
			TestLibrary.reportErrorAndtakeScreenshot(t, "Save_Button_Is_Not_Enabled");
		}
	}

	// ------------------------------------------------------------------------------------------------------------------------
	// this method gives assert for save ebavled
	// Created By: Priyanka Kundu
	public static void assertForIsSaveEnabled() {
		try {
			Assert.assertEquals("Save button is enabled ", "Save button should be disabled");
		} catch (Throwable t) {
			TestLibrary.reportErrorAndtakeScreenshot(t, "Save_Button_Is_Enabled");
		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Assert for if Confirmation Box is not Closed
	// Author: Priyanka Kundu
	public static void assertForConfirmationBoxNotClosed() {
		try {
			Assert.assertEquals(" Confirmation box is not closed.", " Confirmation box should be closed.");
		} catch (Throwable t) {
			TestLibrary.reportErrorAndtakeScreenshot(t, "Confirmation_Box_Is_Not_Closed");
			return;
		}

	}

	// ---------------------------------------------------------------------------------------------------------------------
	// Assertion for Permissions check for User
	// Author: Yogendra Rathore

	public static void assertForPermissionCheckForUserAsPerRoleOnLandingPage(Hashtable<String, String> actualResult,
			Hashtable<String, String> expectedResult, List<String> permissionName, String moduleName) {

		if (permissionName.size() == 0)
			permissionName.add(" No ");

		Enumeration<String> e = expectedResult.keys();
		while (e.hasMoreElements()) {
			String key = (String) e.nextElement();

			String expectedValue = expectedResult.get(key);
			String actualValue = actualResult.get(key);
			if (!expectedValue.equalsIgnoreCase(actualValue)) {
				System.out.println("expected :" + key + expectedValue);
				System.out.println(actualValue);
				try {
					Assert.assertEquals(
							key + " Is " + actualValue + " For " + permissionName + " Permission  For " + moduleName
									+ " Module ",

							key + " Is " + expectedValue + " For " + permissionName + " Permission For " + moduleName
									+ " Module ");
				} catch (Throwable t) {
					TestLibrary.reportErrorAndtakeScreenshot(t,
							key + "_Is_" + actualValue + "_For_" + permissionName + "_Permission.");
					return;
				} // End of catch
			}

		}
	}

	// ---------------------------------------------------------------------------------------------------------------------
	// Assertion for Permissions check for User for Hamburger Menu
	// Author: Yogendra Rathore
	public static void assertForPermissionCheckForUserAsPerRoleOnHamburgerMenu(Hashtable<String, String> actualResult,
			Hashtable<String, String> expectedResult, String moduleName) {

		// Main menu on humbuger is visible.
		if (expectedResult.containsKey(RolesPage.permissions_MainMenu))
			if (!expectedResult.get(RolesPage.permissions_MainMenu)
					.equalsIgnoreCase(actualResult.get(RolesPage.permissions_MainMenu))) {
				try {
					Assert.assertEquals(
							"Main Menu Is " + actualResult.get(RolesPage.permissions_MainMenu) + " For " + moduleName
									+ " Module",
							"Main Menu Should Be " + expectedResult.get(RolesPage.permissions_MainMenu) + " For "
									+ moduleName + " Module");
				} catch (Throwable t) {
					reportErrorAndtakeScreenshot(t, "Main_Menu_Is_" + actualResult.get(RolesPage.permissions_MainMenu)
							+ "_For_" + moduleName + "_Module");

				}
			}

		// sub menu on humbuger is visible.
		if (expectedResult.containsKey(RolesPage.permissions_SubMenu))
			if (!expectedResult.get(RolesPage.permissions_SubMenu)
					.equalsIgnoreCase(actualResult.get(RolesPage.permissions_SubMenu))) {
				try {
					Assert.assertEquals(
							"Sub Menu Is " + actualResult.get(RolesPage.permissions_SubMenu) + " For " + moduleName
									+ " Module",
							"Sub Menu Should Be " + expectedResult.get(RolesPage.permissions_SubMenu) + " For "
									+ moduleName + " Module");
				} catch (Throwable t) {
					reportErrorAndtakeScreenshot(t, "Sub_Menu_Is_" + actualResult.get(RolesPage.permissions_SubMenu)
							+ "_For_" + moduleName + "_Module");

				}
			}

	}

	// ---------------------------------------------------------------------------------------------------------------------
	// Assertion for Permissions check for User
	// Author: Yogendra Rathore

	public static void assertForPermissionCheckForUserAsPerRoleOnCreateEditPage(Hashtable<String, String> actualResult,
			Hashtable<String, String> expectedResult, List<String> permissionName, String moduleName) {

		if (permissionName.size() == 0)
			permissionName.add(" No ");

		Enumeration<String> e = expectedResult.keys();
		while (e.hasMoreElements()) {
			String key = (String) e.nextElement();

			String expectedValue = expectedResult.get(key);
			String actualValue = actualResult.get(key);

			if (!expectedValue.equalsIgnoreCase(actualValue)) {

				System.out.println(key + expectedValue);
				System.out.println(key + actualValue);
				try {
					Assert.assertEquals(
							key + " Is " + actualValue + " For " + permissionName + " Permission  For " + moduleName
									+ " Module",

							key + " Is " + expectedValue + " For " + permissionName + " Permission For " + moduleName
									+ " Module");
				} catch (Throwable t) {
					TestLibrary.reportErrorAndtakeScreenshot(t,
							key + "_Is_" + actualValue + "_For_" + permissionName + "_Permission.");

				} // End of catch
			}

		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to role landing page and return object of
	// role landing page.
	// Author : Yogendra Rathore
	public static RoleLandingPage navigateToRoleLandingPage() throws Exception {

		try {
			loginIfNotLoggedInAndVerifyUserIsLoggedIn();

			// Navigate to role Landing Page
			roleLandingPage = BasePage.pageHeaderNavigation.navigateToRoleLandingPage();

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

			// Verify role Landing page
			verifyRoleLandingPageIsDisplayed(roleLandingPage);

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
		return roleLandingPage;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check Role Landing Page display Process Landing Page
	// Author : Yogendra Rathore
	public static void verifyRoleLandingPageIsDisplayed(RoleLandingPage roleLandingPage) throws Exception {
		// Verify Role Landing page
		if (!roleLandingPage.checkRoleLandingPageIsDisplayed()) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Role Landing Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Role Landing Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_Role_landing_page");
				log.error(
						"Error occured - Not able to Navigate to Role Landing Page for " + BasePage.currentMethodName);
			}
		}
	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to create role page and return createRPage
	// object.
	// Author: Yogendra Rathore
	// Modified By: Rakesh Kumar Sharma
	// Changes :replace LibraryFUnctions.clickoncancelbutton with
	// browserBackUsingKeyboard
	public static CreateRolePage navigateToCreateRolePage() throws Exception {

		// If Browser is not open then Open browser and if User in not
		// Logged In then Login
		TestLibrary.loginIfNotLoggedInAndVerifyUserIsLoggedIn();
		// Navigate to roleLanding Page
		roleLandingPage = BasePage.pageHeaderNavigation.navigateToRoleLandingPage();

		// Check To handle Confirmation Message - If appears
		LibraryFunctions.handlingConfirmationBoxMessage("ok");

		// Verify role Landing Page
		TestLibrary.verifyRoleLandingPageIsDisplayed(roleLandingPage);

		// Method call for navigation to Create New Role Page
		createRolePage = roleLandingPage.navigateToCreateRolePage();

		// Verify Create role Page
		TestLibrary.verifyCreateRolePageIsDisplayed(createRolePage);
		return createRolePage;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------

	// Verify Create role page is displayed
	// Author: Yogendra Rathore
	public static void verifyCreateRolePageIsDisplayed(CreateRolePage createRolePage) throws Exception {
		// Verify Create New Role Page is displayed
		if (!createRolePage.checkCreateRolePageIsDisplayed()) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Create  Role Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Create Role Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_Create_Role_page");
				log.error("Error occured - Not able to Navigate to Create Role Page for " + BasePage.currentMethodName);
				return;
			}
		} // end of if
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------

	// Assertion for sample size
	// Author: Yogendra Rathore
	public static void assertForSamleSize(Hashtable<String, Integer> testData) {

		if (testData.containsKey("sampleSizeForFeatureOfDefectiveType_expected")) {
			if (testData.get("sampleSizeForFeatureOfDefectiveType_expected") != testData
					.get("sampleSizeForFeatureOfDefectiveType_actual")) {
				try {
					Assert.assertEquals("Sample Size Is Not Correct For Feature Type Defective.",
							"Sample Size Should Be Correct For Feature Type Defective.");
				} catch (Throwable t) {
					reportErrorAndtakeScreenshot(t, "Sample_Size_Is_Not_Correct_For_Feature_Type_Defective.");
					log.error("Error occured - Sample Size Is Not Correct For Feature Type Defective. "
							+ BasePage.currentMethodName);

				}
			}
		}

		if (testData.containsKey("sampleSizeForFeatureOfDefectType_expected")) {
			if (testData.get("sampleSizeForFeatureOfDefectType_expected") != testData
					.get("sampleSizeForFeatureOfDefectType_actual")) {
				try {
					Assert.assertEquals("Sample Size Is Not Correct For Feature Type Defect.",
							"Sample Size Should Be Correct For Feature Type Defect.");
				} catch (Throwable t) {
					reportErrorAndtakeScreenshot(t, "Sample_Size_Is_Not_Correct_For_Feature_Type_Defect.");
					log.error("Error occured - Sample Size Is Not Correct For Feature Type Defect. "
							+ BasePage.currentMethodName);
					return;
				}
			}
		}

		if (testData.containsKey("sampleSizeForFeatureOfVariableType_expected")) {
			if (testData.get("sampleSizeForFeatureOfVariableType_expected") != testData
					.get("sampleSizeForFeatureOfVariableType_actual")) {
				try {
					Assert.assertEquals("Sample Size Is Not Correct For Feature Type Variable.",
							"Sample Size Should Be Correct For Feature Type Variable.");
				} catch (Throwable t) {
					reportErrorAndtakeScreenshot(t, "Sample_Size_Is_Not_Correct_For_Feature_Type_Variable.");
					log.error("Error occured - Sample Size Is Not Correct For Feature Type Variable. "
							+ BasePage.currentMethodName);
					return;
				}
			}
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------
	// Assert for Numeric field validation
	// Author: Priyanka Kundu
	public static void assertForNumericFieldVoilation(String result) {
		try {
			Assert.assertEquals("User is not able to enter allowed expected Numeric value : " + result,
					"User should be allowed to enter allowed expected Numeric value.");
		} catch (Throwable t) {
			reportErrorAndtakeScreenshot(t, "User_Should_Be_Allowed_To_Enter_Allowed_Expected_Numeric_Value.");
			log.error("Error occured - Numeric Field Voilation occurs. " + BasePage.currentMethodName);
			return;
		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Navigate to create Control Limit page
	// Author: Priyanka Kundu
	// Modified by : Yogendra Rathore <10-07-19>
	// Removed code for click on cancel button
	public static CreateControlLimitPage navigateToCreateControlLimitPage() throws Exception {

		controlLimitLandingPage = TestLibrary.navigateToControlLimitLandingPage();
		// Navigate to Create Control Limit Page
		createControlLimitPage = controlLimitLandingPage.navigateToCreateControlLimitPage();
		// Verify Create Control Limit page
		TestLibrary.verifyCreateControlLimitPageIsDisplayed(createControlLimitPage);

		return createControlLimitPage;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check Control Limit Landing Page display
	// Author: Priyanka Kundu
	public static void verifyControlLimitLandingPageIsDisplayed(ControlLimitLandingPage controlLimitLandingPage)
			throws Exception {
		// Verify Control Limit Landing page
		if (controlLimitLandingPage.checkControlLimitLandingPageIsDisplayed() == false)

		{
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Control Limit Landing Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Control Limit Landing Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_Control_Limit_Landing_Page");
				log.error("Error occured - Not able to Navigate to Control Limit Landing Page for "
						+ BasePage.currentMethodName);
			}

		}
	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to ControlLimit landing page and return
	// ControlLimitLandingPage object.
	// Author: Priyanka Kundu
	public static ControlLimitLandingPage navigateToControlLimitLandingPage() throws Exception {

		// Verify whether Browser Is Closed
		TestLibrary.loginIfNotLoggedInAndVerifyUserIsLoggedIn();
		LibraryFunctions.handlingConfirmationBoxMessage("ok");

		// Navigate to Control Limit Landing Page
		controlLimitLandingPage = BasePage.pageHeaderNavigation.navigateToControlLimitLandingPage();

		// Check To handle Confirmation Message - If appears
		LibraryFunctions.handlingConfirmationBoxMessage("ok");

		// Verify Control Limit Landing page
		TestLibrary.verifyControlLimitLandingPageIsDisplayed(controlLimitLandingPage);

		return controlLimitLandingPage;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check Create Control Limit Page is displayed
	// Author: Priyanka Kundu
	public static void verifyCreateControlLimitPageIsDisplayed(CreateControlLimitPage createControlLimitPage)
			throws Exception {
		// Verify Control Limit Landing page
		if (createControlLimitPage.checkCreateControlLimitPageIsDisplayed() == false)

		{
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Create Control Limit Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Create Control Limit Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_Create_Control_Limit_Page");
				log.error("Error occured - Not able to Navigate to Create Control Limit Page for "
						+ BasePage.currentMethodName);
			}

		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check Create ResponseGroup Page is displayed
	// Author: Priyanka Kundu
	public static void verifyCreateResponseGroupPageIsDisplayed(CreateResponseGroupPage createResponseGroupPage)
			throws Exception {
		// Verify ResponseGroup Landing page
		if (createResponseGroupPage.checkCreateResponseGroupPageIsDisplayed() == false)

		{
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Create Control Limit Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Create Control Limit Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_Create_Response_Group_Page");
				log.error("Error occured - Not able to Navigate to Create ResponseGroup Page for "
						+ BasePage.currentMethodName);
			}

		}
	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to ResponseGroup landing page and return
	// ResponseGroupLandingPage object.
	// Author: Priyanka Kundu
	public static ResponseGroupLandingPage navigateToResponseGroupLandingPage() throws Exception {

		// Verify whether Browser Is Closed
		TestLibrary.loginIfNotLoggedInAndVerifyUserIsLoggedIn();
		LibraryFunctions.handlingConfirmationBoxMessage("ok");

		// Navigate to Response Group Landing Page
		responseGroupLandingPage = BasePage.pageHeaderNavigation.navigateToResponseGroupLandingPage();

		// Check To handle Confirmation Message - If appears
		LibraryFunctions.handlingConfirmationBoxMessage("ok");

		// Verify Response Group Landing page
		TestLibrary.verifyResponseGroupLandingPageIsDisplayed(responseGroupLandingPage);

		return responseGroupLandingPage;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check ResponseGroup Landing Page display
	// Author: Priyanka Kundu
	public static void verifyResponseGroupLandingPageIsDisplayed(ResponseGroupLandingPage responseGroupLandingPage)
			throws Exception {
		// Verify Control Limit Landing page
		if (responseGroupLandingPage.checkResponseGroupLandingPageIsDisplayed() == false)

		{
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Response Group Landing Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Response Group Landing Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_Response_Group_Landing_Page");
				log.error("Error occured - Not able to Navigate to Response Group Landing Page for "
						+ BasePage.currentMethodName);
			}

		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Navigate to create Control Limit page
	// Author: Priyanka Kundu
	public static CreateResponseGroupPage navigateToCreateResponseGroupPage() throws Exception {

		if (!BasePage.isBrowserClosed() && UtilityFunctions.getMultilingualData("ResponseGroup_Header_Title")
				.equalsIgnoreCase(LibraryFunctions.getPageName())) {
			// Click on Back button
			BasePage.pageHeaderNavigation.clickOnCancelButton();
			responseGroupLandingPage = new ResponseGroupLandingPage();
			// Verify Control Limit Landing Page
			TestLibrary.verifyResponseGroupLandingPageIsDisplayed(responseGroupLandingPage);
		} else {

			responseGroupLandingPage = TestLibrary.navigateToResponseGroupLandingPage();
		}

		// Navigate to Create Response Group Page
		createResponseGroupPage = responseGroupLandingPage.navigateToCreateResponseGroupPage();

		// Verify Create Response Group page
		TestLibrary.verifyCreateResponseGroupPageIsDisplayed(createResponseGroupPage);

		return createResponseGroupPage;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check Create Checklist Page is displayed
	// Author: Priyanka Kundu
	public static void verifyCreateChecklistPageIsDisplayed(CreateChecklistPage createChecklistPage) throws Exception {
		// Verify ResponseGroup Landing page
		if (createChecklistPage.checkCreateChecklistPageIsDisplayed() == false) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Create Checklist Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Create Checklist Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_Create_Checklist_Page");
				log.error("Error occured - Not able to Navigate to Create Checklist Page for "
						+ BasePage.currentMethodName);
			}

		}
	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to Checklist landing page and return
	// ChecklistLandingPage object.
	// Author: Priyanka Kundu
	public static ChecklistLandingPage navigateToChecklistLandingPage() throws Exception {

		// Verify whether Browser Is Closed
		TestLibrary.loginIfNotLoggedInAndVerifyUserIsLoggedIn();
		LibraryFunctions.handlingConfirmationBoxMessage("ok");

		// Navigate to ChecklistLandingPage Landing Page
		checklistLandingPage = BasePage.pageHeaderNavigation.navigateToChecklistLandingPage();

		// Check To handle Confirmation Message - If appears
		LibraryFunctions.handlingConfirmationBoxMessage("ok");

		// Verify Response Group Landing page
		TestLibrary.verifyChecklistLandingPageIsDisplayed(checklistLandingPage);

		return checklistLandingPage;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check Checklist Landing Page display
	// Author: Priyanka Kundu
	public static void verifyChecklistLandingPageIsDisplayed(ChecklistLandingPage checklistLandingPage)
			throws Exception {
		// Verify Checklist Landing page
		if (checklistLandingPage.checkCheckListLandingPageIsDisplayed() == false)

		{
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Checklist Landing Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Checklist Landing Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_Checklist_Landing_Page");
				log.error("Error occured - Not able to Navigate to Checklist Landing Page for "
						+ BasePage.currentMethodName);
			}

		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Navigate to create Checklist page
	// Author: Priyanka Kundu
	public static CreateChecklistPage navigateToCreateChecklistPage() throws Exception {

		if (!BasePage.isBrowserClosed() && UtilityFunctions.getMultilingualData("Checklist_Header_Title")
				.equalsIgnoreCase(LibraryFunctions.getPageName())) {
			// Click on Back button
			BasePage.pageHeaderNavigation.clickOnCancelButton();
			checklistLandingPage = new ChecklistLandingPage();
			// Verify Checklist Landing Page
			TestLibrary.verifyChecklistLandingPageIsDisplayed(checklistLandingPage);
		} else {

			checklistLandingPage = TestLibrary.navigateToChecklistLandingPage();
		}

		// Navigate to Create Response Group Page
		createChecklistPage = checklistLandingPage.navigateToCreateChecklistPage();
		// verify create checklist page is displayed
		TestLibrary.verifyCreateChecklistPageIsDisplayed(createChecklistPage);

		return createChecklistPage;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Navigate and verify DC Requirment page.
	// Author: Yogendra Rathore
	// Send navigateFromDCLandingPage= true if user wants to navigate from DC
	// Configuration landing page
	// updated default page title for dc requirement page
	public static DCRequirementPage navigateAndVerifyToDCRequirementPage(int DCConfiguration_Id,
			boolean navigateFromDCLandingPage) throws Exception {
		try {
			DCConfigurationLandingPage dcLandingPage = new DCConfigurationLandingPage();
			if (BasePage.isBrowserClosed() || !dcLandingPage.checkDCLandingPageisDisplayed())
				dcLandingPage = navigateToDCLandingPage();

			if (!navigateFromDCLandingPage) {
				dcConfigurationPage = navigateToDCConfigurationPage(DCConfiguration_Id);

				dcRequirementPage = dcConfigurationPage.navigateToDCRequirementPage();
			}

			else {
				DCRequirementPage.lbl_Page_Title = UtilityFunctions.getMultilingualData("DCRequirement_PageTitle");
				dcRequirementPage = dcLandingPage.navigateToDCRequirementpage(DCConfiguration_Id);
			}
			// Verify whether DataCollection Requirement page displayed
			// or not
			UtilityFunctions.applicationWait(2000);
			TestLibrary.verifyDCRequirementPageIsDisplayed(dcRequirementPage);

		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}

		return dcRequirementPage;
	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to edit checklist page
	// Author: Priyanka Kundu
	public static EditChecklistPage navigateToEditChecklistPage(String checklistName) throws Exception {
		if (!BasePage.isBrowserClosed() && UtilityFunctions.getMultilingualData("Checklist_Header_Title")
				.equalsIgnoreCase(LibraryFunctions.getPageName())) {
			// Click on Back button
			BasePage.pageHeaderNavigation.clickOnCancelButton();
			checklistLandingPage = new ChecklistLandingPage();
			// Verify checklist landing page
			TestLibrary.verifyChecklistLandingPageIsDisplayed(checklistLandingPage);
		} else {

			// If Browser is not open then Open browser and if User in not
			// Logged In then Login
			TestLibrary.loginIfNotLoggedInAndVerifyUserIsLoggedIn();
			// Navigate to Process Landing Page
			checklistLandingPage = BasePage.pageHeaderNavigation.navigateToChecklistLandingPage();

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

			// Verify checklist landing page
			TestLibrary.verifyChecklistLandingPageIsDisplayed(checklistLandingPage);
		}

		// navigate to edit checklist page
		editChecklistPage = checklistLandingPage.navigateToEditChecklistPage(checklistName);

		// Verify edit checklist Page
		TestLibrary.verifyEditChecklistPageIsDisplayed(editChecklistPage, checklistName);

		return editChecklistPage;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Verify that DataCollection Requirement page is displayed
	// Author :Yogendra Rathore
	public static void verifyDCRequirementPageIsDisplayed(DCRequirementPage dcRequirementPage) throws Exception {

		if (!dcRequirementPage.checkDCRequirementPageIsDisplayed()) {

			try {
				Assert.assertEquals(
						ConstantsUtility.errApplicationPageNotDisplayed + " Data Collection Requirement page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Data Collection Requirement page");

			} catch (Exception t) {
				TestLibrary.reportErrorAndtakeScreenshot(t, "Data_Collection_Requirement_page_Did_not_Display");
				log.error("Error occured - Not able to Navigate to DataCollection Requirement Page for "
						+ BasePage.currentMethodName);
				throw t;
			}
		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check Edit Feature Page is displayed
	public static void verifyEditChecklistPageIsDisplayed(EditChecklistPage editChecklistPage, String editchecklistName)
			throws Exception {
		// check in progress text and wait till 15 secs if Inprogress is
		// displayed.
		UtilityFunctions.applicationWait(2000);
		int index = 0;
		while ((LibraryFunctions.isElementPresent(BasePage.xPath_InProgressImage, 1)
				|| LibraryFunctions.isElementPresent(BasePage.xPath_InProgressText, 1)) && index < 15) {
			UtilityFunctions.applicationWait(1000);
			index++;

		}
		// Verify Edit Feature Page
		if (EditChecklistPage.checkEditChecklistPageIsDisplayed(editchecklistName) == false) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Edit CheckList  Page",
						ConstantsUtility.msgApplicationPageShouldDisplay

								+ " EditFeature Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_editChecklist_page");
				log.error("Error occured - Not able to Navigate to Edit checklist Page for "
						+ BasePage.currentMethodName);
			}
		} // end of if

	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check Checklist Landing Page display
	// Author: Priyanka Kundu
	public static void verifyChecklistPreviewPageIsDisplayed(PreviewChecklistPage previewChecklistPage,
			String checkListPreviewHeaderName) throws Exception {
		// Verify Checklist Landing page
		if (previewChecklistPage.checkCheckListPreviewPageIsDisplayed(checkListPreviewHeaderName) == false)

		{
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Response Group Landing Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Response Group Landing Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_Checklist_Preview_Page");
				log.error("Error occured - Not able to Navigate to Checklist Preview Page for "
						+ BasePage.currentMethodName);
			}

		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Navigate and verify to Edit DC Requirment page.
	// Author: Chanchal Jain
	public static DCRequirementPage navigateAndVerifyEditDCRequirementPage(int DCConfiguration_Id) throws Exception {

		try {
			DCConfigurationLandingPage dcLandingPage = new DCConfigurationLandingPage();
			if (BasePage.isBrowserClosed() || !dcLandingPage.checkDCLandingPageisDisplayed())
				dcLandingPage = navigateToDCLandingPage();

			dcRequirementPage = dcLandingPage.navigateToEditDCRequirementpage(DCConfiguration_Id);

			// Verify whether DataCollection Requirement page displayed
			// or not
			UtilityFunctions.applicationWait(2000);
			TestLibrary.verifyDCRequirementPageIsDisplayed(dcRequirementPage);

		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}

		return dcRequirementPage;
	}

	// ----------------------------------------------------------------------------------------------------------------------------------------------
	// Check Login Page display
	// Modified By: Priyanka Kundu
	public static LoginPage verifyLoginPageIsDisplayed() throws Exception {

		if (BasePage.login.checkLoginPageIsDisplayed() == false) {
			try {
				Assert.assertEquals(ConstantsUtility.errSomeErrorOccured, "Login Page should displayed");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "LogInPage_did_not_open");
				log.error("Error occured - Not able to Navigate to Login Page Page for " + BasePage.currentMethodName);

			} // End of catch
		} // End of If
		return new LoginPage();
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to Shift landing page and return object of
	// Shift Landing Page
	// Author : Yogendra Rathore
	public static ShiftLandingPage navigateToShiftLandingPage() throws Exception {
		shiftLandingPage = new ShiftLandingPage();
		try {
			loginIfNotLoggedInAndVerifyUserIsLoggedIn();
			// Navigate to Shift Landing Page
			if (!shiftLandingPage.checkShiftLandingPageIsDisplayed()) {
				shiftLandingPage = BasePage.pageHeaderNavigation.navigateToShiftLandingPage();

				// Check To handle Confirmation Message - If appears
				LibraryFunctions.handlingConfirmationBoxMessage("ok");

				// Verify ShiftLanding page
				verifyShiftLandingPageIsDisplayed(shiftLandingPage);

				// Check To handle Confirmation Message - If appears
				LibraryFunctions.handlingConfirmationBoxMessage("ok");
				return shiftLandingPage;
			}

		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
		return shiftLandingPage;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check Shift Landing Page display
	// Author : Yogendra Rathore
	public static void verifyShiftLandingPageIsDisplayed(ShiftLandingPage shiftLandingPage) throws Exception {
		// Verify Shift Landing page
		if (!shiftLandingPage.checkShiftLandingPageIsDisplayed()) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Shift Landing Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Shift Landing Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_Shift_landing_page");
				log.error(
						"Error occured - Not able to Navigate to Shift Landing Page for " + BasePage.currentMethodName);
			}
		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to Create Shift page and return object of
	// Create Shift Page
	// Author : Rakesh Kumar Sharma
	public static CreateShiftPage navigateToCreateShiftPage() throws Exception {

		try {

			shiftLandingPage = navigateToShiftLandingPage();
			createShiftPage = shiftLandingPage.clickOnCreateShiftButton();
			verifyCreateShiftPageIsDisplayed(createShiftPage);
			return createShiftPage;

		} catch (Exception e) {
			throw new Exception("Error in navigating to CreateShift page :" + e);
		}

	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check Create Shift Page display
	// Author : Rakesh Kumar Sharma
	public static void verifyCreateShiftPageIsDisplayed(CreateShiftPage createShiftPage) throws Exception {
		UtilityFunctions.applicationWait(2000);
		// Verify Shift Landing page
		if (!createShiftPage.checkCreateShiftPageIsDisplayed()) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Create Shift Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Create Shift Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_CreateShift");
				log.error(
						"Error occured - Not able to Navigate to Create Shift Page for " + BasePage.currentMethodName);
			}
		}
	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to edit shift page on basis of shift name
	// and
	// return editShiftPage
	// object.
	// Author: Yogendra Rathore
	public static EditShiftPage navigateToEditShiftPage(String shiftName) throws Exception {
		if (!BasePage.isBrowserClosed() && UtilityFunctions.getMultilingualData("ShiftLandingPageTitle")
				.equalsIgnoreCase(LibraryFunctions.getPageName())) {
			// Click on Back button
			BasePage.pageHeaderNavigation.clickOnCancelButton();
			shiftLandingPage = new ShiftLandingPage();
			// Verify ShiftLanding Page
			TestLibrary.verifyShiftLandingPageIsDisplayed(shiftLandingPage);
		} else {

			shiftLandingPage = TestLibrary.navigateToShiftLandingPage();
		}

		// navigate to specific edit shift page
		editShiftPage = shiftLandingPage.navigateToEditShiftPage(shiftName);

		// Verify edit shift Page
		TestLibrary.verifyEditShiftPageIsDisplayed(editShiftPage, shiftName);

		return editShiftPage;
	}

	// ---------------------------------------------------------------------------------------------------------------------------
	// Check Edit Shift Page is displayed
	// Author: Yogendra Rathore
	public static void verifyEditShiftPageIsDisplayed(EditShiftPage editShiftPage, String shiftName) throws Exception {
		// check in progress text and wait till 15 secs if Inprogress is
		// displayed.
		UtilityFunctions.applicationWait(2000);
		int index = 0;
		while ((LibraryFunctions.isElementPresent(BasePage.xPath_InProgressImage, 1)
				|| LibraryFunctions.isElementPresent(BasePage.xPath_InProgressText, 1)) && index < 30) {
			UtilityFunctions.applicationWait(1000);
			index++;

		}
		// Verify Edit Shift Page
		if (!editShiftPage.checkEditShiftPageIsDisplayed(shiftName)) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " EditShift Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " EditShift Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_To_Navigate_To_Edit_Shift_Page");
				log.error("Error occured - Not able to Navigate to Edit Shift Page for " + BasePage.currentMethodName);

			}
		} // end of if

	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to Security Policy page and return object of
	// Security Policy Page
	// Author : Rakesh Kumar Sharma
	public static SecurityPolicyPage navigateToSecurityPolicyPage() throws Exception {

		try {

			loginIfNotLoggedInAndVerifyUserIsLoggedIn();

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

			// Navigate to Shift Landing Page
			securityPolicyPage = BasePage.pageHeaderNavigation.navigateToSecurityPolicyPage();

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

			UtilityFunctions.applicationWait(1000);
			// Verify ShiftLanding page
			verifySecurityPolicyPageIsDisplayed(securityPolicyPage);

			return securityPolicyPage;

		} catch (Exception e) {
			throw new Exception("Error in navigating to SecurityPolicy page :" + e);
		}

	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// verifySecurityPolicyPageIsDisplayed
	// Author : Rakesh Kumar Sharma
	public static void verifySecurityPolicyPageIsDisplayed(SecurityPolicyPage securityPolicyPage) throws Exception {
		UtilityFunctions.applicationWait(2000);
		// Verify Shift Landing page
		if (!securityPolicyPage.checkSecurityPolicyPageIsDisplayed()) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " SecurityPolicy Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " SecurityPolicy Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_SecurityPolicyPage");
				log.error(
						"Error occured - Not able to Navigate to SecurityPolicyPage for " + BasePage.currentMethodName);
			}
		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Navigate to Global Configuration Page
	// Author : Yogendra Rathore
	public static GlobalConfigurationPage navigateToGlobalConifurationPage() throws Exception {

		try {
			loginIfNotLoggedInAndVerifyUserIsLoggedIn();

			// Navigate to Global Configuration Page
			globalConfigurationPage = BasePage.pageHeaderNavigation.navigateToGlobalConfigurationPage();

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

			// Verify Global Configuration page
			verifyGlobalConfigurationPageIsDisplayed(globalConfigurationPage);

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

			verifyGlobalConfigurationPageIsDisplayed(globalConfigurationPage);

		} catch (Exception e) {

			throw new Exception("Error in navigating to Global Configuration page :" + e);

		}
		return globalConfigurationPage;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check global configuration display
	// Author : Yogendra Rathore
	public static void verifyGlobalConfigurationPageIsDisplayed(GlobalConfigurationPage globalConfigurationPage)
			throws Exception {

		// Verify Global configuration page
		if (!globalConfigurationPage.checkGlobalConfigurationPageIsDisplayed()) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Global Configuration Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Global Configuration Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_ Global Configuration");
				log.error("Error occured - Not able to Navigate to  Global Configuration Page for "
						+ BasePage.currentMethodName);
			}
		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Verify whether a specific Tab on security policy page is active or not
	// Author: Priyanka Kundu
	public static void verifySecurityPolicyTabIsActive(SecurityPolicyPage securityPolicyPage, String tabName) {
		// Verify Create New Part Page is displayed
		if (!securityPolicyPage.checkForActiveTab(tabName))
			try {
				Assert.assertEquals(tabName + " is not active", tabName + " should be active");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Tab_Is_Not_Active");

			}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Verify whether a specific Tab on Global Configuration page is active or
	// not
	// Author: Priyanka Kundu
	public static void verifyGlobalConfigurationTabIsActive(GlobalConfigurationPage globalConfigurationPage,
			String tabName) {
		// Verify Create New Part Page is displayed
		if (!globalConfigurationPage.checkForActiveTab(tabName))
			try {
				Assert.assertEquals(tabName + " is not active", tabName + " should be active");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Tab_Is_Not_Active");

			}
	}

	// -----------------------------------------------------------------------------------------------------------------------------
	// Inserted test data
	// Create Dashboard and tile
	// Author Name : Chanchal Jain
	// Modified by :YOgendra Rathore
	// COmmented // LibraryFunctions.removeUserPreferenceOfDashboard();
	public static boolean createGenericDashboardWithTile(Hashtable<String, String> testData) {
		String temp = BasePage.currentMethodName;
		BasePage.currentMethodName = "TC_TestData";
		boolean isDashboardCreated;
		try {
			// LibraryFunctions.removeUserPreferenceOfDashboard();
			testData.put(DashboardPage.db_DashboardTile, "true");
			DashboardPage.insertTestData(testData);
			isDashboardCreated = true;

		} catch (Exception e) {
			isDashboardCreated = false;
			// In case of any error message. Fail the test case
			TestLibrary.assertForSomeErrorOccur(e.getMessage());

		} // End of catch
		finally {
			BasePage.currentMethodName = temp;
		}
		return isDashboardCreated;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// navigate and verify checklist or DC Page is displayed
	// Author Name - Chanchal Jain
	// Modified by: Yogendra Rathore
	// Action : added logic to save execution time
	public static Object navigateAndVerifyChecklistOrDataCollectionPageFromDCTile(String dashboardName,
			String checklistOrDCName, String pageName) throws Exception {

		try {

			if (dashboardPage == null || !dashboardPage.checkDashboardPageIsDisplayed())
				// naviagte and Verify Manual DC Landing Page is Displayed
				dashboardPage = TestLibrary.navigateToDashboardPage();

			UtilityFunctions.applicationWait(3000);

			if (!dashboardPage.checkSpecificDashboardPageIsDisplayed(dashboardName)) {
				dashboardPage.searchAndNavigateToDashboardPage(dashboardName);

				verifySpecificDashboardPageIsDisplayed(dashboardPage, dashboardName);
			}

			// naviagte to dc Tile
			dashboardPage.navigateToChecklistOrDataCollectionPageFromDCTile(checklistOrDCName);

			if (pageName.equalsIgnoreCase("DCPage")) {
				beginMeasurementPage = new BeginMeasurementPage();
				// TODO : need to add condition for popups
				TestLibrary.verifyManualDCDataEntryPageIsDisplayed(beginMeasurementPage, checklistOrDCName);
				return beginMeasurementPage;
			}
			if (pageName.equalsIgnoreCase("ChecklistDCPage")) {
				checklistDataCollectionPage = new ChecklistDataCollectionPage();
				// TODO : need to add condition for popups
				verifyChecklistDataCollectionPageIsDisplayed(checklistDataCollectionPage, checklistOrDCName);
				return checklistDataCollectionPage;
			}

		} catch (Exception t) {

			log.error("Error occured - Not able to Navigate to checklist or DC page for " + BasePage.currentMethodName);
			throw t;
		}
		return dashboardPage;

	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check checklist DC Page display
	// Author Name - Chanchal Jain
	public static void verifyChecklistDataCollectionPageIsDisplayed(
			ChecklistDataCollectionPage checklistDataCollectionPage, String checklistName) throws Exception {
		// Verify checklist DC page is displayed.
		if (!checklistDataCollectionPage.checkChecklistDataCollectionPageIsDisplayed(checklistName)) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Checklist DC Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Checklist DC Page");
				return;
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_Checklist_DC_page");
				log.error(
						"Error occured - Not able to Navigate to checklist DC Page for " + BasePage.currentMethodName);
				throw t;
			}
		}

	}

	// ---------------------------------------------------------------------------------------------------------------------
	// Assert for Percentage field validation
	// Author: Rakesh Sharma
	public static void assertForPercentageFieldVoilation(String result) {
		try {
			Assert.assertEquals("Issues in allowed values of Percentage field : " + result,
					"User should be allowed to enter only allowed percentage values.");
		} catch (Throwable t) {
			reportErrorAndtakeScreenshot(t, "User_Should_Be_Allowed_To_Enter_Allowed_Expected_Percentage_Value.");
			log.error("Error occured - Percentage Field Voilation occurs. " + BasePage.currentMethodName);
			return;
		}
	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to DashBoard Page using URL and returns
	// object of DashBoardPage.
	// Author: Chanchal Jain
	// Modified By: Yogendra Rathore
	// Updated action * 1
	public static DashboardPage navigateToDashboardPageUsingURL() throws Exception {
		try {

			// Action *1 started
			String currentURL = BasePage.driver.getCurrentUrl();
			currentURL = currentURL.split("/#")[0];
			currentURL = currentURL + "/#dashboard/";
			// action * 1 ended.
			if (BasePage.IsLoggedIn == false) {
				TestLibrary.loginIfNotLoggedInAndVerifyUserIsLoggedIn();

				dashboardPage = new DashboardPage();
			} else {
				// Method call for navigation to DashBoard Page

				BasePage.driver.navigate().to(currentURL);

				// Check To handle Confirmation Message - If appears
				LibraryFunctions.handlingConfirmationBoxMessage("ok");
			}

			UtilityFunctions.applicationWait(1000);
			LibraryFunctions.checkLoadingIconIsDisplayed("SpinningLoadingIcon", 60);
			LibraryFunctions.checkLoadingIconIsDisplayed("TileLoading", 60);

			// Verify DashBoard is displayed
			TestLibrary.verifyDashboardPageIsDisplayed(dashboardPage);

			return dashboardPage;
		} catch (Exception e) {
			log.error("Error Occurred: While navigating to DashBoard Page " + BasePage.currentMethodName);
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Verify that specific Dashboard page is displayed
	// Author: Chanchal Jain
	public static void verifySpecificDashboardPageIsDisplayed(DashboardPage dashboardpage, String dashboardName)
			throws Exception {

		if (!dashboardpage.checkSpecificDashboardPageIsDisplayed(dashboardName)) {
			try {
				Assert.assertEquals(
						ConstantsUtility.errApplicationPageNotDisplayed + " Work Dashboard Page" + dashboardName,
						ConstantsUtility.msgApplicationPageShouldDisplay + " Work Dashboard Page");
				return;
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_Dashboard_page");
				log.error("Error occured - Not able to Navigate to Dashboard Page for " + BasePage.currentMethodName);
				throw t;
			}
		}
	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to edit role page and return createRPage
	// Author: Yogendra Rathore
	public static EditRolePage navigateToEditRolePage(Hashtable<String, String> testData) throws Exception {

		if (!BasePage.isBrowserClosed() && UtilityFunctions.getMultilingualData("Role_Header_Title")
				.equalsIgnoreCase(LibraryFunctions.getPageName())) { // Click
																		// on
																		// Back

			BasePage.pageHeaderNavigation.clickOnCancelButton();

			roleLandingPage = new RoleLandingPage(); // Verify role Landing Page
			TestLibrary.verifyRoleLandingPageIsDisplayed(roleLandingPage);
		} else {

			// If Browser is not open then Open browser and if User in not
			// //Logged In then Login

			TestLibrary.loginIfNotLoggedInAndVerifyUserIsLoggedIn();
			// Navigate to roleLanding Page
			roleLandingPage = BasePage.pageHeaderNavigation.navigateToRoleLandingPage();

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");
			// Verify role Landing Page

			TestLibrary.verifyRoleLandingPageIsDisplayed(roleLandingPage);
		}

		// Method call for navigation to Create New Role Page
		editRolePage = roleLandingPage.navigateEditRolePage(testData);

		// Verify edit role Page
		TestLibrary.verifyEditRolePageIsDisplayed(editRolePage, testData.get(RoleLandingPage.filter_Role_Role));
		return editRolePage;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------

	// Verify Edit role page is displayed
	// Author: Yogendra Rathore
	public static void verifyEditRolePageIsDisplayed(EditRolePage editRolePage, String roleName) throws Exception {
		// Verify edit New Role Page is displayed
		if (!editRolePage.verifyEditRolePageIsDisplayed(roleName)) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Edit  Role Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Edit Role Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_Edit_Role_page");
				log.error("Error occured - Not able to Navigate to Edit Role Page for " + BasePage.currentMethodName);
				throw new Exception(
						"Error occured - Not able to Navigate to Edit Role Page for " + BasePage.currentMethodName);
			}
		} // end of if
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to ManageSettings page and return object of
	// ManageSettings Page
	// Author : Rakesh Kumar Sharma
	public static ManageSettingsPage navigateToManageSettingsPage() throws Exception {

		try {

			loginIfNotLoggedInAndVerifyUserIsLoggedIn();

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

			// Navigate to Shift Landing Page
			manageSettingsPage = BasePage.pageHeaderNavigation.navigateToManageSettingsPage();

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

			// Verify Manage Settings page
			verifyManageSettingsPageIsDisplayed(manageSettingsPage);

			return manageSettingsPage;

		} catch (Exception e) {
			throw new Exception("Error in navigating to ManageSettings Page :" + e);
		}

	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// verify Manage Settings Page Is Displayed
	// Author : Rakesh Kumar Sharma
	public static void verifyManageSettingsPageIsDisplayed(ManageSettingsPage manageSettingsPage) throws Exception {
		// Verify Manage Settings page
		if (!manageSettingsPage.verifyManageSettingsPageIsDisplayed()) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " ManageSettings Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " ManageSettings Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_ManageSettingsPage");
				log.error(
						"Error occured - Not able to Navigate to ManageSettingsPage for " + BasePage.currentMethodName);

			}
		}
	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to Clone role page and return createRolePage
	// Author: Rakesh Sharma
	public static CreateRolePage navigateCloneRolePage(Hashtable<String, String> testData) throws Exception {

		if (!BasePage.isBrowserClosed() && UtilityFunctions.getMultilingualData("Role_Header_Title")
				.equalsIgnoreCase(LibraryFunctions.getPageName())) { // Click
																		// on
																		// Back

			BasePage.pageHeaderNavigation.clickOnCancelButton();

			roleLandingPage = new RoleLandingPage(); // Verify role Landing Page
			TestLibrary.verifyRoleLandingPageIsDisplayed(roleLandingPage);
		} else {
			// If Browser is not open then Open browser and if User in not
			// //Logged In then Login

			TestLibrary.loginIfNotLoggedInAndVerifyUserIsLoggedIn();
			// Navigate to roleLanding Page
			roleLandingPage = BasePage.pageHeaderNavigation.navigateToRoleLandingPage();

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

			// Verify role Landing Page
			TestLibrary.verifyRoleLandingPageIsDisplayed(roleLandingPage);
		}

		// Method call for navigation to Create New Role/clone role Page
		createRolePage = roleLandingPage.navigateCloneRolePage(testData);

		// Verify clone role Page
		TestLibrary.verifyCreateRolePageIsDisplayed(createRolePage);
		return createRolePage;
	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// assert for retention
	// Author: Rakesh Sharma
	public static void assertForfilterRetention(Hashtable<String, String> testData, boolean valueRetain,
			boolean fieldRetain) throws Exception {
		try {

			if (!valueRetain) {// check filter State Retained. (it will contain
								// key only if value
								// not retained)
				if (!testData.containsKey("filterValueRetained")) {
					try {
						Assert.assertEquals("Filter Value Retained.", "Filter Value Should Not Be Retained.");
					} catch (Throwable t) {
						TestLibrary.reportErrorAndtakeScreenshot(t, "Filter_Value_Retained.");
						return;
					}
				}

				// check filter value in grid Retained.
				if (!testData.containsKey("gridValueRetained")) {
					try {
						Assert.assertEquals("Filter Grid Value  Retained.",
								"Filter Grid Value Should Not Be Retained.");
					} catch (Throwable t) {
						TestLibrary.reportErrorAndtakeScreenshot(t, "Filter_Grid_Value_Retained.");
						return;
					}
				}

				// check filter State Retained.

				if (!testData.containsKey("filterCountCorrect")) {
					try {
						Assert.assertEquals("Filter Count Retained.", "Filter Count Should Not Be Retained.");
					} catch (Throwable t) {
						TestLibrary.reportErrorAndtakeScreenshot(t, "Filter_Count_Retained.");
						return;
					}
				}
			} else {
				// check filter State Retained. (it will contain key only if
				// value
				// not retained)
				if (testData.containsKey("filterValueRetained")) {
					try {
						Assert.assertEquals("Filter Value not Retained.", "Filter Value Should Be Retained.");
					} catch (Throwable t) {
						TestLibrary.reportErrorAndtakeScreenshot(t, "Filter_Value_NotRetained.");
						return;
					}
				}

				// check filter value in grid Retained.
				if (testData.containsKey("gridValueRetained")) {
					try {
						Assert.assertEquals("Filter Grid Value not Retained.", "Filter Grid Value Should Be Retained.");
					} catch (Throwable t) {
						TestLibrary.reportErrorAndtakeScreenshot(t, "Filter_Grid_Value_NotRetained.");
						return;
					}
				}

				// check filter State Retained.
				if (testData.containsKey("filterCountCorrect")) {
					try {
						Assert.assertEquals("Filter Count not  Retained.", "Filter Count Should Be Retained.");
					} catch (Throwable t) {
						TestLibrary.reportErrorAndtakeScreenshot(t, "Filter_Count_NotRetained.");
						return;
					}
				}

			}

			if (fieldRetain) {// check filter field displayed.
				if (testData.containsKey("filterFieldDisplayed")) {
					try {
						Assert.assertEquals("Filter field is not displayed", "Filter field should be displayed");
					} catch (Throwable t) {
						TestLibrary.reportErrorAndtakeScreenshot(t, "Filter_field_NotDisplayed");
						return;
					}
				}
			} else
			// check filter field displayed.
			if (!testData.containsKey("filterFieldDisplayed")) {
				try {
					Assert.assertEquals("Filter field is displayed", "Filter field should not be displayed");
				} catch (Throwable t) {
					TestLibrary.reportErrorAndtakeScreenshot(t, "Filter_field_Displayed");
					return;
				}
			}

		} catch (Exception e) {
			throw new Exception("Error in assertForfilterRetention :" + e);
		}
	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to edit control limit page on basis of part
	// feature process name
	// and return EditControlLimitPage object.
	// Author: Priyanka Kundu
	// Modified by : Yogendra Rathore <10-07-19>
	// Removed code for click on cancel button

	public static EditControlLimitPage navigateToEditCotrolLimitPage(Hashtable<String, String> testData)
			throws Exception {

		controlLimitLandingPage = TestLibrary.navigateToControlLimitLandingPage();

		// navigate to specific edit controlLimit page
		editControlLimitPage = controlLimitLandingPage.navigateToEditControlLimitPage(testData);

		// Verify edit control limit Page
		TestLibrary.verifyEditControlLimitPageIsDisplayed(editControlLimitPage);

		return editControlLimitPage;
	}

	// ---------------------------------------------------------------------------------------------------------------------------
	// Check Edit Control Limit Page is displayed
	// Author: Priyanka Kundu
	public static void verifyEditControlLimitPageIsDisplayed(EditControlLimitPage editControlLimitPage)
			throws Exception {
		// check in progress text and wait till 15 secs if Inprogress is
		// displayed.
		UtilityFunctions.applicationWait(2000);
		int index = 0;
		while ((LibraryFunctions.isElementPresent(BasePage.xPath_InProgressImage, 1)
				|| LibraryFunctions.isElementPresent(BasePage.xPath_InProgressText, 1)) && index < 15) {
			UtilityFunctions.applicationWait(1000);
			index++;

		}
		// Verify Edit Control Limit Page
		if (!editControlLimitPage.checkEditControlLimitPageIsDisplayed()) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Edit Control Limit Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Edit Control Limit Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_To_Navigate_To_Edit_ControlLimit_Page");
				log.error("Error occured - Not able to Navigate to Edit ControlLimit Page for "
						+ BasePage.currentMethodName);

			}
		} // end of if

	}

	// ---------------------------------------------------------------------------------------------------------------------------
	// Check Edit Response group Page is displayed
	// Author: Yogendra Rathore
	public static void verifyEditResponseGroupPageIsDisplayed(EditResponseGroupPage editResponseGroupPage,
			String responseGroupName) throws Exception {
		// check in progress text and wait till 15 secs if Inprogress is
		// displayed.
		UtilityFunctions.applicationWait(2000);
		int index = 0;
		while ((LibraryFunctions.isElementPresent(BasePage.xPath_InProgressImage, 1)
				|| LibraryFunctions.isElementPresent(BasePage.xPath_InProgressText, 1)) && index < 15) {
			UtilityFunctions.applicationWait(1000);
			index++;

		}
		// Verify Edit code group Page
		if (!editResponseGroupPage.checkEditResponseGroupPageIsDisplayed(responseGroupName)) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Edit Response group Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Edit Response group Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_To_Navigate_To_Edit_Response_Group_Page");
				log.error("Error occured - Not able to Navigate to Edit ResponseGroup Page for "
						+ BasePage.currentMethodName);

			}
		} // end of if

	}

	// This method navigates user to edit Response group page on basis of
	// response group name
	// and return editResponseGroupPage object
	// Author: Priyanka Kundu
	public static EditResponseGroupPage navigateToEditResponseGroupPage(String responseGroupName) throws Exception {
		try {
			if (!BasePage.isBrowserClosed() && UtilityFunctions.getMultilingualData("ResponseGroup_Header_Title")
					.equalsIgnoreCase(LibraryFunctions.getPageName())) {
				// Click on Back button
				BasePage.pageHeaderNavigation.clickOnCancelButton();
				responseGroupLandingPage = new ResponseGroupLandingPage();
				// Verify Code Group Landing Page
				TestLibrary.verifyResponseGroupLandingPageIsDisplayed(responseGroupLandingPage);
			} else {

				responseGroupLandingPage = TestLibrary.navigateToResponseGroupLandingPage();
			}

			Hashtable<String, String> testCaseData = new Hashtable<String, String>();
			testCaseData.put(ResponseGroupPage.filter_ResponseGroupName, responseGroupName);
			// navigate to specific edit response group page
			editResponseGroupPage = responseGroupLandingPage.navigateToEditResponseGroupPage(testCaseData);

			// Verify edit code group Page
			TestLibrary.verifyEditResponseGroupPageIsDisplayed(editResponseGroupPage, responseGroupName);

			return editResponseGroupPage;
		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));

		}

	}

	// --------------------------------------------------------------------------------------------
	// navigate and veriy createConditionsPage.
	// Author:Yogendra Rathore
	public static CreateConditionsPage navigateToCreateConditionsPage() throws Exception {

		if (!BasePage.isBrowserClosed() && UtilityFunctions.getMultilingualData("Conditions")
				.equalsIgnoreCase(LibraryFunctions.getPageName())) {
			// Click on Back button
			BasePage.pageHeaderNavigation.clickOnCancelButton();
			conditionsLandingPage = new ConditionsLandingPage();
			// Verifyconditons Landing Page
			TestLibrary.verifyConditionsLandingPageIsDisplayed(conditionsLandingPage);
		} else {

			// If Browser is not open then Open browser and if User in not
			// Logged In then Login
			TestLibrary.loginIfNotLoggedInAndVerifyUserIsLoggedIn();
			// Navigate to conditions landing page
			conditionsLandingPage = BasePage.pageHeaderNavigation.navigateToConditionsLandingPage();

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

			// Verify conditions Landing Page
			TestLibrary.verifyConditionsLandingPageIsDisplayed(conditionsLandingPage);
		}

		// Navigate to Create conditions landing page
		createConditionsPage = conditionsLandingPage.clickOnCreateConditionsButton();
		// Verify Create condintons page
		TestLibrary.verifyCreateConditionsPageIsDisplayed(createConditionsPage);

		return createConditionsPage;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Verify Create Conditions page is displayed
	public static void verifyCreateConditionsPageIsDisplayed(CreateConditionsPage createConditionspage)
			throws Exception {

		// Verify Create Part Page is displayed
		if (!createConditionspage.checkCreateConditionPageIsDisplayed()) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Create Conditions Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Create Conditions Page");
			} catch (Throwable t) {

				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_Create_Conditions_page");
				log.error("Error occured - Not able to Navigate to Create Conditions Page for "
						+ BasePage.currentMethodName);
			}

		} // end of if
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check conditions landing page is displayed.
	// author: Yogendra Rathore
	public static void verifyConditionsLandingPageIsDisplayed(ConditionsLandingPage conditionsLandingPage)
			throws Exception {

		if (!conditionsLandingPage.checkConditionsLandingPageIsDisplayed())

		{
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " ConditionsLanding Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " ConditionsLanding Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_Conditionslanding_page");
				log.error("Error occured - Not able to Navigate to Conditions landing Page for "
						+ BasePage.currentMethodName);
			}

		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to License Management landing page and return
	// object of
	// Shift Landing Page
	// Author : Chanchal Jain
	public static LicenseManagementLandingPage navigateAndVerifyLicenseManagementLandingPage() throws Exception {
		licenseManagementLandingPage = new LicenseManagementLandingPage();
		try {
			loginIfNotLoggedInAndVerifyUserIsLoggedIn();
			// Navigate to Shift Landing Page
			if (!licenseManagementLandingPage.checkLicenseManagementLandingPageIsDisplayed()) {
				licenseManagementLandingPage = BasePage.pageHeaderNavigation.navigateToLicenseManagementLandingPage();

				// Check To handle Confirmation Message - If appears
				LibraryFunctions.handlingConfirmationBoxMessage("ok");

				// Verify ShiftLanding page
				verifyLicenseManagementLandingPageIsDisplayed(licenseManagementLandingPage);

				// Check To handle Confirmation Message - If appears
				LibraryFunctions.handlingConfirmationBoxMessage("ok");
				return licenseManagementLandingPage;
			}

		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
		return licenseManagementLandingPage;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check License Mangement Landing Page display
	// Author : Chanchal Jain
	public static void verifyLicenseManagementLandingPageIsDisplayed(
			LicenseManagementLandingPage licenseManagementLandingPage) throws Exception {
		// Verify License Landing page
		if (!licenseManagementLandingPage.checkLicenseManagementLandingPageIsDisplayed()) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " License Mangement Landing Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " License Mangement Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_License_Mangement_landing_page");
				log.error("Error occured - Not able to Navigate to License Mangement Landing Page for "
						+ BasePage.currentMethodName);
			}
		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Harshita
	// Check Rule Template Page display Rule Template Page
	public static void verifyRuleTemplateandingPageIsDisplayed(RuleTemplateLandingPage ruleTemplateLandingPage)
			throws Exception {
		// Verify Rule Template Landing page
		if (ruleTemplateLandingPage.checkRuleTemplateLandingPageIsDisplayed() == false)

		{
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Rule Template Landing Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + "Rule Template Landing Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_rule_templatelanding_page");
				log.error("Error occured - Not able to Navigate to Rule Template Landing Page for "
						+ BasePage.currentMethodName);
				return;
			}

		}
	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to Rule Template landing page and return
	// ruleTemplateLandingPage
	// object
	// Author: Harshita Shaktawat
	public static RuleTemplateLandingPage navigateToRuleTemplateLandingPage() throws Exception {
		// If Browser is not open then Open browser and if User in not
		// Logged In then Login
		try {
			TestLibrary.loginIfNotLoggedInAndVerifyUserIsLoggedIn();

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

			// Navigates to Rule Template Landing Page and
			// returns the object of Rule Template Landing Page
			ruleTemplateLandingPage = BasePage.pageHeaderNavigation.navigateToRuleTemplateLandingPage();

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

			// Verify if Rule Template Landing page is displayed
			TestLibrary.verifyRuleTemplateLandingPageIsDisplayed(ruleTemplateLandingPage);

			return ruleTemplateLandingPage;

		} catch (Exception e) {
			throw new Exception("TestLibrary - navigateToRuleTemplateLandingPage " + e);
		}
	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to Create Rule Template page and
	// return
	// createRuleTemplatePage
	// object
	// Author: Harshita Shaktawat
	public static CreateRuleTemplatePage navigateToCreateRuleTemplatePage() throws Exception {

		try {

			if (!BasePage.isBrowserClosed()
					&& UtilityFunctions.getMultilingualData("RuleTemplateLandingPage_Header_Title")
							.equalsIgnoreCase(LibraryFunctions.getPageName())
					&& (BasePage.driver.findElement(By.xpath(BasePage.pageHeaderNavigation.xPath_btnBackButton))
							.getText().equals(UtilityFunctions.getMultilingualData("BackButton")))) {
				// Click on Back button
				BasePage.pageHeaderNavigation.clickOnCancelButton();
				ruleTemplateLandingPage = new RuleTemplateLandingPage();
				// Verify Rule Template Landing Page is displayed
				TestLibrary.verifyRuleTemplateLandingPageIsDisplayed(ruleTemplateLandingPage);
			} else {
				// If Browser is not open then Open browser and if User in not
				// Logged In then Login
				TestLibrary.loginIfNotLoggedInAndVerifyUserIsLoggedIn();

				// Navigates to Rule Template Landing Page
				ruleTemplateLandingPage = navigateToRuleTemplateLandingPage();

				// Check To handle Confirmation Message - If appears
				LibraryFunctions.handlingConfirmationBoxMessage("ok");

				// Verify Rule Template Landing Page
				TestLibrary.verifyRuleTemplateLandingPageIsDisplayed(ruleTemplateLandingPage);
			}

			// Method call for navigation to Create Rule Template Page
			createRuleTemplatePage = ruleTemplateLandingPage.navigateToCreateRuleTemplatePage();

			// Verify Create Rule Template Page
			TestLibrary.verifyCreateRuleTemplatePageIsDisplayed(createRuleTemplatePage);
			return createRuleTemplatePage;
		} catch (Exception e) {
			throw new Exception("TestLibrary - navigateToCreateRuleTemplatePage " + e);
		}
	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method verifies display of Create rule template page
	// Author: Harshita Shaktawat
	public static void verifyCreateRuleTemplatePageIsDisplayed(CreateRuleTemplatePage createRuleTemplatePage)
			throws Exception {

		// Verify Create New Rule Template Page is displayed
		if (!createRuleTemplatePage.checkCreateRuleTemplatePageIsDisplayed()) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " CreateRuleTemplate Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " CreateRuleTemplate Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_Create_Rule_Template_page");
				log.error("Error occured - Not able to Navigate to Create Rule Template Page for "
						+ BasePage.currentMethodName);
				throw new Exception("TestLibrary - verifyCreateRuleTemplatePageIsDisplayed " + t);
			}
		} // end of if
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check Rule Template Landing Page is displayed
	// Author : Harshita
	public static void verifyRuleTemplateLandingPageIsDisplayed(RuleTemplateLandingPage ruleTemplateLandingPage)
			throws Exception {
		if (!ruleTemplateLandingPage.checkRuleTemplateLandingPageIsDisplayed()) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " RuleTemplateLanding Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + "RuleTemplateLanding Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_ruleTemplate_landing_page");
				log.error("Error occured - Not able to Navigate to Rule Template Landing Page for "
						+ BasePage.currentMethodName);
				throw new Exception("TestLibrary - verifyRuleTemplateLandingPageIsDisplayed" + t);

			}

		}
	}

	// --------------------------------------------------------------------------------------------
	// navigate and veriy create gauge interface page
	// Author:Yogendra Rathore
	// Modifed by :Yogendra Rathore <29-08-2018>
	// Added navigation method
	public static CreateGaugeInterfacePage navigateToCreateGaugeInterfacePage(String navigationMethod)
			throws Exception {

		if (navigationMethod.equals("FromGaugeInterfaceLandingPage")) {
			if (!BasePage.isBrowserClosed()
					&& UtilityFunctions.getMultilingualData("Gauge_Interface")
							.equalsIgnoreCase(LibraryFunctions.getPageName())
					&& UtilityFunctions.getMultilingualData("BackButton")
							.equalsIgnoreCase(BasePage.pageHeaderNavigation.getLabelOfBackButtonDataSelctor())) {
				// Click on Back button
				BasePage.pageHeaderNavigation.clickOnCancelButton();
				gaugeInterfacesLandingPage = new GaugeInterfacesLandingPage();
				// Verify interface landing page
				TestLibrary.verifyGaugeInterfaceLandingPageIsDisplayed(gaugeInterfacesLandingPage);
			} else {

				navigateToGaugeInterfacesLandingPage();
			}

			// Navigate to Create gauge interface landing page
			createGaugeInterfacePage = gaugeInterfacesLandingPage.clickOnCreateGaugeInterfaceButton();

		} else if (navigationMethod.equals("FromCreateGaugeInterfaceConnectionPage")) {
			createGaugeInterfaceConnectionPage = navigateToCreateGaugeInterfaceConnectionPage();

			createGaugeInterfacePage = createGaugeInterfaceConnectionPage.clickOnAddGaugeInterfaceButton();

		} else {
			throw new Exception("Navigation Method not correct");
		}

		// Verify Create gauge interface page
		TestLibrary.verifyCreateGaugeInterfacePageIsDisplayed(createGaugeInterfacePage);

		return createGaugeInterfacePage;
	}

	// --------------------------------------------------------------------------------------------
	// navigate and veriy gauge interface lanidng page
	// Author:Yogendra Rathore
	public static GaugeInterfacesLandingPage navigateToGaugeInterfacesLandingPage() throws Exception {

		// If Browser is not open then Open browser and if User in not
		// Logged In then Login
		TestLibrary.loginIfNotLoggedInAndVerifyUserIsLoggedIn();

		// Navigate to gauge interface landing page
		gaugeInterfacesLandingPage = BasePage.pageHeaderNavigation.navigateToGaugeInterfacesLandingPage();

		// Check To handle Confirmation Message - If appears
		LibraryFunctions.handlingConfirmationBoxMessage("ok");

		// Verify interface landing page
		TestLibrary.verifyGaugeInterfaceLandingPageIsDisplayed(gaugeInterfacesLandingPage);

		return gaugeInterfacesLandingPage;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Verify Create Gauge Interace page is displayed
	// Author: Yogendra Rathore
	public static void verifyCreateGaugeInterfacePageIsDisplayed(CreateGaugeInterfacePage createGaugeInterfacePage)
			throws Exception {

		// Verify CreateGauge interfacePage is displayed
		if (!createGaugeInterfacePage.checkCreateGaugeInterfacePageIsDisplayed()) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Create Gauge Interface Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Create Gauge Interface Page");
			} catch (Throwable t) {

				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_Create_Gauge Interface_page");
				log.error("Error occured - Not able to Navigate to Create Conditions Page for "
						+ BasePage.currentMethodName);
			}

		} // end of if
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check gauge interface landing page is displayed.
	// author: Yogendra Rathore
	public static void verifyGaugeInterfaceLandingPageIsDisplayed(GaugeInterfacesLandingPage gaugeInterfacesLandingPage)
			throws Exception {

		if (!gaugeInterfacesLandingPage.checkGaugeInterfaceLandingPageIsDisplayed())

		{
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Gauge interface Landing Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Gauge Interface Landing Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_Gauge_Interfacelanding_page");
				log.error("Error occured - Not able to Navigate to Gauge Interface landing Page for "
						+ BasePage.currentMethodName);
			}

		}
	}

	// --------------------------------------------------------------------------------------------
	// navigate and veriy create gauge Interface connection page
	// Author:Yogendra Rathore
	public static CreateGaugeInterfaceConnectionPage navigateToCreateGaugeInterfaceConnectionPage() throws Exception {

		if (!BasePage.isBrowserClosed()
				&& UtilityFunctions.getMultilingualData("Gauge_Devices")
						.equalsIgnoreCase(LibraryFunctions.getPageName())
				&& UtilityFunctions.getMultilingualData("BackButton")
						.equalsIgnoreCase(BasePage.pageHeaderNavigation.getLabelOfBackButtonDataSelctor())) {
			// Click on Back button
			BasePage.pageHeaderNavigation.clickOnCancelButton();
			gaugeDevicesLandingPage = new GaugeDevicesLandingPage();
			// Verify Device landing page
			TestLibrary.verifyGaugeDeviceLandingPageIsDisplayed(gaugeDevicesLandingPage);
		} else {

			navigateToGaugeDevicesLandingPage();
		}

		// Navigate to Create gauge Connection page
		createGaugeInterfaceConnectionPage = gaugeDevicesLandingPage.clickOnCreateGaugeInterfaceConnectionButton();
		// Verify Create gauge Device page
		TestLibrary.verifyCreateGaugeInterfaceConnectionPageIsDisplayed(createGaugeInterfaceConnectionPage);

		return createGaugeInterfaceConnectionPage;
	}

	// --------------------------------------------------------------------------------------------
	// navigate and veriy gauge Device lanidng page
	// Author:Yogendra Rathore
	public static GaugeDevicesLandingPage navigateToGaugeDevicesLandingPage() throws Exception {

		// If Browser is not open then Open browser and if User in not
		// Logged In then Login
		TestLibrary.loginIfNotLoggedInAndVerifyUserIsLoggedIn();
		// Navigate to gauge Device landing page
		gaugeDevicesLandingPage = BasePage.pageHeaderNavigation.navigateToGaugeDevicesLandingPage();

		// Check To handle Confirmation Message - If appears
		LibraryFunctions.handlingConfirmationBoxMessage("ok");

		// Verify Device landing page
		TestLibrary.verifyGaugeDeviceLandingPageIsDisplayed(gaugeDevicesLandingPage);

		return gaugeDevicesLandingPage;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Verify Create Gauge Interace connection page is displayed
	// Author: Yogendra Rathore
	public static void verifyCreateGaugeInterfaceConnectionPageIsDisplayed(
			CreateGaugeInterfaceConnectionPage createGaugeInterfaceConnectionPage) throws Exception {

		// Verify CreateGauge interface connecitonPage is displayed
		if (!createGaugeInterfaceConnectionPage.checkCreateGaugeInterfaceConnectionPageIsDisplayed()) {
			try {
				Assert.assertEquals(
						ConstantsUtility.errApplicationPageNotDisplayed + " Create Gauge InterfaceConnection Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Create Gauge InterfaceConnection Page");
			} catch (Throwable t) {

				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_Create_Gauge InterfaceConnection_page");
				log.error("Error occured - Not able to Navigate to Create gauge interface conneciton  Page for "
						+ BasePage.currentMethodName);
			}

		} // end of if
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check gauge Device landing page is displayed.
	// author: Yogendra Rathore
	public static void verifyGaugeDeviceLandingPageIsDisplayed(GaugeDevicesLandingPage gaugeDevicesLandingPage)
			throws Exception {

		if (!gaugeDevicesLandingPage.checkGaugeDevicesLandingPageIsDisplayed())

		{
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Gauge Device Landing Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Gauge Device Landing Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_Gauge_Devicelanding_page");
				log.error("Error occured - Not able to Navigate to Gauge Device landing Page for "
						+ BasePage.currentMethodName);
			}

		}
	}

	// --------------------------------------------------------------------------------------------
	// navigate and veriy create gauge Format page
	// Author:Yogendra Rathore
	// Modifed by :Yogendra Rathore <29-08-2018>
	// Added navigation method
	// Modified by :Neha Goyal <18-10-2018>
	// Updated FromCreateGaugeDevicePage
	// Gauge Agent and Gauge Interface Connection should be created before
	// calling this method

	public static CreateGaugeFormatPage navigateToCreateGaugeFormatPage(String navigationMethod) throws Exception {

		if (navigationMethod.equals("FromGaugeFormatLandingPage")) {

			if (!BasePage.isBrowserClosed()
					&& UtilityFunctions.getMultilingualData("Gauge_Formats")
							.equalsIgnoreCase(LibraryFunctions.getPageName())
					&& UtilityFunctions.getMultilingualData("BackButton")
							.equalsIgnoreCase(BasePage.pageHeaderNavigation.getLabelOfBackButtonDataSelctor())) {
				// Click on Back button
				BasePage.pageHeaderNavigation.clickOnCancelButton();
				UtilityFunctions.applicationWait(2000);
				gaugeFormatsLandingPage = new GaugeFormatsLandingPage();
				// Verify gauge formatslanding page
				TestLibrary.verifyGaugeFormatsLandingPageIsDisplayed(gaugeFormatsLandingPage);
			} else {

				navigateToGaugeFormatsLandingPage();
			}

			// Navigate to Create gauge format page
			createGaugeFormatPage = gaugeFormatsLandingPage.clickOnCreateGaugeFormatButton();
		} else if (navigationMethod.equals("FromCreateGaugeDevicePage")) {
			createGaugeDevicePage = navigateToCreateGaugeDevicePage();
			// TODO Need to do for user specific Agent name and InterfaceName
			String gaugeInterfaceName = "FA_" + BasePage.currentMethodName + "_Interface";
			String gaugeAgentName = "FA_" + BasePage.currentMethodName + "_Agent";
			Hashtable<String, String> testData = new Hashtable<String, String>();
			;
			testData.put(CreateGaugeDevicePage.field_Agent, gaugeAgentName);
			testData.put(CreateGaugeDevicePage.field_Gauge_Interface, gaugeInterfaceName);
			UtilityFunctions.applicationWait(2000);
			createGaugeDevicePage.inputValueInFields(testData);
			createGaugeFormatPage = createGaugeDevicePage.clickOnAddGaugeFormatButton();

		} else {
			throw new Exception("Navigation Method not correct");
		}
		// Verify Create gauge Device page
		TestLibrary.verifyCreateGaugeFormatPageIsDisplayed(createGaugeFormatPage);
		LibraryFunctions.focusOutOfTheField();
		return createGaugeFormatPage;
	}

	// --------------------------------------------------------------------------------------------
	// navigate and veriy gauge format lanidng page
	// Author:Yogendra Rathore
	public static GaugeFormatsLandingPage navigateToGaugeFormatsLandingPage() throws Exception {

		// If Browser is not open then Open browser and if User in not
		// Logged In then Login
		TestLibrary.loginIfNotLoggedInAndVerifyUserIsLoggedIn();
		// Navigate to gauge Device landing page
		gaugeFormatsLandingPage = BasePage.pageHeaderNavigation.navigateToGaugeFormatsLandingPage();

		// Check To handle Confirmation Message - If appears
		LibraryFunctions.handlingConfirmationBoxMessage("ok");

		// Verify Gauge Formats page
		TestLibrary.verifyGaugeFormatsLandingPageIsDisplayed(gaugeFormatsLandingPage);

		return gaugeFormatsLandingPage;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Verify Create Gauge format page is displayed
	// Author: Yogendra Rathore
	public static void verifyCreateGaugeFormatPageIsDisplayed(CreateGaugeFormatPage createGaugeFormatPage)
			throws Exception {

		// Verify CreateGauge FormatPage is displayed
		if (!createGaugeFormatPage.checkCreateGaugeFormatPageIsDisplayed()) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Create Gauge Format  Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Create Gauge Format  Page");
			} catch (Throwable t) {

				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_Create_Gauge_Format_page");
				log.error("Error occured - Not able to Navigate to Create gauge Format  Page for "
						+ BasePage.currentMethodName);
			}

		} // end of if
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check gauge Format landing page is displayed.
	// author: Yogendra Rathore
	public static void verifyGaugeFormatsLandingPageIsDisplayed(GaugeFormatsLandingPage gaugeFormatsLandingPage)
			throws Exception {

		if (!gaugeFormatsLandingPage.checkGaugeFormatsLandingPageIsDisplayed())

		{
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Gauge Formats Landing Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Gauge Formats Landing Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_Gauge_Formatslanding_page");
				log.error("Error occured - Not able to Navigate to Gauge Formats landing Page for "
						+ BasePage.currentMethodName);
			}

		}
	}

	// --------------------------------------------------------------------------------------------
	// navigate and veriy Lot lanidng page
	// Author:Chanchal Jain
	public static LotLandingPage navigateAndVerifyLotLandingPage() throws Exception {

		// If Browser is not open then Open browser and if User in not
		// Logged In then Login
		TestLibrary.loginIfNotLoggedInAndVerifyUserIsLoggedIn();
		// Navigate to Lot landing page
		lotLandingPage = BasePage.pageHeaderNavigation.navigateToLotLandingPage();

		// Check To handle Confirmation Message - If appears
		LibraryFunctions.handlingConfirmationBoxMessage("ok");

		// Verify Device landing page
		TestLibrary.verifyLotLandingPageIsDisplayed(lotLandingPage);

		return lotLandingPage;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check lot landing page is displayed.
	// Author: Chanchal Jain
	public static void verifyLotLandingPageIsDisplayed(LotLandingPage lotLandingPage) throws Exception {

		if (!lotLandingPage.checkLotLandingPageIsDisplayed()) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Lot Landing Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Lot Landing Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_Lot_Landing_page");
				log.error("Error occured - Not able to Navigate to Lot Landing Page for " + BasePage.currentMethodName);
			}

		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to Workstation landing page and return object
	// of
	// workstations landing page.
	// Author : Tanmay Bhatnagar
	public static WorkstationLandingPage navigateToWorkstationsLandingPage() throws Exception {
		try {
			loginIfNotLoggedInAndVerifyUserIsLoggedIn();

			// Navigate to User Landing Page
			workstationsLandingPage = BasePage.pageHeaderNavigation.navigateToWorkstationsLandingPage();

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

			// Verify UserLanding page
			verifyWorkstationLandingPageIsDisplayed(workstationsLandingPage);

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
		return workstationsLandingPage;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check display of Workstation Landing Page
	// Author : Tanmay
	public static void verifyWorkstationLandingPageIsDisplayed(WorkstationLandingPage workstationLandingPage)
			throws Exception {
		// Verify User Landing page
		if (workstationLandingPage.checkWorkstationLandingPageIsDisplayed() == false) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Workstation Landing Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Workstation Landing Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_workstation_landing_page");
				log.error("Error occured - Not able to Navigate to Workstation Landing Page for "
						+ BasePage.currentMethodName);
			}
		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	/*
	 * This method navigates us from login page to configure workstations page
	 * Return: Object of User Create Page Author - Tanmay
	 */
	public static ConfigureWorkstationPage navigateToConfigureWorkstationsPage() throws Exception {

		if (!BasePage.isBrowserClosed() && UtilityFunctions.getMultilingualData("WorkstationLandingPageTitle")
				.equalsIgnoreCase(LibraryFunctions.getPageName())) {
			// Click on Back button
			BasePage.pageHeaderNavigation.clickOnCancelButton();
			workstationsLandingPage = new WorkstationLandingPage();
			// Verify WorkstationLanding Page
			TestLibrary.verifyWorkstationLandingPageIsDisplayed(workstationsLandingPage);
		} else {

			// If Browser is not open then Open browser and if User in not
			// Logged In then Login
			TestLibrary.loginIfNotLoggedInAndVerifyUserIsLoggedIn();
			// Method call for navigation to UserLanding Page
			workstationsLandingPage = BasePage.pageHeaderNavigation.navigateToWorkstationsLandingPage();

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

			// Verify WorkstationsLanding Page
			TestLibrary.verifyWorkstationLandingPageIsDisplayed(workstationsLandingPage);
		}

		// Navigate to configure workstations Page
		configureWorkstationPage = workstationsLandingPage.navigateToConfigureWorkstationPage();

		// Verify configure workstations Page
		TestLibrary.verifyConfigureWorkstaionPageIsDisplayed(configureWorkstationPage);

		return configureWorkstationPage;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check display of Configure Workstation Page
	// Author : Tanmay
	public static void verifyConfigureWorkstaionPageIsDisplayed(ConfigureWorkstationPage configureWorkstationPage)
			throws Exception {
		// Verify Configure workstations page
		if (configureWorkstationPage.checkConfigureWorkstationsPageIsDisplayed() == false) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Configure Workstation Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Configure Workstation Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_configure_workstation_page");
				log.error("Error occured - Not able to Navigate to Confgure Workstation Page for "
						+ BasePage.currentMethodName);
			}
		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	/*
	 * This method navigates us from login page to Edit Workstation page Return:
	 * Objectof Workstation EditPage Author - Tanmay
	 */
	public static EditWorkstationPage navigateToEditWorkstationPage(String workstationName) throws Exception {

		if (!BasePage.isBrowserClosed() && UtilityFunctions.getMultilingualData("WorkstationLandingPageTitle")
				.equalsIgnoreCase(LibraryFunctions.getPageName())) {
			// Click on Back button
			BasePage.pageHeaderNavigation.clickOnCancelButton();
			workstationsLandingPage = new WorkstationLandingPage();
			// Verify WorkstationLanding Page
			TestLibrary.verifyWorkstationLandingPageIsDisplayed(workstationsLandingPage);
		} else {

			// If Browser is not open then Open browser and if User in not
			// Logged In then Login
			TestLibrary.loginIfNotLoggedInAndVerifyUserIsLoggedIn();
			// Method call for navigation to UserLanding Page
			workstationsLandingPage = BasePage.pageHeaderNavigation.navigateToWorkstationsLandingPage();

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

			// Verify UserLanding Page
			TestLibrary.verifyWorkstationLandingPageIsDisplayed(workstationsLandingPage);
		}
		// Navigate to edit User Page
		Hashtable<String, String> testCaseData = new Hashtable<String, String>();
		testCaseData.put(WorkstationPage.filter_WorkstationName, workstationName);
		editWorkstationPage = workstationsLandingPage.navigateToEditWorkstationPage(testCaseData);

		// Verify Edit User Page
		TestLibrary.verifyEditWorkstationPageIsDisplayed(editWorkstationPage, workstationName);

		return editWorkstationPage;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Verify Edit Workstation page is displayed
	// Author : Tanmay
	public static void verifyEditWorkstationPageIsDisplayed(EditWorkstationPage editWorkstationPage,
			String workstationName) {
		// check in progress text and wait till 15 secs if Inprogress is
		// displayed.
		UtilityFunctions.applicationWait(2000);
		int index = 0;
		while ((LibraryFunctions.isElementPresent(BasePage.xPath_InProgressImage, 1)
				|| LibraryFunctions.isElementPresent(BasePage.xPath_InProgressText, 1)) && index < 15) {
			UtilityFunctions.applicationWait(1000);
			index++;

		}
		if (editWorkstationPage.checkEditWorkstationPageIsDisplayed(workstationName) == false) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Edit Workstation Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Edit Workstation Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_Edit_Workstation_page");

			}
		} // end of if
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to Workstation landing page and return object
	// of
	// workstations landing page.
	// Author : Tanmay Bhatnagar
	public static StatisticalRulesPage navigateToStatisticalRulesLandingPage() throws Exception {

		try {
			loginIfNotLoggedInAndVerifyUserIsLoggedIn();

			// Navigate to User Landing Page
			statisticalRulesPage = BasePage.pageHeaderNavigation.navigateToStatisticalRulesLandingPage();

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

			// Verify Statistical Rules Landing page
			verifyStatisticalRulesLandingPageIsDisplayed(statisticalRulesPage);

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");
			return statisticalRulesPage;

		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}

	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check display of StatisticalRulesPage
	// Author : Tanmay
	public static void verifyStatisticalRulesLandingPageIsDisplayed(StatisticalRulesPage statisticalRulesPage)
			throws Exception {
		// Verify StatisticalRulesPage
		if (statisticalRulesPage.checkStatisticalRulesPageIsDisplayed() == false) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Statistical Rules Landing Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Statistical Rules Landing Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_Statistical_Rules_landing_page");
				log.error("Error occured - Not able to Navigate to Statistical Rules Landing Page for "
						+ BasePage.currentMethodName);
			}
		}
	}

	// --------------------------------------------------------------------------------------------
	// navigate and veriy create Lot page
	// Author:Chanchal Jain
	// Modified by: Rakesh Sharma
	// check for dashboard page
	public static CreateLotPage navigateToCreateLotPage() throws Exception {

		if (!BasePage.isBrowserClosed() && UtilityFunctions.getMultilingualData("Lot_Header_Title")
				.equalsIgnoreCase(LibraryFunctions.getPageName())) {
			// Click on Back button
			BasePage.pageHeaderNavigation.clickOnCancelButton();
			DashboardPage dashboardpage = new DashboardPage();
			if (!dashboardpage.checkDashboardPageIsDisplayed()) {
				lotLandingPage = new LotLandingPage();
				// Verify Lot landing page
				TestLibrary.verifyLotLandingPageIsDisplayed(lotLandingPage);
			} else {
				lotLandingPage = navigateAndVerifyLotLandingPage();
			}
		} else {

			lotLandingPage = navigateAndVerifyLotLandingPage();
		}

		// Navigate to Create gauge Connection page
		createLotPage = lotLandingPage.clickOnCreateLotButton();
		// Verify Create gauge Device page
		TestLibrary.verifyCreateLotPageIsDisplayed(createLotPage);

		return createLotPage;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Verify Create Lot page is displayed
	// Author: Chanchal Jain
	public static void verifyCreateLotPageIsDisplayed(CreateLotPage createLotPage) throws Exception {

		// Verify Create Lot Page is displayed
		if (!createLotPage.checkCreateLotPageIsDisplayed()) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Create Lot Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Create Lot Page");
			} catch (Throwable t) {

				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_Create_Lot_page");
				log.error("Error occured - Not able to Navigate to Create Lot Page for " + BasePage.currentMethodName);
			}

		} // end of if
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// This method navigates us from login page to Edit Lot page Return: Object
	// of Lot EditPage
	// Author - Chanchal Jain
	public static EditLotPage navigateAndVerifyEditLotPage(String lotNumber) throws Exception {

		if (!BasePage.isBrowserClosed() && UtilityFunctions.getMultilingualData("Lot_Header_Title")
				.equalsIgnoreCase(LibraryFunctions.getPageName())) {
			// Click on Back button
			BasePage.pageHeaderNavigation.clickOnCancelButton();
			lotLandingPage = new LotLandingPage();
			// Verify Device landing page
			TestLibrary.verifyLotLandingPageIsDisplayed(lotLandingPage);
		} else {

			lotLandingPage = navigateAndVerifyLotLandingPage();
		}
		// Navigate to edit User Page
		Hashtable<String, String> testCaseData = new Hashtable<String, String>();
		testCaseData.put(LotPage.filter_LotNumber, lotNumber);

		editLotPage = lotLandingPage.navigateToEditLotPage(testCaseData);

		// Verify Edit User Page
		TestLibrary.verifyEditLotPageIsDisplayed(editLotPage, lotNumber);

		return editLotPage;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Verify Edit Workstation page is displayed
	public static void verifyEditLotPageIsDisplayed(EditLotPage editLotPage, String lotNumber) {
		// check in progress text and wait till 15 secs if Inprogress is
		// displayed.
		UtilityFunctions.applicationWait(2000);
		int index = 0;
		while ((LibraryFunctions.isElementPresent(BasePage.xPath_InProgressImage, 1)
				|| LibraryFunctions.isElementPresent(BasePage.xPath_InProgressText, 1)) && index < 50) {
			UtilityFunctions.applicationWait(1000);
			index++;

		}
		if (!editLotPage.checkEditLotPageIsDisplayed(lotNumber)) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Edit Lot Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Edit Lot Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_Edit_Lot_page");

			}
		} // end of if
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	/*
	 * Created By : Rakesh Kumar Sharma
	 * 
	 * Logic: This method navigates us from login page to create menu template page
	 * Return: Object of menu template Page
	 */
	public static CreateMenuTemplatesPage navigateToCreateMenuTemplatePage() throws Exception {

		if (!BasePage.isBrowserClosed() && UtilityFunctions.getMultilingualData("MenuTemplates_HeaderTitle")
				.equalsIgnoreCase(LibraryFunctions.getPageName())) {
			// Click on Back button
			BasePage.pageHeaderNavigation.clickOnCancelButton();
			menuTemplatesLandingPage = new MenuTemplatesLandingPage();
			// Verify MenuTemplates Landing Page
			TestLibrary.verifymenuTemplatesLandingPageIsDisplayed(menuTemplatesLandingPage);
		} else {

			// If Browser is not open then Open browser and if User in not
			// Logged In then Login
			TestLibrary.loginIfNotLoggedInAndVerifyUserIsLoggedIn();
			// Navigate to MenuTemplates Landing Page
			menuTemplatesLandingPage = BasePage.pageHeaderNavigation.navigateToMenuTemplatesLandingPage();

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

			// Verify MenuTemplates Landing Page
			TestLibrary.verifymenuTemplatesLandingPageIsDisplayed(menuTemplatesLandingPage);
		}

		// Navigate to Create MenuTemplates Page
		createMenuTemplatesPage = menuTemplatesLandingPage.navigateToCreateMenuTemplatesPage();

		// Verify Create MenuTemplates Page
		TestLibrary.verifyCreateMenuTemplatesPageIsDisplayed(createMenuTemplatesPage);

		return createMenuTemplatesPage;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// verify MenuTemplates landing Page Is Displayed
	// Author : Rakesh Kumar Sharma
	public static void verifymenuTemplatesLandingPageIsDisplayed(MenuTemplatesLandingPage menuTemplatesLandingPage)
			throws Exception {
		// Verify MenuTemplates page
		if (!menuTemplatesLandingPage.checkMenuTemplatesLandingPageIsDisplayed()) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " MenuTemplates Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " MenuTemplates Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_MenuTemplatesPage");
				log.error(
						"Error occured - Not able to Navigate to MenuTemplatesPage for " + BasePage.currentMethodName);

			}
		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// verify Create MenuTemplates Page Is Displayed
	// Author : Rakesh Kumar Sharma
	public static void verifyCreateMenuTemplatesPageIsDisplayed(CreateMenuTemplatesPage createMenuTemplatesPage)
			throws Exception {
		// Verify Create New MenuTemplates Page is displayed
		if (!createMenuTemplatesPage.checkCreateMenuTemplatesPageIsDisplayed()) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " create MenuTemplates Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " create MenuTemplates Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_Create_MenuTemplates_Page");
				log.error("Error occured - Not able to Navigate to Create MenuTemplates Page "
						+ BasePage.currentMethodName);
				return;
			}
		} // end of if
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	/*
	 * This method navigates us from login page to Edit menu templage page Return:
	 * Object of Edit menu templage page Author - Rakesh Kumar Sharma
	 */
	public static EditMenuTemplatesPage navigateToEditMenuTemplatePage(String menuTemplateName) throws Exception {

		if (!BasePage.isBrowserClosed() && UtilityFunctions.getMultilingualData("MenuTemplate")
				.equalsIgnoreCase(LibraryFunctions.getPageName())) {
			// Click on Back button
			BasePage.pageHeaderNavigation.clickOnCancelButton();
			menuTemplatesLandingPage = new MenuTemplatesLandingPage();
			// Verify UserLanding Page
			TestLibrary.verifymenuTemplatesLandingPageIsDisplayed(menuTemplatesLandingPage);
		} else {

			// If Browser is not open then Open browser and if User in not
			// Logged In then Login
			TestLibrary.loginIfNotLoggedInAndVerifyUserIsLoggedIn();
			// Method call for navigation to UserLanding Page
			menuTemplatesLandingPage = BasePage.pageHeaderNavigation.navigateToMenuTemplatesLandingPage();

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

			// Verify UserLanding Page
			TestLibrary.verifymenuTemplatesLandingPageIsDisplayed(menuTemplatesLandingPage);
		}
		// Navigate to edit MenuTemplate Page
		Hashtable<String, String> testCaseData = new Hashtable<String, String>();
		testCaseData.put(MenuTemplatePage.filter_menuTemplate, menuTemplateName);
		editMenuTemplatesPage = menuTemplatesLandingPage.navigateToEditMenuTemplatesPage(testCaseData);

		// Verify edit MenuTemplate Page
		TestLibrary.verifyEditMenuTemplatesPageIsDisplayed(editMenuTemplatesPage, menuTemplateName);
		return editMenuTemplatesPage;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------

	// Verify Edit MenuTemplates page is displayed
	// Author: Rakesh Kumar Sharma
	public static void verifyEditMenuTemplatesPageIsDisplayed(EditMenuTemplatesPage editMenuTemplatesPage,
			String menuTemplateName) throws Exception {
		// Verify edit New Role Page is displayed
		if (!editMenuTemplatesPage.checkEditMenuTemplatesPageIsDisplayed(menuTemplateName)) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " EditMenuTemplatesPage",
						ConstantsUtility.msgApplicationPageShouldDisplay + " EditMenuTemplatesPage");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_EditMenuTemplatesPage");
				log.error("Error occured - Not able to Navigate to EditMenuTemplatesPage for "
						+ BasePage.currentMethodName);
				throw new Exception("Error occured - Not able to Navigate to EditMenuTemplatesPage for "
						+ BasePage.currentMethodName);
			}
		} // end of if
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// Navigate the user to MenuTemplates LandingPage
	// Author Name: Rakesh Kumar Sharma
	// Modified bY : Yogendra Rathore
	// Added handle ok confirmation message box.
	public static MenuTemplatesLandingPage navigateToMenuTemplatesLandingPage() throws Exception {

		try {
			TestLibrary.loginIfNotLoggedInAndVerifyUserIsLoggedIn();
			PageHeader pageHeader = new PageHeader();
			menuTemplatesLandingPage = pageHeader.navigateToMenuTemplatesLandingPage();
			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

		} catch (Exception e) {
			log.error("Error occurred while navigating to menuTemplates landing Page " + BasePage.currentMethodName);
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
		return new MenuTemplatesLandingPage();
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// Navigate the user to Ntification rule LandingPage
	// Author Name: Rakesh Kumar Sharma
	public static NotificationRulesLandingPage navigateToNotificationRulesLandingPage() throws Exception {
		try {
			TestLibrary.loginIfNotLoggedInAndVerifyUserIsLoggedIn();

			PageHeader pageHeader = new PageHeader();
			notificationRulesLandingPage = pageHeader.navigateToNotificationsRulesLandingPage();
			UtilityFunctions.applicationWait(3000);
			TestLibrary.verifyNotificationRulesLandingPageIsDisplayed(notificationRulesLandingPage);

		} catch (Exception e) {
			log.error("Error occurred while navigating to menuTemplates landing Page " + BasePage.currentMethodName);
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
		return new NotificationRulesLandingPage();
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// Navigate the user to create Notification rule page
	// Author Name: Rakesh Kumar Sharma
	public static CreateNotificationRulesPage navigateToCreateNotificationRulesPage() throws Exception {
		try {
			if (!BasePage.isBrowserClosed()
					&& UtilityFunctions.getMultilingualData("NotificationRulesLandingPage_HeaderTitle")
							.equalsIgnoreCase(LibraryFunctions.getPageName())) {
				// Click on Back button
				BasePage.pageHeaderNavigation.clickOnCancelButton();
				DashboardPage dashboardpage = new DashboardPage();
				if (!dashboardpage.checkDashboardPageIsDisplayed()) {
					notificationRulesLandingPage = new NotificationRulesLandingPage();
					// Verify Rule Template Landing Page is displayed
					TestLibrary.verifyNotificationRulesLandingPageIsDisplayed(notificationRulesLandingPage);
				} else {
					notificationRulesLandingPage = navigateToNotificationRulesLandingPage();
				}

			} else {
				// Navigates to Rule Template Landing Page
				notificationRulesLandingPage = navigateToNotificationRulesLandingPage();
			}

			// Method call for navigation to Create notificationRules Page
			createNotificationRulesPage = notificationRulesLandingPage.navigateToCreateNotificationRulesPage();

			// Verify Create NotificationRules Page
			TestLibrary.verifyCreateNotificationRulesPageIsDisplayed(createNotificationRulesPage);
			return new CreateNotificationRulesPage();
		} catch (Exception e) {
			throw new Exception("TestLibrary - navigateToCreateNotificationRulesPage " + e);
		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check NotificationRules Landing Page is displayed
	// Author : Rakesh Kumar Sharma
	public static void verifyNotificationRulesLandingPageIsDisplayed(
			NotificationRulesLandingPage notificationRulesLandingPage) throws Exception {
		if (!notificationRulesLandingPage.checkNotificationRulesLandingPageIsDisplayed()) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " NotificationRules landing Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + "NotificationRules landing Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_NotificationRules_landing_page");
			}
		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check create NotificationRules Landing Page is displayed
	// Author : Rakesh Kumar Sharma
	public static void verifyCreateNotificationRulesPageIsDisplayed(
			CreateNotificationRulesPage createNotificationRulesPage) throws Exception {
		if (!createNotificationRulesPage.checkCreateNotificationRulesPageIsDisplayed()) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " create NotificationRules Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + "create NotificationRules Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_CreateNotificationRules_page");
				log.error("Error occured - Not able to Navigate to Create NotificationRules Page for "
						+ BasePage.currentMethodName);
				throw new Exception("TestLibrary - verifyCreateNotificationRulesPageIsDisplayed" + t);
			}
		}
	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to Processing Template landing page and return
	// processingTemplateLandingPage
	// object
	// Author: Harshita Shaktawat
	public static ProcessingTemplateLandingPage navigateToProcessingTemplateLandingPage() throws Exception {

		// If Browser is not open then Open browser and if User in not
		// Logged In then Login
		try {
			TestLibrary.loginIfNotLoggedInAndVerifyUserIsLoggedIn();

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

			// Navigates to Processing Template Landing Page and
			// returns the object of Processing Template Landing Page
			processingTemplateLandingPage = BasePage.pageHeaderNavigation.navigateToProcessingTemplateLandingPage();

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

			// Verify if Processing Template Landing page is displayed
			TestLibrary.verifyProcessingTemplateLandingPageIsDisplayed(processingTemplateLandingPage);

			return processingTemplateLandingPage;

		} catch (Exception e) {
			throw new Exception("TestLibrary - navigateToProcessingTemplateLandingPage " + e);
		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check Processing Template Landing Page is displayed
	// Author : Harshita Shaktawat
	public static void verifyProcessingTemplateLandingPageIsDisplayed(
			ProcessingTemplateLandingPage processingTemplateLandingPage) throws Exception {
		if (!processingTemplateLandingPage.checkProcessingTemplateLandingPageIsDisplayed()) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " ProcessingTemplateLanding Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + "ProcessingTemplateLanding Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_processingTemplate_landing_page");
				log.error("Error occured - Not able to Navigate to Processing Template Landing Page for "
						+ BasePage.currentMethodName);

			}

		}
	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to Create Processing Template page and
	// return
	// createProcessingTemplatePage
	// object
	// Author: Harshita Shaktawat
	public static CreateProcessingTemplatePage navigateToCreateProcessingTemplatePage() throws Exception {

		try {
			if (!BasePage.isBrowserClosed()
					&& UtilityFunctions.getMultilingualData("ProcessingTemplateLandingPage_Header_Title")
							.equalsIgnoreCase(LibraryFunctions.getPageName())
					&& (BasePage.driver.findElement(By.xpath(BasePage.pageHeaderNavigation.xPath_btnBackButton))
							.getText().equals(UtilityFunctions.getMultilingualData("BackButton")))) {

				// Click on Back button
				BasePage.pageHeaderNavigation.clickOnCancelButton();
				processingTemplateLandingPage = new ProcessingTemplateLandingPage();

				// Verify Processing Template Landing Page is displayed
				TestLibrary.verifyProcessingTemplateLandingPageIsDisplayed(processingTemplateLandingPage);
			} else {
				// Navigates to Processing Template Landing Page
				processingTemplateLandingPage = navigateToProcessingTemplateLandingPage();
			}

			// Method call for navigation to Create Processing Template Page
			createProcessingTemplatePage = processingTemplateLandingPage.navigateToCreateProcessingTemplatePage();

			// Verify Create Processing Template Page
			TestLibrary.verifyCreateProcessingTemplatePageIsDisplayed(createProcessingTemplatePage);
			return createProcessingTemplatePage;
		} catch (Exception e) {
			throw new Exception("TestLibrary - navigateToCreateProcessingTemplatePage " + e);
		}
	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method verifies display of Create processing template page
	// Author: Harshita Shaktawat
	public static void verifyCreateProcessingTemplatePageIsDisplayed(
			CreateProcessingTemplatePage createProcessingTemplatePage) throws Exception {
		// Verify Create New Processing Template Page is displayed
		if (!createProcessingTemplatePage.checkCreateProcessingTemplatePageIsDisplayed()) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " CreateProcessingTemplate Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " CreateProcessingTemplate Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_Create_Processing_Template_page");
				log.error("Error occured - Not able to Navigate to Create Processing Template Page for "
						+ BasePage.currentMethodName);

			}
		} // end of if
	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to Edit Processing Template page and
	// return
	// createEditTemplatePage
	// object
	// Author: Harshita Shaktawat
	public static EditProcessingTemplatePage navigateToEditProcessingTemplatePage(String processingTemplateName)
			throws Exception {

		try {
			if (!BasePage.isBrowserClosed()
					&& UtilityFunctions.getMultilingualData("ProcessingTemplateLandingPage_Header_Title")
							.equalsIgnoreCase(LibraryFunctions.getPageName())
					&& (BasePage.driver.findElement(By.xpath(BasePage.pageHeaderNavigation.xPath_btnBackButton))
							.getText().equals(UtilityFunctions.getMultilingualData("BackButton")))) {
				// Click on cancel button
				BasePage.pageHeaderNavigation.clickOnCancelButton();
				processingTemplateLandingPage = new ProcessingTemplateLandingPage();
				// Verify Processing Template Landing Page is displayed
				TestLibrary.verifyProcessingTemplateLandingPageIsDisplayed(processingTemplateLandingPage);
			} else {
				// Navigates to Processing Template Landing Page
				processingTemplateLandingPage = navigateToProcessingTemplateLandingPage();
			}

			// Method call for navigation to Edit Processing Template Page
			editProcessingTemplatePage = processingTemplateLandingPage
					.navigateToEditProcessingTemplatePage(processingTemplateName);

			// Verify Edit Processing Template Page
			TestLibrary.verifyEditProcessingTemplatePageIsDisplayed(editProcessingTemplatePage, processingTemplateName);
			return editProcessingTemplatePage;
		} catch (Exception e) {
			throw new Exception("TestLibrary - navigateToEditProcessingTemplatePage " + e);
		}
	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method verifies display of Edit processing template page
	// Author: Harshita Shaktawat
	public static void verifyEditProcessingTemplatePageIsDisplayed(
			EditProcessingTemplatePage editProcessingTemplatePage, String ptName) throws Exception {
		UtilityFunctions.applicationWait(2000);
		int index = 0;
		while ((LibraryFunctions.isElementPresent(BasePage.xPath_InProgressImage, 1)
				|| LibraryFunctions.isElementPresent(BasePage.xPath_InProgressText, 1)) && index < 15) {
			UtilityFunctions.applicationWait(1000);
			index++;

		}

		// Verify Edit Processing Template Page is displayed
		if (!editProcessingTemplatePage.checkEditProcessingTemplatePageIsDisplayed(ptName)) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " EditProcessingTemplate Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " EditProcessingTemplate Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_Edit_Processing_Template_page");
				log.error("Error occured - Not able to Navigate to Edit Processing Template Page for "
						+ BasePage.currentMethodName);

			}
		} // end of if
	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to Edit Rule Template page and
	// return
	// EditRuleTemplatePage
	// object
	// Author: Rakesh Sharma
	public static EditRuleTemplatePage navigateToEditRuleTemplatePage(String ruleTempName) throws Exception {

		try {
			if (!BasePage.isBrowserClosed()
					&& UtilityFunctions.getMultilingualData("RuleTemplateLandingPage_Header_Title")
							.equalsIgnoreCase(LibraryFunctions.getPageName())
					&& (BasePage.driver.findElement(By.xpath(BasePage.pageHeaderNavigation.xPath_btnBackButton))
							.getText().equals(UtilityFunctions.getMultilingualData("BackButton")))) {
				// Click on Back button
				BasePage.pageHeaderNavigation.clickOnCancelButton();
				ruleTemplateLandingPage = new RuleTemplateLandingPage();
				// Verify Rule Template Landing Page is displayed
				TestLibrary.verifyRuleTemplateLandingPageIsDisplayed(ruleTemplateLandingPage);
			} else {
				// Navigates to Rule Template Landing Page
				ruleTemplateLandingPage = navigateToRuleTemplateLandingPage();
			}

			// Method call for navigation to Edit Rule Template Page
			editRuleTemplatePage = ruleTemplateLandingPage.navigateToEditRuleTemplatePage(ruleTempName);

			TestLibrary.verifyEditRuleTemplatePageIsDisplayed(editRuleTemplatePage, ruleTempName);

			return editRuleTemplatePage;
		} catch (Exception e) {
			throw new Exception("TestLibrary - navigateToEditRuleTemplatePage " + e);
		}
	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method verifies display of Edit Rule template page
	// Author: Rakesh Kumar Sharma
	// Added wait condition
	// Modified By : Harshita Shaktawat
	public static void verifyEditRuleTemplatePageIsDisplayed(EditRuleTemplatePage editRuleTemplatePage,
			String ruleTempName) throws Exception {
		// check in progress text and wait till 15 secs if Inprogress is
		// displayed.
		UtilityFunctions.applicationWait(2000);
		int index = 0;
		while ((LibraryFunctions.isElementPresent(BasePage.xPath_InProgressImage, 1)
				|| LibraryFunctions.isElementPresent(BasePage.xPath_InProgressText, 1)) && index < 15) {
			UtilityFunctions.applicationWait(1000);
			index++;

		}

		// Verify Edit Rule Template Page is displayed
		if (!editRuleTemplatePage.checkEditRuleTemplatePageIsDisplayed(ruleTempName)) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " EditRuleTemplate Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " EditRuleTemplate Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_Edit_Rule_Template_page");

			}
		} // end of if
	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// assert for filter retention
	// Author: Rakesh Sharma
	public static void assertForfilterRetention(Hashtable<String, String> testData, boolean valueRetain,
			boolean fieldRetain, boolean gridValueRetain) throws Exception {
		try {

			if (!valueRetain) {// check filter State Retained. (it will contain
								// key only if value
								// not retained)
				if (!testData.containsKey("filterValueRetained")) {
					try {
						Assert.assertEquals("Filter Value Retained.", "Filter Value Should Not Be Retained.");
					} catch (Throwable t) {
						TestLibrary.reportErrorAndtakeScreenshot(t, "Filter_Value_Retained.");
						return;
					}
				}

				// check filter State Retained.
				if (!testData.containsKey("filterCountCorrect")) {
					try {
						Assert.assertEquals("Filter Count Retained.", "Filter Count Should Not Be Retained.");
					} catch (Throwable t) {
						TestLibrary.reportErrorAndtakeScreenshot(t, "Filter_Count_Retained.");
						return;
					}
				}
			} else {
				// check filter State Retained. (it will contain key only if
				// value
				// not retained)
				if (testData.containsKey("filterValueRetained")) {
					try {
						Assert.assertEquals("Filter Value not Retained.", "Filter Value Should Be Retained.");
					} catch (Throwable t) {
						TestLibrary.reportErrorAndtakeScreenshot(t, "Filter_Value_NotRetained.");
						return;
					}
				}

				// check filter State Retained.
				if (testData.containsKey("filterCountCorrect")) {
					try {
						Assert.assertEquals("Filter Count not  Retained.", "Filter Count Should Be Retained.");
					} catch (Throwable t) {
						TestLibrary.reportErrorAndtakeScreenshot(t, "Filter_Count_NotRetained.");
						return;
					}
				}
			}

			// check value in grid Retained.
			if (!gridValueRetain) {
				if (!testData.containsKey("gridValueRetained")) {
					try {
						Assert.assertEquals("Grid Value Retained.", "Grid Value Should Not Be Retained.");
					} catch (Throwable t) {
						TestLibrary.reportErrorAndtakeScreenshot(t, "Grid_Value_Retained.");
						return;
					}
				}
			} else {
				// check filter value in grid Retained.
				if (testData.containsKey("gridValueRetained")) {
					try {
						Assert.assertEquals("Filter Grid Value not Retained.", "Filter Grid Value Should Be Retained.");
					} catch (Throwable t) {
						TestLibrary.reportErrorAndtakeScreenshot(t, "Filter_Grid_Value_NotRetained.");
						return;
					}
				}
			}

			if (fieldRetain) {// check filter field displayed.
				if (testData.containsKey("filterFieldDisplayed")) {
					try {
						Assert.assertEquals("Filter field is not displayed", "Filter field should be displayed");
					} catch (Throwable t) {
						TestLibrary.reportErrorAndtakeScreenshot(t, "Filter_field_NotDisplayed");
						return;
					}
				}
			} else
			// check filter field displayed.
			if (!testData.containsKey("filterFieldDisplayed")) {
				try {
					Assert.assertEquals("Filter field is displayed", "Filter field should not be displayed");
				} catch (Throwable t) {
					TestLibrary.reportErrorAndtakeScreenshot(t, "Filter_field_Displayed");
					return;
				}
			}

		} catch (Exception e) {
			throw new Exception("Error in assertForfilterRetention :" + e);
		}
	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to Edit Notification rule method
	// Author:Yogendra Rathore
	public static EditNotificationRulesPage navigateToEditNotificationRulePage(Hashtable<String, String> testData)
			throws Exception {

		try {
			if (!BasePage.isBrowserClosed() && UtilityFunctions.getMultilingualData("NotificationRules")
					.equalsIgnoreCase(LibraryFunctions.getPageName())) {
				// Click on Back button
				BasePage.pageHeaderNavigation.clickOnCancelButton();
				notificationRulesLandingPage = new NotificationRulesLandingPage();
				// Verify Landing Page is displayed
				TestLibrary.verifyNotificationRulesLandingPageIsDisplayed(notificationRulesLandingPage);
			} else {
				// Navigates to Landing Page
				notificationRulesLandingPage = navigateToNotificationRulesLandingPage();
			}

			// Method call for navigation to edit page
			editNotificationRulesPage = notificationRulesLandingPage.navigateToEditNotificationRulesPage(testData);

			TestLibrary.verifyEditNotificationRulePageIsDisaplayed(editNotificationRulesPage,
					testData.get(NotificationRulesLandingPage.filter_NotificationRuleName));

			return editNotificationRulesPage;
		} catch (Exception e) {
			throw new Exception("TestLibrary - navigateToEditRuleTemplatePage " + e);
		}
	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method verifies display of Edit Notification Rule page
	// Author: Yogendra Rathore
	public static void verifyEditNotificationRulePageIsDisaplayed(EditNotificationRulesPage editNotificationRulesPage,
			String notificationRuleName) throws Exception {
		UtilityFunctions.applicationWait(2000);

		// Verify Page is displayed
		if (!editNotificationRulesPage.checkEditNotificationRulesPageIsDisplayed(notificationRuleName)) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Edit Notification Rule page",
						ConstantsUtility.msgApplicationPageShouldDisplay + "Edit Notification Rule page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_Edit Notification Rule page");

			}
		} // end of if
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	/*
	 * This method navigates us from login page to Edit User page Return: Object of
	 * User EditPage Author - Tanmay
	 */
	public static EditNotificationRulesPage navigateToEditNotificationRulesPage(String notificationRule)
			throws Exception {
		try {
			if (!BasePage.isBrowserClosed()
					&& UtilityFunctions.getMultilingualData("NotificationRulesLandingPage_HeaderTitle")
							.equalsIgnoreCase(LibraryFunctions.getPageName())) {
				// Click on Back button
				BasePage.pageHeaderNavigation.clickOnCancelButton();
				notificationRulesLandingPage = new NotificationRulesLandingPage();
				// Verify Rule Template Landing Page is displayed
				TestLibrary.verifyNotificationRulesLandingPageIsDisplayed(notificationRulesLandingPage);
			} else {
				// Navigates to Rule Template Landing Page
				notificationRulesLandingPage = navigateToNotificationRulesLandingPage();

				// Check To handle Confirmation Message - If appears
				LibraryFunctions.handlingConfirmationBoxMessage("ok");

				// Verify UserLanding Page
				TestLibrary.verifyNotificationRulesLandingPageIsDisplayed(notificationRulesLandingPage);
			}
			// Navigate to edit notificationRules Page
			Hashtable<String, String> testCaseData = new Hashtable<String, String>();
			testCaseData.put(NotificationRulesLandingPage.filter_NotificationRuleName, notificationRule);
			editNotificationRulesPage = notificationRulesLandingPage.navigateToEditNotificationRulesPage(testCaseData);

			// Verify editNotificationRulesPage

			return editNotificationRulesPage;
		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check Calcualtions Landing Page display
	// Author: Yogendra Rathore
	public static void verifyCalculationsLandingPageIsDisplayed(CalculationsLandingPage calculationsLandingPage)
			throws Exception {
		// Verify calculations landing page is dislpayed
		if (!calculationsLandingPage.checkCalculationsLandingPageIsDisplayed())

		{
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Calculations Landing Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + "Calculations Landing Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_Calculations_landing_page");
				log.error("Error occured - Not able to Navigate to Calculations Landing Page for "
						+ BasePage.currentMethodName);
			}

		}
	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to calculations landing page
	// Author: Yogendra Rathore
	public static CalculationsLandingPage navigateToCalculationsLandingPage() throws Exception {

		// Verify whether Browser Is Closed
		TestLibrary.loginIfNotLoggedInAndVerifyUserIsLoggedIn();
		LibraryFunctions.handlingConfirmationBoxMessage("ok");

		// Check To handle Confirmation Message - If appears
		LibraryFunctions.handlingConfirmationBoxMessage("ok");

		// Navigate to calculations Landing Page
		calculationsLandingPage = BasePage.pageHeaderNavigation.navigateToCalculationsLandingPage();

		// Check To handle Confirmation Message - If appears
		LibraryFunctions.handlingConfirmationBoxMessage("ok");

		// Verify calculations Landing page
		TestLibrary.verifyCalculationsLandingPageIsDisplayed(calculationsLandingPage);

		return calculationsLandingPage;
	}

	// ---------------------------------------------------------------------------------------------------------------------------
	// Check Edit Calculations Page is displayed
	// Author: Yogendra Rathore
	public static void verifyEditCalculationsPageIsDisplayed(EditCalculationPage editCalculationPage,
			String calculationName) throws Exception {
		// check in progress text and wait till 15 secs if Inprogress is
		// displayed.
		UtilityFunctions.applicationWait(2000);
		int index = 0;
		while ((LibraryFunctions.isElementPresent(BasePage.xPath_InProgressImage, 1)
				|| LibraryFunctions.isElementPresent(BasePage.xPath_InProgressText, 1)) && index < 15) {
			UtilityFunctions.applicationWait(1000);
			index++;

		}

		if (!editCalculationPage.checkEditCalculationPageIsDisplayed(calculationName)) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Edit Calculations Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Edit Calculations Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_To_Navigate_To_Edit_Calculations_Page");
				log.error("Error occured - Not able to Navigate to Edit Calculations Page for "
						+ BasePage.currentMethodName);

			}
		} // end of if

	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to edit Calculations page on basis of code
	// name

	// Author: Yogendra Rathore
	public static EditCalculationPage navigateToEditCalculationsPage(String calculationName) throws Exception {
		if (!BasePage.isBrowserClosed()
				&& CalculationsLandingPage.calculationsLandingHeaderTitle
						.equalsIgnoreCase(LibraryFunctions.getPageName())
				&& (BasePage.driver.findElement(By.xpath(BasePage.pageHeaderNavigation.xPath_btnBackButton)).getText()
						.equals(UtilityFunctions.getMultilingualData("BackButton")))) {
			// Click on Back button
			BasePage.pageHeaderNavigation.clickOnCancelButton();

			calculationsLandingPage = new CalculationsLandingPage();
			// Verify Calculations Landing Page
			TestLibrary.verifyCalculationsLandingPageIsDisplayed(calculationsLandingPage);
		} else {

			calculationsLandingPage = navigateToCalculationsLandingPage();
		}

		Hashtable<String, String> testData = new Hashtable<String, String>();
		testData.put(CalculationsLandingPage.filter_CalculationName, calculationName);
		// navigate to specific edit Calculations page
		editCalculationPage = calculationsLandingPage.navigateToEditCalculationPage(testData);
		// Verify edit Calculations Page
		TestLibrary.verifyEditCalculationsPageIsDisplayed(editCalculationPage, calculationName);

		return editCalculationPage;
	}

	// ------------------------------------------------------------------------------------------------------------------------------

	// Navigate to create Calculations page
	// Author: Yogendra Rathore
	public static CreateCalculationPage navigateToCreateCalculationPage() throws Exception {

		if (!BasePage.isBrowserClosed() && CalculationsLandingPage.calculationsLandingHeaderTitle
				.equalsIgnoreCase(LibraryFunctions.getPageName())) {
			// Click on Back button
			BasePage.pageHeaderNavigation.clickOnCancelButton();
			calculationsLandingPage = new CalculationsLandingPage();
			// Verify Calculations Landing Page
			TestLibrary.verifyCalculationsLandingPageIsDisplayed(calculationsLandingPage);
		} else {

			calculationsLandingPage = navigateToCalculationsLandingPage();
		}

		// Navigate to Create Calculations Page
		createCalculationPage = calculationsLandingPage.navigateToCreateCalculationPage();
		// Verify Createcalculation page
		TestLibrary.verifyCreateCalculationPageIsDisplayed(createCalculationPage);

		return createCalculationPage;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Verify Create Calculation page is displayed
	// Author: Yogendra Rathore
	public static void verifyCreateCalculationPageIsDisplayed(CreateCalculationPage createCalculationPage) {
		// Verify Create CodeGroup Page is displayed
		if (!createCalculationPage.checkCreateCalculationPageIsDisplayed()) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Create Calculations Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Create Calculations Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_Create_Calculations_Feature_page");
				log.error("Error occured - Not able to Navigate to Create Calculations Page for "
						+ BasePage.currentMethodName);

			}
		} // end of if
	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to conditions landing page
	// Author: Yogendra Rathore
	public static ConditionsLandingPage navigateToConditionsLandingPage() throws Exception {

		// If Browser is not open then Open browser and if User in not
		// Logged In then Login
		TestLibrary.loginIfNotLoggedInAndVerifyUserIsLoggedIn();
		// Navigate to conditions landing page
		conditionsLandingPage = BasePage.pageHeaderNavigation.navigateToConditionsLandingPage();

		// Check To handle Confirmation Message - If appears
		LibraryFunctions.handlingConfirmationBoxMessage("ok");

		// Verify conditions Landing Page
		TestLibrary.verifyConditionsLandingPageIsDisplayed(conditionsLandingPage);

		return conditionsLandingPage;
	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to edit Condtions page on basis of code
	// name

	// Author: Yogendra Rathore
	public static EditConditionsPage navigateToEditCondtionsPage(String conditionName) throws Exception {
		try {
			if (!BasePage.isBrowserClosed() && ConditionsLandingPage.conditionsLandingPageTitle
					.equalsIgnoreCase(LibraryFunctions.getPageName())) {
				// Click on Back button
				BasePage.pageHeaderNavigation.clickOnCancelButton();

				conditionsLandingPage = new ConditionsLandingPage();
				// Verify Condtions Landing Page
				TestLibrary.verifyConditionsLandingPageIsDisplayed(conditionsLandingPage);
			} else {

				conditionsLandingPage = navigateToConditionsLandingPage();
			}

			Hashtable<String, String> testData = new Hashtable<String, String>();
			testData.put(ConditionsLandingPage.filter_ConditionsName, conditionName);
			// navigate to specific edit Condtions page
			editConditionPage = conditionsLandingPage.navigateToEditConditionPage(testData);
			// Verify edit Condtions Page
			TestLibrary.verifyEditCondtionsPageIsDisplayed(editConditionPage, conditionName);

			return editConditionPage;
		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------------
	// Check Edit Condtions Page is displayed
	// Author: Yogendra Rathore
	public static void verifyEditCondtionsPageIsDisplayed(EditConditionsPage editConditionPage, String conditionName)
			throws Exception {
		try {
			// check in progress text and wait till 15 secs if Inprogress is
			// displayed.
			UtilityFunctions.applicationWait(2000);
			int index = 0;
			while ((LibraryFunctions.isElementPresent(BasePage.xPath_InProgressImage, 1)
					|| LibraryFunctions.isElementPresent(BasePage.xPath_InProgressText, 1)) && index < 15) {
				UtilityFunctions.applicationWait(1000);
				index++;

			}

			if (!editConditionPage.checkEditConditionPageIsDisplayed(conditionName)) {
				try {
					Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Edit Condtions Page",
							ConstantsUtility.msgApplicationPageShouldDisplay + " Edit Condtions Page");
				} catch (Throwable t) {
					reportErrorAndtakeScreenshot(t, "Not_Able_To_Navigate_To_Edit_Condtions_Page");
					log.error("Error occured - Not able to Navigate to Edit Condtions Page for "
							+ BasePage.currentMethodName);

				}
			}
		} // end of if
		catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------
	// Assertion for Restore record
	// Author: Rakesh Sharma
	public static void assertForRestoreRecord(Hashtable<String, String> result) throws Exception {
		try {
			String expectedConfirmationMessage = "", actualConfirmationMessage = "";
			String expectedRestoredSuccessfullyMessage = "", actualRestoredSuccessfullyMessage = "",
					actualRestoredPopupTitle = "";
			String expectedRestorePopUpTitle = "";

			if (result.containsKey("expectedConfirmationMessage")) {
				expectedConfirmationMessage = result.get("expectedConfirmationMessage");
			}

			if (result.containsKey("expectedRestoreSuccessfullyMessage")) {
				expectedRestoredSuccessfullyMessage = result.get("expectedRestoreSuccessfullyMessage");
			}

			if (result.containsKey("expectedPopUpTitle")) {
				expectedRestorePopUpTitle = result.get("expectedPopUpTitle");
			}

			// check confirmation displayed
			if (result.containsKey("Confirmation Message Displayed")) {
				try {
					Assert.assertEquals(ConstantsUtility.errNoConfirmationMessageDispalyedOnDeletingRecord,
							ConstantsUtility.msgConfirmationMessageShouldBeDisplayed);
				} catch (Throwable t) {
					TestLibrary.reportErrorAndtakeScreenshot(t,
							"No_Confirmation_Message_Is_Displayed_On_Deleting_A_Record");
					return;
				} // End of catch
			}
			// check confirmation cross [X] button is present
			if (result.containsKey("Pop Up Close Button Present")) {
				try {
					Assert.assertEquals(ConstantsUtility.errValidationMessageCrossIconIsNotPresent,
							ConstantsUtility.msgValidationMessageCrossIconIsNotPresent);
				} catch (Throwable t) {
					TestLibrary.reportErrorAndtakeScreenshot(t,
							"No_Cross[X]_Button_Is_Present_On_Confirmation_Message_Displayed_On_Deleting_A_Record");

				} // End of catch
			}
			// get actual Confirmation message
			if (result.containsKey("Confirmation Message")) {
				actualConfirmationMessage = result.get("Confirmation Message");

				if (!expectedConfirmationMessage.equals(actualConfirmationMessage)) {
					System.out.println("Excpected Confirmation :" + expectedConfirmationMessage);
					System.out.println("Actual Confirmation :" + actualConfirmationMessage);
					try {
						Assert.assertEquals(
								ConstantsUtility.errConfirmationMessageDispalyedOnDeletingRecordIsNotCorrect,
								ConstantsUtility.msgCorrectConfirmationMessageShouldBeDisplayed);
					} catch (Throwable t) {
						TestLibrary.reportErrorAndtakeScreenshot(t,
								"Correct_Confirmation_Message_Is_Not_Displayed_On_Deleting_A_Record");
					} // End of catch
				}
			}

			// get actual Restore successfully message
			{
				if (result.containsKey("Restored successfully Message"))
					actualRestoredSuccessfullyMessage = result.get("Restored successfully Message");

				if (!expectedRestoredSuccessfullyMessage.equals(actualRestoredSuccessfullyMessage)) {
					System.out.println("Excpected restored message :" + expectedRestoredSuccessfullyMessage);
					System.out.println("Actual restored message :" + actualRestoredSuccessfullyMessage);
					try {

						Assert.assertEquals("Restore successful message not correct",
								"Restore successful message should be correct");
					} catch (Throwable t) {
						TestLibrary.reportErrorAndtakeScreenshot(t,
								"Correct_Restore_Successfully_Message_Is_Not_Displayed_On_Restoring_A_Record");
					} // End of catch
				}
			}

			// get actual Restore popup title
			if (result.containsKey("PopupHeaderTitle")) {
				actualRestoredPopupTitle = result.get("PopupHeaderTitle");

				if (!expectedRestorePopUpTitle.equals(actualRestoredPopupTitle)) {
					try {
						Assert.assertEquals("Restore popup title is not correct.",
								"Restore popup title should be correct.");
					} catch (Throwable t) {
						TestLibrary.reportErrorAndtakeScreenshot(t, "Restore_Popup_Title_Is_Not_Correct");
					} // End of catch
				}
			}
			// check accordion body by default collapsed
			if (result.containsKey("OK_Button_Present")) {
				// check ok button present
				if (result.get("OK_Button_Present").equals(String.valueOf(false))) {
					try {
						Assert.assertEquals("Ok button is not present", "Ok button should be present");
					} catch (Throwable t) {
						TestLibrary.reportErrorAndtakeScreenshot(t, "OK_Button_Is_Not_Present");
					} // End of catch
				}
			}
			if (result.containsKey("Cancel_Button_Present")) {
				// check cancel button present
				if (result.get("Cancel_Button_Present").equals(String.valueOf(false))) {
					try {
						Assert.assertEquals("Cancel button is not present", "Cancel button should be present");
					} catch (Throwable t) {
						TestLibrary.reportErrorAndtakeScreenshot(t, "Cancel_Button_Is_Not_Present");
					} // End of catch
				}
			}

			// check cross button present
			if (result.containsKey("Cross_Button_Present"))
				if (result.get("Cross_Button_Present").equals(String.valueOf(false))) {
					try {
						Assert.assertEquals("Cross button is not present", "Cross button should be present");
					} catch (Throwable t) {
						TestLibrary.reportErrorAndtakeScreenshot(t, "Cross_Button_Is_Not_Present");
					} // End of catch
				}
			// check default Focus on Cancelcbutton
			if (result.containsKey("DefaultFocusOnCancel")) {
				try {
					Assert.assertEquals("Default focus is not on cancel button",
							"Default focus should be on cancel button");
				} catch (Throwable t) {
					TestLibrary.reportErrorAndtakeScreenshot(t, "Default_Focus_Is_Not_On_Cancel_Button");
				} // End of catch
			}

		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// --------------------------------------------------------------------------------------------
	// navigate and veriy create gauge device page
	// Author:Yogendra Rathore
	public static CreateGaugeDevicePage navigateToCreateGaugeDevicePage() throws Exception {

		if (!BasePage.isBrowserClosed()
				&& UtilityFunctions.getMultilingualData("Gauge_Devices")
						.equalsIgnoreCase(LibraryFunctions.getPageName())
				&& UtilityFunctions.getMultilingualData("BackButton")
						.equalsIgnoreCase(BasePage.pageHeaderNavigation.getLabelOfBackButtonDataSelctor())) {
			// Click on Back button
			BasePage.pageHeaderNavigation.clickOnCancelButton();
			gaugeDevicesLandingPage = new GaugeDevicesLandingPage();
			// Verify interface landing page
			TestLibrary.verifyGaugeDeviceLandingPageIsDisplayed(gaugeDevicesLandingPage);
		} else {

			gaugeDevicesLandingPage = navigateToGaugeDevicesLandingPage();
		}

		// Navigate to Create gauge device landing page
		createGaugeDevicePage = gaugeDevicesLandingPage.clickOnCreateGaugeDeviceButton();
		// Verify Create gauge device page
		TestLibrary.verifyCreateGaugeDevicePageIsDisplayed(createGaugeDevicePage);
		return createGaugeDevicePage;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Verify Create Gauge device page is displayed
	// Author: Yogendra Rathore
	public static void verifyCreateGaugeDevicePageIsDisplayed(CreateGaugeDevicePage createGaugeDevicePage)
			throws Exception {

		// Verify CreateGauge device Page is displayed
		if (!createGaugeDevicePage.checkCreateGaugeDevicePageIsDisplayed()) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Create Gauge Device Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Create Gauge Device Page");
			} catch (Throwable t) {

				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_Create_Gauge Device_page");
				log.error("Error occured - Not able to Navigate to Create Conditions Page for "
						+ BasePage.currentMethodName);
			}

		} // end of if
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Navigate and verify Create Checklist Requirment page.
	// Author: Harshita Shaktawat
	public static ChecklistRequirementPage navigateToAndVerifyCreateChecklistRequirementPage(String checklistName)
			throws Exception {
		try {

			checklistLandingPage = new ChecklistLandingPage();
			if (BasePage.isBrowserClosed() || !checklistLandingPage.checkCheckListLandingPageIsDisplayed())
				checklistLandingPage = navigateToChecklistLandingPage();

			checklistRequirementPage = checklistLandingPage.navigateToChecklistRequirementPage(checklistName);

			// Verify whether Checklist Requirement page displayed
			// or not
			UtilityFunctions.applicationWait(2000);
			TestLibrary.verifyChecklistRequirementPageIsDisplayed(checklistRequirementPage);

		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}

		return checklistRequirementPage;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Verify that Checklist Requirement page is displayed
	// Author :Harshita Shaktawat
	public static void verifyChecklistRequirementPageIsDisplayed(ChecklistRequirementPage checklistRequirementPage)
			throws Exception {

		if (!checklistRequirementPage.checkChecklistRequirementPageIsDisplayed()) {

			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Checklist Requirement page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Checklist Requirement page");

			} catch (Exception e) {
				throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
			}
		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Navigate and verify to Edit Checklist Requirment page.
	// Author: Harshita Shaktawat
	public static ChecklistRequirementPage navigateAndVerifyEditChecklistRequirementPage(
			String checklistRequirementName) throws Exception {

		try {

			if (BasePage.isBrowserClosed() || !checklistLandingPage.checkCheckListLandingPageIsDisplayed())
				checklistLandingPage = navigateToChecklistLandingPage();

			checklistRequirementPage = checklistLandingPage
					.navigateToEditChecklistRequirementpage(checklistRequirementName);

			// Verify whether DataCollection Requirement page displayed
			// or not
			UtilityFunctions.applicationWait(2000);
			TestLibrary.verifyEditChecklistRequirementPageIsDisplayed(checklistRequirementName);

		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}

		return checklistRequirementPage;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Verify that Checklist Requirement page is displayed
	// Author :Harshita Shaktawat
	public static void verifyEditChecklistRequirementPageIsDisplayed(String checklistRequirementName) throws Exception {

		if (!checklistRequirementPage.checkEditChecklistRequirementPageIsDisplayed(checklistRequirementName)) {

			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Checklist Requirement page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Checklist Requirement page");

			} catch (Exception e) {
				throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
			}
		}
	}

	// ------------------------------------------------------------------------------------------------------------------------

	// this method assert for soft deletion
	// Author : Rakesh Sharma
	public static void assertForSoftDeletion(String entity) {
		// In case of any error message. Fail the test case
		try {
			Assert.assertEquals(entity + " is not soft deleted", entity + " should be soft deleted");
		} catch (Throwable t) {
			TestLibrary.reportErrorAndtakeScreenshot(t, "Soft_Deletion_issue");
			return;
		} // End of catch
	}

	// ---------------------------------------------------------------------------------------------------------------------
	// Assertion for Pop Up when update entity and Save record
	// Author: Rakesh sharma
	public static void assertForSaveConfirmationPopUpDetails(Hashtable<String, String> result) throws Exception {
		String expectedConfirmationMessage = "", actualConfirmationMessage = "";
		String actualSaveConfirmationPopupTitle = "", expectedSaveConfirmationPopupTitle = "";
		try {

			if (result.containsKey("PopUpPresent")) {
				// check ok button present
				if (result.get("PopUpPresent").equals("No")) {
					try {
						Assert.assertEquals("Pop up is not displayed", "Pop Up should be displayed");
					} catch (Throwable t) {
						TestLibrary.reportErrorAndtakeScreenshot(t, "PopUp_Not_Displayed");
					} // End of catch
				}
			}

			if (result.containsKey("expectedConfirmationMessage")) {
				expectedConfirmationMessage = result.get("expectedConfirmationMessage");
			}

			if (result.containsKey("expectedPopUpTitle")) {
				expectedSaveConfirmationPopupTitle = result.get("expectedPopUpTitle");
			}

			// check confirmation displayed
			if (result.containsKey("Confirmation Message Displayed")) {
				try {
					Assert.assertEquals(ConstantsUtility.errNoConfirmationMessageDispalyedOnDeletingRecord,
							ConstantsUtility.msgConfirmationMessageShouldBeDisplayed);
				} catch (Throwable t) {
					TestLibrary.reportErrorAndtakeScreenshot(t,
							"No_Confirmation_Message_Is_Displayed_On_Deleting_A_Record");
					return;
				} // End of catch
			}

			// check confirmation cross [X] button is present
			if (result.containsKey("Pop Up Close Button Present")) {
				try {
					Assert.assertEquals(ConstantsUtility.errValidationMessageCrossIconIsNotPresent,
							ConstantsUtility.msgValidationMessageCrossIconIsNotPresent);
				} catch (Throwable t) {
					TestLibrary.reportErrorAndtakeScreenshot(t,
							"No_Cross[X]_Button_Is_Present_On_Confirmation_Message_Displayed_On_Deleting_A_Record");

				} // End of catch
			}

			// verify all accordians
			if (result.containsKey("ExpectedTotalAccordionItem")) {

				for (int i = 2; i <= Integer.parseInt(result.get("ExpectedTotalAccordionItem")); i++) {
					if (result.containsKey("ExpectedAccordionItem" + i)) {
						if (!result.get("ExpectedAccordionItem" + i).equals(result.get("ActualAccordionItem" + i))) {
							try {
								Assert.assertEquals("According message not correct for " + i,
										"According message should be correct for " + i);
							} catch (Throwable t) {
								TestLibrary.reportErrorAndtakeScreenshot(t, "Accordian item not correct");
							} // End of catch
						}
					}

					for (int j = 1; j < 20; j++) {
						if (result.containsKey("ExpectedAccordionMessage" + i + "_" + j)
								|| result.containsKey("ActualAccordionMessage" + i + "_" + j)) {

							if (!result.containsKey("ExpectedAccordionMessage" + i + "_" + j)
									|| !result.containsKey("ActualAccordionMessage" + i + "_" + j)) {
								try {
									Assert.assertEquals(
											"Entry not found for expected or actual in result file for " + i + "_" + j,
											"Entry should be present for expected or actual in result file for  " + i
													+ "_" + j);
								} catch (Throwable t) {
									TestLibrary.reportErrorAndtakeScreenshot(t, "Entry_NotPresent_In_ResultFile");
								} // End of catch
							}

							if (!result.get("ExpectedAccordionMessage" + i + "_" + j)
									.equals(result.get("ActualAccordionMessage" + i + "_" + j))) {
								try {
									Assert.assertEquals("According message not correct for " + i + "_" + j,
											"According message should be correct for " + i + "_" + j);
								} catch (Throwable t) {
									TestLibrary.reportErrorAndtakeScreenshot(t, "Accordian Message not correct");
								} // End of catch
							}
						}
						j++;
					}

					i++;
				}
			}
			// get actual Confirmation message
			if (result.containsKey("Confirmation Message")) {
				actualConfirmationMessage = result.get("Confirmation Message");

				if (!expectedConfirmationMessage.equals(actualConfirmationMessage)) {
					try {
						Assert.assertEquals(
								ConstantsUtility.errConfirmationMessageDispalyedOnDeletingRecordIsNotCorrect,
								ConstantsUtility.msgCorrectConfirmationMessageShouldBeDisplayed);
					} catch (Throwable t) {
						TestLibrary.reportErrorAndtakeScreenshot(t,
								"Correct_Confirmation_Message_Is_Not_Displayed_On_Deleting_A_Record");
					} // End of catch
				}
			}

			// get actual popup title
			if (result.containsKey("ActualPopupTitle")) {
				actualSaveConfirmationPopupTitle = result.get("ActualPopupTitle");
				if (!expectedSaveConfirmationPopupTitle.equals(actualSaveConfirmationPopupTitle)) {
					try {
						Assert.assertEquals("Delete popup title is not correct.",
								"Delete popup title should be correct.");
					} catch (Throwable t) {
						TestLibrary.reportErrorAndtakeScreenshot(t, "Delete_Popup_Title_Is_Not_Correct");
					} // End of catch
				}
			}

			// check accordion body by default collapsed
			if (result.containsKey("Collapsed_By Default")) {
				try {
					Assert.assertEquals("Accordion Item body is not Collapsed By default",
							"Accordion Item body should be Collapsed By default");
				} catch (Throwable t) {
					TestLibrary.reportErrorAndtakeScreenshot(t, "Accordion_Item_Body_Is_Not_Collapsed_By_Default");
				} // End of catch
			}

			// check on clicking expandcollapse button body is expaned (when
			// collapsed)if data count is less than 21

			if (result.containsKey("Expanded")) {
				try {
					Assert.assertEquals("Accordion Item body is not Expanded on clicking ExpandCollapse Button",
							"Accordion Item body should be Expanded on clicking ExpandCollapse Button");
				} catch (Throwable t) {
					TestLibrary.reportErrorAndtakeScreenshot(t,
							"Accordion_Item_Body_Is_Not_Expanded_On_Clicking_ExpandCollapse_Button");
				} // End of catch
			}

			// check on clicking expandcollapse button body is collapsed (when
			// expaned)

			if (result.containsKey("Collapsed")) {
				try {
					Assert.assertEquals("Accordion Item body is not Collapsed on clicking ExpandCollapse Button",
							"Accordion Item body should be Collapsed on clicking ExpandCollapse Button");
				} catch (Throwable t) {
					TestLibrary.reportErrorAndtakeScreenshot(t,
							"Accordion_Item_Body_Is_Not_Collapsed_On_Clicking_ExpandCollapse_Button");
				} // End of catch
			}

			if (result.containsKey("OK_Button_Present")) {
				// check ok button present
				if (result.get("OK_Button_Present").equals(String.valueOf(false))) {
					try {
						Assert.assertEquals("Ok button is not present", "Ok button should be present");
					} catch (Throwable t) {
						TestLibrary.reportErrorAndtakeScreenshot(t, "OK_Button_Is_Not_Present");
					} // End of catch
				}
			}
			if (result.containsKey("Cancel_Button_Present")) {
				// check cancel button present
				if (result.get("Cancel_Button_Present").equals(String.valueOf(false))) {
					try {
						Assert.assertEquals("Cancel button is not present", "Cancel button should be present");
					} catch (Throwable t) {
						TestLibrary.reportErrorAndtakeScreenshot(t, "Cancel_Button_Is_Not_Present");
					} // End of catch
				}
			}

			// check cross button present
			if (result.containsKey("Cross_Button_Present"))
				if (result.get("Cross_Button_Present").equals(String.valueOf(false))) {
					try {
						Assert.assertEquals("Cross button is not present", "Cross button should be present");
					} catch (Throwable t) {
						TestLibrary.reportErrorAndtakeScreenshot(t, "Cross_Button_Is_Not_Present");
					} // End of catch
				}

			// check default Focus on Cancelcbutton
			if (result.containsKey("DefaultFocusOnCancel")) {
				try {
					Assert.assertEquals("Default focus is not on cancel button",
							"Default focus should be on cancel button");
				} catch (Throwable t) {
					TestLibrary.reportErrorAndtakeScreenshot(t, "Default_Focus_Is_Not_On_Cancel_Button");
				} // End of catch
			}
		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// Navigate the user to create Notification rule page
	// Author Name: Rakesh Kumar Sharma
	public static CreateNotificationRulesPage navigateToCreateNotificationRulesPageForStaticSharedSteps()
			throws Exception {
		try {
			if (!BasePage.isBrowserClosed()) {

				if (!LibraryFunctions.isElementDisplayed(NotificationRulesPage.xPath_lblPageTitle, 3)) {
					// Click on Cancel button
					BasePage.pageHeaderNavigation.clickOnCancelButton();

					if (LibraryFunctions.isElementDisplayed(NotificationRulesPage.xPath_lblPageTitle, 3)
							&& BasePage.driver.findElement(By.xpath(NotificationRulesPage.xPath_lblPageTitle)).getText()
									.equals(NotificationRulesPage.createNotificationRulesPage_PageTitle))

						return new CreateNotificationRulesPage();
					else {
						createNotificationRulesPage = TestLibrary.navigateToCreateNotificationRulesPage();
					}

				} else if (LibraryFunctions.isElementDisplayed(NotificationRulesPage.xPath_lblPageTitle, 3)
						&& BasePage.driver.findElement(By.xpath(NotificationRulesPage.xPath_lblPageTitle)).getText()
								.equals(NotificationRulesPage.createNotificationRulesPage_PageTitle))

					return new CreateNotificationRulesPage();
				else {
					createNotificationRulesPage = TestLibrary.navigateToCreateNotificationRulesPage();
				}
			} else
				createNotificationRulesPage = TestLibrary.navigateToCreateNotificationRulesPage();

			// Verify Create NotificationRules Page
			TestLibrary.verifyCreateNotificationRulesPageIsDisplayed(createNotificationRulesPage);
			return createNotificationRulesPage;
		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// Assert in case of error in shared steps.
	// Author: Rakesh Sharma
	public static void assertForSharedStep(String sharedStepId, String issueList) {

		System.out.println("Issue in " + sharedStepId + " : " + issueList);

		try {
			Assert.assertEquals("Error in Shared Step id : " + sharedStepId + " :-issues are " + issueList,
					" Shared step should work as expected ");
		} catch (Throwable t) {
			TestLibrary.reportErrorAndtakeScreenshot(t, "SharedStep" + sharedStepId);

		} // End of catch
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Peform Purge Activity
	// Author : Yogendra Rathore
	// Modified By : Yogendra Rathore <29-08-2017>
	// Action : added finally block.
	// Modified by :Yogendra < 25-09-2018>
	// modified the funtioanlity.
	// modified by: Rakesh Sharma on 01-05-2019
	// removed throwing exception
	public static boolean performPurgeActivity() throws Exception {
		boolean purgeCompletedSuccessfully = false;
		try {

			// navigate to global config purge tab
			dataPurgePage = navigateToDataPurgePage();

			purgeCompletedSuccessfully = dataPurgePage.performPurgeActivityAndVerifyPurgingIsCompleted();

		} catch (Exception e) {

			e.printStackTrace();

		} finally {
			LibraryFunctions.closeBrowser();
		}
		return purgeCompletedSuccessfully;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Verify that Appearance page is displayed
	// Modified By : Rakesh Kumar Sharma
	// Changed Assert statement
	public static void verifyAppearancePageIsDisplayed(AppearancePage appearancePage) throws Exception {
		if (!appearancePage.checkAppearancePageIsDisplayed()) {
			try {
				Assert.assertEquals("System did not navigate to Dashboard page",
						"System should navigate to Dashboard Page");
			} catch (Throwable t) {

				reportErrorAndtakeScreenshot(t, "Appearance_Page_not_displayed");

			}
		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Verify that Navigation to ProcessModel landing page
	// Author :Yogendra rathore
	public static ProcessModelLandingPage navigateToProcessModelLandingPage() throws Exception {

		try {
			TestLibrary.loginIfNotLoggedInAndVerifyUserIsLoggedIn();

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

			processModelLandingPage = BasePage.pageHeaderNavigation.navigateToProcessModelLandingPage();

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

			// Verify whether processModelLandingPage displayed
			// or not
			TestLibrary.verifyProcessModelLandingPageIsDisplayed(processModelLandingPage);

		} catch (Exception e) {

			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}

		return processModelLandingPage;

	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Verify that processModelLandingPageis displayed
	// Author :Yogendra Rathore
	public static void verifyProcessModelLandingPageIsDisplayed(ProcessModelLandingPage processModelLandingPage)
			throws Exception {
		if (!processModelLandingPage.checkProcessModelLandingPageisDisplayed()) {

			try {
				Assert.assertEquals(" Process Model Landing Page is not dispolayed",
						"Process Model Landing Page should display");
			} catch (Exception t) {
				TestLibrary.reportErrorAndtakeScreenshot(t, "ProcessModel_Landing_Page_Did_not_Display");
				throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), t));
			}
		}
	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to edit feature page on basis of removed
	// feature name
	// and
	// return editFeaturePage
	// object.
	// Author: Yogendra Rathore
	public static EditFeaturePage navigateToEditFeaturePageForRemovedRecord(String featureName) throws Exception {
		try {
			if (!BasePage.isBrowserClosed() && UtilityFunctions.getMultilingualData("Feature_Header_Title")
					.equalsIgnoreCase(LibraryFunctions.getPageName())) {
				// Click on Back button
				BasePage.pageHeaderNavigation.clickOnCancelButton();
				featureLandingPage = new FeatureLandingPage();
				// Verify Feature Landing Page
				TestLibrary.verifyFeatureLandingPageIsDisplayed(featureLandingPage);
			} else {

				// If Browser is not open then Open browser and if User in not
				// Logged In then Login
				TestLibrary.loginIfNotLoggedInAndVerifyUserIsLoggedIn();
				// Navigate to Feature Landing Page
				featureLandingPage = BasePage.pageHeaderNavigation.navigateToFeatureLandingPage();

				// Check To handle Confirmation Message - If appears
				LibraryFunctions.handlingConfirmationBoxMessage("ok");

				// Verify Feature Landing Page
				TestLibrary.verifyFeatureLandingPageIsDisplayed(featureLandingPage);
			}

			// navigate to specific edit feature page
			Hashtable<String, String> testData = new Hashtable<String, String>();
			testData.put(FeaturePage.filter_FeatureName, featureName);
			testData.put(FeaturePage.filter_FeatureShowRemovedRecords, "Active");
			String filterResult = featureLandingPage.applyFilter(testData);

			if (filterResult == null) {
				throw new Exception("no removed record found for " + featureName);
			} // click on 1st edit icon

			editFeaturePage = featureLandingPage.navigateToEditFeaturePageForRemovedRecord(featureName);

			// Verify edit feature Page
			TestLibrary.verifyEditFeaturePageIsDisplayed(editFeaturePage, featureName);

			return editFeaturePage;
		} catch (Exception t) {
			TestLibrary.reportErrorAndtakeScreenshot(t, "Feature_Landing_Page_Did_not_Display");
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), t));
		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Verify Workdashboard page is displayed
	// Author : Harshita Shaktawat
	public static void verifyWorkDashboardPageIsDisplayed(DashboardPage dashboardPage) throws Exception {
		// check in progress text and wait till 15 secs if Inprogress is
		// displayed.
		UtilityFunctions.applicationWait(2000);
		int index = 0;
		while ((LibraryFunctions.isElementPresent(BasePage.xPath_InProgressImage, 1)
				|| LibraryFunctions.isElementPresent(BasePage.xPath_InProgressText, 1)) && index < 15) {
			UtilityFunctions.applicationWait(1000);
			index++;

		}
		if (!dashboardPage
				.checkSpecificDashboardPageIsDisplayed(UtilityFunctions.getMultilingualData("lblWorkDashboard"))) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Work Dashboard Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Work Dashboard Page");
			} catch (Exception e) {
				reportErrorAndtakeScreenshot(e, "Not_Able_to_navigate_to_Work Dashboard Page");
				throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));

			}
		} // end of if
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// navigate To Edit SubGroup Page From Data
	// Author Name - HArshita Shaktawat
	public static Object navigateToEditSubGroupPageFromData(int rowNumber, int finishedItemTileIndexNumber)
			throws Exception {

		try {

			UtilityFunctions.applicationWait(1000);

			dashboardPage = TestLibrary.navigateToDashboardPage();

			TestLibrary.verifyWorkDashboardPageIsDisplayed(dashboardPage);

			dashboardPage.naviagteToDataTableOnFinishedItemTileByClickingOnGivenIndex(finishedItemTileIndexNumber);

			editSubGroupPage = dashboardPage.navigateToEditSubGroupPageFromDataTableOfFinishedItemTile(rowNumber);

			TestLibrary.verifyEditSubGroupPageIsDisplayed(editSubGroupPage);
			return editSubGroupPage;

		} catch (Exception e) {
			log.error("Error occured - Not able to Navigate to Edit SubGroup Page for " + BasePage.currentMethodName);
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}

	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check Edit SubGroup Page is displayed
	public static void verifyEditSubGroupPageIsDisplayed(EditSubGroupPage editSubGroupPage) throws Exception {
		// Verify Manual DC DataEntry page or enter sample time pop up is
		// displayed.

		if (!editSubGroupPage.checkEditSubGroupPageIsDisplayed()) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Edit SubGroup Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Edit SubGroup Page");
				return;
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_EditSubGroup_page");
				log.error(
						"Error occured - Not able to Navigate to Edit SubGroup Page for " + BasePage.currentMethodName);
				throw t;
			}

		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Assert if element is disabled
	// Author: Harshita Shaktawat
	public static void assertWhenElementIsDisabled(String elementName) {

		try {
			Assert.assertEquals(elementName + " is disabled", elementName + " should be enabled");
		} catch (Throwable t) {
			TestLibrary.reportErrorAndtakeScreenshot(t, "ElementIsDisabled");

		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// navigate to edit gauge device page
	// - Rakesh
	public static EditGaugeDevicePage navigateToEditGaugeDevicePage(String gaugeDeviceName) throws Exception {

		if (!BasePage.isBrowserClosed()
				&& UtilityFunctions.getMultilingualData("Gauge_Devices")
						.equalsIgnoreCase(LibraryFunctions.getPageName())
				&& UtilityFunctions.getMultilingualData("BackButton")
						.equalsIgnoreCase(BasePage.pageHeaderNavigation.getLabelOfBackButtonDataSelctor())) {
			// Click on Back button
			BasePage.pageHeaderNavigation.clickOnCancelButton();
			gaugeDevicesLandingPage = new GaugeDevicesLandingPage();
			// Verify interface landing page
			TestLibrary.verifyGaugeDeviceLandingPageIsDisplayed(gaugeDevicesLandingPage);
		} else {

			gaugeDevicesLandingPage = navigateToGaugeDevicesLandingPage();
		}

		// Navigate to edit User Page
		Hashtable<String, String> testCaseData = new Hashtable<String, String>();
		testCaseData.put(GaugeDevicesLandingPage.filter_Gauge_Device_Name, gaugeDeviceName);
		editGaugeDevicePage = gaugeDevicesLandingPage.navigateToEditGaugeDevicePage(testCaseData);

		// Verify Edit User Page
		TestLibrary.verifyEditGaugeDevicePageIsDisplayed(editGaugeDevicePage, gaugeDeviceName);

		return editGaugeDevicePage;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// navigate to edit gauge device page
	// - Rakesh
	public static void verifyEditGaugeDevicePageIsDisplayed(EditGaugeDevicePage editGaugeDevicePage,
			String gaugeDeviceName) throws Exception {
		// check in progress text and wait till 15 secs if Inprogress is
		// displayed.
		UtilityFunctions.applicationWait(2000);
		int index = 0;
		while ((LibraryFunctions.isElementPresent(BasePage.xPath_InProgressImage, 1)
				|| LibraryFunctions.isElementPresent(BasePage.xPath_InProgressText, 1)) && index < 15) {
			UtilityFunctions.applicationWait(1000);
			index++;

		}
		// Verify Edit gauge device Page is displayed
		if (!editGaugeDevicePage.checkEditGaugeDevicePageIsDisplayedForGaugeDevice(gaugeDeviceName)) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " EditGaugeDevice Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " EditGaugeDevice Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_To_Navigate_To_EditGaugeDevice_Page");
				log.error("Error occured - Not able to Navigate to EdEditGaugeDevice page for "
						+ BasePage.currentMethodName);
				throw new Exception();
			}
		} // end of if
	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to language label feature page on basis of
	// feature name
	// and
	// return featureLanguageLabelPage object
	// object.
	// Author:Yogendra Rathore
	public static FeatureLanguageLabelPage navigateToFeatureLanguageLabelPage(String featureName) throws Exception {
		if (!BasePage.isBrowserClosed() && UtilityFunctions.getMultilingualData("Feature_Header_Title")
				.equalsIgnoreCase(LibraryFunctions.getPageName())) {
			// Click on Back button
			BasePage.pageHeaderNavigation.clickOnCancelButton();
			featureLandingPage = new FeatureLandingPage();
			// Verify Feature Landing Page
			TestLibrary.verifyFeatureLandingPageIsDisplayed(featureLandingPage);
		} else {

			featureLandingPage = navigateToFeatureLandingPage();
		}

		// navigate to specific edit feature page
		Hashtable<String, String> testCaseData = new Hashtable<String, String>();
		testCaseData.put(FeaturePage.filter_FeatureName, featureName);
		featureLanguageLabelPage = featureLandingPage.navigateToFeatureLanguageLabelPage(testCaseData);

		// Verify Page
		TestLibrary.verifyLanguageLabelPageIsDisplayed(featureLanguageLabelPage,
				UtilityFunctions.getMultilingualData("Feature_Header_Title"), featureName);

		return featureLanguageLabelPage;
	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to language label Process page on basis of
	// Process name
	// and
	// return ProcessLanguageLabelPage object
	// object.
	// Author:Yogendra Rathore
	public static ProcessLanguageLabelPage navigateToProcessLanguageLabelPage(String processName) throws Exception {
		if (!BasePage.isBrowserClosed() && UtilityFunctions.getMultilingualData("Process_Header_Title")
				.equalsIgnoreCase(LibraryFunctions.getPageName())) {
			// Click on Back button
			BasePage.pageHeaderNavigation.clickOnCancelButton();
			processLandingPage = new ProcessLandingPage();
			// Verify ProcessLanding page
			TestLibrary.verifyProcessLandingPageIsDisplayed(processLandingPage);
		} else {

			processLandingPage = navigateToProcessLandingPage();
		}

		// navigate to specific edit Process page
		Hashtable<String, String> testCaseData = new Hashtable<String, String>();
		testCaseData.put(ProcessPage.filter_ProcessName, processName);

		processLanguageLabelPage = processLandingPage.navigateToProcessLanguageLabelPage(testCaseData);
		// Verify Page
		TestLibrary.verifyLanguageLabelPageIsDisplayed(processLanguageLabelPage,
				UtilityFunctions.getMultilingualData("Process_Header_Title"), processName);

		return processLanguageLabelPage;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check Language label page is displayed
	// Author :Yogendra Rathore
	public static void verifyLanguageLabelPageIsDisplayed(LanguageLabelPage languageLabelPage, String headerTitle,
			String pageTitle) throws Exception {
		// Verify page isdisplayed
		if (!languageLabelPage.checkLanguageLabelPageIsDisplayed(headerTitle, pageTitle))

		{
			try {
				Assert.assertEquals(
						ConstantsUtility.errApplicationPageNotDisplayed + " languageLabelPage for " + pageTitle,
						ConstantsUtility.msgApplicationPageShouldDisplay + " languageLabel Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_languageLabelPage_page");
				throw new Exception("Not_Able_to_navigate_to_languageLabelPage_page_for_" + pageTitle);
			}

		}
	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to edit gauge format page on basis of gauge
	// format name
	// and
	// return editGaugeFormatPage
	// object.
	// Author: Rakesh sharma
	// Modified by :Neha Goyal <25-10-2018>
	// Updated FromCreateGaugeDevicePage
	// Gauge Format, Gauge Agent and Gauge Interface Connection should be
	// created before
	// calling this method

	public static EditGaugeFormatPage navigateToEditGaugeFormatPage(String navigationMethod, String gaugeFormatName)
			throws Exception {
		if (navigationMethod.equals("FromGaugeFormatLandingPage")) {
			if (!BasePage.isBrowserClosed()
					&& UtilityFunctions.getMultilingualData("Gauge_Formats")
							.equalsIgnoreCase(LibraryFunctions.getPageName())
					&& UtilityFunctions.getMultilingualData("BackButton")
							.equalsIgnoreCase(BasePage.pageHeaderNavigation.getLabelOfBackButtonDataSelctor())) {
				// Click on Back button
				BasePage.pageHeaderNavigation.clickOnCancelButton();
				UtilityFunctions.applicationWait(4000);
				gaugeFormatsLandingPage = new GaugeFormatsLandingPage();
				// Verify gauge formatslanding page
				TestLibrary.verifyGaugeFormatsLandingPageIsDisplayed(gaugeFormatsLandingPage);
			} else {

				navigateToGaugeFormatsLandingPage();
			}
			// navigate to specific edit feature page
			Hashtable<String, String> testCaseData = new Hashtable<String, String>();
			testCaseData.put(GaugeFormatsLandingPage.filter_Gauge_Format_Name, gaugeFormatName);
			editGaugeFormatPage = gaugeFormatsLandingPage.navigateToEditGaugeFormatPage(testCaseData);
		} else if (navigationMethod.equals("FromCreateGaugeDevicePage")) {
			createGaugeDevicePage = navigateToCreateGaugeDevicePage();
			// TODO Need to do for user specific Agent name and InterfaceName
			String gaugeInterfaceName = "FA_" + BasePage.currentMethodName + "_Interface";
			String gaugeAgentName = "FA_" + BasePage.currentMethodName + "_Agent";
			gaugeFormatName = "FA_" + BasePage.currentMethodName + "_Format";

			Hashtable<String, String> testData = new Hashtable<String, String>();
			;
			testData.put(CreateGaugeDevicePage.field_Agent, gaugeAgentName);
			testData.put(CreateGaugeDevicePage.field_Gauge_Interface, gaugeInterfaceName);
			testData.put(CreateGaugeDevicePage.field_Gauge_Format, gaugeFormatName);

			createGaugeDevicePage.inputValueInFields(testData);

			editGaugeFormatPage = createGaugeDevicePage.clickOnEditGaugeFormatButton();

		} else {
			throw new Exception("Navigation Method not correct");
		}
		// Verify edit gaugeFormats Page
		TestLibrary.verifyEditGaugeFormatsPageIsDisplayed(editGaugeFormatPage, gaugeFormatName);

		return editGaugeFormatPage;
	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method navigates verifies edit gauge format page on basis of gauge
	// format name
	// Author: Rakesh sharma
	public static void verifyEditGaugeFormatsPageIsDisplayed(EditGaugeFormatPage editGaugeFormatPage,
			String gaugeFormatName) throws Exception {
		// Verify page isdisplayed
		if (!editGaugeFormatPage.checkEditGaugeFormatPageIsDisplayed(gaugeFormatName)) {
			try {
				Assert.assertEquals(
						ConstantsUtility.errApplicationPageNotDisplayed + " EditGaugeFormatPage for " + gaugeFormatName,
						ConstantsUtility.msgApplicationPageShouldDisplay + " EditGaugeFormatPage Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_EditGaugeFormatPage");
				return;
			}

		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to ManageSettings page and return object of
	// ManageSettings Page
	// Author :Yogendra rathore
	public static MyProcessesAssignResponsibilityPopUp navigateToMyProcessesAssignResponsibilityPopUp()
			throws Exception {

		try {

			loginIfNotLoggedInAndVerifyUserIsLoggedIn();

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");
			BasePage.pageHeaderNavigation.clickOnCancelButton();

			myProcessesAssignResponsibilityPopUp = BasePage.pageHeaderNavigation
					.openProcessHierarchyAssignResponsibilityPopUp();

			// Verify Manage Settings page
			verifyMyProcessesAssignResponsibilityPopUpIsDisplayed(myProcessesAssignResponsibilityPopUp);

			return myProcessesAssignResponsibilityPopUp;

		} catch (Exception e) {
			throw new Exception("Error in navigating to ManageSettings Page :" + e);
		}

	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// verifyMyProcessesAssignResponsibilityPopUp Is Displayed
	// Author : Yogendra Rathore
	public static void verifyMyProcessesAssignResponsibilityPopUpIsDisplayed(
			MyProcessesAssignResponsibilityPopUp myProcessesAssignResponsibilityPopUp) throws Exception {
		// Verify
		if (!myProcessesAssignResponsibilityPopUp.checkMyProcessesAssignResponsibilityPopUpIsDisplayed()) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " My Process PopUp",
						ConstantsUtility.msgApplicationPageShouldDisplay + " My Process PopUp");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_My_Process_PopUp");
				log.error("Error occured - Not able to Navigate to My Process PopUp for " + BasePage.currentMethodName);

			}
		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------

	// Verify create part recipe page is displayed
	// Author : Yogendra Rathore
	public static void verifyCreatePartRecipePageIsDisplayed(CreatePartRecipePage createPartRecipePage,
			String operationDiagramId) throws Exception {

		// Verify Page is displayed
		if (!createPartRecipePage.checkCreatePartRecipePageIsDisplayed(operationDiagramId)) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " create part recipe page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " create part recipe page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_To_Navigate_To_create_part_recipe_page");

				throw new Exception();
			}
		} // end of if
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------

	// Verify create part recipe page is displayed
	// Author : Yogendra Rathore
	public static void verifyEditPartRecipePageIsDisplayed(EditPartRecipePage editPartRecipePage) throws Exception {

		// Verify Page is displayed
		if (!editPartRecipePage.checkEditPartRecipePageIsDisplayed()) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " edit part recipe page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " edit part recipe page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_To_Navigate_To_edit_part_recipe_page");

				throw new Exception();
			}
		} // end of if
	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to create production assignment page
	// Author: Yogendra Rathore
	public static CreateProductionAssignmentsPage navigateToCreateProductionAssighmentPage() throws Exception {
		try {
			if (!BasePage.isBrowserClosed() && UtilityFunctions.getMultilingualData("Production_Assignments")
					.equalsIgnoreCase(LibraryFunctions.getPageName())) {
				// Click on Back button
				BasePage.pageHeaderNavigation.clickOnCancelButton();
				DashboardPage dashboardpage = new DashboardPage();
				if (!dashboardpage.checkDashboardPageIsDisplayed()) {
					productionAssignmentsLandingPage = new ProductionAssignmentsLandingPage();
					// Verify Production assighment landing page
					TestLibrary.verifyProductionAssignmentsLandingPageIsDisplayed(productionAssignmentsLandingPage);
				} else {
					productionAssignmentsLandingPage = navigateToProductionAssignmentsLandingPage();
				}
			} else {

				productionAssignmentsLandingPage = navigateToProductionAssignmentsLandingPage();
			}

			// navigate to create page
			createProductionAssignmentsPage = productionAssignmentsLandingPage
					.navigateToCreateProductionAssignmentPage();

			// Verify create Page
			TestLibrary.verifyCreateProductionAssignmentsPageIsDisplayed(createProductionAssignmentsPage);
		} catch (Exception e) {

			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
		return createProductionAssignmentsPage;
	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to production assignment landing page
	// Author: Yogendra Rathore
	public static ProductionAssignmentsLandingPage navigateToProductionAssignmentsLandingPage() throws Exception {

		try { // If Browser is not open then Open browser and if User in not
				// Logged In then Login
			TestLibrary.loginIfNotLoggedInAndVerifyUserIsLoggedIn();
			// Navigate to Landing Page
			productionAssignmentsLandingPage = BasePage.pageHeaderNavigation
					.navigateToProductionAssignmentsLandingPage();

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

			// Verify Production assighment landing page
			TestLibrary.verifyProductionAssignmentsLandingPageIsDisplayed(productionAssignmentsLandingPage);
		} catch (Exception e) {

			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
		return new ProductionAssignmentsLandingPage();
	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to edit prodcution assignment page
	// Author: Yogendra rathore
	public static EditProductionAssignmentsPage navigateToEditProductionAssignmentPage(String processName)
			throws Exception {
		try {
			if (!BasePage.isBrowserClosed() && UtilityFunctions.getMultilingualData("Production_Assignments")
					.equalsIgnoreCase(LibraryFunctions.getPageName())) {
				System.out.println("yog 1"); // Click on Back button
				BasePage.pageHeaderNavigation.clickOnCancelButton();
				productionAssignmentsLandingPage = new ProductionAssignmentsLandingPage();
				// Verify Production assighment landing page
				TestLibrary.verifyProductionAssignmentsLandingPageIsDisplayed(productionAssignmentsLandingPage);
			} else {
				System.out.println("yog 11");
				productionAssignmentsLandingPage = navigateToProductionAssignmentsLandingPage();

			}
			System.out.println("yog 111");
			// navigate to edit page
			editProductionAssignmentsPage = productionAssignmentsLandingPage
					.navigateToEditProductionAssignmentPage(processName);
			System.out.println("yog 11111");
			// Verify edit page is displayed
			TestLibrary.verifyEditProductionAssignmentPageIsDisplayed(editProductionAssignmentsPage, processName);
			;
		} catch (Exception e) {

			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
		return editProductionAssignmentsPage;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check Process Landing Page display Production assignment Landing Page
	// Author:Yogendra Rathore
	public static void verifyProductionAssignmentsLandingPageIsDisplayed(
			ProductionAssignmentsLandingPage productionAssignmentsLandingPage) throws Exception {
		// Verify production assignmentLanding page
		if (!productionAssignmentsLandingPage.checkProductionAssignmentsLandingPageIsDisplayed()) {
			try {
				Assert.assertEquals(
						ConstantsUtility.errApplicationPageNotDisplayed + " ProductionAssignment Landing Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " ProductionAssignment  Landing Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_ ProductionAssignment_landing_page");
				return;

			}
		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Verify Create Production assignment page is displayed
	// Author :Yogendra Rathore
	public static void verifyCreateProductionAssignmentsPageIsDisplayed(
			CreateProductionAssignmentsPage createProductionAssignmentsPage) {
		// Verify Create prodcution assignment Page is displayed
		if (!createProductionAssignmentsPage.checkCreateProductionAssignmentPageIsDisplayed()) {
			try {
				Assert.assertEquals(
						ConstantsUtility.errApplicationPageNotDisplayed + " Create Production Assignment Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Create Production AssignmentPage");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_Create_Production_Assignment_page");

			}
		} // end of if
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Verify edit Production assignment page is displayed
	// Author :Yogendra Rathore
	public static void verifyEditProductionAssignmentPageIsDisplayed(
			EditProductionAssignmentsPage editProductionAssignmentsPage, String processName) throws Exception {
		// check in progress text and wait till 15 secs if Inprogress is
		// displayed.
		UtilityFunctions.applicationWait(2000);
		int index = 0;
		while ((LibraryFunctions.isElementPresent(BasePage.xPath_InProgressImage, 1)
				|| LibraryFunctions.isElementPresent(BasePage.xPath_InProgressText, 1)) && index < 15) {
			UtilityFunctions.applicationWait(1000);
			index++;

		}
		// Verify Edit Page is displayed
		if (!editProductionAssignmentsPage.checkEditProductionAssignmentPageIsDisplayed(processName)) {
			try {
				Assert.assertEquals(
						ConstantsUtility.errApplicationPageNotDisplayed + " Edit Production assignment Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Edit Production assignment Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_To_Navigate_To_Edit_Production_assignment_Page");

			}
		} // end of if
	}

	// --------------------------------------------------------------------------------------------
	// navigate and veriy Event codes page
	// Author :Yogendra Rathore
	public static EventCodePage navigateToEventCodePage() throws Exception {

		// If Browser is not open then Open browser and if User in not
		// Logged In then Login
		TestLibrary.loginIfNotLoggedInAndVerifyUserIsLoggedIn();
		eventCodePage = BasePage.pageHeaderNavigation.navigateToEventCodePage();

		// Check To handle Confirmation Message - If appears
		LibraryFunctions.handlingConfirmationBoxMessage("ok");

		// Verifypage
		TestLibrary.verifyEventCodePageIsDisplayed(eventCodePage);

		return eventCodePage;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check Event codes page is displayed.
	// Author :Yogendra Rathore
	public static void verifyEventCodePageIsDisplayed(EventCodePage eventCodePage) throws Exception {

		if (!eventCodePage.checkEventCodesPageIsDisplayed()) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Event code Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " event code Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_EventCode_page");

			}

		}
	}

	// --------------------------------------------------------------------------------------------
	// navigate and veriy configure Event codes type page
	// Author :Yogendra Rathore
	public static ConfigureCodeTypePage navigateToConfigureCodeTypePage() throws Exception {

		if (!BasePage.isBrowserClosed() && UtilityFunctions.getMultilingualData("Lbl_EventCodes")
				.equalsIgnoreCase(LibraryFunctions.getPageName())) {
			// Click on Back button
			BasePage.pageHeaderNavigation.clickOnCancelButton();

			eventCodePage = new EventCodePage();

			TestLibrary.verifyEventCodePageIsDisplayed(eventCodePage);
		} else {
			eventCodePage = TestLibrary.navigateToEventCodePage();
		}

		// Navigate to Configure code type page
		configureCodeTypePage = eventCodePage.navigateToConfigureCodeTypePage();

		verifyConfigureCodeTypePageIsDisplayed(configureCodeTypePage);

		return configureCodeTypePage;
	}

	// -------------------------------------------------------------------------------------------------------------------------------------
	// Verify Configure Event codes type page is displayed
	// Author :Yogendra Rathore
	public static void verifyConfigureCodeTypePageIsDisplayed(ConfigureCodeTypePage configureCodeTypePage)
			throws Exception {

		// Verify configureCodeTypePage is displayed
		if (!configureCodeTypePage.checkConfigureCodeTypePageIsDisplayed()) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " ConfigureCodeTypePage",
						ConstantsUtility.msgApplicationPageShouldDisplay + " configureCodeTypePage");
			} catch (Throwable t) {

				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_configureCodeTypePage");
			}

		} // end of if
	}

	// --------------------------------------------------------------------------------------------
	// navigate and veriy configure Event codes Language label page
	// Author :Yogendra Rathore
	public static EventCodeLanguageLabelPage navigateToEventCodeLanguagePage() throws Exception {

		if (!BasePage.isBrowserClosed() && UtilityFunctions.getMultilingualData("Lbl_EventCodes")
				.equalsIgnoreCase(LibraryFunctions.getPageName())) {
			// Click on Back button
			BasePage.pageHeaderNavigation.clickOnCancelButton();

			eventCodePage = new EventCodePage();

			TestLibrary.verifyEventCodePageIsDisplayed(eventCodePage);
		} else {
			eventCodePage = TestLibrary.navigateToEventCodePage();
		}

		// Navigate to event code lanugage label page
		eventCodeLanguageLabelPage = eventCodePage.navigateToEventCodeLanguageLabelPage();

		// Verify Page
		TestLibrary.verifyLanguageLabelPageIsDisplayed(eventCodeLanguageLabelPage,
				UtilityFunctions.getMultilingualData("Lbl_EventCodes"), "");

		return eventCodeLanguageLabelPage;
	}

	// --------------------------------------------------------------------------------------------
	// navigate and veriy configure Event codes type Language label page
	// Author :Yogendra Rathore
	public static EventCodeTypeLanguageLabelPage navigateToEventCodeTypeLanguagePage() throws Exception {

		configureCodeTypePage = navigateToConfigureCodeTypePage();

		// Navigate to event code lanugage label page
		eventCodeTypeLanguageLabelPage = configureCodeTypePage.navigateToEventCodeTypeLanguageLabelPage();

		// Verify Page
		TestLibrary.verifyLanguageLabelPageIsDisplayed(eventCodeTypeLanguageLabelPage,
				UtilityFunctions.getMultilingualData("Lbl_EventCodes"), "");

		return eventCodeTypeLanguageLabelPage;
	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to language label feature page on basis of
	// tag group name and
	// return tagGroupLanguageLabelPage object
	// Author:Rakesh Sharma
	public static TagGroupLanguageLabelPage navigateToTagGroupLanguageLabelPage(String tagGroupName) throws Exception {
		if (!BasePage.isBrowserClosed() && UtilityFunctions.getMultilingualData("TagGroup_Header_Title")
				.equalsIgnoreCase(LibraryFunctions.getPageName())) {
			// Click on Back button
			BasePage.pageHeaderNavigation.clickOnCancelButton();
			tagGroupLandingPage = new TagGroupLandingPage();
			// Verify Tag Group Landing Page
			TestLibrary.verifyTagGroupLandingPageIsDisplayed(tagGroupLandingPage);
		} else {

			tagGroupLandingPage = TestLibrary.navigateToTagGroupLandingPage();
		}

		// navigate to specific edit tag Group page
		Hashtable<String, String> testCaseData = new Hashtable<String, String>();
		testCaseData.put(TagGroupPage.filter_TagGroup_TagGroupName, tagGroupName);
		tagGroupLanguageLabelPage = tagGroupLandingPage.navigateToTagGroupLanguageLabelPage(testCaseData);

		// Verify Page
		TestLibrary.verifyLanguageLabelPageIsDisplayed(tagGroupLanguageLabelPage,
				UtilityFunctions.getMultilingualData("TagGroup_Header_Title"), tagGroupName);

		return tagGroupLanguageLabelPage;
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// Assert for shared step
	// Author: Rakesh Sharma
	public static void assertForSharedStep(String sharedStepNumber) {

		try {
			Assert.assertEquals("Issue In shared step : " + sharedStepNumber, "Shared Step should function Properly");
		} catch (Throwable t) {
			TestLibrary.reportErrorAndtakeScreenshot(t, "Issue_In_shared_step_" + sharedStepNumber);
		} // End of catch
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// navigate to change history page
	public static ChangeHistoryPage navigateToChangeHistoryPage() throws Exception {
		try {
			loginIfNotLoggedInAndVerifyUserIsLoggedIn();

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

			// Navigate to change history page
			changeHistoryPage = BasePage.pageHeaderNavigation.navigateToChangeHistoryPage();

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

			UtilityFunctions.applicationWait(1000);
			// Verify ShiftLanding page
			verifyChangeHistoryPageIsDisplayed(changeHistoryPage);

			return changeHistoryPage;
		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		} // End of catch

	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Verify that changeHistory page is displayed
	// Modified By : Rakesh Kumar Sharma
	public static void verifyChangeHistoryPageIsDisplayed(ChangeHistoryPage changeHistoryPage) throws Exception {
		// check in progress text and wait till 15 secs if Inprogress is
		// displayed.
		UtilityFunctions.applicationWait(2000);
		int index = 0;
		while ((LibraryFunctions.isElementPresent(BasePage.xPath_InProgressImage, 1)
				|| LibraryFunctions.isElementPresent(BasePage.xPath_InProgressText, 1)) && index < 15) {
			UtilityFunctions.applicationWait(1000);
			index++;

		}
		// Verify changeHistoryPage is displayed
		if (!changeHistoryPage.checkChangeHistoryPageIsDisplayed()) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " ChangeHistory Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " ChangeHistory Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_To_Navigate_To_ChangeHistory_Page");
				log.error(
						"Error occured - Not able to Navigate to ChangeHistory Page for " + BasePage.currentMethodName);
				throw new Exception();
			}
		} // end of if
	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to language label part page on basis of
	// part name and return partLanguageLabelPage object
	// Author:Rakesh Sharma
	public static PartLanguageLabelPage navigateToPartLanguageLabelPage(String partName) throws Exception {
		if (!BasePage.isBrowserClosed() && UtilityFunctions.getMultilingualData("Part_Header_Title")
				.equalsIgnoreCase(LibraryFunctions.getPageName())) {
			// Click on Back button
			BasePage.pageHeaderNavigation.clickOnCancelButton();
			partLandingPage = new PartLandingPage();
			// Verify Feature Landing Page
			TestLibrary.verifyPartLandingPageIsDisplayed(partLandingPage);
		} else {

			partLandingPage = navigateToPartLandingPage();
		}

		// navigate to specific edit part page
		Hashtable<String, String> testCaseData = new Hashtable<String, String>();
		testCaseData.put(PartPage.filter_PartName, partName);
		partLanguageLabelPage = partLandingPage.navigateToPartLanguageLabelPage(testCaseData);

		// Verify Page
		TestLibrary.verifyLanguageLabelPageIsDisplayed(partLanguageLabelPage,
				UtilityFunctions.getMultilingualData("Part_Header_Title"), partName);

		return partLanguageLabelPage;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Verify that ViewHistory page is displayed
	// Modified By : Rakesh Kumar Sharma
	public static void verifyViewHistoryPageIsDisplayed(ViewHistoryPage viewHistoryPage, String titleHeader)
			throws Exception {
		// check in progress text and wait till 15 secs if Inprogress is
		// displayed.
		UtilityFunctions.applicationWait(2000);
		int index = 0;
		while ((LibraryFunctions.isElementPresent(BasePage.xPath_InProgressImage, 1)
				|| LibraryFunctions.isElementPresent(BasePage.xPath_InProgressText, 1)) && index < 15) {
			UtilityFunctions.applicationWait(1000);
			index++;

		}
		// Verify changeHistoryPage is displayed
		if (!viewHistoryPage.checkViewHistoryPageIsDisplayed(titleHeader)) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " viewHistory Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " viewHistory Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_To_Navigate_To_ViewHistory_Page");
				log.error("Error occured - Not able to Navigate to ViewHistory Page for " + BasePage.currentMethodName);
				throw new Exception();
			}
		} // end of if
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check collectedDataPareto_Collections Page is displayed
	// Author : Rakesh Sharma
	public static void verifyCollectedDataParetoCollectionsPageIsDisplayed(
			CollectedDataPareto_CollectionsPage collectedDataPareto_CollectionsPage) throws Exception {
		// Verify Manual DC DataEntry page or enter sample time pop up is
		// displayed.

		if (!collectedDataPareto_CollectionsPage.checkCollectedDataParetoCollectionsPageIsDisplayed()) {
			try {
				Assert.assertEquals(
						ConstantsUtility.errApplicationPageNotDisplayed + " collectedDataPareto_CollectionsPage Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " collectedDataPareto_CollectionsPage Page");
				return;
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_collectedDataPareto_CollectionsPage_page");
				log.error("Error occured - Not able to Navigate to collectedDataPareto_CollectionsPage Page for "
						+ BasePage.currentMethodName);
				throw t;
			}

		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check CollectedDataPareto DataTable Page is displayed
	// Author : Rakesh Sharma
	public static void verifyCollectedDataParetoDataTablePageIsDisplayed(
			CollectedDataPareto_DataTablePage collectedDataPareto_DataTablePage) throws Exception {
		// Verify Manual DC DataEntry page or enter sample time pop up is
		// displayed.

		if (!collectedDataPareto_DataTablePage.checkCollectedDataParetoDataTablePageIsDisplayed()) {
			try {
				Assert.assertEquals(
						ConstantsUtility.errApplicationPageNotDisplayed + " CollectedDataPareto_DataTablePage Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " CollectedDataPareto_DataTablePage Page");
				return;
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_CollectedDataPareto_DataTablePage_page");
				log.error("Error occured - Not able to Navigate to CollectedDataPareto_DataTablePage Page for "
						+ BasePage.currentMethodName);
				throw t;
			}

		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// This method navigates to view history page
	// Author: Rakesh Sharma
	public static ViewHistoryPage navigateToViewHistoryPage(String moduleName, Hashtable<String, String> testDataFilter,
			String titleHeader) throws Exception {
		try {
			ArrayList<String> result = new ArrayList<String>();
			changeHistoryPage = TestLibrary.navigateToChangeHistoryPage();
			if (moduleName.equals("SpecLimit")) {
				specificationLimitChangeHistoryPage = (SpecificationLimitChangeHistoryPage) changeHistoryPage
						.navigateToIndividualHistoryPage("SpecLimit");
				result = specificationLimitChangeHistoryPage.applyAndVerifyFilter(testDataFilter);
				TestLibrary.assertForFilteredColumns(result);
				viewHistoryPage = specificationLimitChangeHistoryPage.clickOnEditButtonOnFirstRowOnChangeHistoryPage();
				TestLibrary.verifyViewHistoryPageIsDisplayed(viewHistoryPage, titleHeader);
			} else if (moduleName.equals("SubGroupData")) {
				subGroupChangeHistoryPage = (SubGroupChangeHistoryPage) changeHistoryPage
						.navigateToIndividualHistoryPage("SubGroupData");
				result = subGroupChangeHistoryPage.applyAndVerifyFilter(testDataFilter);
				TestLibrary.assertForFilteredColumns(result);
				viewHistoryPage = subGroupChangeHistoryPage.clickOnEditButtonOnFirstRowOnChangeHistoryPage();
				TestLibrary.verifyViewHistoryPageIsDisplayed(viewHistoryPage, titleHeader);
			}
			// TODO
			// if condition for other modules
			return viewHistoryPage;
		} catch (Throwable t) {
			reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_ViewHistory_page");
			log.error("Error occured - Not able to Navigate to ViewHistory Page for " + BasePage.currentMethodName);
			throw t;
		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Verify that CompareHistory page is displayed
	// Modified By : Rakesh Kumar Sharma
	public static void verifyCompareHistoryPageIsDisplayed(CompareHistoryPage compareHistoryPage) throws Exception {
		// check in progress text and wait till 15 secs if Inprogress is
		// displayed.
		UtilityFunctions.applicationWait(2000);
		int index = 0;
		while ((LibraryFunctions.isElementPresent(BasePage.xPath_InProgressImage, 1)
				|| LibraryFunctions.isElementPresent(BasePage.xPath_InProgressText, 1)) && index < 15) {
			UtilityFunctions.applicationWait(1000);
			index++;

		}
		// Verify changeHistoryPage is displayed
		if (!compareHistoryPage.checkCompareHistoryPageIsDisplayed()) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " compareHistory Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " compareHistory Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_To_Navigate_To_CompareHistory_Page");
				log.error("Error occured - Not able to Navigate to CompareHistory Page for "
						+ BasePage.currentMethodName);
				throw new Exception();
			}
		} // end of if
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// This method navigates to Compare history page
	// Author: Rakesh Sharma
	public static CompareHistoryPage navigateToCompareHistoryPage(String moduleName,
			Hashtable<String, String> testDataFilter, String titleHeader, int rowNum) throws Exception {
		try {
			viewHistoryPage = TestLibrary.navigateToViewHistoryPage(moduleName, testDataFilter, titleHeader);
			compareHistoryPage = viewHistoryPage.navigateToAndVerifyCompareHistoryPage(rowNum);
			return compareHistoryPage;

		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// --------------------------------------------------------------------------------------------------------------------
	// check no record found is displayed
	// Author: Rakesh Sharma
	public static void verifyNoRecrodFoundIsDisplayed(LandingPage landingPage) throws Exception {
		try {
			if (!landingPage.checkNoRecrodFoundIsDisplayed()) {
				try {
					Assert.assertEquals("no record found not displayed", "no record found should be displayed");
				} catch (Throwable t) {
					TestLibrary.reportErrorAndtakeScreenshot(t, "NoRecordNotDisplayed");
				}
			}
		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// --------------------------------------------------------------------------------------------
	// navigate and veriy edit gauge interface page
	// Author:Yogendra Rathore
	public static EditGaugeInterfacePage navigateToEditGaugeInterfacePage(String navigationMethod,
			String gaugeInterfaceName) throws Exception {

		if (navigationMethod.equals("FromGaugeInterfaceLandingPage")) {
			if (!BasePage.isBrowserClosed()
					&& UtilityFunctions.getMultilingualData("Gauge_Interface")
							.equalsIgnoreCase(LibraryFunctions.getPageName())
					&& UtilityFunctions.getMultilingualData("BackButton")
							.equalsIgnoreCase(BasePage.pageHeaderNavigation.getLabelOfBackButtonDataSelctor())) {
				// Click on Back button
				BasePage.pageHeaderNavigation.clickOnCancelButton();
				gaugeInterfacesLandingPage = new GaugeInterfacesLandingPage();
				// Verify interface landing page
				TestLibrary.verifyGaugeInterfaceLandingPageIsDisplayed(gaugeInterfacesLandingPage);
			} else {

				navigateToGaugeInterfacesLandingPage();
			}

			editGaugeInterfacePage = gaugeInterfacesLandingPage.navigateToEditGaugeInterfacePage(gaugeInterfaceName);

			LibraryFunctions.handlingConfirmationBoxMessage("OK");

		} else if (navigationMethod.equals("FromCreateGaugeInterfaceConnectionPage")) {
			// TODO

		} else {
			throw new Exception("Navigation Method not correct");
		}

		// Verify edit gauge interface page
		TestLibrary.verifyEditGaugeInterfacePageIsDisplayed(editGaugeInterfacePage, gaugeInterfaceName);

		return editGaugeInterfacePage;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// navigate to edit gauge interface page
	// Author :Yogendra Rathore
	public static void verifyEditGaugeInterfacePageIsDisplayed(EditGaugeInterfacePage editGaugeInterfacePage,
			String gaugeInterfaceName) throws Exception {
		// check in progress text and wait till 15 secs if Inprogress is
		// displayed.
		UtilityFunctions.applicationWait(2000);
		int index = 0;
		while ((LibraryFunctions.isElementPresent(BasePage.xPath_InProgressImage, 1)
				|| LibraryFunctions.isElementPresent(BasePage.xPath_InProgressText, 1)) && index < 15) {
			UtilityFunctions.applicationWait(1000);
			index++;

		}
		// Verify Edit gauge interface Page is displayed
		if (!editGaugeInterfacePage.checkEditGaugeInterfacePageIsDisplayed(gaugeInterfaceName)) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " EditGaugeInterface Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " EditGaugeInterface Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_To_Navigate_To_EditGaugeInterface_Page");
				log.error("Error occured - Not able to Navigate to EdEditGaugeInterface page for "
						+ BasePage.currentMethodName);
				throw new Exception();
			}
		} // end of if
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Navigate to Data Purge page
	// Author : Yogendra Rathore
	public static DataPurgePage navigateToDataPurgePage() throws Exception {

		try {
			loginIfNotLoggedInAndVerifyUserIsLoggedIn();

			// Navigate to purge page

			dataPurgePage = BasePage.pageHeaderNavigation.navigateToDataPurgePage();

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

			// Verify page is displayed
			verifyDataPurgePageIsDisplayed(dataPurgePage);

		} catch (Exception e) {

			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));

		}
		return dataPurgePage;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check data purge display
	// Author : Yogendra Rathore
	public static void verifyDataPurgePageIsDisplayed(DataPurgePage dataPurgePage) throws Exception {

		// Verify page
		if (!dataPurgePage.checkDataPurgePageIsDisplayed()) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Data Purge Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Data Purge Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_ DataPurge_Page");

			}
		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Verify Exclusion Rule page is displayed
	// Author: Neha Goyal
	public static void verifyExclusionRulePageIsDisplayed(ExclusionRulePage exclusionRulePage) throws Exception {

		// Verify Exclusion Rule Page is displayed
		if (!exclusionRulePage.checkexclusionRulePageIsDisplayed()) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Exclusion Rule Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Exclusion Rule Page");
			} catch (Throwable t) {

				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_Exclusion_Rule_page");
				log.error("Error occured - Not able to Navigate to exclusion rule Page for "
						+ BasePage.currentMethodName);
			}

		} // end of if
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Verify that Dashboard page DC tile view all page is displayed
	// Author : Rakesh Kumar Sharma
	public static void verifyDCTileViewAllPageIsDisplayed(DashboardPage dashboardpage) throws Exception {
		if (dashboardpage.checkViewAllDCTileIsDisplayed() == false) {
			try {
				Assert.assertEquals("System did not navigate to Dashboard dc tile view all page",
						"System should navigate to Dashboard dc tile view all Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "DCTileViewAll_Page_not_displayed");
				throw new Exception("TestLibrary - error in verifyDCTileViewAllPageIsDisplayed method " + t);
			}
		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	/*
	 * Created By : Rakesh Sharma Logic: This method navigates us from login page to
	 * create WorkFlow page Return: Object of CreateWorkFlow Page
	 */
	public static CreateWorkflowPage navigatetoCreateWorkFlowPage() throws Exception {

		if (!BasePage.isBrowserClosed() && UtilityFunctions.getMultilingualData("WorkFlow_Header_Title")
				.equalsIgnoreCase(LibraryFunctions.getPageName())) {
			// Click on Back button
			BasePage.pageHeaderNavigation.clickOnCancelButton();
			workFlowLandingPage = new WorkflowLandingPage();
			// Verify WorkFlow Landing Page
			TestLibrary.verifyWorkFlowLandingPageIsDisplayed(workFlowLandingPage);
		} else {

			// If Browser is not open then Open browser and if User in not
			// Logged In then Login
			TestLibrary.loginIfNotLoggedInAndVerifyUserIsLoggedIn();
			// Navigate to WorkFlow Landing Page
			workFlowLandingPage = BasePage.pageHeaderNavigation.navigateToWorkFlowLandingPage();

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

			// Verify WorkFlow Landing Page
			TestLibrary.verifyWorkFlowLandingPageIsDisplayed(workFlowLandingPage);
		}

		// Navigate to Create WorkFlow Page
		createWorkFlowPage = workFlowLandingPage.navigateToCreateWorkFlowPage();

		// Verify Create WorkFlow Page
		TestLibrary.verifyCreateWorkFlowPageIsDisplayed(createWorkFlowPage);

		return createWorkFlowPage;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check display of WorkFlow Landing Page
	// Author : Rakesh
	public static void verifyWorkFlowLandingPageIsDisplayed(WorkflowLandingPage workFlowLandingPage) throws Exception {
		// Verify User Landing page
		if (workFlowLandingPage.checkWorkFlowLandingPageIsDisplayed() == false) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " WorkFlow Landing Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " WorkFlow Landing Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_workFlow_landing_page");
				log.error("Error occured - Not able to Navigate to Workflow Landing Page for "
						+ BasePage.currentMethodName);
			}
		}
	}

	// ----------------------------------------------------------------------------------------------------------------------------------
	// Author - Rakesh Sharma
	// Verify Create WorkFlow page is displayed
	public static void verifyCreateWorkFlowPageIsDisplayed(CreateWorkflowPage createWorkFlowPage) {
		// Verify Create Part Page is displayed
		if (createWorkFlowPage.checkCreateWorkflowPageIsDisplayed() == false) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Create Workflow Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Create Workflow Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_Create_WorkFlow_page");
				log.error("Error occured - Not able to Navigate to Create WorkFlow Page for "
						+ BasePage.currentMethodName);
			}
		} // end of if
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to Workflow landing page and return object
	// of Workflow landing page.
	// Author : Rakesh Sharma
	public static WorkflowLandingPage navigateToWorkFlowLandingPage() throws Exception {
		try {
			loginIfNotLoggedInAndVerifyUserIsLoggedIn();

			// Navigate to WorkFlow Landing Page
			workFlowLandingPage = BasePage.pageHeaderNavigation.navigateToWorkFlowLandingPage();

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

			// Verify WorkFlow Landing Page
			TestLibrary.verifyWorkFlowLandingPageIsDisplayed(workFlowLandingPage);

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
		return workFlowLandingPage;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check display of WorkFlowAssignment Landing Page
	// Author : Rakesh
	public static void verifyWorkflowAssignmentLandingPageIsDisplayed(
			WorkflowAssignmentLandingPage workflowAssignmentLandingPage) throws Exception {
		// Verify User Landing page
		if (workflowAssignmentLandingPage.checkWorkFlowAssignmentLandingPageIsDisplayed() == false) {
			try {
				Assert.assertEquals(
						ConstantsUtility.errApplicationPageNotDisplayed + " workflowAssignment Landing Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " workflowAssignment Landing Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_workflowAssignmentlanding_page");
				log.error("Error occured - Not able to Navigate to workflowAssignment Landing Page for "
						+ BasePage.currentMethodName);
			}
		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to WorkflowAssignment landing page and return
	// object
	// of WorkflowAssignment landing page.
	// Author : Rakesh Sharma
	public static WorkflowAssignmentLandingPage navigateToWorkFlowAssignmentLandingPage() throws Exception {
		try {
			if (!BasePage.isBrowserClosed() && UtilityFunctions.getMultilingualData("WorkFlowAssignment_Header_Title")
					.equalsIgnoreCase(LibraryFunctions.getPageName())) {
				// Click on Back button
				BasePage.pageHeaderNavigation.clickOnCancelButton();
				workflowAssignmentLandingPage = new WorkflowAssignmentLandingPage();
				// Verify Landing Page
				TestLibrary.verifyWorkflowAssignmentLandingPageIsDisplayed(workflowAssignmentLandingPage);
			} else {
				loginIfNotLoggedInAndVerifyUserIsLoggedIn();

				// Navigate to WorkFlow Landing Page
				workFlowLandingPage = BasePage.pageHeaderNavigation.navigateToWorkFlowLandingPage();

				// Check To handle Confirmation Message - If appears
				LibraryFunctions.handlingConfirmationBoxMessage("ok");

				// Verify WorkFlow Landing Page
				TestLibrary.verifyWorkFlowLandingPageIsDisplayed(workFlowLandingPage);

				// Check To handle Confirmation Message - If appears
				LibraryFunctions.handlingConfirmationBoxMessage("ok");

				workflowAssignmentLandingPage = workFlowLandingPage.navigateToWorkflowAssignmentPage();
				TestLibrary.verifyWorkflowAssignmentLandingPageIsDisplayed(workflowAssignmentLandingPage);
			}

		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
		return workflowAssignmentLandingPage;
	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to edit workflow assignment page on basis of
	// workflow name
	// Author: rakesh sharma
	public static EditWorkflowAssignmentPage navigateToEditWorkflowAssignmentPage(String workflowName)
			throws Exception {
		// Navigate to workflow assignment Landing Page
		workflowAssignmentLandingPage = TestLibrary.navigateToWorkFlowAssignmentLandingPage();

		// navigate to specific edit page
		Hashtable<String, String> testCaseData = new Hashtable<String, String>();
		testCaseData.put(WorkflowAssignmentLandingPage.filter_WorkflowName, workflowName);
		editWorkFlowAssignmentPage = workflowAssignmentLandingPage
				.navigateToEditPageForSpecificWorkFlowAssignment(testCaseData);

		// Verify edit workflowAssignment Page
		TestLibrary.verifyEditWorkFlowAssignmentPage(editWorkFlowAssignmentPage, workflowName);

		return editWorkFlowAssignmentPage;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check Edit editWorkFlowAssignmentPage is displayed
	// Author: rakesh sharma

	public static void verifyEditWorkFlowAssignmentPage(EditWorkflowAssignmentPage editWorkFlowAssignmentPage,
			String workflowName) {
		// check in progress text and wait till 15 secs if Inprogress is
		// displayed.
		UtilityFunctions.applicationWait(2000);
		int index = 0;
		while ((LibraryFunctions.isElementPresent(BasePage.xPath_InProgressImage, 1)
				|| LibraryFunctions.isElementPresent(BasePage.xPath_InProgressText, 1)) && index < 15) {
			UtilityFunctions.applicationWait(1000);
			index++;

		}
		// Verify editWorkFlowAssignmentPage
		if (editWorkFlowAssignmentPage.checkEditWorkFlowAssignmentPageIsDisplayed(workflowName) == false) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " editWorkFlowAssignment Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " editWorkFlowAssignment Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_editWorkFlowAssignmentPage");
				log.error("Error occured - Not able to Navigate to edit WorkFlowAssignment Page for "
						+ BasePage.currentMethodName);
			}
		} // end of if

	}

	// ----------------------------------------------------------------------------------------------------------------------------------
	// Author - Rakesh Sharma
	// Verify Create WorkFlowAssignment page is displayed
	public static void verifyCreateWorkflowAssignmentPageIsDisplayed(
			CreateWorkflowAssignmentPage createWorkflowAssignmentPage) {
		// Verify Create Part Page is displayed
		if (createWorkflowAssignmentPage.checkCreateWorkFlowAssignmentPageIsDisplayed() == false) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Create WorkflowAssignment Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Create WorkflowAssignment Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_Create_WorkflowAssignment_page");
				log.error("Error occured - Not able to Navigate to Create WorkflowAssignment Page for "
						+ BasePage.currentMethodName);
			}
		} // end of if
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	/*
	 * Created By : Rakesh Sharma Logic: This method navigates us from login page to
	 * create WorkFlow Assignment page Return: Object of CreateWorkFlowAssignment
	 * Page
	 */
	public static CreateWorkflowAssignmentPage navigatetoCreateWorkFlowAssignmentPage() throws Exception {

		// Navigate to workflow assignment Landing Page
		workflowAssignmentLandingPage = TestLibrary.navigateToWorkFlowAssignmentLandingPage();

		// Navigate to Create WorkFlow Assignment Page
		createWorkflowAssignmentPage = workflowAssignmentLandingPage.navigateToCreateWorkFlowAssignmentPage();

		// Verify Create WorkFlowAssignment Page
		TestLibrary.verifyCreateWorkflowAssignmentPageIsDisplayed(createWorkflowAssignmentPage);

		return createWorkflowAssignmentPage;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to Work dashboard Page
	// Author : Yogendra Rathore
	// modified by Rakesh Sharma on 13-06-2019
	// return new Dashboard Page
	public static DashboardPage navigateToWorkDashboardPage() throws Exception {
		try {
			loginIfNotLoggedInAndVerifyUserIsLoggedIn();

			String currentUrl = BasePage.driver.getCurrentUrl();

			String spiltArrary[] = new String[2];

			// get expected validation message
			spiltArrary = UtilityFunctions.splitString(currentUrl, "#");
			String url = spiltArrary[0] + "#dashboard/-1";
			BasePage.driver.navigate().to(url);

			if (!LibraryFunctions.isBrowserAlertMessageIsPresent()) {
				LibraryFunctions.checkLoadingIconIsDisplayed("SpinningLoadingIcon", 60);
				LibraryFunctions.checkLoadingIconIsDisplayed("GridLoadingIcon", 60);
			} else {
				LibraryFunctions.handlingConfirmationBoxMessage("OK");

				LibraryFunctions.checkLoadingIconIsDisplayed("SpinningLoadingIcon", 60);
				LibraryFunctions.checkLoadingIconIsDisplayed("GridLoadingIcon", 60);
			}
		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
		return new DashboardPage();
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Verify that DataCollection edit Requirement page is displayed
	// Author :Rakesh Sharma
	public static void verifyEditDCRequirementPageIsDisplayed(DCRequirementPage dcRequirementPage,
			String dcRequirementName) throws Exception {

		if (!dcRequirementPage.checkEditDCRequirementPageIsDisplayed(dcRequirementName)) {

			try {
				Assert.assertEquals(
						ConstantsUtility.errApplicationPageNotDisplayed + " Data Collection Edit Requirement page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Data Collection Edit Requirement page");

			} catch (Exception t) {
				TestLibrary.reportErrorAndtakeScreenshot(t, "Data_Collection_EditRequirement_page_Did_not_Display");
				log.error("Error occured - Not able to Navigate to DataCollection Edit Requirement Page for "
						+ BasePage.currentMethodName);
				throw t;
			}
		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to Shift log page and return object of
	// Shift Log Page
	// Author : Rakesh Sharma
	public static ShiftLogPage navigateToShiftLogPage() throws Exception {
		shiftLogPage = new ShiftLogPage();
		try {
			loginIfNotLoggedInAndVerifyUserIsLoggedIn();
			// Navigate to Shift Landing Page
			if (!shiftLogPage.checkShiftLogPageIsDisplayed()) {
				shiftLogPage = BasePage.pageHeaderNavigation.navigateToShiftLogPage();

				// Check To handle Confirmation Message - If appears
				LibraryFunctions.handlingConfirmationBoxMessage("ok");

				// Verify ShiftLanding page
				verifyShiftLogPageIsDisplayed(shiftLogPage);

				// Check To handle Confirmation Message - If appears
				LibraryFunctions.handlingConfirmationBoxMessage("ok");
				return shiftLogPage;
			}

		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
		return shiftLogPage;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check Shift Log Page display
	// Author : Rakesh Sharma
	public static void verifyShiftLogPageIsDisplayed(ShiftLogPage shiftLogPage) throws Exception {
		// Verify Shift Landing page
		if (!shiftLogPage.checkShiftLogPageIsDisplayed()) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Shift Log Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Shift Log Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_Shift_log_page");
				log.error("Error occured - Not able to Navigate to Shift Log Page for " + BasePage.currentMethodName);
			}
		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Navigate to Bulk delete subgroup data Page
	// Author : Neha Goyal
	public static BulkDeleteSubgroupDataPage navigateToBulkDeleteSubgroupDataPage() throws Exception {

		try {
			loginIfNotLoggedInAndVerifyUserIsLoggedIn();

			// Navigate to purge page

			bulkDeleteSubgroupDataPage = BasePage.pageHeaderNavigation.navigateToBulkDeleteSubgroupDataPage();

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

			// Verify page is displayed
			verifyBulkDeleteSubgroupDataPageIsDisplayed(bulkDeleteSubgroupDataPage);

		} catch (Exception e) {

			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));

		}
		return bulkDeleteSubgroupDataPage;
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check Bulk Delete Subgroup Data page display
	// Author : Neha Goyal
	public static void verifyBulkDeleteSubgroupDataPageIsDisplayed(
			BulkDeleteSubgroupDataPage bulkDeleteSubgroupDataPage) throws Exception {

		// Verify page
		if (!bulkDeleteSubgroupDataPage.checkBulkDeleteSubgroupDataPageIsDisplayed()) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Bulk Delete Subgroup Data Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " Bulk Delete Subgroup Data Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_ BulkDeleteSubgroupData_Page");

			}
		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check Event reviews page is displayed.
	// Author :Rakesh Sharma
	public static void verifyEventReviewsPageIsDisplayed(EventReviewsPage eventReviewsPage) throws Exception {
		if (!eventReviewsPage.checkEventReviewsPageIsDisplayed()) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Event review Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " event review Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_Eventreview_page");

			}

		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Check Event details page is displayed.
	// Author :Rakesh Sharma
	public static void verifyEventDetailsPageIsDisplayed(EventDetailsPage eventDetailsPage) throws Exception {

		if (!eventDetailsPage.checkEventDetailsPageIsDisplayed()) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " Event details Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " event details Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_Eventdetails_page");

			}

		}
	}

	// ---------------------------------------------------------------------------------------------------------------------------
	// Check Edit Shift log Page is displayed
	// Author: Rakesh Sharma
	public static void verifyEditShiftLogsPageIsDisplayed(EditShiftLogsPage editShiftLogsPage, String shiftName,
			String processName) throws Exception {
		// check in progress text and wait till 15 secs if Inprogress is
		// displayed.
		UtilityFunctions.applicationWait(2000);
		int index = 0;
		while ((LibraryFunctions.isElementPresent(BasePage.xPath_InProgressImage, 1)
				|| LibraryFunctions.isElementPresent(BasePage.xPath_InProgressText, 1)) && index < 30) {
			UtilityFunctions.applicationWait(1000);
			index++;

		}
		// Verify Edit Shift Page
		if (!editShiftLogsPage.checkEditShiftLogsPageIsDisplayed(shiftName, processName)) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + " EditShiftLogs Page",
						ConstantsUtility.msgApplicationPageShouldDisplay + " EditShiftLogs Page");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_To_Navigate_To_Edit_ShiftLogs_Page");
				log.error("Error occured - Not able to Navigate to Edit ShiftLogs Page for "
						+ BasePage.currentMethodName);

			}
		} // end of if

	}

	// ---------------------------------------------------------------------------------------------------------------------
	// Assertion for ReActivate record
	// Author: rakesh sharma
	public static void assertForReActivateRecord(Hashtable<String, String> result) throws Exception {
		String expectedConfirmationMessage = "", actualConfirmationMessage = "", expectedDeletePopUpTitle = "";
		String expectedDeletedSuccessfullyMessage = "", actualDeletedSuccessfullyMessage = "",
				actualDeletedPopupTitle = "";

		if (result.containsKey("expectedConfirmationMessage")) {
			expectedConfirmationMessage = result.get("expectedConfirmationMessage");
		}

		if (result.containsKey("expectedReActivateSuccessfullyMessage")) {
			expectedDeletedSuccessfullyMessage = result.get("expectedReActivateSuccessfullyMessage");
		}

		if (result.containsKey("expectedPopUpTitle")) {
			expectedDeletePopUpTitle = result.get("expectedPopUpTitle");
		}

		// check confirmation displayed
		if (result.containsKey("Confirmation Message Displayed")) {

			try {
				Assert.assertEquals(ConstantsUtility.errNoConfirmationMessageDispalyedOnDeletingRecord,
						ConstantsUtility.msgConfirmationMessageShouldBeDisplayed);
			} catch (Throwable t) {
				TestLibrary.reportErrorAndtakeScreenshot(t,
						"No_Confirmation_Message_Is_Displayed_On_Deleting_A_Record");
				return;
			} // End of catch
		}
		// check confirmation cross [X] button is present
		if (result.containsKey("Pop Up Close Button Present")) {
			try {
				Assert.assertEquals(ConstantsUtility.errValidationMessageCrossIconIsNotPresent,
						ConstantsUtility.msgValidationMessageCrossIconIsNotPresent);
			} catch (Throwable t) {
				TestLibrary.reportErrorAndtakeScreenshot(t,
						"No_Cross[X]_Button_Is_Present_On_Confirmation_Message_Displayed_On_Deleting_A_Record");

			} // End of catch
		}
		// get actual Confirmation message
		if (result.containsKey("Confirmation Message")) {
			actualConfirmationMessage = result.get("Confirmation Message");

			if (!expectedConfirmationMessage.equals(actualConfirmationMessage)) {
				System.out.println(expectedConfirmationMessage + "-- Exepcted Confirmation message");
				System.out.println(actualConfirmationMessage + "-- Actual Confirmation message");

				try {
					Assert.assertEquals(ConstantsUtility.errConfirmationMessageDispalyedOnDeletingRecordIsNotCorrect,
							ConstantsUtility.msgCorrectConfirmationMessageShouldBeDisplayed);
				} catch (Throwable t) {
					TestLibrary.reportErrorAndtakeScreenshot(t,
							"Correct_Confirmation_Message_Is_Not_Displayed_On_Deleting_A_Record");
				} // End of catch
			}
		}

		// get actual delete successfully message
		{
			if (result.containsKey("ReActivated successfully Message"))
				actualDeletedSuccessfullyMessage = result.get("ReActivated successfully Message");

			if (result.containsKey("expectedReActivateSuccessfullyMessage")
					|| result.containsKey("ReActivated successfully Message")) {
				if (!expectedDeletedSuccessfullyMessage.equals(actualDeletedSuccessfullyMessage)) {
					System.out.println(expectedDeletedSuccessfullyMessage + "-- Exepcted message");
					System.out.println(actualDeletedSuccessfullyMessage + "-- Actual message");
					try {
						Assert.assertEquals(
								ConstantsUtility.errDeletedSuccessfullyMessageDispalyedOnDeletingRecordIsNotCorrect,
								ConstantsUtility.msgCorrectDeletedSuccessfullyMessageShouldBeDisplayed);
					} catch (Throwable t) {
						TestLibrary.reportErrorAndtakeScreenshot(t,
								"Correct_ReActivate_Successfully_Message_Is_Not_Displayed_On_Deleting_A_Record");
					} // End of catch
				}
			}
		}

		// get actual delete popup title
		if (result.containsKey("PopupHeaderTitle")) {
			actualDeletedPopupTitle = result.get("PopupHeaderTitle");

			if (!expectedDeletePopUpTitle.equals(actualDeletedPopupTitle)) {
				System.out.println(expectedDeletePopUpTitle);
				System.out.println(actualDeletedPopupTitle);
				try {
					Assert.assertEquals("ReActivate popup title is not correct.",
							"ReActivate popup title should be correct.");
				} catch (Throwable t) {
					TestLibrary.reportErrorAndtakeScreenshot(t, "ReActivate_Popup_Title_Is_Not_Correct");
				} // End of catch
			}
		}

		if (result.containsKey("OK_Button_Present")) {
			// check ok button present
			if (result.get("OK_Button_Present").equals(String.valueOf(false))) {
				try {
					Assert.assertEquals("Ok button is not present", "Ok button should be present");
				} catch (Throwable t) {
					TestLibrary.reportErrorAndtakeScreenshot(t, "OK_Button_Is_Not_Present");
				} // End of catch
			}
		}
		if (result.containsKey("Cancel_Button_Present")) {
			// check cancel button present
			if (result.get("Cancel_Button_Present").equals(String.valueOf(false))) {
				try {
					Assert.assertEquals("Cancel button is not present", "Cancel button should be present");
				} catch (Throwable t) {
					TestLibrary.reportErrorAndtakeScreenshot(t, "Cancel_Button_Is_Not_Present");
				} // End of catch
			}
		}

		// check cross button present
		if (result.containsKey("Cross_Button_Present"))
			if (result.get("Cross_Button_Present").equals(String.valueOf(false))) {
				try {
					Assert.assertEquals("Cross button is not present", "Cross button should be present");
				} catch (Throwable t) {
					TestLibrary.reportErrorAndtakeScreenshot(t, "Cross_Button_Is_Not_Present");
				} // End of catch
			}
		// check default Focus on Cancelcbutton
		if (result.containsKey("DefaultFocusOnCancel")) {
			try {
				Assert.assertEquals("Default focus is not on cancel button",
						"Default focus should be on cancel button");
			} catch (Throwable t) {
				TestLibrary.reportErrorAndtakeScreenshot(t, "Default_Focus_Is_Not_On_Cancel_Button");
			} // End of catch
		}

	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to proces state language label page
	// and return ProcessStateLanguageLabelPage object
	// Author:Vikas Mital
	public static ProcessStateLanguageLabelPage navigateToProcessStateLanguageLabelPage() throws Exception {
		if (!BasePage.isBrowserClosed() && UtilityFunctions.getMultilingualData("Process_States_Header_Title")
				.equalsIgnoreCase(LibraryFunctions.getPageName())) {
			// Click on Back button
			BasePage.pageHeaderNavigation.clickOnCancelButton();
			configureProcessStatesPage = new ConfigureProcessStatesPage();
			// Verify configure Process State Landing Page is displayed
			TestLibrary.verifyConfigureProcessStatesPageIsDisplayed(configureProcessStatesPage);
		} else {

			configureProcessStatesPage = navigateToConfigureProcessStatesPage();
		}
		processStateLanguageLabelPage = configureProcessStatesPage.navigateToProcessStateLanguageLabelPage();

		// Verify Page
		TestLibrary.verifyLanguageLabelPageIsDisplayed(processStateLanguageLabelPage,
				UtilityFunctions.getMultilingualData("Process_States_Header_Title"), "");

		return processStateLanguageLabelPage;
	}

	// ----------------------------------------------------------------------------------------------------------------
	// This method navigates user to Response Group Language Label page of a
	// response group name
	// and return ResponseGroupLanguageLabelPage object
	// Author: Mohnish Bhatia
	public static ResponseGroupLanguageLabelPage navigateToResponseGroupLanguageLabelPage(String responseGroupName)
			throws Exception {
		try {
			if (!BasePage.isBrowserClosed() && UtilityFunctions.getMultilingualData("ResponseGroup_Header_Title")
					.equalsIgnoreCase(LibraryFunctions.getPageName())) {
				// Click on Cancel button
				BasePage.pageHeaderNavigation.clickOnCancelButton();
				responseGroupLandingPage = new ResponseGroupLandingPage();
				// Verify Response Group Landing Page
				TestLibrary.verifyResponseGroupLandingPageIsDisplayed(responseGroupLandingPage);
			} else {

				responseGroupLandingPage = TestLibrary.navigateToResponseGroupLandingPage();
			}

			Hashtable<String, String> testCaseData = new Hashtable<String, String>();
			testCaseData.put(ResponseGroupPage.filter_ResponseGroupName, responseGroupName);
			// navigate to specific language label response group page
			responseGroupLanguageLabelPage = responseGroupLandingPage
					.navigateToResponseGroupLanguageLabelPage(testCaseData);

			// Verify language label response group Page
			TestLibrary.verifyLanguageLabelPageIsDisplayed(responseGroupLanguageLabelPage,
					UtilityFunctions.getMultilingualData("ResponseGroup_Header_Title"), responseGroupName);

			return responseGroupLanguageLabelPage;
		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));

		}

	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to Clone role page and return createRolePage
	// Author: Rakesh Sharma
	public static void assertForfilterRetention(Hashtable<String, String> testData, boolean valueRetain,
			boolean fieldRetain, boolean gridValueRetain, boolean filterCountRetain) throws Exception {
		try {

			if (!valueRetain) {// check filter State Retained. (it will contain
								// key only if value
								// not retained)
				if (!testData.containsKey("filterValueRetained")) {
					try {
						Assert.assertEquals("Filter Value Retained.", "Filter Value Should Not Be Retained.");
					} catch (Throwable t) {
						TestLibrary.reportErrorAndtakeScreenshot(t, "Filter_Value_Retained.");
						return;
					}
				}

				// check filter State Retained.
				if (filterCountRetain && testData.containsKey("filterCountCorrect")) {
					try {
						Assert.assertEquals("Filter Count not Retained.", "Filter Count Should Be Retained.");
					} catch (Throwable t) {
						TestLibrary.reportErrorAndtakeScreenshot(t, "Filter_Count_NotRetained.");
						return;
					}
				} else if (!filterCountRetain && !testData.containsKey("filterCountCorrect")) {
					try {
						Assert.assertEquals("Filter Count Retained.", "Filter Count Should not Be Retained.");
					} catch (Throwable t) {
						TestLibrary.reportErrorAndtakeScreenshot(t, "Filter_Count_Retained.");
						return;
					}
				}
			} else {
				// check filter State Retained. (it will contain key only if
				// value
				// not retained)
				if (testData.containsKey("filterValueRetained")) {
					try {
						Assert.assertEquals("Filter Value not Retained.", "Filter Value Should Be Retained.");
					} catch (Throwable t) {
						TestLibrary.reportErrorAndtakeScreenshot(t, "Filter_Value_NotRetained.");
						return;
					}
				}

				// check filter State Retained.
				if (testData.containsKey("filterCountCorrect")) {
					try {
						Assert.assertEquals("Filter Count not  Retained.", "Filter Count Should Be Retained.");
					} catch (Throwable t) {
						TestLibrary.reportErrorAndtakeScreenshot(t, "Filter_Count_NotRetained.");
						return;
					}
				}
			}

			// check value in grid Retained.
			if (!gridValueRetain) {
				if (!testData.containsKey("gridValueRetained")) {
					try {
						Assert.assertEquals("Grid Value Retained.", "Grid Value Should Not Be Retained.");
					} catch (Throwable t) {
						TestLibrary.reportErrorAndtakeScreenshot(t, "Grid_Value_Retained.");
						return;
					}
				}
			} else {
				// check filter value in grid Retained.
				if (testData.containsKey("gridValueRetained")) {
					try {
						Assert.assertEquals("Filter Grid Value not Retained.", "Filter Grid Value Should Be Retained.");
					} catch (Throwable t) {
						TestLibrary.reportErrorAndtakeScreenshot(t, "Filter_Grid_Value_NotRetained.");
						return;
					}
				}
			}

			if (fieldRetain) {// check filter field displayed.
				if (testData.containsKey("filterFieldDisplayed")) {
					try {
						Assert.assertEquals("Filter field is not displayed", "Filter field should be displayed");
					} catch (Throwable t) {
						TestLibrary.reportErrorAndtakeScreenshot(t, "Filter_field_NotDisplayed");
						return;
					}
				}
			} else
			// check filter field displayed.
			if (!testData.containsKey("filterFieldDisplayed")) {
				try {
					Assert.assertEquals("Filter field is displayed", "Filter field should not be displayed");
				} catch (Throwable t) {
					TestLibrary.reportErrorAndtakeScreenshot(t, "Filter_field_Displayed");
					return;
				}
			}

		} catch (Exception e) {
			throw new Exception("Error in assertForfilterRetention :" + e);
		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to Data collection types page and return
	// object of
	// the page name
	// Author : Yamini Jain
	public static DataCollectionTypesPage navigateToDataCollectionTypesPage() throws Exception {

		try {

			loginIfNotLoggedInAndVerifyUserIsLoggedIn();

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

			// Navigate to Shift Landing Page
			dataCollectionTypesPage = BasePage.pageHeaderNavigation.navigateToDataCollectionTypesPage();

			// Check To handle Confirmation Message - If appears
			LibraryFunctions.handlingConfirmationBoxMessage("ok");

			UtilityFunctions.applicationWait(1000);
			// Verify ShiftLanding page
			verifyDataCollectionTypesPageIsDisplayed(dataCollectionTypesPage);

			return dataCollectionTypesPage;

		} catch (Exception e) {
			throw new Exception("Error in navigating to Data collection types page :" + e);
		}

	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// verify Data Collection types page is displayed
	// Author :Yamini Jain
	public static void verifyDataCollectionTypesPageIsDisplayed(DataCollectionTypesPage dataCollectionTypesPage)
			throws Exception {
		UtilityFunctions.applicationWait(2000);
		// Verify Shift Landing page
		if (!dataCollectionTypesPage.checkDataCollectionTypesPageIsDisplayed()) {
			try {
				Assert.assertEquals(ConstantsUtility.errApplicationPageNotDisplayed + "DataCollectionTypesPage",
						ConstantsUtility.msgApplicationPageShouldDisplay + "DataCollectionTypesPage");
			} catch (Throwable t) {
				reportErrorAndtakeScreenshot(t, "Not_Able_to_navigate_to_DataCollectionTypesPage");
				log.error("Error occured - Not able to Navigate to DataCollectionTypesPage for "
						+ BasePage.currentMethodName);
			}
		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Verify that comment page is displayed
	// Modified By : Rakesh Kumar Sharma
	public static void verifyCommentsPageIsDisplayed(CommentsPage commentsPage) throws Exception {
		if (!commentsPage.checkCommentsPageIsDisplayed()) {
			try {
				// If login failed with valid credentials fail the
				// assertion
				Assert.assertEquals("System did not navigate to comments page",
						"System should navigate to comments Page");
			} catch (Throwable t) {

				reportErrorAndtakeScreenshot(t, "CommentsPage_not_displayed");
				throw new Exception("TestLibrary - error in verifyCommentsPageIsDisplayed method " + t);
			}
		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// download gauge latest gauge installer
	// Author : Yogendra Rathore
	public static void downloadLatestGaugeInstaller(String location, String installerName) throws Exception {

		try {

			// delete existing
			UtilityFunctions.deleteFolderAtGivenLocation(location, installerName);
			// download new gauge installer
			navigateToDashboardPage();

			BasePage.pageHeaderNavigation.downloadLatestGaugeInstaller();

			Thread.sleep(8000);
			String nameOfWindow = UtilityFunctions.getMultilingualData("Enact") + " - Google Chrome";

			// click on keep button
			WindowsDriver<WebElement> appDriver = UtilityFunctions.getDriverForSpecificDesktopWindow(nameOfWindow);

			// check gauge is already installed

			int size = appDriver.findElementsByName("Keep").size();

			if (size > 0) {

				appDriver.findElementByName("Keep").click();
				System.out.println("Clicked On Keep");
				// wait to repair the gauge agent - 25 seconds
				int index = 0;
				int time = 0;
				while (index < 12 && !UtilityFunctions.checkFolderExistsAtGivenLocation(location, installerName)) {
					Thread.sleep(5000);
					time = time + 5;
					if (index == 0)
						System.out.println("Waiting for " + installerName + " to be downloaded");
					index++;
				}

				if (UtilityFunctions.checkFolderExistsAtGivenLocation(location, installerName))
					System.out.println("Gauge Installer downloaded successfully in " + time + " seconds by "
							+ BasePage.currentMethodName);
				else
					System.out.println("Gauge Installer not downloaded successfully");

			}
		} catch (Exception e) {

			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	// Verify that Select Dashboard landing page is displayed
	// Author By : Ruby Jain
	public static void verifySelectDashboardLandingPageIsDisplayed(
			SelectDashboardLandingPage selectDashboardLandingPage) throws Exception {

		if (!selectDashboardLandingPage.checkSelectDashboardLandingPageIsDisplayed()) {
			try {
				// If login failed with valid credentials fail the assertion
				Assert.assertEquals("System did not navigate to Select Dashboard  page",
						"System should navigate to Select Dashboard  Page");
			} catch (Throwable t) {

				reportErrorAndtakeScreenshot(t, "Select Dashboard Page_not_displayed");
				throw new Exception("TestLibrary - error in verifySelect Dashboard PageIsDisplayed method " + t);
			}
		}
	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// This method navigates user to language label shift page on basis of
	// shift name and return shiftLanguageLabelPage object
	// Author:Vikas Mittal
	public static ShiftLanguageLabelPage navigateToShiftLanguageLabelPage(String shiftName) throws Exception {
		if (!BasePage.isBrowserClosed() && UtilityFunctions.getMultilingualData("ShiftLandingPageTitle")
				.equalsIgnoreCase(LibraryFunctions.getPageName())) {
			// Click on Back button
			BasePage.pageHeaderNavigation.clickOnCancelButton();
			shiftLandingPage = new ShiftLandingPage();
			// Verify Shift Landing Page
			TestLibrary.verifyShiftLandingPageIsDisplayed(shiftLandingPage);
		} else {

			shiftLandingPage = navigateToShiftLandingPage();
		}

		// navigate to specific edit shift page
		Hashtable<String, String> testCaseData = new Hashtable<String, String>();
		testCaseData.put(ShiftPage.filter_ShiftName, shiftName);
		shiftLanguageLabelPage = shiftLandingPage.navigateToShiftLanguageLabelPage(testCaseData);

		// Verify Page
		TestLibrary.verifyLanguageLabelPageIsDisplayed(shiftLanguageLabelPage,
				UtilityFunctions.getMultilingualData("ShiftLandingPageTitle"), shiftName);

		return shiftLanguageLabelPage;
	}
	
	
	
	
	public static InventoLogin navigateToInventoLoginPageAndVerifyLoginPageIsDisplayed() throws Exception {
        try {
               PageHeader pageHeader = new PageHeader();
               // if browser closed then open broswer and hit test site url

               if (LibraryFunctions.isBrowserClosed())

                     // Open Browser and Url of application
                     BasePage.login1 = new InventoLogin(BasePage.TestConfiguration.getProperty("Browser"),
                                   BasePage.TestConfiguration.getProperty("TestSiteURL"));

               if (BasePage.login1.checkLoginPageIsDisplayed() == false) {
                     try {
                            Assert.assertEquals(ConstantsUtility.errSomeErrorOccured,
                                          "Appliction url should open and Login Page should displayed");
                     } catch (Throwable t) {
                            reportErrorAndtakeScreenshot(t, "Application_Url_did_not_open");
                            log.error("Application URL is not opened for " + BasePage.currentMethodName);
                     } // End of catch
               } // End of If
        } catch (Exception e) {
               throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));

        }
        return new InventoLogin();
 }

}// end of class
