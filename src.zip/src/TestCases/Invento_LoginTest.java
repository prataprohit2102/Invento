package TestCases;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Hashtable;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import Base.BasePage;

import Util.ConstantsUtility;
import Util.ExcelUtility;
import Util.LibraryFunctions;
import Util.TestLibrary;
import Util.UtilityFunctions;
public class Invento_LoginTest {
       @BeforeMethod(alwaysRun = true)
       public void setMethodName(Method method) {

              // To get the current method name on the start of the test method
              BasePage.currentMethodName = method.getName();
              

       }

       @AfterMethod(alwaysRun = true)
       public void getMethodName(Method method) {
              // Reset the method name to blank when test method ends
              BasePage.currentMethodName = null;
              

       }

       
       // To verify the login button functionality using valid credentials
              @Test()
              public void TC_1() {

                     // If run mode set to "No" in Test Suite sheet then test will not
                     // execute otherwise it
                     // will execute
                     TestLibrary.verifyTestIsExecutable(BasePage.currentMethodName);

                     try {

                           TestLibrary.navigateToInventoLoginPageAndVerifyLoginPageIsDisplayed();

                     BasePage.login.doLogin(userName, password, companyId);
                           // Verify whether login successfully or not
                           //TestLibrary.verifyDashboardPageIsDisplayed(dashboardPage);

                     } // End of try
                     catch (Exception e) {
                           // In case of any error message. Fail the test case
                           TestLibrary.assertForSomeErrorOccur(e.getMessage());
                     } // End of catch
                     
                     
              }// End of Method

}

