package TestCases;

import org.testng.annotations.Test;

import Pages.InventoLogin;
import Pages.ViewListOfMoviesPage;
import Util.TestLibrary;

public class ViewListMoviesTestCases 
{
	@Test
	public void TC()
	{InventoLogin inventoLogin;
		ViewListOfMoviesPage viewListOfMoviesPage;
		TestLibrary.navigateToInventoLoginPageAndVerifyLoginPageIsDisplayed();
		InventoLogin.LoginAsAdmin("admin","password");
		
		viewListOfMoviesPage.checkIfMovieIsPresentInViewList("notebook");
		
	}
}
