package Listener;

import java.io.File;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.List;

import Base.BasePage;

import Util.*;

import org.testng.IAnnotationTransformer;
import org.testng.IInvokedMethod;
import org.testng.IInvokedMethodListener;
import org.testng.IRetryAnalyzer;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;
import org.testng.annotations.ITestAnnotation;
import org.testng.internal.Utils;

public class TestsListenerAdapter implements IInvokedMethodListener, ITestListener, IAnnotationTransformer {
	public static int countOfContinousFailure = 0;
	public static int countOfNotAbleToLogin = 0;
	public static SimpleDateFormat simpleDateFormat = BasePage.simpleDateFormat_1;

	// modified by: rakesh
	// modified Action1 (// Action 1: added {.replace("'", "")})
	public void afterInvocation(IInvokedMethod method, ITestResult result) {
		/*
		 * String fileName = System.getProperty("user.dir") + File.separator +
		 * "ErrorScreenshots" + File.separator + "filename.jpg";
		 */
		if (method.isTestMethod()) {
			List<Throwable> verificationFailures = ErrorUtility.getVerificationFailures();
			if (verificationFailures != null) {
				// if there are verification failures...
				if (verificationFailures.size() != 0) {
					// set the test to failed
					result.setStatus(ITestResult.FAILURE);

					// if there is an assertion failure add it to
					// verificationFailures
					if (result.getThrowable() != null) {
						verificationFailures.add(result.getThrowable());
					}

					int size = verificationFailures.size();
					// if there's only one failure just set that
					if (size == 1) {
						result.setThrowable(verificationFailures.get(0));
					} else {
						// create a failure message with all failures and stack
						// traces (except last failure)
						StringBuffer failureMessage = new StringBuffer("Multiple failures (").append(size)
								.append("):nn");
						for (int i = 0; i < size - 1; i++) {
							failureMessage.append("Failure ").append(i + 1).append(" of ").append(size).append(":n");
							Throwable t = verificationFailures.get(i);
							try {
								String fullStackTrace = Utils.stackTrace(t, false)[1];
								failureMessage.append(fullStackTrace).append("nn");
							} catch (Exception e) {
								System.out.println("error in getting and appending stacktrace " + t);
							}

						}

						// final failure
						try {
							Throwable last = verificationFailures.get(size - 1);
							failureMessage.append("Failure ").append(size).append(" of ").append(size).append(":n");
							failureMessage.append(last.toString());

							// set merged throwable
							// Action 1: added {.replace("'", "")}

							String failureMessageStr = failureMessage.toString();
							failureMessageStr = failureMessageStr.replace("'", "");
							failureMessageStr = failureMessageStr.replace("\n", "");

							if (failureMessageStr.contains("Do you want to navigate away from this page"))
								failureMessageStr = " Alert issue: Do you want to navigate away from this page ";

							Throwable merged = new Throwable(failureMessage.toString().replace("'", ""));
							merged.setStackTrace(last.getStackTrace());

							result.setThrowable(merged);
						} catch (Exception e) {
							System.out.println("error in getting and appending final failure stacktrace ");
						}

					}
				}
			} else {
				System.out.println("Closing browser as Verification failure list is Null on Listners page.");

				LibraryFunctions.closeBrowser();
			}
		}

	}

	public void beforeInvocation(IInvokedMethod arg0, ITestResult arg1) {

	}

	@Override
	public void onTestStart(ITestResult result) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onTestSuccess(ITestResult result) {
		try {
			BasePage.endTimeOfTestCase = UtilityFunctions.getCurrentDateInGivenFormat(simpleDateFormat);
			long diffSeconds = UtilityFunctions.getTimeDifferenceInSeconds(BasePage.startTimeOfTestCase,
					BasePage.endTimeOfTestCase);
			int diffMintues = (int) (diffSeconds / 60);
			int diffMintuesSec = (int) (diffSeconds % 60);
			// Set Execution Passed
			UtilityFunctions.setExecutionStatus("PASSED");

			// Set Execution Passed In Summary Sheet
			UtilityFunctions.setExecutionStatusInSummarySheet("PASSED");

			// write error in excel w.r.t to test case.
			UtilityFunctions.setFailureCauseInSummarySheet("N/A");

			// set execution time in both the sheet.
			UtilityFunctions.setExecutionTimeInExcelSheet(String.valueOf(diffMintues + "." + diffMintuesSec),
					BasePage.xls);

			UtilityFunctions.setExecutionTimeInExcelSheet(String.valueOf(diffMintues + "." + diffMintuesSec),
					BasePage.xls_Summary);
			// increase count of passed test cases
			BasePage.numberOfTestCasePassed++;
			System.out.println("Execution Time :  " + diffMintues + " Minutes " + diffMintuesSec + " Seconds.");

			System.out.println("Passed Count: " + BasePage.numberOfTestCasePassed);
			System.out.println("Failed Count: " + BasePage.numberOfTestCaseFailed);

			countOfContinousFailure = 0;
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void onTestFailure(ITestResult result) {
		try {
			String error = "";
			BasePage.endTimeOfTestCase = UtilityFunctions.getCurrentDateInGivenFormat(simpleDateFormat);
			System.out.println("End Time :" + BasePage.endTimeOfTestCase);
			long diffSeconds = UtilityFunctions.getTimeDifferenceInSeconds(BasePage.startTimeOfTestCase,
					BasePage.endTimeOfTestCase);
			int diffMintues = (int) (diffSeconds / 60);
			int diffMintuesSec = (int) (diffSeconds % 60);

			error = result.getThrowable().getMessage();
			// write error in excel w.r.t to test case.
			UtilityFunctions.setFailureCauseInSummarySheet(error);

			// Set Execution Failed
			UtilityFunctions.setExecutionStatus("FAILED");

			// Set Execution Failed in test summary sheet
			UtilityFunctions.setExecutionStatusInSummarySheet("FAILED");
			// set execution time in both the sheet.
			// set execution time in both the sheet.
			UtilityFunctions.setExecutionTimeInExcelSheet(String.valueOf(diffMintues + "." + diffMintuesSec),
					BasePage.xls);

			UtilityFunctions.setExecutionTimeInExcelSheet(String.valueOf(diffMintues + "." + diffMintuesSec),
					BasePage.xls_Summary);
			// increase count of failed test cases.
			BasePage.numberOfTestCaseFailed++;
			System.out.println("Execution Time :  " + diffMintues + " Minutes " + diffMintuesSec + " Seconds.");
			System.out.println("Passed Count: " + BasePage.numberOfTestCasePassed);
			System.out.println("Failed Count: " + BasePage.numberOfTestCaseFailed);

			// added by yogendra to close browser chrome in case of parrallel
			// execution.

			if (error.contains("System should navigate to Dashboard Page"))
				countOfNotAbleToLogin++;

			if (countOfNotAbleToLogin >= 2) {
				// UserPage.deleteTestDataFromUser(UserPage.getUserId(BasePage.excel_User));
				countOfNotAbleToLogin = 0;
			}

			if (UtilityFunctions.checkFolderExistsAtGivenLocation(System.getProperty("user.dir") + "\\..",
					BasePage.commonRepositoryFolderForParallelExecution))
				LibraryFunctions.closeBrowser();
			else
			// added by yogendra to close browser chrome in case of time out.
			if (error.contains("finish within the time-out"))
				LibraryFunctions.closeBrowser();

			if (error.contains("UnreachableBrowserException")
					|| error.contains("Error communicating with the remote browser")
					|| error.contains("no such window")) {

				System.out.println("Driver Value :-" + BasePage.dr);
				// set driver =null
				LibraryFunctions.closeBrowser();
				BasePage.driver = null;
				BasePage.dr = null;
				//TestLibrary.loginIfNotLoggedInAndVerifyUserIsLoggedIn();

			}

			// increase count of continous failure by 1
			countOfContinousFailure++;

			if (countOfContinousFailure >= 3) {
				LibraryFunctions.closeBrowser();

				//TestLibrary.loginIfNotLoggedInAndVerifyUserIsLoggedIn();
				countOfContinousFailure = 0;
				System.out.println("Count Of Continous Failure is  3, so closed the browser.");
			}
		} catch (Exception e) {
			System.out.println("Error in on TestFailure:" + BasePage.currentMethodName);
			e.printStackTrace();

		}

	}

	@Override
	public void onTestSkipped(ITestResult result) {
		// Set Execution Skipped
		UtilityFunctions.setExecutionStatus("SKIPPED");

		// set execution time in both the sheet.
		UtilityFunctions.setExecutionTimeInExcelSheet("0", BasePage.xls);

		if (BasePage.copyDataToTestSummarySheet)
		// Set Execution Skipped in test summary sheet
		{
			UtilityFunctions.setExecutionStatusInSummarySheet("SKIPPED");
			UtilityFunctions.setExecutionTimeInExcelSheet("0", BasePage.xls_Summary);

		}
	}

	@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
		// TODO Auto-generated method stub

	}

	@Override
	// Modified by : Yogendra Rathore
	// Action : added purge activity.
	// Purge activity is performed only for sanitySuite only for single run, not
	// for ReRun
	// Modified by : Yogendra Rathore <30-08-2018>
	// Action : added data deletion and execution folder deletion approach for
	// sanity. execution folder is deleted when sanity runs in parrallel
	// execution.
	public void onStart(ITestContext context) {
		boolean isSanitySuite = false;
		isSanitySuite = context.getCurrentXmlTest().getSuite().getName().equals("Automated_TestSuite_Sanity");

		if ((isSanitySuite) && !BasePage.isPurgeActivityPerformed && BasePage.copyDataToTestSummarySheet) {
			try {
				// delete execution folders if sanity

				String location = System.getProperty("user.dir") + "\\..\\..\\"
						+ BasePage.commonRepositoryFolderForParallelExecution;

				File directory = new File(location);

				// make sure directory exists
				if (directory.exists()) {
					UtilityFunctions.deleteFolderAtGivenLocation(System.getProperty("user.dir") + "\\resources",
							"Exceution Folder");

					UtilityFunctions.createFolderAtGivenLocation(System.getProperty("user.dir") + "\\resources",
							"Exceution Folder");
				}
				// *delete execution folders if sanity

				//TestLibrary.performPurgeActivity();
				BasePage.isPurgeActivityPerformed = true;
			} catch (Exception e) {
				System.out.println("Exception In Purge Activty on TestsListenerAdapter Page.");
				e.printStackTrace();
			}
		}

		// TODO Auto-generated method stub

	}

	@Override
	public void onFinish(ITestContext context) {
		// TODO Auto-generated method stub

	}

	@Override
	public void transform(ITestAnnotation annotation, Class testClass, Constructor testConstructor, Method testMethod) {
		IRetryAnalyzer retry = annotation.getRetryAnalyzer();

		if (retry == null) {
			annotation.setRetryAnalyzer(Retry.class);
		}

	}

}
