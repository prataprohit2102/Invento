package TestCases;

import static org.testng.Assert.assertThrows;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Hashtable;

import org.apache.log4j.Logger;
import org.hamcrest.object.HasToString;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import Base.BasePage;
import Pages.InventoLogin;
import Util.ConstantsUtility;
import Util.ErrorUtility;
import Util.ExcelUtility;
import Util.LibraryFunctions;
import Util.TestLibrary;
import Util.UtilityFunctions;

public class Invento_LoginTest {
	@BeforeMethod(alwaysRun = true)
	public void setMethodName(Method method) {

		// To get the current method name on the start of the test method
		BasePage.currentMethodName = method.getName();

	}

	@AfterMethod(alwaysRun = true)
	public void getMethodName(Method method) {
		// Reset the method name to blank when test method ends
		BasePage.currentMethodName = null;

	}

	// To verify the login button functionality using valid credentials
	@Test()
	public void TC_1234() {

		// If run mode set to "No" in Test Suite sheet then test will not
		// execute otherwise it
		// will execute
		TestLibrary.verifyTestIsExecutable(BasePage.currentMethodName);
		InventoLogin inventoLogin;
		try {

			inventoLogin = TestLibrary.navigateToInventoLoginPageAndVerifyLoginPageIsDisplayed();

			inventoLogin.LoginAsAdmin("admin", "password");

		} // End of try
		catch (Exception e) {
			// In case of any error message. Fail the test case
			TestLibrary.reportErrorAndtakeScreenshot(e, "Login_Is_Not_Successful");
			Assert.assertEquals("Not login", "Login is not successfull");
		} // End of catch

	}// End of Method

	@Test
	public void TC_1456() {
		TestLibrary.verifyTestIsExecutable(BasePage.currentMethodName);
		Hashtable<String, String> testData = new Hashtable<String, String>();
		try {
			InventoLogin.openApplicationInIncognitoModeOfChromeAndLogin(testData, false);
		} catch (Exception e) {
			TestLibrary.reportErrorAndtakeScreenshot(e, "Login_Is_Not_Successful");
			Assert.assertEquals("Not login", "");
		}
	}
}
