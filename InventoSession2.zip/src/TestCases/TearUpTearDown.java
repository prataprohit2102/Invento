package TestCases;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.List;



import org.apache.commons.io.FileUtils;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeGroups;
import org.testng.annotations.BeforeSuite;

import Base.BasePage;
import Util.DataBaseFunctionsLibraray;

import Util.LibraryFunctions;
import Util.ResourceStringVariables;
import Util.UtilityFunctions;

public class TearUpTearDown {

	/**
	 * Create backup of output folder at the end and starting of each suite
	 * execution
	 */

	// / Yogendra Rathore <01-03-2019> commented back up codde
	@BeforeSuite(alwaysRun = true)
	public void ouputBackupBeforeSuite() {
		try {
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// / Rakesh Sharma on 20-08-19
	@BeforeSuite(alwaysRun = true)
	public void resetResourceStringVariables() {
		try {
			ResourceStringVariables.resetResourceStringVariables();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@AfterSuite(alwaysRun = true)
	public void ouputBackupAfterSuite() {
		try {

			LibraryFunctions.closeBrowser();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@BeforeClass(alwaysRun = true)
	public void beforeClass() {
		try {
			System.out.println("@BeforeClass teardown");
		} catch (Exception e) {

		}
	}

	// this method closes DB connection
	// Author: Yogendra Rathore
	@AfterSuite(alwaysRun = true)
	public void closeDBConnection() {
		// close DB connection at the end of the
		// suite
		if (DataBaseFunctionsLibraray.conn != null) {
			DataBaseFunctionsLibraray.closeDatabaseConnection();
			System.out.println("<--End Of Execution -->");
			System.out.println("DB connection closed");
		}
	}

	// get result of test suite in test input sheet.
	// this method adds new column "Status" to the sheet.
	// Author: Yogendra Rathore
	// Modified BY : Yogendra Rathore <28-08-2017>
	// Action 1* : added shared Steps sheet
	// Modified BY : Yogendra Rathore <18-04-2019>
	// Action 2* : added set run mode N
	@BeforeSuite(alwaysRun = true)
	public void getSuiteStatusInExcel() {

		// get suite status
		UtilityFunctions.getSuiteStatusInExcel();

		// copy test data to excel sheet
		if (BasePage.copyDataToTestSummarySheet) {

			//BasePage.checkHealthOfApplicationForAutomationSuiteExecution();
			// Action 2* : added set run mode N
			UtilityFunctions.changeRunModeInTestInputSheetIfTestCaseIsNotReadyToBeExecuted();

			// delete sheet
			BasePage.xls_Summary.removeSheet("TestCases");

			// delete sheet
			BasePage.xls_Summary.removeSheet("Summary");

			// delete sheet purge status
			BasePage.xls_Summary.removeSheet("PurgeStatus");

			// delete sheet for Execution time
			BasePage.xls_Summary.removeSheet("ExecutionTime");

			// create new sheet
			BasePage.xls_Summary.addSheet("TestCases");

			// create new sheet
			BasePage.xls_Summary.addSheet("Summary");

			// create new Execution time
			BasePage.xls_Summary.addSheet("ExecutionTime");

			// create new Purge Status
			BasePage.xls_Summary.addSheet("PurgeStatus");

			// Action 1* : added shared Steps sheet
			// delete sheet for "SharedSteps"time
			BasePage.xls_Summary.removeSheet("SharedSteps");

			// create new sheet
			BasePage.xls_Summary.addSheet("SharedSteps");

			// add new columns "TestCases" and "FailedSteps" in test Input
			// Sheet.
			BasePage.xls_Summary.addColumn("SharedSteps", "TestCases");

			BasePage.xls_Summary.addColumn("SharedSteps", "FailedSteps");

			// copy test input sheet to summary sheet.
			UtilityFunctions.copyTestCasesSheetToTestSummarySheetFromTestExecutionInputSheet();

		} else
			// set shared steps status.
			UtilityFunctions.getDataForSharedStepsReRun();
	}

	// set number of license to 500

	// Author: Yogendra Rathore
	// modified by : Yogendra Rathore <26-07-18>
	// commented the code as this fucntionality is not loger valid

	/*
	 * @BeforeSuite(alwaysRun = true) public void setLicesnesInDB() {
	 * 
	 * UtilityFunctions.setLicenseCount(500);
	 * 
	 * }
	 */

	// set test case number executed to zero
	// Author: Yogendra Rathore
	@BeforeSuite(alwaysRun = true)
	public void setTestCaseNumberToZero() {

		// set test case number to 0
		BasePage.numberOfTestCaseExecuted = 0;
		BasePage.totalNumberOfTestCaseExecuted = UtilityFunctions.getTotalNumberOfTestCasesInYRunMode();

	}

	/**
	 * Clear all files from output folder before suite execution
	 */
	@BeforeSuite(alwaysRun = true)
	public void outputClean() {

		// set Run mode no of pass test cases
		UtilityFunctions.changeRunModeInTestInputSheet();

	}

	// this method get test summary sheet.
	// Author: Yogendra Rathore
	@AfterSuite(alwaysRun = true)
	public void getTestSummarySheetStatus() {
		try {
			System.out.println(UtilityFunctions.getPassedFailedStatusFromSummarySheet());
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	// --------------------------------------------------------------------------------------
	// delete all data of temp folder.
	// Author: Yogendra Rathore
	@AfterSuite(alwaysRun = true)
	public void deleteDataOfTempFOlder() {
		try {

			// check for parralle execution and kill chrome driver.
			if (!UtilityFunctions.checkFolderExistsAtGivenLocation(System.getProperty("user.dir") + "\\..\\..",
					BasePage.commonRepositoryFolderForParallelExecution)) {
				// get path of temp folder
				String pathOfTempFolder = System.getProperty("user.home") + "\\AppData\\Local\\Temp";
				// get all files and folders of temp folder
				List<String> listOfFilesAndFolders = UtilityFunctions.listFilesAndFolders(pathOfTempFolder);

				// delete all files and folders.
				for (int i = 0; i < listOfFilesAndFolders.size(); i++) {

					UtilityFunctions.deleteFolderAtGivenLocation(pathOfTempFolder, listOfFilesAndFolders.get(i));

				} // delete folders

				UtilityFunctions.killProcess(BasePage.broswerDriverExe);
				UtilityFunctions.killProcess("WinAppDriver.exe");
				System.out.println("Files Deleted Successfully From Temp Folder");
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	// --------------------------------------------------------------------------------------
	// set shared steps results for reRun
	// Author: Yogendra Rathore
	@AfterSuite(alwaysRun = true)
	public void setDataForSharedStepsReRun() {
		try {
			// set shared steps status.
			UtilityFunctions.setDataForSharedStepsReRun();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
