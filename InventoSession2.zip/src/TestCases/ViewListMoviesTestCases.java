package TestCases;

import org.testng.annotations.Test;

import Pages.InventoLogin;
import Pages.ViewListOfMoviesPage;
import Util.TestLibrary;

public class ViewListMoviesTestCases 
{
	@Test
	public void TC() {
	try {
	{	InventoLogin inventoLogin;
		inventoLogin=new InventoLogin();
		ViewListOfMoviesPage viewListOfMoviesPage = null;
		
		TestLibrary.navigateToInventoLoginPageAndVerifyLoginPageIsDisplayed();
		inventoLogin.LoginAsAdmin("admin","password");
		
		viewListOfMoviesPage.checkIfMovieIsPresentInViewList("notebook");
		
	}
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
}
