package Pages;

import org.openqa.selenium.By;
import org.testng.Assert;

import Base.BasePage;
import Util.LibraryFunctions;
import Util.UtilityFunctions;

public class ViewListOfMoviesPage extends BasePage {
	protected static String xpath_Btn_Search = "//input[@type='search']";
	protected static String xpath_Chkbx_SearchAvailableMovies = "//input[@type='checkbox']";
	protected static String xpath_lbl_NoResultsFound = "//div[contains(text(), 'No Results found :/')]";
	protected static String xpath_lbl_MovieName = "//div[@class='mycard']//div//h2";

	// ----------------------------------------------------------------------------
	public void viewCurrentListOfMovies() throws Exception {

		try {

		} catch (Exception e) {
			// If any error occurs
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}

	}

	// ----------------------------------------------------------------------------
	public void loginAsAdmin() throws Exception {
		try {

		} catch (Exception e) {
			// If any error occurs
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// ----------------------------------------------------------------------------
	public void addNewMovie() throws Exception {

		try {

		} catch (Exception e) {
			// If any error occurs
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}

	}

	// ----------------------------------------------------------------------------
	public void logoutAdmin() throws Exception {
		try {

		} catch (Exception e) {
			// If any error occurs
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// ----------------------------------------------------------------------------
	public void isMovieVisibleToUser() throws Exception {
		try {

		} catch (Exception e) {
			// If any error occurs
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// ---------------------
	// check if a movie is present
	public void checkIfMovieIsPresentInViewList(String movieName) {
		try {
			// LibraryFunctions.isElementDisplayed(xpath_Btn_Search, 10);
			LibraryFunctions.enterText(xpath_Btn_Search, movieName, false);
			if (LibraryFunctions.isElementDisplayed(xpath_lbl_NoResultsFound, 10)) {
				Assert.assertEquals("Movie should be displayed in search", "movie not found");
			} else if (LibraryFunctions.isElementDisplayed(xpath_lbl_MovieName, 10)) {
				// Assert.assertEquals(movieName, actualMovieName);
				System.out.println("The Movie you are looking is found");
			}

		} catch (Exception e) {

			System.out.println("Movie not Found");
			e.printStackTrace();
		}
	}

}
