package Pages;

import java.io.File;
import java.util.Hashtable;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.testng.Assert;

import Base.BasePage;
import Util.LibraryFunctions;
import Util.UtilityFunctions;

public class InventoLogin extends BasePage {
	public static final String xPath_txt_UserName = "//input[@name='username']";
	private final String xPath_txt_Password = "//input[@name='password']";
	private final String xPath_btn_LoginButton = "//button[@name='Login']";
	private final String xPath_btn_CancelButton = "//a[@name='Cancel']";
	private final String xPath_btn_LogoutButton = "//a[text()='Logout']";
	public final String xPath_btn_AddButton = "//*[@class='navLink']";
	protected static String xpath_Btn_Search = "//input[@type='search']";
	protected static String xpath_Chkbx_SearchAvailableMovies = "//input[@type='checkbox']";
	protected static String xpath_lbl_NoResultsFound = "//div[contains(text(), 'No Results found :/')]";
	protected static String xpath_lbl_MovieName = "//div[@class='mycard']//div//h2";

	// New xpath of version V2
	protected static String xPath_openLoginPanel = "//button[@type='button' and text()='#'] ";

	public InventoLogin() {
		super();
	}
	/*
	 * public InventoLogin(String property, String property2) { super("", ""); }
	 */

	/*
	 * public InventoLogin() { // TODO Auto-generated constructor stub }
	 */

	public InventoLogin(String browser, String appURL) {
		super(browser, appURL);
	}

	// ----------------------------------------------------------------------------
	public void viewCurrentListOfMovies() throws Exception {

		try {

		} catch (Exception e) {
			// If any error occurs
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}

	}

	// ----------------------------------------------------------------------------
	public void loginAsAdmin() throws Exception {
		try {

		} catch (Exception e) {
			// If any error occurs
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// ----------------------------------------------------------------------------
	public void addNewMovie() throws Exception {

		try {

		} catch (Exception e) {
			// If any error occurs
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}

	}

	// ----------------------------------------------------------------------------
	public void logoutAdmin() throws Exception {
		try {

		} catch (Exception e) {
			// If any error occurs
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// ----------------------------------------------------------------------------
	public void isMovieVisibleToUser() throws Exception {
		try {

		} catch (Exception e) {
			// If any error occurs
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// ---------------------
	// check if a movie is present
	public void checkIfMovieIsPresentInViewList(String movieName) {
		try {
			// LibraryFunctions.isElementDisplayed(xpath_Btn_Search, 10);
			LibraryFunctions.enterText(xpath_Btn_Search, movieName, false);
			if (LibraryFunctions.isElementDisplayed(xpath_lbl_NoResultsFound, 10)) {
				Assert.assertEquals("Movie should be displayed in search", "movie not found");
			} else if (LibraryFunctions.isElementDisplayed(xpath_lbl_MovieName, 10)) {
				// Assert.assertEquals(movieName, actualMovieName);
				System.out.println("The Movie you are looking is found");
			}

		} catch (Exception e) {

			System.out.println("Movie not Found");
			e.printStackTrace();
		}
	}

	public boolean checkLoginPageIsDisplayed() throws Exception {
		// handle pop up if already exists.
		try {
			LibraryFunctions.checkLoadingIconIsDisplayed("SpinningLoadingIcon", 60);
			LibraryFunctions.isElementDisplayed(xPath_openLoginPanel, 10);
			return LibraryFunctions.isElementDisplayed(xPath_openLoginPanel, 1);
		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	public void LoginAsUser(String userName, String password) throws Exception {
		try {
			if (LibraryFunctions.isElementDisplayed(xPath_openLoginPanel, 10)) {
				LibraryFunctions.click(xPath_openLoginPanel, "", 10);
				String r;
				if (LibraryFunctions.isElementDisplayed(xPath_btn_CancelButton, 10)) {
					LibraryFunctions.click(xPath_btn_CancelButton, "", 10);
					LibraryFunctions.enterText(xPath_txt_UserName, userName, false);
					LibraryFunctions.enterText(xPath_txt_Password, password, false);
					LibraryFunctions.click(xPath_btn_LoginButton, "", 10);

					if (!LibraryFunctions.isElementDisplayed(xPath_btn_LogoutButton, 10)) {
						Assert.assertEquals("User not logged in", "User should be logged in");
					}
					System.out.print("User successfully logged in");
				}

			} else {
				Assert.assertEquals("Login panel button is not displayed", "Login panel button shold be displayed");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void LoginAsAdmin(String userName, String password) throws Exception {
		try {

			if (LibraryFunctions.isElementDisplayed(xPath_openLoginPanel, 10)) {
				LibraryFunctions.click(xPath_openLoginPanel, "", 10);
				String r;
				if (LibraryFunctions.isElementDisplayed(xPath_btn_CancelButton, 10)) {
					LibraryFunctions.click(xPath_btn_CancelButton, "", 10);
					LibraryFunctions.enterText(xPath_txt_UserName, userName, false);
					LibraryFunctions.enterText(xPath_txt_Password, password, false);
					LibraryFunctions.click(xPath_btn_LoginButton, "", 10);

					if (!LibraryFunctions.isElementDisplayed(xPath_btn_LogoutButton, 10)) {
						Assert.assertEquals("Admin not logged in", "Admin should be logged in");
					}
					System.out.print("Admin successfully logged in");
				} else {
					Assert.assertEquals("Login panel button is not displayed", "Login panel button shold be displayed");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public static void checkUserIsLoggedIn() throws Exception {
		try {

		} catch (Exception e) {
			// If any error occurs
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	public static EventFiringWebDriver openApplicationInIncognitoModeOfChromeAndLogin(
			Hashtable<String, String> testData, boolean quitBrowser) throws Exception {
		EventFiringWebDriver tempdriver = null;
		EventFiringWebDriver tempdriver2 = null;
		try {
			String userName = "admin";
			String password = "password";
			// String companyId = BasePage.TestConfiguration.getProperty("CompanyID");

			// set user defined user name
			if (testData.containsKey("UserName"))
				userName = testData.get("UserName");
			else
				userName = BasePage.TestConfiguration.getProperty("UserName");

			ChromeOptions options = null;
			// set user defined workstation
			options = new ChromeOptions();
			options.addArguments("--incognito");

			DesiredCapabilities capabilities = DesiredCapabilities.chrome();
			capabilities.setCapability(ChromeOptions.CAPABILITY, options);

			// set path for chrome driver
			File file = new File(System.getProperty("user.dir") + "\\Resources\\Chrome_Driver\\chromedriver.exe");
			System.setProperty("webdriver.chrome.driver", file.getAbsolutePath());

			options.addArguments("test-type", "start-maximized");
			options.addArguments("--disable-features=VizDisplayCompositor");

			capabilities.setCapability("chrome.binary", file.getAbsolutePath());
			capabilities.setCapability(ChromeOptions.CAPABILITY, options);
			capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);

			dr_incognito = new ChromeDriver(capabilities);

			dr_incognito.navigate().to(BasePage.TestConfiguration.getProperty("TestSiteURL"));

			// assingn temp driver to hold object of driver of chorme browser
			tempdriver = BasePage.driver;

			// set BasePage.driver to incongnito mode driver to use all the
			// methods of the framework on incognito mode
			BasePage.driver = new EventFiringWebDriver(dr_incognito);

			// DashboardPage dashboardPage = BasePage.login.doLogin(userName, password,
			// companyId);

			tempdriver2 = BasePage.driver;

			// close bowser if required.
			if (quitBrowser)
				dr_incognito.quit();

			// returning incognito driver
			return tempdriver2;
		} catch (Exception e) {
			throw new Exception("BasePage - openApplicationInIncognitoModeOfChromeAndLogin " + e);
		} finally {
			// assign back the value of chrome driver to the BasePage.driver. so
			// that if we are just starting incognito but not assigning it
			// anywhere
			BasePage.driver = tempdriver;
		}

	}

}
