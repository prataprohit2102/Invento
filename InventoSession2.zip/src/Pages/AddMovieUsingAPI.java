package Pages;




	import org.json.simple.JSONObject;
	import org.testng.Assert;

	import io.restassured.RestAssured;
	import io.restassured.http.Headers;

	import io.restassured.response.Response;
	import io.restassured.specification.RequestSpecification;

	public class AddMovieUsingAPI {

	       public static void main(String[] args) {
	              // Specify the base URL to the RESTful web service
	              RestAssured.baseURI = "http://autothon-nagarro-backend-e02.azurewebsites.net/movies";
	              
	       //     RestAssured.baseURI ="http://restapi.demoqa.com/customer";
	              RequestSpecification request = RestAssured.given();
	              
	               JSONObject requestParams = new JSONObject();
	              
	               requestParams.put("rating", 1); 
	               requestParams.put("title", "Whatever");
	              requestParams.put("description", "Hi its a wonderful movie");
	              requestParams.put("categories", "[Drama]");
	              
	               requestParams.put("image",  "https://autothon-nagarro-frontend-e02.azurewebsites.net/addMovie");
	              requestParams.put("director", "James Baba");
	              
	              request.body(requestParams.toJSONString());
	              
	              System.out.println(request.toString());
	              Response response = request.post("/movie");
	              
	               int statusCode = response.getStatusCode();
	              System.out.println(statusCode);
	              // Assert.assertEquals(statusCode, "201");
	              String successCode = response.jsonPath().get("SuccessCode");
	              Assert.assertEquals( "Correct Success code was returned", successCode, "OPERATION_SUCCESS");
	              
	              
	              Headers headers = response.getHeaders();
	              headers.asList();
	              System.out.println(headers);
	       }
	              
	       }



}
