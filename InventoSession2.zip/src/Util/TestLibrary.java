package Util;

import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;
import Pages.*;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.SkipException;



import Base.BasePage;
import Pages.*;
import io.appium.java_client.windows.WindowsDriver;
//import io.appium.java_client.windows.WindowsDriver;

public class TestLibrary {
		public static String temp = "";

	
	// Check Test Case is executable
	public static void verifyTestIsExecutable(String testCaseName) {
		// If run mode set to "No" in Test Suite sheet then test will not
		// execute
		if (UtilityFunctions.IsExecutable(testCaseName, BasePage.xls) != true) {
			throw new SkipException("Run Mode Set to No");
		} else {
			// this code is for all those test cases which are run twice on
			// single call.

			if (temp != BasePage.currentMethodName) {
				BasePage.numberOfTestCaseExecuted++;
				temp = BasePage.currentMethodName;
			}

			// close browser in case error page is displayed.
			

			
			System.out.println();
			System.out.println();
			System.out.println("----------------------------------------------------------------");
			System.out.println("Current Method :" + BasePage.currentMethodName);
			if (!BasePage.titleOfTestCase.equals(""))
				System.out.println("Title :" + BasePage.titleOfTestCase);
			System.out.println("Executing TC: " + BasePage.numberOfTestCaseExecuted + " Out Of : "
					+ BasePage.totalNumberOfTestCaseExecuted);
			

			try {
				System.out.println("Number Of Chrome.exe running ="
						+ UtilityFunctions.getNumberOfTimesAProcessIsRunning("chrome.exe"));

				SimpleDateFormat simpleDateFormat = BasePage.simpleDateFormat_1;

				BasePage.startTimeOfTestCase = UtilityFunctions.getCurrentDateInGivenFormat(simpleDateFormat);
				System.out.println("Start Time Of TestCase: " + BasePage.startTimeOfTestCase);
				System.out.println("User Preffered Language In Excel: "
						+ BasePage.TestConfiguration.getProperty("UserPrefferedLanguage"));

				if (BasePage.current_LoggedIn_User.equals(""))
					System.out.println("Current Logged In User :- " + "No User Logged In");
				else
					System.out.println("Current Logged In User :- " + BasePage.current_LoggedIn_User);
			} catch (Exception e) {
			}
		}

	}

	// ----------------------------------------------------------------------------------------------------------------------------
	// Verify that input data is not blank
	public static void verifyInputDataIsNotBlank(Hashtable<String, String> TestDataSet) {
		if (UtilityFunctions.checkInputDataIsNotBlank(TestDataSet) == false)
			Assert.assertEquals(ConstantsUtility.errTestDataIsBlank, ConstantsUtility.msgTestDataShouldNotBeBlank);

	}
	
	
	public static InventoLogin navigateToInventoLoginPageAndVerifyLoginPageIsDisplayed() throws Exception {
        try {
               
               // if browser closed then open broswer and hit test site url

               if (LibraryFunctions.isBrowserClosed())

                     // Open Browser and Url of application
                     BasePage.login1 = new InventoLogin(BasePage.TestConfiguration.getProperty("Browser"),
                                   BasePage.TestConfiguration.getProperty("TestSiteURL"));

               if (BasePage.login1.checkLoginPageIsDisplayed() == false) {
                     try {
                            Assert.assertEquals(ConstantsUtility.errSomeErrorOccured,
                                          "Appliction url should open and Login Page should displayed");
                     } catch (Throwable t) {
                            reportErrorAndtakeScreenshot(t, "Application_Url_did_not_open");
           
                     } // End of catch
               } // End of If
        } catch (Exception e) {
               throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));

        }
        return new InventoLogin();
 }
	
	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------

	// Reports the error in the error listener and creates and file for the
	// screenshot and adds it into the TestNG report
	// Modified by: Yogendra Rathore
	public static void reportErrorAndtakeScreenshot(Throwable t, String screenShotFileName) {
		ErrorUtility.addVerificationFailure(t);
		UtilityFunctions.applicationWait(500);
		if (screenShotFileName != "")
			UtilityFunctions.takeScreenshot(screenShotFileName);

	}

}// end of class
