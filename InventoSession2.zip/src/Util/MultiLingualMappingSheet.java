/*
 * package Util;
 * 
 * public class MultiLingualMappingSheet {
 * 
 * // This method maps mulilingual sheet entries with Resource string excel, //
 * We have created 2 methods, becase single method was too large to save , // as
 * we cannot save a method after a certain size. // Author : yogendra Rathore
 * public static String mapMultiLingualSheet(String key) {
 * 
 * String value = ""; String temp = ""; String temp1 = ""; String temp2 = "";
 * String temp3 = "";
 * 
 * try { switch (key) { case "BackButton": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1) + "X"; break;
 * 
 * case "ShortnameUniquenessValidationMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(154) + "X"; break; case
 * "Code_Already_Exists": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(458) + "X"; break; case
 * "CodeGroup_Already_Exists": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(492) + "X"; break; case
 * "Required": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(96) + "X"; break; case
 * "RevisionnameUniquenessValidationMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(426) + "X"; break; case
 * "InvalidFormatValidationMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(69) + "X"; break; case
 * "ResetPasswordLinkSendSuccessfully": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1134)
 * 
 * + "X"; break; case "InvalidLoginCredentials": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(636)
 * 
 * + "X"; break; case "ProcessState_Already_Exists": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(950) + "X";
 * break; case "ForgotPassword_DefaultMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1130) + "X"; break; case
 * "UsernameUniquenessValidationMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(607) + "X"; break; case
 * "EmaiUniquenessValidationMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(608) + "X"; break; case
 * "SaveSuccessfullyMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(102) + "X"; value =
 * value.replace("{0}", "<Element Name>"); break; case
 * "ProcessState_Configurations_Save_Successfully": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(966) + "X";
 * break; case "AccountDeactivationMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(635) + "X"; break; case
 * "ForgotPasswordLinkSendSuccessfully": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1143) + "X"; break; case
 * "PartCountMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1388) + "X";
 * 
 * value = value.replace("{0}", "<count>"); value = value .replace( "{1}", "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(76) + "X");
 * 
 * break; case "ProcessCountMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1388) + "X";
 * 
 * value = value.replace("{0}", "<count>"); value = value .replace( "{1}", "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(194) + "X");
 * 
 * break; case "ParameterSet_NoProcessMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1832) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(194) + "X");
 * 
 * break; case "ParameterSet_NoFeatureMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1832) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(33) + "X");
 * 
 * break; case "FeatureCountMessage":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1388) + "X";
 * 
 * value = value.replace("{0}", "<count>"); value = value .replace( "{1}", "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(33) + "X");
 * 
 * break; case "TagValueAlreayExists": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2377) + "X"; break; case
 * "ParameterSet_NoPartMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1832) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(68) + "X");
 * 
 * break; case "ParameterSet_NoCodeMessage":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1832) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(398) + "X");
 * 
 * break; case "CodeCountMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1388) + "X";
 * 
 * value = value.replace("{0}", "<count>"); value = value .replace( "{1}", "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(398) + "X");
 * 
 * break; case "ParameterSet_SelectedParts": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2036) + "X"; break;
 * 
 * case "ParameterSet_SelectedTags": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1463) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(43) + "X"); break; case
 * "ParameterSet_NoTagMessage":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1832) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(399) + "X");
 * 
 * break; case "MultiProcessCountMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1388) + "X";
 * 
 * value = value.replace("{0}", "<count>"); value = value .replace( "{1}", "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(237) + "X");
 * 
 * break; case "SinglePartCountMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1388) + "X";
 * 
 * value = value.replace("{0}", "<count>"); value = value .replace( "{1}", "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(68) + "X");
 * 
 * break; case "MultiFeatureCountMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1388) + "X";
 * 
 * value = value.replace("{0}", "<count>"); value = value .replace( "{1}", "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(80) + "X");
 * 
 * break; case "EndDateSmallerThanStartDate": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1404) + "X"; break; case
 * "Part_AlreadyExists": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(331) + "X"; break; case
 * "ValidationMessageForInvalidImage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1404) + "X"; break; case
 * "ValidationMessageForGreaterThan600KBImage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(110) + "X"; break; case
 * "ValidationMessage_CreateSpecificationPage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(107) + "X"; break; case
 * "AccordionItem_OnlyInputPart": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(670) + "X"; break; case
 * "AccordionItem_OnlyOutputPart": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(671) + "X"; break; case
 * "Feature_DeleteConfirmaitonMessageWithAssociations": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(569) + "X";
 * break; case "SpecLimit_DeleteConfirmaitonMessage": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(143) + "X";
 * value = value.replace("{0}", "<Part,Revision,Feature,Lot,Process>"); break;
 * case "Part_DeleteConfirmaitonMessageWithAssociations": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(665) + "X";
 * break; case "Part_DeleteConfirmaitonMessageWithOutAssociations": value = "X"
 * + UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(567) + "X";
 * 
 * value = value.replace("{0}", "<PartName,Revision>"); break; case
 * "Tag_DeleteConfirmaitonMessageWithAssociations": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(478) + "X";
 * break; case "Feature_DeleteConfirmaitonMessageWithOutAssociations": value =
 * "X" + UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(567) +
 * "X";
 * 
 * value = value.replace("{0}", "<Element Name>");
 * 
 * break; case "CollectionAid_DeleteConfirmationMessage": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(944) + "X";
 * value = value.replace("{0} - {1}", "<Part,Revision,Feature>");
 * 
 * break; case "RemovedSuccessfullyMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(472) + "X"; value =
 * value.replace("{0}", "<Element Removed>");
 * 
 * break; case "Process_DeleteConfirmaitonMessageWithAssociations": value = "X"
 * + UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(573) + "X";
 * break; case "ConfirmationMessageForUnsavedData": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(91) + "X"; //
 * below line is replacing a special character with space - // don't remove this
 * line- Yogendra Rathore value = value.replace("�", " ");
 * 
 * break; case
 * "EditPartRevision_ConfirmationMessageForUnsavedDataOnClickingCreateSpecButton"
 * : value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(580) + "X"; break; case
 * "ValidationDisplayedOnGivingEndDateLessThanStartDate": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(489) + "X";
 * break; case "ConfirmationMessage_EditFeaturePage": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(580) + "X";
 * break; case "AccordionItem_AssignedODMessage_Feature": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(564) + "X";
 * break; case "AccordionItem_AssignedDCMessage_Feature": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(565) + "X";
 * break; case "AccordionItem_AssignedProcessMessage_Tag": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(496) + "X";
 * break; case "AccordionItem_AssignedPartMessage_Tag": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(497) + "X";
 * break; case "AccordionItem_AssignedFeatureMessage_Tag": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(498) + "X";
 * break; case "AccordionItem_AssignedCodeMessage_Tag": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(500) + "X";
 * break; case "AccordionItem_AssignedUserMessage_Tag": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(970) + "X";
 * break; case "AccordionItem_AssignedCodeGroupMessage_Tag": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(501) + "X";
 * break; case "Feature_SpecLimit_ConfirmationMessage": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(1012) + "X";
 * break; case "TagGroup_DeleteConfirmaitonMessageWithAssociations": value = "X"
 * + UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(558) + "X";
 * break; // for feature dont change as message varies in feature and part\ //
 * process case "Feature_SubGroup_ConfirmationMessage": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(1116) + "X";
 * break; // for part and process case "SubGroup_ConfirmationMessage": value =
 * "X" + UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(654) +
 * "X"; break; case "Part_SubGroup_ConfirmationMessage": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(655) + "X";
 * break; case "ConfirmatioPopUp_MessageHeader": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(221) + "X"; break; case
 * "ConfirmationMessageForTotalCountGreaterThanSubGroupSize": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(699) + "X";
 * break; case "ConfirmationMessage_ParametSetSelectEntityPage_Dynamic_Feature":
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1717) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(33) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1390) + "X");
 * 
 * break; case "ConfirmationMessage_ParametSetSelectEntityPage_Dynamic_Process":
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1717) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(194) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1390) + "X");
 * 
 * break; case "ConfirmationMessage_ParametSetSelectEntityPage_Static_Feature":
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1717) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(33) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1391) + "X");
 * 
 * break; case "ConfirmationMessage_ParametSetSelectEntityPage_Static_Process":
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1717) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(194) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1391) + "X");
 * 
 * break; case "AccordionItem_AssignedParameterSetMessage_Tag": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(1202) + "X";
 * break; case "ConfirmationMessage_ParametSetSelectEntityPage_Dynamic_Part":
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1717) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(76) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1390) + "X"); break; case
 * "ConfirmationMessage_ParametSetSelectEntityPage_Static_Part": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(1717) + "X";
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(76) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1391) + "X");
 * 
 * break; case "ValidationDisplayedOnGivingCreateToDateLessThanFromDate": value
 * = "X" + UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(346) +
 * "X"; break; case "SingleDCModalBoxMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(731) + "X";
 * 
 * temp = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(75) + "X";
 * 
 * value = value.replace("{1}", temp);
 * 
 * value = value.toLowerCase(); value = value.replace("{0}", "<Count>"); break;
 * case "DCModalBoxMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(728) + "X";
 * 
 * temp = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(792) + "X"; value =
 * value.replace("{1}", temp); value = value.toLowerCase(); value =
 * value.replace("{0}", "<Count>");
 * 
 * break; case "SpecLimitModalBoxMessage":
 * 
 * // when multiple limit exist. changing from 731 to 728. use //
 * SingleSpecLimitModalBoxMessage for single limit value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(728) + "X";
 * 
 * temp = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(4030) + "X"; value =
 * value.replace("{1}", temp); value = value.toLowerCase(); value =
 * value.replace("{0}", "<Count>"); break; case
 * "SingleSpecLimitModalBoxMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(731) + "X";
 * 
 * value = value .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(4029) + "X");
 * 
 * value = value.toLowerCase(); value = value.replace("{0}", "<Count>");
 * 
 * break; case "OperationModalBoxMessage":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(728) + "X";
 * 
 * temp = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(729) + "X";
 * 
 * value = value.replace("{1}", temp); value = value.toLowerCase(); value =
 * value.replace("{0}", "<Count>"); break; case
 * "SinglePartRecipeModalBoxMessage":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(731) + "X";
 * 
 * temp = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(70) + "X";
 * 
 * value = value.replace("{1}", temp);
 * 
 * value = value.toLowerCase(); value = value.replace("{0}", "<Count>"); break;
 * case "OperationDiagramModalBoxMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(728) + "X";
 * 
 * temp = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(774) + "X";
 * 
 * value = value.replace("{1}", temp); value = value.toLowerCase(); value =
 * value.replace("{0}", "<Count>");
 * 
 * break; case "SingleOperationDiagramModalBoxMessage": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(731) + "X";
 * 
 * temp = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(67) + "X";
 * 
 * value = value.replace("{1}", temp); value = value.toLowerCase(); value =
 * value.replace("{0}", "<Count>"); break; case
 * "Process_Can'tBeDeletedMessage_OnlyProcess": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1164)
 * 
 * + "X"; value = value.replace("{0}", "<Process Name>"); break; case
 * "Process_Can'tBeDeletedMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1186) + "X"; value =
 * value.replace("{0}", "<Entity Name>"); break; case "TagModalBoxMessage":
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(728) + "X";
 * 
 * temp = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(43) + "X";
 * 
 * value = value.replace("{1}", temp); value = value.toLowerCase(); value =
 * value.replace("{0}", "<Count>"); break; case "SingleTagModalBoxMessage":
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(731) + "X";
 * 
 * temp = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(399) + "X";
 * 
 * value = value.replace("{1}", temp); value = value.toLowerCase(); value =
 * value.replace("{0}", "<Count>"); break; case "SingleDCDefModalBoxMessage":
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(731) + "X";
 * 
 * temp = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(75) + "X";
 * 
 * value = value.replace("{1}", temp);
 * 
 * value = value.toLowerCase(); value = value.replace("{0}", "<Count>"); break;
 * case "DCDefModalBoxMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(728) + "X";
 * 
 * temp = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(792) + "X";
 * 
 * value = value.replace("{1}", temp);
 * 
 * value = value.toLowerCase(); value = value.replace("{0}", "<Count>"); break;
 * case "ModalBox_PartRecipe_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(799) + "X"; break; case
 * "PromptForSampleSize": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(714) + "X"; break; case
 * "OnStart": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(856) + "X"; break; case
 * "OnSave": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(857) + "X"; break; case
 * "SampleSizeValidatonMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(772) + "X"; value =
 * value.replace("{0}", "<SampleSize>");
 * 
 * break; case "SytemEnteredSampleTime": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(854) + "X"; break; case
 * "UserEnteredSampleTime": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(855) + "X"; break; case
 * "TimeStamp_ValidationForFutureDate": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1368) + "X"; break; case
 * "EnterSampleTime": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(716) + "X"; break; case
 * "PartRecipeModalBoxMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(728) + "X";
 * 
 * temp = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(739) + "X";
 * 
 * value = value.replace("{1}", temp); value = value.toLowerCase(); value =
 * value.replace("{0}", "<Count>"); break; case
 * "ModalBox_OperationDiagram_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(775) + "X"; break; case
 * "SingleOperationModalBoxMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(731) + "X";
 * 
 * temp = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(52) + "X";
 * 
 * value = value.replace("{1}", temp); value = value.toLowerCase(); value =
 * value.replace("{0}", "<Count>"); break; case
 * "ProcessPage_TagCount_MulitpleTag_Message": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(728) + "X"; value =
 * value.replace("{0}", "<TagCount>");
 * 
 * temp = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(43) + "X";
 * 
 * value = value.replace("{1}", temp); value = value.toLowerCase(); temp =
 * value; value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(194) + "X";
 * 
 * value = value + ": <ProcessName> "; value = value + temp; value =
 * value.replace("<tagcount>", "<TagCount>");
 * 
 * break; case "Unauthorized_Access_Page_Message": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(69) +
 * "XYou don't have permission to view this page.X" + "X"; break; case
 * "ProcessPage_TagCount_SingleTag_Message": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(731) + "X";
 * 
 * temp = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(399) + "X";
 * 
 * value = value.replace("{1}", temp); value = value.toLowerCase(); value =
 * value.replace("{0}", "<TagCount>"); temp = value; value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(194) + "X";
 * 
 * value = value + ": <ProcessName> "; value = value + temp; value =
 * value.replace("<tagcount>", "<TagCount>");
 * 
 * break; case "SaveSuccessfullyMessageForLimit": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(213) + "X"; value =
 * value.replace("{0}", "<PartName> - <FeatureName>");
 * 
 * break; case "Password_Change_Successful": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1028) + "X"; break; case
 * "UserConfiguredTagSaveSuccessfullyMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(623) + "X"; break; case
 * "ModalBox_SpecLimit_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(724) + "X"; break; case
 * "AllowModification": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(429) + "X"; break; case
 * "SpecNotificationMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(441) + "X" + "," + "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(442) + "X" +
 * "," + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(443) + "X" + "," + "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2145) + "X" +
 * " Notification Rule(s)";
 * 
 * break; case "ModalBox_DC_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(725) + "X"; break; case
 * "PS_SelectCodeHeaderTitle": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1460) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(843) + "X");
 * 
 * value = value .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1461) + "X");
 * 
 * break; case "PS_SelectProcessPopUpHeader_OpeationTitle": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(52) + "X" +
 * " - " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1472) + "X";
 * 
 * break; case "PS_SelectedProcessPopUpHeader_Title": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(1472) + "X";
 * break; case "AccordionItem_AssignedODMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(664) + "X"; break; case
 * "AccordionItem_ImpactedPartRecipe": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(596) + "X"; break; case
 * "Default_ParentProcess": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(601) + "X"; break; case
 * "AccordionItem_AssignedChildProcess": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1189) + "X"; break; case
 * "actualAccordionItem_AssignedSpecLimitMessage_Feature": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(566) + "X";
 * break; case "AccordionItem_AssignedSpecLimit": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(566) + "X"; break; case
 * "Create_Feature_Page_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(37) + "X"; break; case
 * "Spec_Page_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(182) + "X"; break; case
 * "Unauthorized_Access_Page_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(773) + "X"; break; case
 * "Role_Header_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(579) + "X"; break; case
 * "Create_Role_Page_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(546) + "X"; break;
 * 
 * case "Create_Part_Page_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(59) + "X"; break; case
 * "Set_Process_State_Page_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(943) + "X"; break; case
 * "Create_Part_Revision_Page_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(494) + "X"; break; case
 * "CodeGroup_Page_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(395) + "X"; break; case
 * "UserLandingPageTitle": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(646) + "X"; break; case
 * "Edit_Limit_Page_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(246) + "X"; break; case
 * "Edit_CodeGroup_Page_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(416) + "X"; break; case
 * "Create_Process_Page_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(238) + "X"; break; case
 * "ManualDCLandingPageTitle": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(732) + "X"; break; case
 * "TagGroup_Page_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(402) + "X"; break; case
 * "Configure_User_Tags_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(527) + "X"; break; case
 * "ModalBox_ViewCode_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(840) + "X"; break; case
 * "Create_User_Page_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(506) + "X"; break; case
 * "DCTagPopUpTitle_AllPieces": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1257) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(687) + "X");
 * 
 * break; case "CollectionAids_Page_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(844) + "X"; break; case
 * "Create_CollectionAids_Page_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(845) + "X"; break; case
 * "Edit_CollectionAids_Page_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(997) + "X"; break; case
 * "TagCount": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(399) + "XTag 1 of 1" + "X";
 * break; case "ParameterSet_Page_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1083) + "X"; break; case
 * "ModalBox_Operation_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(726) + "X"; break; case
 * "ModalBox_Tag_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(723) + "X"; break; case
 * "SelectProcessEntity_Page_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1460) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1080) + "X");
 * 
 * value = value .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1461) + "X"); break; case
 * "ModalBox_Reset_Password": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1029) + "X"; break; case
 * "ModalBox_Change_Password": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1340) + "X"; break; case
 * "Part_Header_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(76) + "X";
 * 
 * break; case "Process_Header_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1080) + "X"; break; case
 * "Spec_Header_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(4030) + "X"; break; case
 * "Feature_Header_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(80) + "X"; break; case
 * "DataCollectionConfiguration_Header_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(308) + "X"; break; case
 * "DataCollection_Header_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(732) + "X"; break; case
 * "CodeGroup_Header_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(393) + "X"; break; case
 * "TagGroup_Header_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1077) + "X"; break; case
 * "PartRecipeQuickAddition_Header_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(353) + "X"; break; case
 * "DCSetting_Header_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(427) + "X"; break; case
 * "Process_States_Grid_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(972) + "X"; break; case
 * "Configure_Process_States_Page_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(861) + "X"; break; case
 * "PartRevision_Header_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1211) + "X"; break; case
 * "Process_States_Header_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(832) + "X"; break; case
 * "Dashboard_Header_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(66) + "X"; break;
 * 
 * case "Individual_Settings_Page_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(600) + "X"; break; case
 * "ColumnName_Piece": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(195) + "X"; break; case
 * "ParameterSet_Header_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1082) + "X"; break; case
 * "GridProcessSelectedEntity": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1885) + "X"; break; case
 * "SelectProcessEntity_Header_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1463) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1080) + "X"); break; case
 * "SelectFeatureEntity_Header_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1463) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(80) + "X"); break; case
 * "SelectPartsEntity_Header_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1463) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(76) + "X");
 * 
 * break; case "ResponseGroup_Header_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2496) + "X"; break; case
 * "ControlLimit_Header_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1263) + "X"; break;
 * 
 * case "ColumnName_Part_Name": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(141) + "X"; break; case
 * "ColumnName_USL": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(184) + "X"; break; case
 * "ColumnName_LSL": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(188) + "X"; break; case
 * "ColumnName_Target": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(186) + "X"; break; case
 * "ColumnName_FeatureName": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(140) + "X"; break; case
 * "ColumnName_FeatureName_Spec": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2491) + "X"; break; case
 * "ColumnName_Lot": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(192) + "X"; break; case
 * "ColumnName_Process": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(194) + "X"; break; case
 * "ColumnName_URL": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(183) + "X"; break; case
 * "ColumnName_UWL": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(185) + "X"; break; case
 * "ColumnName_LWL": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(187) + "X"; break; case
 * "ColumnName_LRL": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(189) + "X"; break; case
 * "ColumnName_UWP": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(87) + "X"; break; case
 * "ColumnName_LWP": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(88) + "X"; break; case
 * "ColumnName_USG": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(89) + "X"; break; case
 * "ColumnName_LSG": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(90) + "X"; break; case
 * "ColumnName_TagGroup": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(871) + "X"; break; case
 * "ColumnName_CurrentState_Part": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(956) + "X"; break; case
 * "ColumnName_PreviousState_Part": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(957) + "X"; break; case
 * "ColumnName_ProcessState": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(933) + "X"; break; case
 * "ColumnName_StateType": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(870) + "X"; break; case
 * "ColumnName_ChangeIntitiation": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(839) + "X"; break; case
 * "ColumnName_MAVUpper": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(801) + "X"; break; case
 * "ColumnName_Max_MAVUpper": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(802) + "X"; break; case
 * "ColumnName_MAV_LSC": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(800) + "X"; break; case
 * "ColumnName_MAVLower": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(803) + "X"; break; case
 * "ColumnName_Max_MAVLower": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(804) + "X"; break; case
 * "ColumnName_T2Upper": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(806) + "X"; value =
 * value.replace("<sub>", ""); value = value.replace("</sub>", ""); break; case
 * "ColumnName_T1Upper": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(807) + "X"; value =
 * value.replace("<sub>", ""); value = value.replace("</sub>", ""); break; case
 * "ColumnName_T1T2Upper": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(808) + "X"; value =
 * value.replace("<sub>", ""); value = value.replace("</sub>", ""); break; case
 * "ColumnName_Max_T2Upper": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(809) + "X"; value =
 * value.replace("<sub>", ""); value = value.replace("</sub>", ""); break; case
 * "ColumnName_T1T2_LSC": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(805) + "X"; break; case
 * "ColumnName_T1Lower": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(811) + "X"; value =
 * value.replace("<sub>", ""); value = value.replace("</sub>", ""); break; case
 * "ColumnName_T2Lower": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(810) + "X"; value =
 * value.replace("<sub>", ""); value = value.replace("</sub>", ""); break; case
 * "ColumnName_Max_BetweenT1T2Lower": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(812) + "X"; value =
 * value.replace("<sub>", ""); value = value.replace("</sub>", ""); break; case
 * "ColumnName_MaxT2Lower": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(813) + "X"; value =
 * value.replace("<sub>", ""); value = value.replace("</sub>", ""); break; case
 * "ColumnName_UpdatedDate": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(136) + "X"; break; case
 * "ColumnName_LastUpdatedBy": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(711) + "X"; break; case
 * "ColumnName_CreationDate": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(134) + "X"; break; case
 * "ColumnName_CreatedBy": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(133) + "X"; break; case
 * "ColumnName_Image": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(50) + "X"; break; case
 * "ColumnName_FeatureType": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(139) + "X"; break; case
 * "ColumnName_Tag": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(399) + "X"; break; case
 * "ColumnName_DataCollection": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(21) + "X"; break; case
 * "ColumnName_SpecificationLimit": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(4029) + "X"; break; case
 * "ColumnName_Operation": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(52) + "X"; break; case
 * "ColumnName_ProcessName": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(240) + "X"; break; case
 * "ColumnName_ProcessCategory": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(69) + "XProcess CategoryX" +
 * "X"; break; case "ColumnName_OperationDiagram": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(67) + "X";
 * break; case "ColumnName_Status": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(453) + "X"; break; case
 * "ColumnName_PartRecipe": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(70) + "X"; break;
 * 
 * case "ColumnName_PartRevision": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(190) + "X"; break; case
 * "ColumnName_Units": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(191) + "X"; break; case
 * "ColumnName_DataCollectionDefinition": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(75) + "X"; break; case
 * "ColumnName_OperationDiagramName": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(132) + "X"; break; case
 * "ColumnName_Feature": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(33) + "X"; break; case
 * "ColumnName_PartFamily": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(32) + "X"; break; case
 * "ColumnName_Code": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(398) + "X"; break; case
 * "ColumnName_CodeGroup": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(42) + "X"; break; case
 * "ColumnName_Active": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(451) + "X"; break; case
 * "ColumnName_CodeName": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(396) + "X"; break; case
 * "ColumnName_Role": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(538) + "X"; break; case
 * "ColumnName_Supervisor_Name": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(541) + "X"; break; case
 * "ColumnName_Preferred_Language": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(543) + "X"; break; case
 * "ColumnName_Username": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(535) + "X"; break; case
 * "ColumnName_Email": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(534) + "X"; break; case
 * "ColumnName_Access_Level": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(539) + "X"; break; case
 * "ColumnName_Name": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(563) + "X"; break;
 * 
 * case "ColumnName_Weight": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(450) + "X"; break; case
 * "ColumnName_TagType": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(404) + "X"; break; case
 * "ColumnName_TextingNumber": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(540) + "X"; break; case
 * "ColumnName_TagGroupName": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(403) + "X"; break; case
 * "ColumnName_PartFamilyTitle": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(858) + "X"; value =
 * value.replace("{0}", "<Element Name>");
 * 
 * break; case "ColumnName_Part": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(68) + "X"; break; case
 * "ColumnName_ CollectionAid": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(844) + "X"; break; case
 * "ColumnName_ParentPrcoessName": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(35) + "X"; break; case
 * "ColumnName_Part_Family": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(576) + "X"; break; case
 * "PartNotExistsValidationMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2553) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(68) + "X");
 * 
 * break; case "ColumnName_ParameterSetName": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1086) + "X"; break; case
 * "ColumnName_Summary": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1095) + "X"; break; case
 * "ColumnName_Criteria": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1097) + "X"; break; case
 * "ColumnName_AssignedWorkDashboard": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2228) + "X"; break; case
 * "ManualDCLandingPageGridHeader": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(316) + "X"; break; case
 * "ColumnName_SelectedFeature": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1823) + "X"; break; case
 * "CodeGroupNotExist": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(462) + "X"; break; case
 * "ResponseGroupNotExist": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2501) + "X"; break; case
 * "ContextMenuUploadImage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(81) + "X"; break; case
 * "ContextMenuChangeImage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(48) + "X"; break; case
 * "ContextMenuRemoveImage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(49) + "X"; break; case
 * "LandingPage_ContextMenu_CreatePartRevisionIconText": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(389) + "X";
 * break; case "LandingPage_ContextMenu_HistoryIconText": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2368) + "X";
 * break;
 * 
 * case "LandingPage_ContextMenu_RemoveIconText": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(245) + "X"; break; case
 * "StateType_Idle": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(927) + "X"; break; case
 * "StateType_Pause": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(929) + "X"; break; case
 * "StateType_Run": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(926) + "X"; break; case
 * "StateType_ScheduledDown": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(930) + "X"; break; case
 * "StateType_Start": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(925) + "X"; break; case
 * "StateType_Stop": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(928) + "X"; break; case
 * "StateType_UnscheduledDown": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(931) + "X"; break; case
 * "TagType_Numeric": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(820) + "X"; break; case
 * "TagType_Textual": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(821) + "X"; break; case
 * "Status_Active": value = "0 - " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(451) + "X"; break; case
 * "Status_Inactive": value = "1 - " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(421) + "X"; break; case
 * "Status_Inactive_User": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(452) + "X"; break; case
 * "FeatureType_Variable": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(177) + "X"; break; case
 * "FeatureType_Defect": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(176) + "X"; break; case
 * "FeatureType_Defective": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(175) + "X"; break; case
 * "FeatureType_CheckList": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(127) + "X"; break;
 * 
 * case "ChangeIntitiation_Manual": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(951) + "X"; break; case
 * "FeatureType_Time": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(178) + "X"; break; case
 * "ChangeIntitiation_Automatic": value = "2 - " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(953) + "X"; break; case
 * "ChangeIntitiation_Event": value = "1 - " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(952) + "X"; break; case
 * "ParameterSetTimeZone_Latest": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1394) + "X"; break; case
 * "ParameterSetTimeZone_Current": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1392) + "X"; break; case
 * "ParameterSetTimeZone_Earlier": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1393) + "X"; break; case
 * "ParameterSetTimeUnit_Minute": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1395) + "X"; break; case
 * "ParameterSetTimeUnit_Hour": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1396) + "X"; break; case
 * "ParameterSetTimeUnit_Day": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1397) + "X"; break; case
 * "ParameterSetTimeUnit_Week": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1398) + "X"; break; case
 * "ParameterSetTimeUnit_Month": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1399) + "X"; break; case
 * "ParameterSetTimeUnit_Quarter": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1410) + "X"; break; case
 * "ParameterSetTimeUnit_Year": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1400) + "X"; break; case
 * "TimeSelectionType_Dynamic": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1390) + "X"; break; case
 * "TimeSelectionType_Static": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1391) + "X"; break; case
 * "Module_PartRevision": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(488) + "X"; break; case
 * "Module_Part": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(68) + "X"; break; case
 * "ResponseType_SingleAnswer": value = "1 - " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2487) + "X"; break; case
 * "ResponseType_MultipleAnswer": value = "2 - " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2488) + "X"; break; case
 * "FilterButtonTitle": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(797) + "X"; break;
 * 
 * case "ColumnName_ConfigureColumnTitle": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(697) + "X"; break; case
 * "CodeGroup_AddCodes": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(397) + "X"; break; case
 * "CodeGroup_CheckBoxLabel": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(454) + "X"; break; case
 * "Lable_SampleSize": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(255) + "X"; break; case
 * "Quantity": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2359) + "X"; break; case
 * "LBL_All_Pieces": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(687) + "X"; break; case
 * "Lable_Edit": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(85) + "X"; break; case
 * "Lable_Delete": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(29) + "X"; break; case
 * "Condition_And": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1152) + "X"; break; case
 * "Condition_OR": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(650) + "X"; break; case
 * "Condition_XOR": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1154) + "X"; break; case
 * "Condition_Is_Not": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1161) + "X"; break; case
 * "Condition_State_Is": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1183) + "X"; break; case
 * "Condition_State_Is_Not": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1184) + "X"; break; case
 * "Condition_Between": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1163) + "X"; break; case
 * "TotalCount": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(686) + "X";
 * 
 * value = value.replace("{0}", "<count>");
 * 
 * break; case "Condition_Equals": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1162) + "X"; break; case
 * "Condition_Is": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1160) + "X"; break; case
 * "Label_Part": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(68) + "X"; break; case
 * "LicenseType_Username": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(535) + "X"; break; case
 * "LicenseType_Workstation": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1049) + "X"; break; case
 * "SelectFeature_Exclude": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1460) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(80) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1462) + "X");
 * 
 * break; case "SelectPart_Exclude": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1460) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(76) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1462) + "X");
 * 
 * break; case "SelectProcess_Exclude": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1460) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1080) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1462) + "X"); break; case
 * "SelectTag_Exclude":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1460) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(43) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1462) + "X");
 * 
 * break; case "SelectFeature_Include": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1460) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(80) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1461) + "X");
 * 
 * break; case "SelectPart_Include": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1460) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(76) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1461) + "X");
 * 
 * break; case "SelectProcess_Include":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1460) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1080) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1461) + "X");
 * 
 * break; case "SelectTag_Include": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1460) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(43) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1461) + "X");
 * 
 * break; case "ColumnName_SelectAll": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1455) + "X"; break; case
 * "Lable_Process": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(194) + "X"; break; case
 * "AssignedDashboard_No": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(460) + "X"; break; case
 * "ParameterSet_None": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1524) + "X"; break; case
 * "ParameterSet_TagNotExists": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2553) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(871) + "X");
 * 
 * break; case "GridFeatureSelectedEntity": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1887) + "X"; break; case "To":
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(344) + "X"; break; case
 * "SelectCode_Exclude": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1460) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(843) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1462) + "X");
 * 
 * break; case "HelperText_TypeSelect": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(63) + "X"; break; case
 * "HelperText_Select": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(30) + "X"; break; case
 * "No_Record_Found": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(65) + "X"; break; case
 * "Password_Guidelines": temp = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1026) + "X"; temp =
 * temp.replace("{0}", "8");
 * 
 * temp1 = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1307) + "X"; temp1 = temp1 +
 * " [ ] ? / < > ~ # ` ! @ _ - $ % ^ & * ( ) + = { } | : \" ; ' ,";
 * 
 * temp2 = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1025) + "X"; temp2 =
 * temp2.replace("{0}", "365");
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1020) + "X" + "\n" + temp
 * 
 * + "\n" + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1021) + "X" + "\n" + "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(1308) + "X" +
 * "\n" + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1315) + "X" + "\n" + temp1 +
 * "\n" + temp2; break; case "Password_Guidelines_Change_Password":
 * 
 * temp = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1026) + "X"; temp =
 * temp.replace("{0}", "8");
 * 
 * temp1 = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1307) + "X"; temp1 =
 * temp.replace("{0}", "{}[]^$@%()...");
 * 
 * temp2 = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1309) + "X"; temp2 =
 * temp.replace("{0}", "5");
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1020) + "X" + "\n\n" + "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(1314) + "X" +
 * "\n" + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1314) + "X" + "\n" + "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(1308) + "X" +
 * "\n" + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1315) + "X" + "\n" + temp1 +
 * "\n" + temp2 + "X"; break; case "HelperText_Type": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(41) + "X";
 * break; case "PS_FilterCountText": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2445) + "X"; break; case
 * "CodeName_PlaceHolder": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(455) + "X"; break; case
 * "USL_gt_LRL_LWL_Target_UWL_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(149) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(184) + "X"); temp = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(189) + "X" +
 * ", " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(187) + "X" + ", " + "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(186) + "X";
 * value = value.replace("{1}", temp);
 * 
 * value = value .replace( "{2}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(185) + "X");
 * 
 * break; case "Target_lt_USL_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(214) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(186) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(184) + "X");
 * 
 * break; case "UWL_lt_USL_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(214) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(185) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(184) + "X");
 * 
 * break; case "LWL_lt_USL_ErrorMessage":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(214) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(187) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(184) + "X");
 * 
 * break; case "LRL_lt_USL_ErrorMessage":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(214) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(189) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(184) + "X");
 * 
 * break; case "URL_gt_Target_UWL_USL_ErrorMessage": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(149) + "X";
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(183) + "X"); temp = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(186) + "X" +
 * ", " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(185) + "X"; value =
 * value.replace("{1}", temp);
 * 
 * value = value .replace( "{2}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(184) + "X");
 * 
 * break; case "LSL_lt_LWL_Target_UWL_URL_ErrorMessage": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(150) + "X";
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(188) + "X"); temp = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(187) + "X" +
 * ", " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(186) + "X" + ", " + "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(185) + "X" +
 * ", " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(184) + "X"; value =
 * value.replace("{1}", temp);
 * 
 * value = value .replace( "{2}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(183) + "X");
 * 
 * break; case "LSG_lt_USG_ErrorMessage":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(214) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(90) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(89) + "X");
 * 
 * break; case "USG_gt_LSG_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(215) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(89) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(90) + "X");
 * 
 * break; case "LWP_lt_UWP_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(214) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(88) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(87) + "X");
 * 
 * break; case "UWP_gt_LWP_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(215) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(87) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(88) + "X");
 * 
 * break; case "UWL_gt_LWL_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(215) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(185) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(187) + "X");
 * 
 * break; case "LWL_lt_UWL_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(214) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(187) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(185) + "X");
 * 
 * break; case "LSL_gt_LRL_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(215) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(188) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(189) + "X");
 * 
 * break; case "LRL_lt_LSL_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(214) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(189) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(188) + "X");
 * 
 * break; case "USL_lt_URL_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(214) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(184) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(183) + "X");
 * 
 * break; case "URL_gt_USL_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(215) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(183) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(184) + "X");
 * 
 * break; case "LSL_lt_LWL_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(214) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(188) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(187) + "X");
 * 
 * break; case "LWL_gt_LRL_LSL_ErrorMessage":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(149) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(187) + "X"); temp = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(189) + "X";
 * value = value.replace("{1}", temp);
 * 
 * value = value .replace( "{2}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(188) + "X");
 * 
 * break; case "LRL_lt_LWL_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(214) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(189) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(187) + "X");
 * 
 * break; case "UWL_lt_USL_URL_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(150) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(185) + "X"); temp = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(184) + "X";
 * value = value.replace("{1}", temp);
 * 
 * value = value .replace( "{2}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(183) + "X");
 * 
 * break; case "URL_gt_UWL_USL_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(149) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(183) + "X"); temp = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(185) + "X";
 * value = value.replace("{1}", temp);
 * 
 * value = value .replace( "{2}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(184) + "X");
 * 
 * break; case "USL_gt_LWL_Target_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(149) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(184) + "X"); temp = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(187) + "X";
 * value = value.replace("{1}", temp);
 * 
 * value = value .replace( "{2}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(186) + "X");
 * 
 * break; case "LWL_lt_Target_USL_URL_ErrorMessage": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(150) + "X";
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(187) + "X"); temp = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(186) + "X" +
 * ", " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(184) + "X"; value =
 * value.replace("{1}", temp);
 * 
 * value = value .replace( "{2}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(183) + "X");
 * 
 * break; case "URL_gt_LWL_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(215) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(183) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(187) + "X");
 * 
 * break; case "LSL_lt_Target_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(214) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(188) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(186) + "X");
 * 
 * break; case "Target_gt_LRL_LSL_LWL_ErrorMessage": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(149) + "X";
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(186) + "X"); temp = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(189) + "X" +
 * ", " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(188) + "X"; value =
 * value.replace("{1}", temp);
 * 
 * value = value .replace( "{2}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(187) + "X");
 * 
 * break; case "LWL_lt_Target_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(214) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(187) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(186) + "X");
 * 
 * break; case "LRL_lt_LSL_Target_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(150) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(189) + "X"); temp = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(188) + "X";
 * value = value.replace("{1}", temp);
 * 
 * value = value .replace( "{2}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(186) + "X");
 * 
 * break; case "Target_lt_UWL_USL_URL_ErrorMessage": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(150) + "X";
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(186) + "X"); temp = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(185) + "X" +
 * ", " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(184) + "X"; value =
 * value.replace("{1}", temp);
 * 
 * value = value .replace( "{2}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(183) + "X");
 * 
 * break; case "LSL_lt_UWL_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(214) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(188) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(185) + "X");
 * 
 * break; case "Target_lt_UWL_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(214) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(186) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(185) + "X");
 * 
 * break; case "UWL_gt_LRL_LSL_LWL_Target_ErrorMessage": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(149) + "X";
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(185) + "X"); temp = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(189) + "X" +
 * ", " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(188) + "X" + ", " + "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(187) + "X";
 * value = value.replace("{1}", temp);
 * 
 * value = value .replace( "{2}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(186) + "X");
 * 
 * break; case "LRL_lt_UWL_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(214) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(189) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(185) + "X"); break; case
 * "URL_gt_LRL_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(215) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(183) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(189) + "X");
 * 
 * break; case "LRL_lt_URL_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(214) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(189) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(183) + "X");
 * 
 * break; case "USL_gt_LSL_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(215) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(184) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(188) + "X");
 * 
 * break; case "LSL_lt_USL_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(214) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(188) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(184) + "X");
 * 
 * break; case "LWL_lt_Target_UWL_USL_URL_ErrorMessage": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(150) + "X";
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(187) + "X"); temp = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(186) + "X" +
 * ", " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(185) + "X" + ", " + "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(184) + "X";
 * value = value.replace("{1}", temp);
 * 
 * value = value .replace( "{2}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(183) + "X");
 * 
 * break; case "URL_gt_LRL_LSL_LWL_Target_UWL_USL_ErrorMessage": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(149) + "X";
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(183) + "X"); temp = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(189) + "X" +
 * ", " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(188) + "X" + ", " + "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(187) + "X" +
 * ", " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(186) + "X" + ", " + "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(185) + "X";
 * value = value.replace("{1}", temp);
 * 
 * value = value .replace( "{2}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(184) + "X");
 * 
 * break; case "LRL_lt_LSL_LWL_Target_UWL_USL_URL_ErrorMessage": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(150) + "X";
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(189) + "X"); temp = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(188) + "X" +
 * ", " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(187) + "X" + ", " + "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(186) + "X" +
 * ", " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(185) + "X" + ", " + "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(184) + "X";
 * value = value.replace("{1}", temp);
 * 
 * value = value .replace( "{2}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(183) + "X");
 * 
 * break; case "UWL_lt_URL_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(214) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(185) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(183) + "X");
 * 
 * break; case "LWL_lt_URL_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(214) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(187) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(183) + "X");
 * 
 * break; case "URL_gt_LSL_LWL_Target_UWL_USL_ErrorMessage": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(149) + "X";
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(183) + "X"); temp = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(188) + "X" +
 * ", " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(187) + "X" + ", " + "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(186) + "X" +
 * ", " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(185) + "X"; value =
 * value.replace("{1}", temp);
 * 
 * value = value .replace( "{2}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(184) + "X");
 * 
 * break; case "USL_gt_UWL_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(215) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(184) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(185) + "X");
 * 
 * break; case "URL_gt_UWL_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(215) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(183) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(185) + "X");
 * 
 * break; case "Password_Not_Changed_Successfully": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(69) +
 * "XPassword reset unsuccessful. Please try again.X" + "X"; break; case
 * "InvalidCode": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1212) + "X"; break; case
 * "InvalidValueValidationMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(464) + "X"; break; case
 * "Password_Changed_Successfully": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1216) + "X"; break; case
 * "Activation_Start_Date_Greater_Than_End_Date": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(594) + "X"; break; case
 * "LWL_gt_LSL_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(215) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(187) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(188) + "X");
 * 
 * break; case "URL_gt_LSL_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(215) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(183) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(188) + "X");
 * 
 * break; case "Password_Reset_Unsuccessful": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1027) + "X"; break; case
 * "Password_Change_Unsuccessful": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1346) + "X"; break; case
 * "Password_Expired_Message": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(633) + "X"; break; case
 * "T2_lt_T1_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(214) + "X";
 * 
 * value = value .replace( "{0}", "T2 " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(518) + "X"); value = value
 * .replace( "{1}", "T1 " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(518) + "X");
 * 
 * break; case "T2_lt_LSC_T1_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(150) + "X"; value = value
 * .replace( "{0}", "T2 " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(518) + "X"); temp = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(511) + "X";
 * value = value.replace("{1}", temp);
 * 
 * value = value .replace( "{2}", "T1 " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(518) + "X");
 * 
 * break; case "LSC_gt_T1_T2_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(149) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(511) + "X"); temp = "T1 " + "X"
 * + UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(518) + "X";
 * value = value.replace("{1}", temp);
 * 
 * value = value .replace( "{2}", "T2 " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(518) + "X"); break; case
 * "T1_lt_LSC_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(214) + "X";
 * 
 * value = value .replace( "{0}", "T1 " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(518) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(511) + "X");
 * 
 * break; case "LSC_gt_MAVLower_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(215) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(511) + "X"); value = value
 * .replace( "{1}", "MAV " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(518) + "X");
 * 
 * break; case "MAVUpper_gt_MAVLower_ErrorMessage": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(215) + "X";
 * 
 * value = value .replace( "{0}", "MAV " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(517) + "X"); value = value
 * .replace( "{1}", "MAV " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(518) + "X");
 * 
 * break; case "MAVLower_lt_LSC_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(214) + "X";
 * 
 * value = value .replace( "{0}", "MAV " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(518) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(511) + "X");
 * 
 * break; case "MAVLower_lt_LSC_MAVUpper_ErrorMessage": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(150) + "X";
 * value = value .replace( "{0}", "MAV " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(518) + "X"); temp = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(511) + "X";
 * value = value.replace("{1}", temp);
 * 
 * value = value .replace( "{2}", "MAV " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(517) + "X");
 * 
 * break; case "LSC_lt_MAVUpper_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(214) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(511) + "X"); value = value
 * .replace( "{1}", "MAV " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(517) + "X");
 * 
 * break; case "MAVUpper_gt_LSC_MAVLower_ErrorMessage": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(149) + "X";
 * value = value .replace( "{0}", "MAV " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(517) + "X"); temp = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(511) + "X";
 * value = value.replace("{1}", temp);
 * 
 * value = value .replace( "{2}", "MAV " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(518) + "X"); break; case
 * "MAVLower_lt_MAVUpper_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(214) + "X";
 * 
 * value = value .replace( "{0}", "MAV " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(518) + "X"); value = value
 * .replace( "{1}", "MAV " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(517) + "X");
 * 
 * break; case "T1Lower_lt_T2Upper_T1Upper_LSC_ErrorMessage": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(150) + "X";
 * value = value .replace( "{0}", "T1 " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(518) + "X"); temp = "T2 " + "X"
 * + UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(517) + "X" +
 * ", " + "T1 " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(517) + "X"; value =
 * value.replace("{1}", temp);
 * 
 * value = value .replace( "{2}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(511) + "X");
 * 
 * break; case "T2Lower_lt_T2Upper_T1Upper_LSC_T1Lower_ErrorMessage": value =
 * "X" + UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(150) +
 * "X"; value = value .replace( "{0}", "T2 " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(518) + "X"); temp = "T2 " + "X"
 * + UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(517) + "X" +
 * ", " + "T1 " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(517) + "X" + ", " + "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(511) + "X";
 * value = value.replace("{1}", temp);
 * 
 * value = value .replace( "{2}", "T1 " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(518) + "X");
 * 
 * break; case "T2Lower_lt_LSC_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(214) + "X";
 * 
 * value = value .replace( "{0}", "T2 " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(518) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(511) + "X");
 * 
 * break;
 * 
 * case "T2Lower_lt_T1Upper_LSC_T1Lower_ErrorMessage": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(150) + "X";
 * value = value .replace( "{0}", "T2 " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(518) + "X"); temp = "T1 " + "X"
 * + UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(517) + "X" +
 * ", " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(511) + "X"; value =
 * value.replace("{1}", temp);
 * 
 * value = value .replace( "{2}", "T1 " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(518) + "X");
 * 
 * break; case "T1Lower_lt_T1Upper_LSC_ErrorMessage": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(150) + "X";
 * value = value .replace( "{0}", "T1 " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(518) + "X"); temp = "T1 " + "X"
 * + UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(517) + "X";
 * value = value.replace("{1}", temp);
 * 
 * value = value .replace( "{2}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(511) + "X");
 * 
 * break; case "T1_gt_T2_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(215) + "X";
 * 
 * value = value .replace( "{0}", "T1 " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(518) + "X"); value = value
 * .replace( "{1}", "T2 " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(518) + "X");
 * 
 * break; case "T2Lower_lt_T1Upper_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(214) + "X";
 * 
 * value = value .replace( "{0}", "T2 " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(518) + "X"); value = value
 * .replace( "{1}", "T1 " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(517) + "X");
 * 
 * break; case "T1Lower_lt_T1Upper_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(214) + "X";
 * 
 * value = value .replace( "{0}", "T1 " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(518) + "X"); value = value
 * .replace( "{1}", "T1 " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(517) + "X");
 * 
 * break; case "T1Upper_lt_T2Upper_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(214) + "X";
 * 
 * value = value .replace( "{0}", "T1 " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(517) + "X"); value = value
 * .replace( "{1}", "T2 " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(517) + "X");
 * 
 * break; case "T2Lower_gt_T1Upper_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(215) + "X";
 * 
 * value = value .replace( "{0}", "T2 " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(517) + "X"); value = value
 * .replace( "{1}", "T1 " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(517) + "X");
 * 
 * break; case "LSC_lt_T2Upper_T1Upper_ErrorMessage": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(150) + "X";
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(511) + "X"); temp = "T2 " + "X"
 * + UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(517) + "X";
 * value = value.replace("{1}", temp);
 * 
 * value = value .replace( "{2}", "T1 " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(517) + "X");
 * 
 * break; case "T2Upper_gt_LSC_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(215) + "X";
 * 
 * value = value .replace( "{0}", "T2 " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(517) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(511) + "X");
 * 
 * break; case "LSC_gt_T1Lower_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(215) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(511) + "X"); value = value
 * .replace( "{1}", "T1 " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(518) + "X");
 * 
 * break; case "T2Upper_gt_T1Lower_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(215) + "X";
 * 
 * value = value .replace( "{0}", "T2 " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(517) + "X"); value = value
 * .replace( "{1}", "T1 " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(518) + "X");
 * 
 * break; case "T1Upper_gt_T1Lower_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(215) + "X";
 * 
 * value = value .replace( "{0}", "T1 " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(517) + "X"); value = value
 * .replace( "{1}", "T1 " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(518) + "X");
 * 
 * break; case "T1Upper_gt_Lsc_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(215) + "X";
 * 
 * value = value .replace( "{0}", "T1 " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(517) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(511) + "X");
 * 
 * break; }
 * 
 * // call second method if (value.equals("")) value =
 * mapMultiLingualSheet1(key); } catch (Exception e) { e.printStackTrace(); }
 * return value; }
 * 
 * private static String mapMultiLingualSheet1(String key) {
 * 
 * String value = ""; String temp = "";
 * 
 * try {
 * 
 * switch (key) { case "T1Upper_gt_T2Lower_ErrorMessage": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(215) + "X";
 * value = value .replace( "{0}", "T1 " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(517) + "X"); value = value
 * .replace( "{1}", "T2 " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(518) + "X");
 * 
 * break; case "LSC_gt_T2Lower_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(215) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(511) + "X"); value = value
 * .replace( "{1}", "T2 " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(518) + "X");
 * 
 * break; case "T2Upper_gt_T2Lower_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(215) + "X";
 * 
 * value = value .replace( "{0}", "T2 "
 * 
 * + "X" + UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(517) +
 * "X"); value = value .replace( "{1}", "T2 " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(518) + "X");
 * 
 * break; case "MAVUpper_gt_LSC_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(215) + "X"; value = value
 * .replace( "{0}", UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(4035) + " " + "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(517) + "X");
 * value = value .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(511) + "X");
 * 
 * break; case "T2Upper_gt_T1Upper_LSC_T1Lower_T2Lower_ErrorMessage": value =
 * "X" + UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(149) +
 * "X";
 * 
 * value = value .replace( "{0}", "T2 "
 * 
 * + "X" + UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(517) +
 * "X"); value = value .replace( "{1}", "T1 " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(517) + "X" + ", " + "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(511) + "X" +
 * ", T1 " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(518) + "X");
 * 
 * value = value .replace( "{2}", "T2 " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(518) + "X");
 * 
 * break; case "T1Upper_gt_LSC_T1Lower_T2Lower_ErrorMessage": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(149) + "X";
 * 
 * value = value .replace( "{0}", "T1 "
 * 
 * + "X" + UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(517) +
 * "X"); value = value .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(511) + "X" + ", T1 " + "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(518) + "X");
 * 
 * value = value .replace( "{2}", "T2 " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(518) + "X");
 * 
 * break; case "LSC_lt_T1Upper_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(214) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(511) + "X"); value = value
 * .replace( "{1}", "T1 " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(517) + "X");
 * 
 * break; case "Part_Is_Inactive": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(476) + "X"; break; case
 * "Part_Feature_Existing_Combination_Message": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(959) + "X";
 * 
 * break; case "Process_Not_Exists": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2553) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(194) + "X");
 * 
 * break; case "TagGroupName_Already_Exists": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(465) + "X";
 * 
 * break; case "MinValue_lt_MaxValue": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(448) + "X";
 * 
 * break; case "MaxValue_gt_MinValue": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(449) + "X";
 * 
 * break; case "FeatureNotExistsValidationMessage": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2553) + "X";
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(33) + "X");
 * 
 * break; case "InvalidMaxValueValidationMessage": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2374) + "X";
 * 
 * break; case "InvalidMinValueValidationMessage": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2375) + "X";
 * 
 * break; case "EndDateTimeCannotLessThanStartDateTime": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(1404) + "X";
 * 
 * break; case "NewAndConfirmPasswordMismatch": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2540) + "X";
 * 
 * break; case "Part_Not_Exists": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2533) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(68) + "X");
 * 
 * break; case "PopOverPieceSpecLimit": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(108) + "X"; break; case
 * "Selected_Process": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1144) + "X";
 * 
 * break; case "Would_You_Like_To_Continue": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(470) + "X";
 * 
 * break; case "ValueBelowReasonableLimit_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2393) + "X"; break; case
 * "ValueAboveReasonableLimit_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(430) + "X";
 * 
 * break; case "OutOfSpecificationLimits_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(314) + "X"; value =
 * value.replace("{0}", "<Part>");
 * 
 * value = value.replace("{1}", "<Feature>"); break; case
 * "SelectPartPopUpHeader_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(32) + "X" + " - " + "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(1431) + "X";
 * 
 * break; case "UnreasonableValueEntered": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(939) + "X"; break; case
 * "ValueMustBeWithinResonableLimit": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(940) + "X"; break; case
 * "OutOfWarningLimits_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(474) + "X"; value =
 * value.replace("{0}", "<Part>");
 * 
 * value = value.replace("{1}", "<Feature>");
 * 
 * break; case "RemoveEntityPopupTitle": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(568) + "X"; value =
 * value.replace("{0}", "<Element Name>"); break; case
 * "IndividualSettings_AllValueRequired": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(610) + "X"; break; case
 * "IndividualSettings_AtLeastOneValueRequired": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(611) + "X"; break; case
 * "IndividualSettings_NoValueRequired": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(612) + "X"; break; case
 * "IndividualSettings_ValueOnly": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(622) + "X"; break; case
 * "IndividualSettings_ValueAndRequiredCode": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(616) + "X"; break; case
 * "IndividualSettings_ValueAndOptionalCode": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(617) + "X"; break; case
 * "IndividualSettings_AllValues": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(853) + "X"; break; case
 * "IndividualSettings_ReasonableValuesOnly": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(852) + "X"; break; case
 * "IndividualSettings_CodeOnly": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(619) + "X"; break; case
 * "ProcessState_History_Last_20": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2368) + "X" + " (" + "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(1062) + "X" +
 * ")";
 * 
 * break; case "Part_InActivation_Validation_Message": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(1253) + "X";
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(4083) + "X"); break; case
 * "Process_State_Idle": value = "3 - " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(927) + "X"; break; case
 * "Process_State_Pause": value = "5 - " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(929) + "X";
 * 
 * break; case "Process_State_Run": value = "2 - " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(926) + "X";
 * 
 * break; case "Process_State_ScheduledDown": value = "6 - " + "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(930) + "X";
 * 
 * break; case "Process_State_Start": value = "1 - " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(925) + "X";
 * 
 * break; case "Process_State_Stop": value = "4 - " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(928) + "X";
 * 
 * break; case "Process_State_UnscheduledDown": value = "7 - " + "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(931) + "X";
 * 
 * break;
 * 
 * case "Permissions_Create": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(522) + "X"; break; case
 * "Permissions_View": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(523) + "X"; break; case
 * "Permissions_CreateRevision": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(389) + "X"; break; case
 * "Permissions_Edit": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(85) + "X"; break; case
 * "Permissions_Remove": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(245) + "X"; break; case
 * "Permissions_EditUniqueId": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(524) + "X"; break; case
 * "Permissions_Release": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(589) + "X"; break; case
 * "Permissions_ViewHistory": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(3032) + "X"; break; case
 * "FilterApplied": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2445) + "X"; break; case
 * "FiltersApplied": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2420) + "X"; break; case
 * "InActivation_Date_Message": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(971) + "X"; break; case
 * "MDC_AddLotDetails": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1544) + "X"; break; case
 * "MDC_ConfirmationMessageDataCollection": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1655) + "X"; break; case
 * "OutOfWithInPieceLimits_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2031)
 * 
 * + "X"; value = value.replace("{0}", "<Part>"); value = value.replace("{1}",
 * "<Feature>");
 * 
 * break; case "Lot_TestingReleased": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2351) + "X"; break; case
 * "ViewCodeModalBoxMessage":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(842) + "X"; value =
 * value.replace("{0}", "<CodeGroupName>");
 * 
 * temp = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(731) + "X";
 * 
 * temp = temp .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(398) + "X"); temp =
 * temp.toLowerCase(); temp = temp.replace("{0}", "<Count>");
 * 
 * value = value + " " + temp;
 * 
 * break; case "MDC_MissingValue_HeaderTitle": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2013) + "X"; break; case
 * "MDC_MissingValueConfirmationMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2014)
 * 
 * + "X"; break; case "Create_Lot_Page_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2349) + "X"; break; case
 * "MDC_CreateLot_ConfirmationMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2595) + "X"; value =
 * value.replace("{0}", "<LotName>"); break; case
 * "Checklist_Default_Processes_Selected": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1832) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1245) + "X");
 * 
 * break; case "Checklist_Assignment_Grid_Label": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(354)
 * 
 * + "X"; break; case "Checklist_Process_Label": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(194) + "X"; break; case
 * "Checklist_Name_Header": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(563) + "X"; break; case
 * "Checklist_Assignee_Header": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1285) + "X"; break; case
 * "Checklist_Header_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2650) + "X"; break; case
 * "Checklist_BasicInformation_Section_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1316) + "X"; break; case
 * "Checklist_ProcessSelection_Section_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2533) + "X"; break; case
 * "Checklist_EventGeneration_Section_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2535) + "X"; break; case
 * "Checklist_Assignment_Section_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1288) + "X"; break; case
 * "Checklist_Preview": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2554) + "X"; break; case
 * "ColumnName_Checklist": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(127) + "X"; break; case
 * "Checklist_Create": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2524) + "X"; break; case
 * "DefineCondition": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1056) + "X"; break; case
 * "DefineAction": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1102) + "X"; break; case
 * "RequirementCondition": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1103) + "X"; break; case
 * "RequirementWindow": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1233) + "X"; break; case
 * "Test Requirement Condition": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1219) + "X"; break; case
 * "Clear": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(51) + "X"; break; case
 * "If True": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1282) + "X"; break;
 * 
 * case "DefineActionTabTitle": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1109) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2598) + "X"); break; case
 * "SpecifyTime": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1107) + "X"; break; case
 * "RunOnce": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1110) + "X"; break; case
 * "DefineFrequency": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1111) + "X"; break; case
 * "Every": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1112) + "X"; break; case
 * "SpecifyTime_FromLastDataCollection": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1113) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(21) + "X"); break; case
 * "SpecifyTime_BasedOnReference": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1114) + "X"; break; case
 * "Days": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1120) + "X"; break; case
 * "Hours": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1119) + "X"; break; case
 * "Minutes": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1118) + "X"; break; case
 * "SpecifyTime_ResetFrequencyOnPartChange": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1115) + "X"; break; case
 * "SpecifyProcess": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1108) + "X"; break; case
 * "Deadline": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1228) + "X"; break; case
 * "SetWindowTabTitle": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1227) + "X"; break; case
 * "SetWindow_AfterScheduledOccurrence": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1229) + "X"; break; case
 * "SetWindow_BeforeScheduledOccurrence": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1232) + "X"; break; case
 * "SetWindow_MarkTheDataCollectionLateIfNotCollected": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(1230)
 * 
 * + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2598) + "X"); break; case
 * "EarlyReminder": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1231) + "X"; break; case
 * "Reminder": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1332) + "X"; break; case
 * "Occurrence": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1333) + "X"; break; case
 * "EditExisting": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1099) + "X"; break; case
 * "CreateNew": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(409) + "X"; break;
 * 
 * case "Feature_AlreadyExists": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(300) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(33) + "X");
 * 
 * break; case "Checklist_DefectTypeFeatureCannotBeSelected": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2498) + "X";
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(176) + "X");
 * 
 * break; case "Checklist_DefectiveTypeFeatureCannotBeSelected": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2498) + "X";
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(175) + "X");
 * 
 * break; case "Checklist_VariableTypeFeatureCannotBeSelected": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2498) + "X";
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(177) + "X"); break; case
 * "ColumnName_None": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1524) + "X"; break; case
 * "Checklist_AlreayExists": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(128) + "X"; break; case
 * "Checklist_Role": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(538) + "X"; break; case
 * "Checklist_User": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(508) + "X"; break; case
 * "Checklist_Workstation": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1049) + "X"; break; case
 * "Months": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1289) + "X"; break; case
 * "Weeks": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1249) + "X"; break; case
 * "Years": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1250) + "X"; break; case
 * "Late": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1334) + "X"; break; case
 * "LotNotExistsValidationMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2553) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(192) + "X"); break; case
 * "LotUniquenessValidationMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2361) + "X"; break; case
 * "MDC_DataCollectionType_PopupTitle": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2823) + "X"; break;
 * 
 * case "Checklist_RoleAlreadyExists": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(300) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(538) + "X");
 * 
 * break; case "Checklist_UserAlreadyExists": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(300) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(508) + "X");
 * 
 * break; case "Checklist_WorkstationAlreadyExists": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(300) + "X";
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1049) + "X");
 * 
 * break; case "Checklist_RoleNotExists": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2553) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(538) + "X");
 * 
 * break; case "Checklist_UserNotExists": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2553) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(508) + "X");
 * 
 * break; case "Checklist_WorkstationNotExists": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2553) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1049) + "X"); break;
 * 
 * case "Checklist_PreviewHeader": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2555) + "X"; value =
 * value.replace("{0}", "<Element Name>"); break; case "Preview": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2554) + "X";
 * break; case "AccordionItem_ChecklistFeature": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(605) + "X"; value =
 * value.replace("{0}", "<Element Name>");
 * 
 * break; case "Checklist_DeleteConfirmaitonMessageWithAssociations": value =
 * "X" + UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2557) +
 * "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2610) + "X");
 * 
 * break; case "DeleteConfirmaitonMessageWithOutAssociations": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(567) + "X";
 * value = value.replace("{0}", "<Element Name>"); break; case "RemovalTitle":
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(568) + "X"; value =
 * value.replace("{0}", "<Element Name>"); break; case
 * "Checklist_SingleTagPopUp_Header":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(127) + "X" +
 * ": <ChecklistName> ";
 * 
 * temp = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(731) + "X";
 * 
 * temp = temp .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(399) + "X"); temp =
 * temp.toLowerCase(); temp = temp.replace("{0}", "<Count>");
 * 
 * value = value + temp; break;
 * 
 * case "Preview_Comment_Placeholder": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2560) + "X"; break; case
 * "Preview_Response_Placeholder": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2561) + "X"; break; case
 * "User_Popup_Header": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(829) + "X"; break; case
 * "SelectProcesses": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1123) + "X"; break; case
 * "ConditionDoenstExist": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2553) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1155) + "X");
 * 
 * break; case "LateTimeMustBeLessThanDeadline": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1294) + "X"; break; case
 * "Conditions": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1059) + "X"; break; case
 * "USL_gt_LRL_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(215) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(184) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(189) + "X");
 * 
 * break; case "TSL_gt_LRL_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(215) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(186) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(189) + "X");
 * 
 * break; case "LWL_gt_LRL_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(215) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(187) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(189) + "X");
 * 
 * break; case "UWL_gt_LRL_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(215) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(185) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(189) + "X");
 * 
 * break; case "Target_gt_LSL_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(215) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(186) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(188) + "X");
 * 
 * break; case "UWL_gt_LSL_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(215) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(185) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(188) + "X");
 * 
 * break; case "LRL_lt_Target_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(214) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(189) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(186) + "X");
 * 
 * break; case "USL_gt_Target_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(215) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(184) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(186) + "X");
 * 
 * break; case "URL_gt_Target_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(215) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(183) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(186) + "X");
 * 
 * break; case "UWL_gt_Target_ErrorMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(215) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(185) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(186) + "X");
 * 
 * break;
 * 
 * case "DCRequirement_PageTitle": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1073) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(21) + "X");
 * 
 * break; case "ContinueButton": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(734) + "X"; break; case
 * "SampleSize_SubTitle": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(733) + "X"; break;
 * 
 * case "ConfirmationMessageForTotalCountLessThanOrEqualTo999": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(814) + "X";
 * value = value.replace("{0}", "100000000"); break; case
 * "ResponseGroup_OneActiveChoiceMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2507) + "X"; break; case
 * "ResponseGroup_FeaturePopUp_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2518) + "X"; break; case
 * "ResponseGroup_SingleFeaturePopUp_Header":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2517) + "X"; value =
 * value.replace("{0}", "<RespGroupName>");
 * 
 * temp = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(731) + "X";
 * 
 * temp = temp .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(33) + "X"); temp =
 * temp.toLowerCase(); temp = temp.replace("{0}", "<Count>");
 * 
 * value = value + " " + temp;
 * 
 * break; case "ResponseGroup_RemovalMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(567) + "X"; value =
 * value.replace("{0}", "<RespGroupName>");
 * 
 * break; case "ResponseGroup_RemovalTitle": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(568) + "X"; value =
 * value.replace("{0}", "<RespGroupName>"); break; case
 * "ResponseGroup_RemovedSuccessfullyMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(472) + "X"; value =
 * value.replace("{0}", "<RespGroupName>"); break; case
 * "ColumnName_QuestionText": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2489) + "X"; break;
 * 
 * case "CreateResponseGroup_Header_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2492) + "X"; break; case
 * "EditResponseGroup_Header_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(69) + "XEdit Response GroupX" +
 * "X"; break; case "ColumnName_ResponseType": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2494) + "X"; break; case
 * "ColumnName_ResponseGroup": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2493) + "X"; break; case
 * "ColumnName_Choice": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2502) + "X"; break; case
 * "ColumnName_Comment": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2504) + "X"; break; case
 * "ColumnName_Track": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2503) + "X"; break; case
 * "RuleTemplateNotExists": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2390) + "X"; break; case
 * "FeatureTypeNotApplicale": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2388) + "X"; break; case
 * "ProceesingTemplateNotExists": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2389) + "X"; break; case
 * "ControlLimit_SaveSuccessfullyMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2384) + "X"; value =
 * value.replace("{0} - {1} - {2}", "<Element Name>"); break; case
 * "ControlLimit_EffectiveDateMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2386)
 * 
 * + "X";
 * 
 * value = value.replace("{0}", "<Date>");
 * 
 * break; case "ControlLimit_EffectiveLesserDateMessage": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2387) + "X";
 * value = value.replace("{0}", "<Date>"); break; case
 * "ControlLimit_PopUpRemovalTitle": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2398) + "X"; break; case
 * "ControlLimit_RemoveMessageAtEdit": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2395)
 * 
 * + "X"; value = value.replace("{0}", "<Date>"); break;
 * 
 * case "Operation_Not_Exists": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2553) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(52) + "X"); break; case
 * "ColumnName_EffectiveFrom": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1414) + "X"; break; case
 * "ColumnName_ProcessSigma": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2371) + "X"; break; case
 * "ColumnName_ProcessMean": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1300) + "X"; break; case
 * "ColumnName_WithinPieceSigma": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2372) + "X"; break; case
 * "ColumnName_RuleTemplate": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2066) + "X"; break; case
 * "ColumnName_ProcessingTemplate": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2382) + "X"; break; case
 * "CL_DataStream": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1266) + "X"; break; case
 * "CL_AssociatedCLPopUp": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2380) + "X"; break;
 * 
 * case "ViewRequirementConditions": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(69) +
 * "XView Requirement ConditionsX" + "X"; break; case "Requirements": value =
 * "X" + UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2573) +
 * "X"; break; case "Active": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(451) + "X"; break; case
 * "DefectiveTypeFeatureCan'tBeSelected": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2498) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(175) + "X"); break; case
 * "DefectTypeFeatureCan'tBeSelected": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2498) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(176) + "X"); break; case
 * "ChecklistTypeFeatureCan'tBeSelected": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2498) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(127) + "X"); break; case
 * "ColumnName_Shift": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1385) + "X"; break; case
 * "ParameterSet_TagAlreadyExists": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2377) + "X"; break; case
 * "PS_PartPopUpHeader_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1431) + "X"; break; case
 * "Shift_Exclude": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1460) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1477) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1462) + "X");
 * 
 * break; case "Shift_Include": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1460) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1477) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1461) + "X");
 * 
 * break; case "ParameterSet_NoShiftMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1832) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1385) + "X");
 * 
 * break; case "GridShiftSelectedEntity": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(69) + "XShifts Selected:X" +
 * "X"; break; case "SelectShiftEntity_Header_Title": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(1463) + "X";
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1477) + "X");
 * 
 * break; case "Lot_Header_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2458) + "X"; break; case
 * "SelectLot_Include": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1460) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2458) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1461) + "X");
 * 
 * break; case "GridLotSelectedEntity": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(302) + "X"; break; case
 * "SelectLotEntity_Header_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1463) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2458) + "X");
 * 
 * break; case "Criteria_LotStatus": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(254) + "X"; break; case
 * "Criteria_TagGroup": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(871) + "X"; break; case
 * "ColumnName_Category": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1698) + "X"; break; case
 * "LotStatusType_Created": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2369) + "X"; break; case
 * "ColumnName_LotName": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(740) + "X"; break; case
 * "PS_SelectedLotPopUpHeader_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1411) + "X"; break; case
 * "PS_DeleteConfirmaitonMessageWithAssociations": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2304)
 * 
 * + "X"; break; case "AccordionItem_AssignedToDashboard": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2294) + "X";
 * break; case "PS_RemovedSuccessfullyMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(472) + "X"; value =
 * value.replace("{0}", "<ParameterSetName>"); break; case "PS_RemovalMessage":
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(567) + "X"; value =
 * value.replace("{0}", "<ParameterSetName>");
 * 
 * break; case "PS_RemovalTitle": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(568) + "X"; value =
 * value.replace("{0}", "<ParameterSetName>"); break; case
 * "EditKeyboardEnteredValuesDuringDataEntry": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(439)
 * 
 * + "X"; break; case "EditGaugeEnteredValuesDuringDataEntry": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2143) + "X";
 * break; case "DisplayScale": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(3052)
 * 
 * + "X"; break; case "HighlightGridNotification": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(3053) + "X";
 * break; case "HighlightPopupNotification": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(3054) + "X"; break; case
 * "PlaySoundWhenAGaugeValueIsEntered": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2145) + "X"; break; case
 * "SpecificationLimitNotification": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(3051)
 * 
 * + "X"; break; case "GaugeEnteredValueNotification": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2144) + "X";
 * break; case "Default": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(601) + "X";
 * 
 * break; case "Custom": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(342) + "X"; value =
 * value.toUpperCase(); break; case "DcConfigSaveSuccessmsg": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2615) + "X";
 * value = value.replace("{0}", "<Element Name>"); break; case
 * "DcConfigSaveSuccessmsg2": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2615) + "X"; value =
 * value.replace("{0}", "<Element Name>"); break; case
 * "ColumnName_ChildProcess": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1820) + "X"; break; case
 * "ShiftCountMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1388) + "X";
 * 
 * value = value.replace("{0}", "<count>");
 * 
 * value = value .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1385) + "X");
 * 
 * break; case "LotCountMessage":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1388) + "X";
 * 
 * value = value.replace("{0}", "<count>");
 * 
 * value = value .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(192) + "X"); break;
 * 
 * case "DC_DataCollectionType_ChkBoxLabel": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(556) + "X"; break; case
 * "DC_AllowLotCreation_ChkBoxLabel": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2596) + "X"; break; case
 * "DC_InputPartFaimily1_ChkboxLabel": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(69) +
 * "<DC Test Name>_InputPartFamily1" + "X"; break; case
 * "DCIndSetting_EntryMethod": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2142) + "X"; break; case
 * "DCIndSetting_EntryMethod_NextValue": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2134) + "X"; break; case
 * "DCIndSetting_EntryMethod_CurrentValue": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2135) + "X"; break; case
 * "DCIndSetting_EntryMethod_NewestUnusedValue": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2136) + "X"; break; case
 * "DCIndSetting_EntryMethod_OldestUnusedValue": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2137) + "X"; break; case
 * "DCIndSetting_EntryMethod_DispListOfValues": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2138) + "X"; break; case
 * "DCSetting_Assignment_AllowOnly": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1284)
 * 
 * + "X"; break; case "GaugeDev_CurrentValue": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2135) + "X"; break; case
 * "DCIndSetting_Custom": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(342) + "X"; break; case
 * "DCIndSetting_Default": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(601) + "X"; break; case
 * "IndividualSettings_WithinPieceMeasurement": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1995) + "X"; break; case
 * "DCConfig_GlobalSampleSizeMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2619)
 * 
 * + "X"; break;
 * 
 * case "DataCollectionConfig_SaveSuccessfullyMessage": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2615)
 * 
 * + "X"; value = value.replace("{0}", "<Element Name>");
 * 
 * break;
 * 
 * case "AccordionItem_ResponseGroupFeature": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(498) + "X"; break; case
 * "ResponseGroup_DeleteConfirmaitonMessageWithAssociations": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2557)
 * 
 * + "X";
 * 
 * temp = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2493) + "X"; temp =
 * temp.toLowerCase(); value = value.replace("{0}", temp);
 * 
 * break; case "ColumnName_ControlLimit": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2381) + "X"; break; case
 * "SingleCLModalBoxMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(731) + "X";
 * 
 * value = value .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2381) + "X"); value =
 * value.toLowerCase(); value = value.replace("{0}", "<Count>");
 * 
 * break; case "EditControlLimit_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2394) + "X"; break; case
 * "AccordionItem_AssignedProcessStateMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1226) + "X"; break;
 * 
 * case "FeatureTypeDrpDwn_Variable": value = "1 - " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(177) + "X"; break; case
 * "GaugeValue_ShowNewestOnTop": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2139) + "X"; break; case
 * "GaugeValue_SpecifyMaximumNumberOfValuesIn the list": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2141)
 * 
 * + "X"; break; case "GaugeValue_AllowPreviouslyUsedValuesToBeDisplayed": value
 * = "X" + UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2140)
 * 
 * + "X"; break; case "EntryMethod_NotificationMsgWhenBothCheckBoxUnchecked":
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2221)
 * 
 * + "X"; break; case "DynamicLabel": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2662) + "X"; break; case
 * "GaugeDevice": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1505) + "X"; break; case
 * "DCRequirementAlreadyExistsMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1201) + "X"; break; case
 * "NoNewChangeIsSaved": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(980) + "X"; break; case
 * "ResponseType_SingleAnswer_Checklist": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2487) + "X"; break; case
 * "ColumnName_Requirements": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2573) + "X"; break; case
 * "Assignee_Role": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(538) + "X"; break; case
 * "Feature_DCModalBoxMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(728) + "X";
 * 
 * temp = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(732) + "X";
 * 
 * value = value.replace("{1}", temp); value = value.toLowerCase(); value =
 * value.replace("{0}", "<Count>"); break; case
 * "Feature_SingleDCModalBoxMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(731) + "X";
 * 
 * temp = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2598) + "X";
 * 
 * value = value.replace("{1}", temp); value = value.toLowerCase(); value =
 * value.replace("{0}", "<Count>");
 * 
 * break; case "ResponseType_MultipleAnswer_Checklist": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2488) + "X";
 * break; case "User_Status_Active": value = "1 - " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(451) + "X"; break; case
 * "User_Status_Inactive": value = "0 - " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(421) + "X";
 * 
 * break; case "ShiftLandingPageTitle": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1477) + "X"; break; case
 * "createShiftPageHeaderTitle": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1477) + "X"; break; case
 * "ColumnShiftName": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1384) + "X"; break; case
 * "CreateShiftTitle": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1386) + "X"; break; case
 * "ProcessShiftSchedule_CreateShiftPage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1428) + "X"; break; case
 * "ColumnName_Monday": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1419) + "X"; break; case
 * "ColumnName_Tuesday": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1420) + "X"; break; case
 * "ColumnName_Wednesday": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1421) + "X"; break; case
 * "ColumnName_Thursday": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1422) + "X"; break; case
 * "ColumnName_Friday": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1423) + "X"; break; case
 * "ColumnName_Saturday": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1424) + "X"; break; case
 * "ColumnName_Sunday": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1418) + "X"; break; case
 * "lbl_Schedule": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1454) + "X"; break; case
 * "lbl_DefineSchedule": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1412) + "X"; break; case
 * "lbl_DerivedFromParentProcess": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1553) + "X"; break; case
 * "lbl_EffectiveFrom": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1414) + "X"; break; case
 * "lbl_ViewProcesses": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1306) + "X"; break; case
 * "lbl_SelectProcess": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(328) + "X"; break; case
 * "lbl_PlusOneDay": value = "+1 " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2107) + "X"; break; case
 * "error_TimeOverLapWithPreviousDay": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1425) + "X"; break; case
 * "error_TimeOverLapWithNextDay": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1426) + "X"; break; case
 * "column_StartTime": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1415) + "X"; break; case
 * "column_EndTime": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1416) + "X"; break; case
 * "ShiftAlreadyExists": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1459) + "X"; break; case
 * "createShift_MessageForAtleastOneProcessSelection": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(1466)
 * 
 * + "X"; break; case "AccordionItem_AssignedShift": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(1540) + "X";
 * break; case "AccordionItem_ShiftDeleteSingleProcess": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(1541)
 * 
 * + "X"; break;
 * 
 * case "ShiftCantBeRemoved_Process": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(798)
 * 
 * + "X"; break; case "Part_Is_Inactive_PFDetail": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(476) + "X";
 * break; case "Global_Configuration": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2526) + "X"; break; case
 * "Label_SpecificationLimits": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(730) + "X"; break; case
 * "Label_WarningLimit": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(180) + "X"; break; case
 * "Label_ReasonableLimit": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(199) + "X"; break; case
 * "Label_Auto-fill": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2539) + "X"; break; case
 * "Label_%for'WarningLimits'": value = "% " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2531) + "X"; break; case
 * "Label_xfor'ReasonableLimits'": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2548) + "X"; break; case
 * "Label_DefaultCapabilityTargetValues": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2527) + "X"; break; case
 * "Label_CpTarget": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2252) + "X"; break; case
 * "Label_PpTarget": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2254) + "X"; break; case
 * "Label_CpkTarget": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2253) + "X"; break; case
 * "Label_PpkTarget": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2255) + "X"; break; case
 * "SecurityPolicyPageTitle": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(974) + "X"; break; case
 * "SecurityPolicyPageHeaderText": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(976) + "X"; break; case
 * "SecurityPolicyPage_UserloginSettingsTab": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(977) + "X"; break; case
 * "SecurityPolicyPage_CredentialSettingsTab": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(978) + "X"; break; case
 * "SecurityPolicyPage_DataAuthenticationSettingsTab": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(979) + "X";
 * break; case "SecurityPolicyPage_UserNameValidation_LengthHigherThanAllowed":
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(836) + "X" + " 90.";
 * 
 * break; case "SecurityPolicyPage_UserNameValidation_LengthLowerThanAllowed":
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1668) + "X" + " 5.";
 * 
 * break; case "SecurityPolicyPage_SaveSuccessMessage": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(1035) + "X";
 * break; case "Yes": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(459) + "X"; break; case "No":
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(460) + "X"; break; case
 * "ManageSettingsPageTitle": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(427) + "X"; break; case
 * "ManageSettingsPageHeaderText": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(427) + "X"; break; case
 * "CPK_Target_Range": value = "<LowerValue> <= " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2253) + "X" +
 * " <= <UpperValue>"; break; case "CP_Target_Range": value = "<LowerValue> <= "
 * + "X" + UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2252)
 * + "X" + " <= <UpperValue>"; break; case "PP_Target_Range": value =
 * "<LowerValue> <= " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2254) + "X" +
 * " <= <UpperValue>";
 * 
 * break; case "PPK_Target_Range": value = "<LowerValue> <= " + "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2255) + "X" +
 * " <= <UpperValue>";
 * 
 * break; case "Warning_Limit_Range": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(69) +
 * "XRange should be between <LowerValue>% to <UpperValue>%X" + "X"; break; case
 * "Reasonable_Limit_Range": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(69) +
 * "XRange should be between <LowerValue> to <UpperValue>X" + "X"; break;
 * 
 * case "SecurityPolicy_Header_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(974) + "X"; break; case
 * "SecurityPolicy_IdleForOneDay": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1042) + "X"; break; case
 * "SecurityPolicy_UseEmailIdNo": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(460) + "X"; break; case
 * "GeneralSetting": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1626) + "X"; break; case
 * "UnitOfMeasurementAlreadyExists": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(253) + "X"; break; case
 * "AbbreviationAlreadyExists": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(242) + "X"; break; case
 * "GC_DataCollectionType_TabHeader": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(556) + "X"; break; case
 * "Lbl_ChkBox_EnableDataCollectionType": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2570) + "X"; break; case
 * "ColumnName_Type": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(41) + "X"; break; case
 * "GC_SaveSuccessMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2541) + "X"; break; case
 * "GC_RemoveDCType_ConfirmationMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(567)
 * 
 * + "X"; value = value.replace("{0}", "<DCTypeName>"); break; case
 * "GC_DCType_AlreadyExistMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2739) + "X"; break; case
 * "SecurityPolicy_MissingInfoMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1030)
 * 
 * + "X"; break; case "GlobalConfiguration_Header_Title": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2526) + "X";
 * break; case "ColumnName_Abbreviation": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(872) + "X"; break; case
 * "ColumnName_Unit_Of_Measurement": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1468) + "X"; break; case
 * "ColumnName_UnitType": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(193) + "X"; break; case
 * "UnitType_Angle": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(105) + "X"; break; case
 * "UnitType_Area": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(57) + "X"; break; case
 * "UnitType_Count": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(241) + "X"; break; case
 * "UnitType_Currency": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(111) + "X"; break; case
 * "UnitType_Current": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1392) + "X"; break; case
 * "UnitType_Data": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(69) + "XDataX" + "X"; break;
 * case "UnitType_Density": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(112) + "X"; break; case
 * "UnitType_Energy": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(174) + "X"; break; case
 * "UnitType_Force": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(181) + "X"; break; case
 * "UnitType_Height": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(69) + "XHeightX" + "X"; break;
 * case "UnitType_Length": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1615) + "X"; break; case
 * "UnitType_Luminosity": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(152) + "X"; break; case
 * "UnitType_Mass": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(26) + "X"; break; case
 * "UnitType_Power": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(157) + "X"; break; case
 * "UnitType_Pressure": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(158) + "X"; break; case
 * "UnitType_Speed": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(103) + "X"; break; case
 * "UnitType_Temperature": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(79) + "X"; break; case
 * "UnitType_Time": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(178) + "X"; break; case
 * "UnitType_Torque": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(159) + "X"; break; case
 * "UnitType_Viscosity": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(162) + "X"; break; case
 * "UnitType_Volume": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(74) + "X"; break; case
 * "UnitType_Width": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(69) + "XWidthX" + "X"; break;
 * case "UnitType_Work": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(160) + "X"; break; case
 * "UnitWillBeRemovedContinue": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(69) +
 * "XUnit will be removed. Continue?X" + "X"; break;
 * 
 * case "Events": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1905) + "X"; break; case
 * "Status_Removed": value = "2 - " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2762) + "X"; break; case
 * "Status_All": value = "3 - " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1711) + "X"; break;
 * 
 * case "GCAbbr_DeleteConfirmaitonMessageWithAssociations": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(350)
 * 
 * + "X"; break; case "AccordionItem_Impacted_Lot": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(637) + "X";
 * break;
 * 
 * case "SecurityPolicyPage_Forever": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1060) + "X"; break; case
 * "SecurityPolicy_IdleForFiveDay": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1044) + "X"; break; case
 * "SecurityPolicy_IdleForThreeDay": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1043) + "X"; break; case
 * "SecurityPolicy_IdleFor15Min": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1036) + "X"; break; case
 * "SecurityPolicy_IdleFor30Min": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1037) + "X"; break; case
 * "SecurityPolicy_IdleFor1Hour": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1038) + "X"; break; case
 * "SecurityPolicy_IdleFor4Hour": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1039) + "X"; break; case
 * "SecurityPolicy_IdleFor8Hour": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1040) + "X"; break; case
 * "SecurityPolicy_IdleFor15Hour": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1041) + "X"; break; case
 * "Aggregated": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2483) + "X"; break; case "Raw":
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2482) + "X"; break; case
 * "URL_CreateSpecHelpLink": value = "SpecLimits/CreatingSpecLimits.htm"; break;
 * case "RequiredAnswersMissing": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2594) + "X"; break; case
 * "ConfirmationMessage_NoResponseEntered": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2593)
 * 
 * + "X"; break; case "URL_SpecLimitLandingPageHelpLink": value =
 * "SpecLimits/ManagingSpecLimits.htm"; break; case
 * "URL_EditSpecLimitPageHelpLink": value = "SpecLimits/EditingSpecLimits.htm";
 * break; case "UserPage_UserNameValidation_LengthLowerThanAllowed": value = "X"
 * + UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(375)
 * 
 * + "X"; value = value.replace("{0}", "<SetLength>");
 * 
 * break; case "uRL_SecurityPolicyPageHelpLink": value =
 * "Security/ConfiguringSecurityPolicy.htm"; break; case
 * "SecurityPolicyPage_validationForPasswordLength_HigherThanAllowed": value =
 * "X" + UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(1033) +
 * "X" + " 20.";
 * 
 * break; case
 * "SecurityPolicyPage_validationForPasswordLength_LowerThanAllowed": value =
 * "X" + UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(1034) +
 * "X" + " 5.";
 * 
 * break; case "ManageSettingsPage_BasicInformation": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(1316) + "X";
 * break; case "ManageSettingsPage_Notifications": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(1317) + "X";
 * break; case "Removed": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2762) + "X"; break;
 * 
 * case "GC_ActiveDCToBeDefined": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2581)
 * 
 * + "X"; break; case "Role_Management": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(521) + "X"; break; case
 * "Authentication": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2694) + "X"; break; case
 * "User_Management": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(520) + "X"; break; case
 * "AccessDeniedText": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(790)
 * 
 * + "X"; break;
 * 
 * case "NoAccessLevelMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1203) + "X"; break; case
 * "InvalidPermissionMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2466)
 * 
 * + "X"; break; case "FifteenMinutes": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1036) + "X"; break; case
 * "ThirtyMinutes": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1037) + "X"; break; case
 * "OneHour": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1038) + "X"; break; case
 * "FourHours": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1039) + "X"; break; case
 * "EightHours": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1040) + "X"; break; case
 * "FifteenHours": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1041) + "X"; break; case
 * "OneDay": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1042) + "X"; break; case
 * "ThreeDays": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1043) + "X"; break; case
 * "FiveDays": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1044) + "X"; break; case
 * "RoleNameUniquenessValidationMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(592) + "X"; break; case
 * "ValidationMessage_PasswordAdvanceNotification": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(1045)
 * 
 * + "X"; break; case "NoSystemAccess": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(585) + "X"; break; case
 * "LastLogin": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2574) + "X"; break; case "d":
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2187) + "X"; break; case "m":
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2188) + "XmX" + "X"; break;
 * case "y": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2575) + "X"; value =
 * value.toLowerCase(); break; case "Ago": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2332) + "X"; break; case
 * "Count-TimeUnit-Ago": value = "X<count><TimeUnit> " + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2332) + "X"; break; case
 * "Today": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(338) + "X"; break; case "w":
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2576) + "X"; break; case
 * "ParameterSet": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1185) + "X"; break; case
 * "NotificationRule": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2399) + "X"; break; case
 * "PermissionTabText": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(549) + "X"; break; case
 * "Role_AlreayExists": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(592) + "X"; break; case
 * "GC_Chart": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2437) + "X"; break; case
 * "GC_CodeGroup": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(42) + "X"; break; case
 * "GC_Condition": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1155) + "X"; break; case
 * "GC_ControlLimit": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2381) + "X"; break; case
 * "GC_Feature": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(33) + "X"; break; case
 * "GC_GaugeSetup": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2224) + "X"; break; case
 * "GC_GlobalConfiguration": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2526) + "X"; break; case
 * "GC_License": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1191) + "X"; break; case
 * "GC_MenuTemplate": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1358) + "X"; break; case
 * "GC_NotificationRule": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2399) + "X"; break; case
 * "GC_ParameterSet": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1185) + "X"; break; case
 * "GC_ShiftLog": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(742) + "X"; break; case
 * "GC_StatisticalRule": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2401) + "X"; break; case
 * "MenuTemplate_Not_Exist": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2553) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1358) + "X"); break; case
 * "ManageSettingsPageMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(427) + "X";
 * 
 * break;
 * 
 * case "URL_CloneRolePageHelpLink": value = "Roles/CloningRoles.htm"; break; }
 * 
 * // call second method if (value.equals("")) value =
 * mapMultiLingualSheet2(key); } catch (Exception e) { e.printStackTrace(); }
 * return value; }
 * 
 * private static String mapMultiLingualSheet2(String key) {
 * 
 * String value = ""; String temp = "";
 * 
 * try {
 * 
 * switch (key) { case "URL_CreateRolePageHelpLink": value =
 * "Roles/CreatingRoles.htm"; break; case "URL_EditRolePageHelpLink": value =
 * "Roles/EditingRoles.htm"; break; case "URL_RoleLandingPageHelpLink": value =
 * "Roles/ManagingRoles.htm"; break; case "Roles_PopUp_AvailableUsers": value =
 * "X" + UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(659) +
 * "X"; break; case "Roles_PopUp_HelperMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(658) + "X"; break; case
 * "Roles_PopUp_AssignedUsers": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(660) + "X"; break; case
 * "Roles_PopUp_AssignRoleToUsers": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(642) + "X"; break; case
 * "RolesLandingPage_RoleName": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(548) + "X"; break; case
 * "RolesLandingPage_Users": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(646) + "X"; break; case
 * "RolesLandingPage_User": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(508) + "X"; break; case
 * "Roles_Permissions_ActionOrientedAlignment": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(555) + "X"; break;
 * 
 * case "Permissions_Authentication": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2694) + "X"; break; case
 * "Permissions_ConfigureParameters": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(293) + "X"; break; case
 * "ColumnName_FirstName": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(532) + "X"; break; case
 * "ColumnName_LastName": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(533) + "X"; break; case
 * "RolesLandingPage_UserPopUp_EntityHeading": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(830) + "X";
 * 
 * value = value.replace("{0}", "<RoleName>");
 * 
 * break; case "RolesLandingPage_UserPopUp_UsersCount": value = "X" +
 * "(<count> " + "X"; value = value.toLowerCase(); break; case
 * "Roles_RemoveRole_ConfirmationMessage1": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(679) + "X"; value =
 * value.replace("{0}", "<RoleName>"); break; case
 * "Roles_RemoveRole_AssociationConfirmationMessage1": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2557) + "X";
 * temp = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(538) + "X"; temp =
 * temp.toLowerCase(); value = value.replace("{0}", temp); break;
 * 
 * case "Roles_AssignedToDcMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(565) + "X"; break;
 * 
 * case "Roles_AssignedToCheckListMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2558) + "X"; break; case
 * "ProcessStateLandingPageTimeZoneLabel": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1279) + "X"; break; case
 * "Date&Time(Local)_Label": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(319) + "X" + " " + "X" + "(" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2070) + ")" +
 * "X";
 * 
 * break; case "ShowRemovedRecords": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2766) + "X"; break; case
 * "Permissions_Manage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1196) + "X"; break; case
 * "License": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1191) + "X"; break; case
 * "MenuTemplate": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1358) + "X"; break; case
 * "Workstation": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1049) + "X"; break; case
 * "MenuTemplates_HeaderTitle": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1298) + "X"; break; case
 * "CreateMenuTemplate_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1343) + "X"; break; case
 * "Create_Condition_PageTitle": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1054) + "X"; break; case
 * "Gauge_Interface": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1240) + "X"; break; case
 * "Create_Gauge_Interface": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1501) + "X"; break; case
 * "Gauge_Formats": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1577) + "X"; break; case
 * "Create_Gauge_Format": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1578) + "X"; break; case
 * "Gauge_Devices": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1728) + "X"; break; case
 * "Gauge_Interface_Connection": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1725) + "X"; break; case
 * "Gauge_Initialization": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1637) + "X"; break; case
 * "Measurement_Initialization": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1639) + "X"; break; case
 * "Measurement_Start ": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1641) + "X"; break; case
 * "Measurement_End": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1643) + "X"; break; case
 * "Measurement_Read": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1645) + "X"; break; case
 * "Measurement_Post": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1647) + "X"; break; case
 * "Measurement_Request": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1649) + "X"; break; case
 * "Data_Collection_Start": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1651) + "X"; break; case
 * "Data_Collection_End": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1653) + "X"; break; case
 * "RuleTemplateLandingPage_Header_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2171) + "X"; break; case
 * "ColumnName_Rule_Template_Name": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2063) + "X"; break; case
 * "ColumnName_TimeToTimeRule": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2513) + "X"; break; case
 * "ColumnName_BetweenPieceRule": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2514) + "X"; break; case
 * "ColumnName_WithinPieceRule": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2515) + "X"; break; case
 * "Create_RuleTemplate_Page_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2064) + "X"; break;
 * 
 * case "AboveUpperControlLimit": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1857) + "X"; break;
 * 
 * case "LicenseManagement": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1051) + "X"; break; case
 * "AddLicenseAssignment": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1251) + "X"; break; case
 * "UsernameAndWorkstation": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1093) + "X"; break; case
 * "RemainingLicenses": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1121) + "X"; break;
 * 
 * case "Agent": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2074) + "X"; break; case
 * "Gauge_Interface_Name": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1502) + "X"; break; case
 * "Data_Port_Configuration": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1745) + "X"; break; case
 * "Port_Initialization": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1582) + "X"; break; case
 * "Port_Termination": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1583) + "X"; break; case
 * "Gauge_Format": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1504) + "X"; break; case
 * "WorkstationLandingPageTitle": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2588) + "X"; break; case
 * "Configure_Workstation_Page_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2771) + "X"; break; case
 * "ColumnName_Workstation_Name": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1003) + "X"; break; case
 * "Workstation_Configurations_Save_Successfully": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2773) + "X";
 * break;
 * 
 * case "ProcessModels": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(774) + "X"; break; case
 * "Security": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1241) + "X"; break; case
 * "ShiftLogs": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1480) + "X"; break; case
 * "Calculations": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2281) + "X"; break; case
 * "Licenses": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1248) + "X"; break; case
 * "Workstations": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2588) + "X"; break; case
 * "NotificationRules": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1713) + "X"; break; case
 * "StatisticalRules": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2061) + "X"; break; case
 * "ProcessingTemplates": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2195) + "X"; break; case
 * "GaugeAgentInstaller": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2621) + "X"; break; case
 * "Global": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2529) + "X"; break; case
 * "MenuTemplateName": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1341) + "X"; break; case
 * "NotificationRulesLandingPage_HeaderTitle": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1713) + "X"; break; case
 * "CreateNotificationRulesPage_PageTitle": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1714) + "X"; break; case
 * "NCC_Violation": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1872) + "X"; break; case
 * "SpecificationViolation": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1873) + "X"; break; case
 * "StatisticalViolation": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1874) + "X"; break; case
 * "ChecklistViolation": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2608) + "X"; break; case
 * "Defective": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(175) + "X"; break; case
 * "NotificationRules_StatusTabHeading": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1806) + "X"; value =
 * value.replace("{0}", "<Element Name>");
 * 
 * break; case "Due": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1877) + "X"; break;
 * 
 * case "Missed": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1878) + "X"; break; case
 * "Success": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1879) + "X"; break; case
 * "AlarmType": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1750) + "X"; break; case
 * "DataStream": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2611) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1266) + "X");
 * 
 * break; case "Recipients": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1804) + "X"; break; case
 * "NotificationRules_RecipientsTabHeading": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(508) + "X" + "/" + "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(1049) + "X" +
 * "/" + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(538) + "X"; break; case
 * "Configuration": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1238) + "X"; break; case
 * "RealTimeAnalytics": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(69) + "XReal Time AnalyticsX" +
 * "X"; break; case "Labels": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1242) + "X"; break; case
 * "Downloads": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2620) + "X"; break; case
 * "NotificationRuleName": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1715) + "X"; break;
 * 
 * case "Username": value = "1 - " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(535) + "X"; break; case
 * "License_Workstation": value = "2 - " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1049) + "X"; break; case
 * "License_RemoveEntityPopupMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1149) + "X";
 * 
 * value = value.replace("{0}", "<Element Name>");
 * 
 * break; case "ModifyLicenseAssignment": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1053) + "X"; break;
 * 
 * case "LotNumber": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2347) + "X"; break; case
 * "CurrentStatus": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(420) + "X"; break; case
 * "StatusTime": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2348) + "X"; break; case
 * "Sound": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1318) + "X"; break; case
 * "DefineNotificationPlatform": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1320) + "X"; break; case
 * "PlaySound": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1319) + "X"; break; case
 * "StatisticalRulesLandingPageTitle": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2060) + "X"; break; case
 * "ColumnName_Priority": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2073) + "X"; break; case
 * "ColumnName_RuleType": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2068) + "X"; break; case
 * "ColumnName_Hits": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2069) + "X"; break; case
 * "ColumnName_Count": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(241) + "X"; break; case
 * "ColumnName_Label": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2071) + "X"; break; case
 * "TimeToTimeRule_TabTitle": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2510) + "X"; break; case
 * "BetweenPieceRule_TabTitle": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2511) + "X"; break; case
 * "WithinPieceRule_TabTitle": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2512) + "X"; break; case
 * "ProcessingTemplateLandingPage_Header_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2195) + "X"; break; case
 * "ColumnName_Processing_Template_Name": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2092) + "X"; break; case
 * "ColumnName_Feature_Type": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(139) + "X"; break; case
 * "ColumnName_Normalization": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2093) + "X"; break; case
 * "ColumnName_Control_Limit_Confidence_Interval": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2094) + "X";
 * break; case "ColumnName_Processing_Option": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2099) + "X"; break; case
 * "ColumnName_Initialize_on_Part_Change": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2097) + "X"; break; case
 * "priority": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2073) + "X"; break; case
 * "ruleType": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2068) + "X"; break; case
 * "hits": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2069) + "X"; break; case
 * "count": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(241) + "X"; break; case
 * "label": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2071) + "X"; break; case
 * "enabled": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2174) + "X"; break; case
 * "Create_ProcessingTemplate_Page_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2091) + "X"; break; case
 * "Password_Guidelines_ChangePassword_ManageSettings":
 * 
 * temp = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1026) + "X"; temp =
 * temp.replace("{0}", "8");
 * 
 * String temp1 = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1307) + "X"; temp1 = temp +
 * " [ ] ? / < > ~ # ` ! @ _ - $ % ^ & * ( ) + = { } | : \" ; ' ,";
 * 
 * String temp2 = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1025) + "X"; temp2 =
 * temp.replace("{0}", "365");
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1020) + "X" + "\n\n" + "X" +
 * temp + "\n" + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1021) + "X" + "\n" + "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(1308) + "X" +
 * "\n" + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1315) + "X" + "\n" + temp1 +
 * "\n" + temp2 + "X";
 * 
 * break;
 * 
 * case "URL_WorkStationLandingPageHelpLink": value =
 * "Workstations/ManagingWorkstations.htm"; break; case
 * "Workstation_AlreayExists": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2772) + "X"; break; case
 * "Label_Already_Exists": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2207) + "X"; break; case
 * "CountGreaterThanHits": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2208) + "X"; break; case
 * "HitsLessThanCount": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2209) + "X"; break; case
 * "Statistical_Rule_Delete_Message":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2364) + "X"; value =
 * value.replace("{0}", "<Element Name>"); value = value.replace("<br/> ",
 * "\n"); value = value.replace("<br/>", "\n"); value = value.replace("<br />",
 * "\n");
 * 
 * break; case "HelperText_Date": value = "M/d/yyyy h:mm:ss tt"; break; case
 * "CombinationAlreadyExists": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2210) + "X"; break; case
 * "WorkStation_Header_AccessLevel_PopUp": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1145) + "X"; break; case
 * "Workstation_AccessLevelCount_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(731) + "X";
 * 
 * temp = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(539) + "X";
 * 
 * value = value.replace("{1}", temp); value = value.toLowerCase(); value =
 * value.replace("{0}", "<Element Name>"); break; case
 * "Menu_Template_Name_already_exists": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1374) + "X"; break;
 * 
 * case
 * "Workstation_errorMsg_WorkStationNotAutothorizedAndUserNotAbleToAuthorize":
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2695) + "X"; break; case
 * "GC_Workstation": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1049) + "X"; break; case
 * "View_Workstation_Page_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2774) + "X"; break;
 * 
 * case "Menu_Template_Name_already_exists.": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1374) + "X"; break; case
 * "WorkstationSavedSuccessfullyMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(102) + "X";
 * 
 * value = value.replace("{0}", "<Element Name>");
 * 
 * break; case "WorkStation_Header_Checklist_PopUp": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2586) + "X";
 * break; case "Workstation_ChecklistCount_Title": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(731) + "X";
 * 
 * temp = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(127) + "X";
 * 
 * value = value.replace("{1}", temp);
 * 
 * value = value.toLowerCase(); value = value.replace("{0}", "<Element Name>");
 * break; case "viewPopUpTitleWorkstation": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2585) + "X";
 * 
 * value = value.replace("{0}", "<Element Name>"); ; break; case
 * "Workstation_DCCount_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(731) + "X";
 * 
 * temp = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(21) + "X";
 * 
 * value = value.replace("{1}", temp);
 * 
 * value = value.toLowerCase(); value = value.replace("{0}", "<Element Name>");
 * 
 * break; case "WorkStation_Header_NotificationRule_PopUp": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2587) + "X";
 * break; case "Workstation_NotificationRuleCount_Title": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(731) + "X";
 * value = value.replace("{0}", "<Element Name>");
 * 
 * temp = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2399) + "X";
 * 
 * value = value.replace("{1}", temp); value = value.toLowerCase(); break; case
 * "Column_Assigned_License": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(570) + "X"; break; case
 * "Column_Last_Authenticated_By": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2583) + "X"; break; case
 * "View_Role": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1629) + "X"; break; case
 * "View_User": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(829) + "X"; break; case
 * "Menu_Template": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1358) + "X"; break; case
 * "MenuTemplateViewPopUpHeading":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(731) + "X"; value =
 * value.toLowerCase(); value = value.replace("{0}", "<Count>"); value =
 * value.replace("{1}", "<Module>");
 * 
 * temp = value;
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1358) + "X" +
 * ": <MenuTemplateName> " + temp; break; case "Search": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(710) + "X";
 * break; case "StatisticalRule_HitsGreaterThanOne_Message": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2523) + "X";
 * break; case "URL_StatisticalPageHelpLink": value =
 * "StatisticalRules/ManagingStatisticalRules.htm"; break; case
 * "URL_MenuTemplatelandingPage_HelpLink": value =
 * "MenuTemplates/ManagingMenuTemplates.htm"; break; case
 * "URL_CreateMenuTemplatePage_HelpLink": value =
 * "MenuTemplates/CreatingMenuTemplates.htm"; break; case
 * "URL_EditMenuTemplatePage_HelpLink": value =
 * "MenuTemplates/EditingMenuTemplates.htm"; break; case "Qty": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(698) + "X";
 * break; case "Lot": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(192) + "X"; break; case
 * "MenuTemplate_DeleteConfirmaitonMessage_WithAssociation": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(567) + "X";
 * value = value.replace("{0}", "<Element Name>");
 * 
 * temp = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(138) + "X";
 * 
 * value = value + "\n" + "\n" + temp; break; case
 * "AccordionItem_AssignedRoleMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2000) + "X"; break; case
 * "Process_ProcessWithSameNameMsg": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2108) + "X"; break; case
 * "Shifts_ProcessDeletetionMsg_IfOnlyOneProcessAssigned": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(1541) + "X";
 * break; case "URL_LotLandingPageHelpLink": value = "Lots/ManagingLots.htm";
 * break; case "URL_CreateLotPageHelpLink": value = "Lots/CreatingLots.htm";
 * break; case "URL_EditLotPageHelpLink": value = "Lots/EditingLots.htm"; break;
 * case "Lot_LotAlreadyExistAsRemoved": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2734) + "X"; break; case
 * "CurrentProcess": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2367) + "X"; break; case
 * "Lot_LotAlreadyExistForPart": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2361) + "X"; break; case
 * "NotificationRuleNameAlreadyExists": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1734) + "X"; break; case
 * "OnHold": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2353) + "X"; break; case
 * "TestingComplete": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2352) + "X"; break; case
 * "ParameterSet_Time_InfoIconMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1405) + "X"; value =
 * value.replace("<br/> �  ", "\n"); value = value.replace("<br/>  ", "\n");
 * value = value.replace("<b>", ""); value = value.replace("</b>", "");
 * 
 * break;
 * 
 * case "StartDate&Time": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(423) + "X"; break; case
 * "EndDate&Time": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(424) + "X"; break; case
 * "DataCollectionS": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2611) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(21) + "X");
 * 
 * break; case "CheckListS": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2611) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(127) + "X");
 * 
 * break; case "SelectCheckLlistsEntity_Header_Title": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(1463) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(127) + "X"); break; case
 * "SelectDataCollectionEntity_Header_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1463) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(732) + "X");
 * 
 * break; case "Above_T2_upper": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1851) + "X"; break; case
 * "Below_T2_lower": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1854) + "X"; break; case
 * "Above_MAV_upper": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1852) + "X"; break; case
 * "Below_MAV_lower": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1855) + "X"; break; case
 * "Above_USL": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1842) + "X"; break; case
 * "Below_LSL": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1876) + "X"; break; case
 * "Above_URL": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1843) + "X"; break; case
 * "Below_LRL": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1847) + "X"; break; case
 * "Above_UWL": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1875) + "X"; break; case
 * "Below_LWL": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1848) + "X"; break; case
 * "Above_UWP": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1844) + "X"; break; case
 * "Below_LWP": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1849) + "X"; break; case
 * "Above_USG": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1845) + "X"; break; case
 * "Below_LSG": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1850) + "X"; break; case
 * "Notify_When": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1807) + "X"; break; case
 * "Upper": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(517) + "X"; break; case
 * "Lower": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(518) + "X"; break; case
 * "Below_Lower_Control_Limit": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1861) + "X"; break; case
 * "In_or_Above_Upper_Zone_A": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1858) + "X"; break; case
 * "In_or_Below_Lower_Zone_A": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1862) + "X"; break; case
 * "In or_Above_Upper_Zone_B": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1859) + "X"; break; case
 * "In_or_Below_Lower_Zone_B": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1863) + "X"; break; case
 * "Run_Above_Centerline": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1860) + "X"; break; case
 * "Run_Below_Centerline": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1864) + "X"; break; case
 * "Others": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1732) + "X"; break; case
 * "Run_within_Zone_C": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1865) + "X"; break; case
 * "Avoidance_of_Zone_C": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1866) + "X"; break; case
 * "Consecutive_Points_Rising": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1867) + "X"; break; case
 * "Consecutive_Points_Falling": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1868) + "X"; break; case
 * "Oscillating_Up_and_Down": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1869) + "X"; break; case
 * "No_Variation_in_Values": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1870) + "X"; break; case
 * "DC_Assigned_Users": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2035) + "X"; break; case
 * "Error_AtleastOneSelect_NotificationRule": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1733) + "X";
 * 
 * value = value.replace("status", "<element>"); break; case
 * "Error_ExistingSelectLost_NotificationRule": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1735) + "X"; break; case
 * "Lot_ClosedAccepted": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2354) + "X"; break; case
 * "Lot_ClosedRejected": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2355) + "X"; break; case
 * "Notification_Rule_Any_Data_Collection":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1832) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(21) + "X");
 * 
 * break; case "Lots_Association_Message": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(557) + "X"; break; case
 * "No_License_Available_Message_For_User": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(999) + "X"; break; case
 * "NotificationRule_NoDcMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1832) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(21) + "X");
 * 
 * break; case "AnyCheckList": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1832) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(127) + "X");
 * 
 * break; case "RecipientDoesNotExist": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2553) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2571) + "X");
 * 
 * break; case "WorkstationLicenseAssociatedConfirmationMessage": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(525) + "X";
 * break; case "No_License_Available_Message_For_Machine": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2718) + "X";
 * break; case "Username/Workstation_doesn't_exist": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2553) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1093) + "X");
 * 
 * break; case "License_already_exists.": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1148) + "X"; break;
 * 
 * case "You_have_been_logged_out_from_this_session.": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2568) + "X";
 * break;
 * 
 * case "NotInListMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2049) + "X"; break;
 * 
 * case "Change": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1824) + "X"; break; case
 * "URL_NotificationLandingPageHelpLink": value =
 * "NotificationRules/ManagingNotificationRules.htm"; break; case
 * "URL_CreateNotificationPageHelpLink": value =
 * "NotificationRules/CreatingNotificationRules.htm"; break; case
 * "URL_EditNotificationPageHelpLink": value =
 * "NotificationRules/EditingNotificationRules.htm"; break; case
 * "TrackCountExceeded": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2609) + "X"; break; case
 * "NotificationRules_ChecklistTabHeading": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2015) + "X"; break; case
 * "NotificationRules_Checklist_Pageheader": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1460) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(127) + "X");
 * 
 * value = value .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1461) + "X");
 * 
 * break; case "NotificationRules_DataCollection_Pageheader": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(1460) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(732) + "X");
 * 
 * value = value .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1461) + "X");
 * 
 * break; case "Workstation_doesn�t_exist": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2778) + "X"; break; case
 * "URL_LicenseLandingPageHelpLink": value = "Licenses/AssigningLicenses.htm";
 * break; case "EntityCountMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1388) + "X";
 * 
 * value = value.replace("{0}", "<count>");
 * 
 * value = value.replace("{1}", "<entity>"); break;
 * 
 * case "NotificationRule_UpdateSuccessMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2310) + "X"; break; case
 * "NotificationRule_AlreadyExistAsRemoved": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2747) + "X"; break;
 * 
 * case "ViewRequirements": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2577) + "X"; break; case
 * "CreateRequirements": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2549) + "X"; break; case
 * "MoreRequirements": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2802) + "X"; break; case
 * "Create_Calculation": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2033) + "X"; break; case
 * "Calculation_Name": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2152) + "X"; break; case
 * "Save_as_Feature": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2193) + "X"; break; case
 * "Initiators": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2257) + "X"; break; case
 * "Add_Below": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2783) + "X"; break; case
 * "Add_Above": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2782) + "X"; break; case
 * "Calculation": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2058) + "X"; break; case
 * "Calculation_RemoveStepMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2754) + "X"; value =
 * value.replace("{0}", "<StepNumber>");
 * 
 * break; case "Calculation_StepNumber": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2753) + "X"; value =
 * value.replace("{0}", "<StepNumber>");
 * 
 * break; case "Calculation_RemovePopUptTitle": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(69) +
 * "XRemove Step <StepNumber>X" + "X"; break;
 * 
 * case "RuleTemplateNameAlreadyExistsErrorMsg": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2230) + "X"; break; case
 * "RuleTemplateNameAlreadyExistsAsRemoveRecordErrorMsg": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2751) + "X";
 * break; case "URL_RuleTemplateLandingPageHelpLink": value =
 * "RuleTemplates/ManagingRuleTemplates.htm"; break; case
 * "URL_CreateRuleTemplatePageHelpLink": value =
 * "RuleTemplates/CreatingRuleTemplates.htm"; break; case
 * "URL_EditRuleTemplatePageHelpLink": value =
 * "RuleTemplates/EditingRuleTemplates.htm"; break; case
 * "RuleTemplate_ViewPopUp_SubHeading": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2066) + "X" +
 * ": <Element Name>";
 * 
 * break; case "RuleTemplate_ViewPopUp_SubHeadingWithOneCount": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(731) + "X";
 * 
 * temp = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2062) + "X"; value =
 * value.replace("{1}", temp); value = value.toLowerCase(); value =
 * value.replace("{0}", "<Count>"); break; case
 * "RuleTemplate_ViewPopUp_SubHeadingWithMoreThanOneCount": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(728) + "X";
 * 
 * temp = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2177) + "X";
 * 
 * value = value.replace("{1}", temp); value = value.toLowerCase(); value =
 * value.replace("{0}", "<Count>"); break; case
 * "RuleTemplate_TimeToTimeViewPopUpHeader": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2519) + "X"; break; case
 * "RuleTemplate_BetweenPieceViewPopUpHeader": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2520) + "X"; break; case
 * "RuleTemplate_WithinPieceViewPopUpHeader": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2521) + "X"; break;
 * 
 * case "Tag_Group_Name_already exists_as_removed_record": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(1023) + "X";
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(403) + "X"); break; case
 * "Tag_already exists_as_removed_record": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2724) + "X"; break;
 * 
 * case "CodeGroupRemoval_Success": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(948) + "X";
 * 
 * value = value.replace("{0}", "<Element Name>"); break; case
 * "CodeGroupRemoval_ConfirmationWithoutAssociation": temp = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(947) + "X";
 * temp = temp.replace("{0}", "<Element Name>"); value = temp + "\n" + "\n" +
 * "X" + UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(1070) +
 * "X"; break; case "Condition_Name": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1055) + "X";
 * 
 * break; case "SettingSaveSuccessfullyMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(102) + "X"; temp = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(427) + "X";
 * temp = temp.toLowerCase(); value = value.replace("{0}", "<Element Name> " +
 * temp);
 * 
 * break; case "Condtions_DeleteConfirmaitonMessage_WithAssociation":
 * 
 * temp = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(567) + "X";
 * 
 * temp = temp.replace("{0}", "<Element Name>"); value = temp + "\n" + "\n" +
 * "X" + UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(1344) +
 * "X";
 * 
 * break;
 * 
 * case "AssignedToDcRequirementMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1369) + "X"; break; case
 * "Day_of_week": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2550) + "X"; break; case
 * "Gauge_Interface_Connection_saved_successfully.": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(1882)
 * 
 * + "X"; break; case "TCP/IP": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1809) + "X"; break; case
 * "Com_Port": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1737) + "X"; break; case
 * "Gauge_Format_Name": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1579) + "X"; break; case
 * "RuleTemplate_Association_Message": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1106) + "X"; break; case
 * "Associated_ControlLimit_ConfirmationMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1129) + "X"; break;
 * 
 * case "ProcessingTemplateNameAlreadyExistsAsRemoveRecordErrorMsg": value = "X"
 * + UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2743) + "X";
 * break;
 * 
 * case "URL_CreateProcessPageHelpLink": value =
 * "Processes/CreatingProcesses.htm"; break; case
 * "message_RestoreConfirmation_WithoutAssociation": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2701) + "X";
 * 
 * value = value.replace("{0}", "<Element Name>"); value =
 * value.replace(" <br>", "\n"); value = value.replace("<br>", "\n"); break;
 * case "RestoredSuccessfullyMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2700) + "X";
 * 
 * value = value.replace("{0}", "<Element Name>"); break;
 * 
 * case "RestorePopUpTitle": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2698) + "X"; value =
 * value.replace("{0}", "<Element Name>"); break; case "Create_Gauge_Device":
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1726) + "X"; break; case
 * "Gauge_Device_Name": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1727) + "X"; break; case
 * "DeleteConfirmaitonMessageWithAssociationsForGaugeInterface":
 * 
 * temp = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(567) + "X";
 * 
 * temp = temp.replace("{0}", "<Element Name>");
 * 
 * value = temp + "\n" + "\n" + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2025) + "X";
 * 
 * temp = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1500) + "X"; value =
 * value.replace("{0}", temp.toLowerCase());
 * 
 * break;
 * 
 * case "AccordionItem_AssignedGaugeFormat": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2027) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1504) + "X");
 * 
 * break;
 * 
 * case "AccordionItem_AssignedGaugeDevice": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2027) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1505) + "X");
 * 
 * break;
 * 
 * case "ProcessingOption_ShewhartCUSUM": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2128) + "X"; break; case
 * "ProcessingOption_Exponentially_Weighted_Moving_Average": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2131) + "X";
 * break; case "ProcessingOption_EconomicControlLimit": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2130) + "X";
 * break; case "ProcessingOption_TabularCUSUM": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2129) + "X"; break; case
 * "ProcessingOption_CoefficientOfVariation": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2155) + "X"; break;
 * 
 * case "Modifying_a_gauge_interface_connection_will_affect_1_gauge_device.":
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1889) + "X"; value =
 * value.replace("{0}", "1");
 * 
 * break; case
 * "Modifying_a_gauge_interface_connection_will_affect_N_gauge_devices.": value
 * = "X" + UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(1991)
 * + "X"; value = value.replace("{0}", "<count>");
 * 
 * break; case "NormalizationOption_Nominal": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1299) + "X"; break; case
 * "NormalizationOption_Target": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(186) + "X"; break; case
 * "NormalizationOption_ProcessMean": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1300) + "X"; break; case
 * "NormalizationOption_Standardized": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1301) + "X"; break; case
 * "AtLeastOneMeanShiftDetectionLimit_ErrorMessage": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2101) + "X";
 * break; case "Part - Feature combination already exists as removed record":
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2738) + "X"; break;
 * 
 * case "SelectParentProcess": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1075) + "X"; break; case
 * "Msg_ParentProcessWithSameChildName": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2172) + "X"; break; case
 * "Msg_ProcesslAlreadyContainsChildAsRemovedRecord": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2697) + "X";
 * break; case "Msg_ResponseAlreadyExistAsRemovedRecord": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(1023) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2493) + "X");
 * 
 * break; case "Msg_ChoiceAlreadyExistAsRemovedRecord": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2727) + "X";
 * break; case "Restore_Confirmation_Message_For_PartRevision": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2699) + "X";
 * 
 * value = value.replace("{0}", "<Element Name>"); value =
 * value.replace(" <br>", "\n"); value = value.replace("<br>", "\n"); break;
 * 
 * case "message_SpecLimitRestoreConfirmation_WithoutAssociation": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(1986) + "X";
 * 
 * value = value.replace("{0}", "<Element Name>"); value =
 * value.replace(" <br>", "\n"); value = value.replace("<br>", "\n"); value =
 * value.replace("<br/>", "\n");
 * 
 * break;
 * 
 * case "message_RestoreConfirmation_WithoutAssociation_Feature":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2767) + "X";
 * 
 * value = value.replace("{0}", "<Element Name>"); value =
 * value.replace(" <br>", "\n"); value = value.replace("<br>", "\n"); break;
 * 
 * case "message_RestoreConfirmation_WithoutAssociation_Process":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2701) + "X";
 * 
 * value = value.replace("{0}", "<Element Name>"); value =
 * value.replace(" <br>", "\n"); value = value.replace("<br>", "\n"); break;
 * 
 * case "Msg_ChecklistAlreadyExistAsRemovedRecord": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2730) + "X";
 * break; case "Msg_LabelAlreadyExistAsRemovedRecord": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2750) + "X";
 * break;
 * 
 * case "ShortName_AlreadyExistAsRemoved": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(461) + "X"; break;
 * 
 * case "ProcessingTemplateNameAlreadyExistsErrorMsg": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2231) + "X";
 * break; case "FeatureType_Attribute": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2479) + "X"; break; case
 * "AccessLevelPopUp": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1193) + "X"; break; case
 * "ToolTip_ControlLimitConfidenceInterval_Probability": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2241) + "X";
 * value = value.replace("<br/>", "\n");
 * 
 * value = value.replace("{0}", "90.0");
 * 
 * value = value.replace("{1}", "99.999"); break; }
 * 
 * // call third method if (value.equals("")) value =
 * mapMultiLingualSheet3(key); } catch (Exception e) { e.printStackTrace(); }
 * return value; }
 * 
 * private static String mapMultiLingualSheet3(String key) {
 * 
 * String value = ""; String temp = "";
 * 
 * try { switch (key) {
 * 
 * case "ToolTip_WaitingFactor": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2247) + "X"; value =
 * value.replace("<br/>", "\n"); value = value.replace("{0}", "0");
 * 
 * value = value.replace("{1}", "1"); break; case "ToolTip_FastInitialResponse":
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2246) + "X"; value =
 * value.replace("<br/>", "\n"); value = value.replace("{0}", "0");
 * 
 * value = value.replace("{1}", "99"); break; case
 * "URL_ProcessingTemplateLandingPageHelpLink": value =
 * "ProcessingTemplates/ManagingProcessingTemplates.htm"; break; case
 * "errorMessage_MSZLGreaterThanMSZU": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2202) + "X"; break; case
 * "errorMessage_MSZULessThanMSZL": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2203) + "X"; break; case
 * "ProcessingTemplate_Association_Message": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1150) + "X"; break; case
 * "URL_CalculationsLandingPageHelpLink": value =
 * "Calculations/ManagingCalculations.htm"; break; case
 * "URL_CreateCalculationPageHelpLink": value =
 * "Calculations/CreatingCalculations.htm"; break; case
 * "URL_EditCalculationPageHelpLink": value =
 * "Calculations/EditingCalculations.htm"; break; case "SelectAnOutputOption":
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2197) + "X"; break; case
 * "ConfigureOutput": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2282) + "X"; break; case
 * "Collect_Data": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2831) + "X"; break; case
 * "ChecklistRequirement_PageTitle": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1073) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(127) + "X");
 * 
 * break; case "URL_GlobalConfigurationPageHelpLink": value =
 * "GlobalConfiguration/ConfiguringGlobalSettings.htm"; break; case
 * "Workstation_doesn't_exist": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2778) + "X"; break;
 * 
 * case "ErrorMessage_InputAlreadyExistsInEquation": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(961) + "X";
 * break; case "View_CollectionAids_Page_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2800) + "X"; break; case
 * "Static_NoEntitySelected": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1832) + "X"; value =
 * value.replace("{0}", "X<entity>X");
 * 
 * break; case "ConfirmationMessage_Static_StaticToDynamic": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(1717) + "X";
 * 
 * value = value.replace("{0}", "<entity>");
 * 
 * break;
 * 
 * case "Static_xpathProcess": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1830) + "X"; break; case
 * "Static_xpathPart": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2344) + "X"; break; case
 * "Static_xpathFeature": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1886) + "X"; break; case
 * "Static_xpathCheckList": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2618) + "X"; break; case
 * "Static_xpathDC": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2054) + "X"; break; case
 * "FeatureUpdate_ConfirmationMessageHeader": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(941) + "X"; break; case
 * "AccordionItem_AssignedControlLimit_Feature": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(949) + "X"; break; case
 * "AccordionItem_AssignedPartFeature_Feature": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(955) + "X"; break; case
 * "FeatureUpdate_PopUpTitle": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(938) + "X"; break; case
 * "WarningLimitToolTip": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2546) + "X"; break; case
 * "ReasonableLimitToolTip": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2547) + "X"; break; case
 * "StaticEntityPage_PageTitle": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1463) + "X";
 * 
 * value = value.replace("{0}", "<EntityName>");
 * 
 * break; case "DynamicEntity_PageTitle":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1460) + "X";
 * 
 * value = value.replace("{0}", "<EntityName>");
 * 
 * value = value.replace("{1}", "<Condition>");
 * 
 * break; case "ValueAlreadySelected": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1464) + "X"; break; case
 * "Entity_DoesNot_Exist": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2553) + "X";
 * 
 * value = value.replace("{0}", "X<EntityName>X");
 * 
 * break; case "NoTagAvailableForSelection": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2661) + "X"; break; case
 * "CountSelectedMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1388) + "X";
 * 
 * value = value.replace("{0}", "<count>"); value = value.replace("{1}",
 * "<entity>");
 * 
 * break; case "label_EntitySelected": value = "X<EntityName> Selected:X";
 * break; case "dynamicCriteria_DefaultMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2684) + "X" + "\n" + "X" +
 * "<CriteriaName>" + "X" + "\n" + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2685) + "X" + "\n" + "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(871) + "X" +
 * "\n" + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2686) + "X"; break;
 * 
 * case "CalculationNameAlreadyExists": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2259) + "X"; break; case
 * "AddInput": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(874) + "X"; break; case
 * "Alert": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(220) + "X"; break; case
 * "UsedEntityCantBeChangedInEquationMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(965) + "X";
 * 
 * value = value.replace("{0}", "<Entity Name>"); break; case
 * "UsedEntityCantBeDeletedInEquationMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(964) + "X"; value =
 * value.replace("{0}", "<Entity Name>"); break; case
 * "viewPopUpTitleCalculation": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2156) + "X";
 * 
 * value = value.replace("{0}", "<Entity Name>"); break; case "lbl_ViewProcess":
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1833) + "X"; break; case
 * "ViewProcessModalBoxMoreThanOneCountMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(728) + "X";
 * 
 * temp = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1080) + "X";
 * 
 * value = value.replace("{1}", temp); value = value.toLowerCase(); value =
 * value.replace("{0}", "<Count>"); break; case
 * "ViewPartModalBoxMoreThanOneCountMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(728) + "X";
 * 
 * temp = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(76) + "X";
 * 
 * value = value.replace("{1}", temp);
 * 
 * value = value.toLowerCase(); value = value.replace("{0}", "<Count>"); break;
 * case "lbl_ViewPart": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2167) + "X"; break; case
 * "CalculationViewPopUpModalBoxTitle": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2156) + "X"; value =
 * value.replace("{0}", "<Entity Name>"); break; case
 * "CalculationNameAlreadyExistsAsRemovedRecord": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2277) + "X"; break; case
 * "SAYT_NoRecordFoundMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(65) + "X"; value =
 * value.toUpperCase(); break; case "ErrorMessage_FeatureDoesntExists": value =
 * "X" + UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(104) +
 * "X"; break; case "ErrorMessage_FeatureUsedAsOutput": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2780) + "X";
 * break; case "ColumnName_Output": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(25) + "X"; break; case
 * "Initiators_Header_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2257) + "X"; break; case
 * "lbl_ViewInitiator": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2244) + "X"; break; case
 * "ViewInitiatorModalBoxMoreThanOneCountMessage": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(728) + "X";
 * 
 * temp = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2257) + "X";
 * 
 * value = value.replace("{1}", temp);
 * 
 * value = value.toLowerCase(); value = value.replace("{0}", "<Count>"); break;
 * case "ViewFeatureModalBoxMoreThanOneCountMessage": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(728) + "X";
 * 
 * temp = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(80) + "X";
 * 
 * value = value.replace("{1}", temp);
 * 
 * value = value.toLowerCase(); value = value.replace("{0}", "<Count>"); break;
 * case "Step1": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2753) + "X"; value =
 * value.replace("{0}", "1"); value = value.toUpperCase(); break; case "Step2":
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2753) + "X"; value =
 * value.replace("{0}", "2"); value = value.toUpperCase(); break; case
 * "errorMessage_AtLeastOneStepIsRequired": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2309) + "X"; break; case
 * "errorMessage_AllInitiatorsMustBeDefined": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2787) + "X"; break; case
 * "errorMessage_AtLeastOneOutputMustBeDefined": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2745) + "X"; break; case
 * "toolTipOnlyOneOperatorIsAllowed": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2790) + "X"; break; case
 * "CalculationName_AlreayExists": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2259) + "X"; break; case
 * "ErrorMessage_NestedFunctionNotAllowedWithMoreButton": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2789) + "X";
 * break; case "ErrorMessage_NestedFunctionNotAllowed": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2789) + "X";
 * break; case "StepCount": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2753) + "X";
 * 
 * value = value.replace("{0}", "<count>"); break; case
 * "errorMessage_AtLeastOneStepIsRequiredWithOutMoreButton": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2309) + "X";
 * break; case "ErrorMessage_OutputMustBeDefined": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2793) + "X";
 * break; case "Long Name": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(40) + "X"; break; case
 * "AccordionItem_AssignedChecklist": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2559) + "X"; break; case
 * "URL_FeatureLandingPageHelpLink": value = "Features/ManagingFeatures.htm";
 * break; case "URL_CreateFeaturePageHelpLink": value =
 * "Features/CreatingFeatures.htm"; break; case "URL_EditFeaturePageHelpLink":
 * value = "Features/EditingFeatures.htm"; break; case
 * "ErrorMessage_ThisItemWasRemoved": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2792) + "X"; break; case
 * "FeatureAlreadyDefinedInOtherCalculation": value = "<Entity Name> " + "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2788) + "X" +
 * " " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2748) + "X" + "."
 * 
 * ; break; case "ErrorMessage_InvalidEntry": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1194) + "X"; break; case
 * "ErrorMessage_OutputAlreadyDefinedInStep": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2795) + "X";
 * 
 * value = value.replace("{0}", "<Count>");
 * 
 * break; case "toolTipParameterMustBeInputOrSavedFeature": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2794) + "X";
 * break; case "Backspace": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(868) + "X"; break; case
 * "FeatureAlreadyDefinedInOtherCalculationInStep":
 * 
 * value = "<Entity Name> " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2788) + "X" + " " +
 * "<Entity Name1> - " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2753) + "X" + "."
 * 
 * ; value = value.replace("{0}", "<Step Count>");
 * 
 * break; case "PopUp_RemoveStepTitle": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2757) + "X";
 * 
 * value = value.replace("{0}", "<Count>"); break; case
 * "PopUp_RemoveStepMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2755) + "X";
 * 
 * value = value.replace("{0}", "<Count>");
 * 
 * break; case "ErrorMessage_FeatureAlsoDefinedInStep":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2752) + "X";
 * 
 * value = value.replace("{0}", "<Entity Name>");
 * 
 * value = value.replace("{1}", "<Count>");
 * 
 * break; case "productionAssignments": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2874) + "X"; break; case
 * "English - US": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2870) + "X"; break; case
 * "English - UK": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2871) + "X"; break; case
 * "German - Germany": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2872) + "X"; break; case
 * "Spanish - Mexico": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2873) + "X"; break; case
 * "Vietnamese - Vietnam": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2886) + "X"; break; case
 * "Header_Purge": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2813) + "X"; break; case
 * "Purge_HelperMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2814) + "X" + "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2815) + "X";
 * 
 * break; case "Header_PurgeAllItems": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2817) + "X"; break; case
 * "msg_PurgePopUp_ConfirmationMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2818) + "X" + "\n" + "\n" + "X"
 * + UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2819) + "X";
 * break;
 * 
 * case "Msg_NoRemovedItemAvailable": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2820) + "X"; break; case
 * "GC_DCType_AlreadyExistAsRemovedMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2740) + "X"; break; case
 * "UnitOfMeasurementAlreadyExistsAsRemovedRecord": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2733) + "X";
 * break; case "AbbreviationAlreadyExistsAsRemovedRecord": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2732) + "X";
 * break; case "msg_PurgeRunning": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2825) + "X"
 * 
 * + "\n" + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2826) + "X"; break; case
 * "msg_CantRestoreMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2829) + "X"; value =
 * value.replace("{0}", "<EntityName>"); break; case "msg_PurgeFailed": value =
 * "X" + UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2828);
 * value = value.replace("{0}", ""); break; case "msg_PurgeSuccess": value = "X"
 * + UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2827); value
 * = value.replace("{0}", "");
 * 
 * break; case "lbl_AllRemovedItems": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2812) + "X"; break; case
 * "lbl_ProcessCollection": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2860) + "X"; break; case
 * "lbl_Appearance": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2703) + "X"; break; case
 * "URL_CodeGroupLandingPageHelpLink": value =
 * "CodeGroups/ManagingCodeGroups.htm"; break; case
 * "URL_EditCodeGroupLandingPageHelpLink": value =
 * "CodeGroups/EditingCodeGroups.htm"; break; case
 * "URL_CreateCodeGroupLandingPageHelpLink": value =
 * "CodeGroups/CreatingCodeGroups.htm"; break; case
 * "CodeGrp_AlreadyExistAsRemoved": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1023) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(42) + "X"); break; case
 * "CodeName_AlreadyExistAsRemoved": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2725) + "X"; break; case
 * "TagGrp_AlreadyAssigned": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2832) + "X"; break; case
 * "ErrorMessage_FeatureAlreadySelected": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1458) + "X"; break; case
 * "AccordionItem_AssignedControlLimitMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1063) + "X"; break; case
 * "AccordionItem_AssignedUserAccessLevelMessage": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(1200) + "X";
 * break; case "AccordionItem_AssignedWorkstationAccessLevelMessage": value =
 * "X" + UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2706) +
 * "X"; break; case "AccordionItem_AssignedGaugeDeviceMessage_Process": value =
 * "X" + UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2707) +
 * "X"; break; case "AccordionItem_AssignedLotMessage": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2562) + "X";
 * break; case "AccordionItem_AssignedCalculationMessage": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(1371) + "X";
 * break; case "AccordionItem_AssignedProductionAssignmentsWillBeImpacted":
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2884) + "X"; break; case
 * "txtPartProcessHeading": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2786) + "X"; break; case
 * "Label_LimitParameterSet": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2673) + "X" + "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(1394) + "X" +
 * "\n" + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2672) + "X";
 * 
 * break; case "lblFeatureInCapitals": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(33) + "X"; break; case
 * "lblTestCaluclationPopUpTitle": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(864) + "X"; break; case
 * "lblValues": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2564) + "X"; break; case
 * "txtMessageIsALsoDefinedInOtherCalculations": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2749) + "X"; break; case
 * "Step1_InCamelLetters": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2753) + "X"; value =
 * value.replace("{0}", "1"); break; case "Data Collection - Features": value =
 * "X" + UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(744) +
 * "X"; break; case "LandingPage_ContextMenu_LanguageIconText": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2891) + "X";
 * break; case "Lbl_AssignedChecklist": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2558) + "X"; break; case
 * "Lbl_ParentProcessUpdateConfirmationMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1101) + "X"; break; case
 * "Associated control limit records will be impacted": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(1129) + "X";
 * break; case "lblWorkDashboard": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2421) + "X"; break; case
 * "lblError_TestCalculationPopUp": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1287) + "X"; break; case
 * "Static_xpathShift": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2651) + "X"; break; case
 * "ChecklistInCaps": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(127) + "X"; break; case
 * "lblEditSubGroup": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2366) + "X"; break; case
 * "lblDataTable": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1706) + "X"; break; case
 * "columnName_TimeZone": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1413) + "X"; break; case
 * "msg_ParentAndChildCantExistWithSameName": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2173) + "X"; break; case
 * "msg_CantBeAssignedAsParentProcess": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2465) + "X";
 * 
 * value = value.replace("{0}", "<EntityName>"); break; case
 * "msg_ParentProcesslAlreadyContainsChildAsRemovedRecord": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2696) + "X";
 * break; case "msg_ProcessCantBeRestoredUntilParentIsRestored": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2702) + "X";
 * 
 * value = value.replace("{0}", "<ChildProcessName>");
 * 
 * value = value.replace("{1}", "<ParentProcessName>");
 * 
 * break; case "user": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(508) + "X"; value =
 * value.toLowerCase(); break; case "MenuTemplateName_AlreadyExistAsRemoved":
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2741) + "X"; break; case
 * "ParentProcessPopUp_CompanyDivisionCanNotSelect_Msg": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(1100) + "X";
 * break; case "ResponseGroupAlreadyExists": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2505) + "X"; break; case
 * "ChoiceAlreadyExists": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2506) + "X"; break; case
 * "AccessCodeIsIncorrect": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1000) + "X"; break; case
 * "AuthenticateWorkstation": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1002) + "X"; break; case
 * "PleaseEnterTheAccessCodeSentToYourEmailId": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1007) + "X"; break; case
 * "Permissions_Assign": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2911) + "X"; break; case
 * "DC_Config_Common_NotificationMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(258) + "X"; break; case
 * "ShowingResult_Lbl": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(717) + "X";
 * 
 * value = value .replace( "{0}", "<count>" + " " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(719) + "X");
 * 
 * break;
 * 
 * case "LanguagelabelsSavedSuccesssfullyMessage": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2892) + "X";
 * value = value.replace("{0}", "<languageLabel>");
 * 
 * break; case "Lbl_SequenceRule": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(428) + "X"; break; case
 * "WorkStation_RemoteAuthentication": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2928) + "X"; break; case
 * "WorkStation_LocalAuthentication": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2927) + "X"; break; case
 * "Lbl_Notification": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(431) + "X"; break; case
 * "Lbl_PromptForSampleSize": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(432) + "X" + " " + "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(255) + "X";
 * 
 * break; case "Lbl_SampleTime": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(715) + "X"; break; case
 * "Lbl_RequiredInformation": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(962) + "X"; break; case
 * "Lbl_Application": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2761) + "X"; break; case
 * "Lbl_CodeType": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2920) + "X"; break; case
 * "Lbl_EventCode": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2917) + "X"; break; case
 * "Lbl_EventCodes": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2921) + "X"; break; case
 * "Error_NoAccess_DataEntry": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1304) + "X";
 * 
 * value = value.replace("{0}", "<EntityName>");
 * 
 * break; case "OneProcessSelectedMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1117) + "X"; value =
 * value.replace("{0}", "1"); break; case
 * "PartRecipe(s)SavedSuccessfullyMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(337) + "X"; value =
 * value.replace("{0}", "<OutputPart>");
 * 
 * break; case "PartRecipes": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(739) + "X"; break; case
 * "CreatePartRecipe": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(217) + "X"; break; case
 * "SelectProcessModel": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(578) + "X"; break; case
 * "CreatePartRecipePageNoticiationMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(229) + "X"; break; case
 * "ProcessModelDoesntExist": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2553) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(67) + "X");
 * 
 * break;
 * 
 * case "EditTotalLicense_NotificationMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2914) + "X"; break; case
 * "License_ValidationMinCount": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2905) + "X";
 * 
 * value = value.replace("{0}", "<count>");
 * 
 * break; case "SelectPart&ItsRevisionToCopyPartRecipe(s)": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(582) + "X";
 * break; case "AccordionItem_AssignedParameterSet": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(1202) + "X";
 * break; case "Production_Assignments": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2874) + "X"; break; case
 * "CreateProductionAssignment": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2939) + "X"; break; case
 * "EditProductionAssignment": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2946) + "X"; break; case
 * "ActiveAssignments": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2913) + "X"; break; case
 * "Assigments(Latest30Days)": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2955) + "X" + " ("
 * 
 * + "X" + UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(1094)
 * + "X" + ")";
 * 
 * break; case "OverlappingCombinationWillNotBeAllowed": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2952) + "X";
 * 
 * value = value.replace("{0}", "<part lot combination>");
 * 
 * break; case "ProductionAssignmentSavedSuccessfullyMessage": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2951) + "X";
 * value = value.replace("{0}", "<processName>");
 * 
 * break; case "ProductionAssignmentDeleteConfirmationMessage": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2979) + "X";
 * value = value.replace("{0}", "<processName>"); break; case
 * "ProductionAssignmentDeletePopUpTitle": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2983)
 * 
 * + "X";
 * 
 * value = value.replace("{0}", "<processName>");
 * 
 * break; case "ProductionAssignmentDeleteSuccessfullyMessage": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2980) + "X";
 * value = value.replace("{0}", "<processName>"); break; case
 * "Lbl_EventCodeName": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2919) + "X"; break; case
 * "Lbl_ConfigureCodeTypes": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2940) + "X"; break; case
 * "LanguageLabelSavedSuccessfullyForCodeType": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2892) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2943) + "X");
 * 
 * break; case "LanguageLabelSavedSuccessfullyForCode":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2892) + "X";
 * 
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2936) + "X");
 * 
 * break; case "Pareto": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1722) + "X"; break; case
 * "Hierarchy": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2599) + "X"; break; case
 * "Violation": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2600) + "X"; break; case
 * "CollectedDataType": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1481) + "X"; break; case
 * "CollectionName": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1482) + "X"; break; case
 * "EventCodeType": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2942) + "X"; break; case
 * "CollectedData": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(321) + "X"; break; case
 * "ProcessEvents": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2034) + "X"; break; case
 * "SubgroupData": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1092) + "X"; break; case
 * "undefined": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2024) + "X";
 * 
 * break; case "ParetoChart": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1994) + "X"; break; case
 * "Select View Type": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1592) + "X"; break; case
 * "Graph": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1819) + "X"; break; case
 * "GraphAndReport": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1788) + "X"; break; case
 * "Report": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1789) + "X"; break; case
 * "Pieces": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2011) + "X"; break; case
 * "SIGL": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1801) + "X"; break; case
 * "Total": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(243) + "X"; break;
 * 
 * case "ToolTip_ControlLimitConfidenceInterval_Sigma": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(1910) + "X";
 * value = value + " = 1.632" + "\n" + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1909) + "X" + " = 4.417";
 * 
 * break; case "productionAssignment": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2925) + "X"; break; case
 * "PartNotExistsWithoutX": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(216) + "X"; break; case
 * "Company": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2601) + "X"; break; case
 * "ProductionAssignmentRemovalConfirmationMessage": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2950) + "X";
 * 
 * value = value.replace("{0}", "<PartLotName>");
 * 
 * value = value.replace("{1}", "<StartEndTime>");
 * 
 * break; case "ProductionAssignmentRemovalConfirmationMessageWithoutTime":
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2957) + "X";
 * 
 * value = value.replace("{0}", "<PartLotName>");
 * 
 * break; case "ProductionAssignmentRemovalConfirmationMessageBlankRow": temp =
 * "X" + UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(567) +
 * "X"; temp = temp .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2925) + "X"); value = temp;
 * 
 * break; case "ProductionAssignmentStartTimeCantGreaterMessage": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2953) + "X";
 * break; case "ProductionAssignment_AtLeastOneAssingmentMessage": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2954) + "X";
 * break; case "ProductionAssignment_RemovePopUp_Header": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2948) + "X";
 * break; case "ConfigureFilters": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(709) + "X"; break; case
 * "PartActiveAssignment": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(68) + "X" + " (" + "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2913) + "X" +
 * ")";
 * 
 * break; case "LotActiveAssignment":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(192) + "X" + " (" + "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2913) + "X" +
 * ")";
 * 
 * break; case "Percent of Total (Count)": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2056) + "X"; break; case
 * "Pareto Chart": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1994) + "X"; break; case
 * "Chart Summary": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1601) + "X"; break; case
 * "Total Subgroups": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1811) + "X"; break; case
 * "Total Pieces": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1812) + "X"; break; case
 * "Date Range": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1813) + "X"; break; case
 * "Part(s)": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1814) + "X"; break; case
 * "Process(es)": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1815) + "X"; break; case
 * "Feature(s)": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1816) + "X"; break; case
 * "Total Events": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2422) + "X"; break; case
 * "Portuguese_Brazil": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(3042) + "X"; break; case
 * "Spanish_Spain": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(3045) + "X"; break; case
 * "Define Levels": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1591) + "X"; break; case
 * "No data to display. Please": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2301) + "X"; break; case
 * "select Parameter Set": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2302) + "X"; break; case
 * "Division": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2602) + "X"; break; case
 * "Region": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2603) + "X"; break; case
 * "Site": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2563) + "X"; break; case
 * "Department": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2604) + "X"; break; case
 * "Area": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(57) + "X"; break; case
 * "Process Unit": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2605) + "X"; break; case
 * "Process": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(194) + "X"; break; case
 * "Sub Process": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2606) + "X"; break; case
 * "No data to display": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2201) + "X"; break; case
 * "Please select a chart to view details": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1471) + "X"; break; case
 * "Select Level": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(129) + "X"; break; case
 * "Manual": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(951) + "X"; break; case
 * "EnterTag": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(456) + "X"; break; case
 * "TagValueCharacterLimitMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2373) + "X"; value =
 * value.replace("{0}", "<limit>");
 * 
 * break; case "TagValueMaximumValueMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2374) + "X"; break; case
 * "errorMessage_AtLeastOneOutputMustBeDefinedWithoutMoreButton": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2745) + "X";
 * break;
 * 
 * case "Lot_DeleteConfirmation_Message":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(567) + "X";
 * 
 * value = value.replace("{0}", "<Element Name>");
 * 
 * value = value + "\n" + "\n" + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(557) + "X"; break;
 * 
 * case "ChangeHistory": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(3028) + "X"; break; case
 * "Assign/Unassign": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(3064) + "X"; break; case
 * "ChangeType": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(3031) + "X"; break; case
 * "Restore": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2219) + "X"; break; case
 * "Column_RecordDate": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(3029) + "X"; break; case
 * "ASCII_LABEL": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1521) + "X"; break; case
 * "PreviousValue": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(3041) + "X"; break; case
 * "LowerLSL": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(202) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(188) + "X");
 * 
 * break; case "UpperUSL": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(201) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(184) + "X");
 * 
 * break; case "Changes": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(3030) + "X"; break; case
 * "Collections": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2904) + "X"; break; case
 * "LowerToggleState":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(202) + "X";
 * 
 * value = value.replace("{0}", "X" + "<limit>" + "X") + " " + "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(3038) + "X";
 * 
 * break; case "UpperToggleState": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(201) + "X";
 * 
 * value = value.replace("{0}", "X" + "<limit>" + "X") + " " + "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(3038) + "X";
 * break; case "LowerLimit": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(202) + "X";
 * 
 * value = value.replace("{0}", "X" + "<limit>" + "X");
 * 
 * break; case "UpperLimit": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(201) + "X";
 * 
 * value = value.replace("{0}", "X" + "<limit>" + "X"); break; case "MAVLSC":
 * value = "MAV" + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(519) + "X" + " - " + "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(510) + "X";
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(511) + "X");
 * 
 * break; case "T1T2LSC":
 * 
 * value = "T1T2" + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(519) + "X" + " - " + "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(510) + "X";
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(511) + "X");
 * 
 * break; case "MAVUnitSameAsSpec": value = "MAV" + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(519) + "X - " + "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(509) + "XX" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(3039) + "X";
 * 
 * break; case "T1T2UnitSameAsSpec": value = "T1T2" + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(519) + "X - " + "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(509) + "XX" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(3039) + "X";
 * 
 * break; case "MAVUnit":
 * 
 * value = "MAV" + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(519) + "X" + " - " + "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(191) + "X";
 * 
 * break; case "T1T2Unit":
 * 
 * value = "T1T2" + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(519) + "X" + " - " + "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(191) + "X";
 * 
 * break; case "MaxGreaterUpper": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(802) + "X"; break; case
 * "MaxLessLower": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(804) + "X"; break; case
 * "MAVUpperToggleState": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(801) + "X" + " " + "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(3038) + "X";
 * 
 * break; case "MAVLowerToggleState": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(803) + "X" + " " + "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(3038) + "X";
 * 
 * break; case "MAVUpper": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(801) + "X"; break; case
 * "MAVLower": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(803) + "X"; break; case
 * "MAXBetweenT1T2Upper": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(808) + "X"; value =
 * value.replace("<sub>", ""); value = value.replace("</sub>", "");
 * 
 * break; case "MAXBetweenT1T2Lower": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(808) + "X"; value =
 * value.replace("<sub>", ""); value = value.replace("</sub>", "");
 * 
 * break; case "View_Limit_Page_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2799) + "X"; break; case
 * "Default Name": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2902) + "X"; break; case
 * "Message_RestoreConfirmation_WithoutAssociation_SpecLimit": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(1986) + "X";
 * value = value.replace("{0}", "<Element Name>"); value =
 * value.replace(" <br>", "\n"); value = value.replace("<br>", "\n"); break;
 * 
 * case "Message_RestoreSuccess_SpecLimit": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1996) + "X"; value =
 * value.replace("{0}", "<Element Name>");
 * 
 * break; case "Message_SpecAlreadyExistForGivenCombination": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2716) + "X";
 * 
 * value = value.replace("{0} - {1} - {2}", "<Element Name>");
 * 
 * break; case "BulkDeleteSubgroupData": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(3072) + "X"; break; case
 * "Prompt": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(3058) + "X"; break; case
 * "Prompt (Limited)": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(3059) + "X"; break; case
 * "No Prompt": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(3060) + "X"; break; case
 * "DataCollectionTypeCountMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1388) + "X";
 * 
 * value = value.replace("{0}", "<count>");
 * 
 * value = value .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2823) + "X");
 * 
 * break; case "GaugeInterfaceNameAlreadyExists": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1548) + "X"; break; case
 * "GaugeInterfaceModifyMessageWhenDeviceIsAssociated": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(1730) + "X" +
 * "\n" + "\n" + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1808) + "X"; break; case
 * "ViewGaugeDevice": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1888) + "X"; break; case
 * "ViewGaugeDevicePopUpMessageForSingleDevice":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(731) + "X";
 * 
 * temp = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(4030) + "X";
 * 
 * temp = temp.toLowerCase(); value = value.replace("{0}", "<Count>");
 * 
 * value = value.replace("{1}", temp);
 * 
 * temp = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1528) + "X"; temp =
 * temp.replace("{0}", "<interfaceName>");
 * 
 * value = temp + value; break; case
 * "ViewGaugeDevicePopUpMessageForMultipleDevices": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(728) + "X";
 * value = value.replace("{0}", "<Count>");
 * 
 * temp = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1728) + "X";
 * 
 * value = value.replace("{1}", temp); value = value.toLowerCase(); temp =
 * value; value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1528) + "X";
 * 
 * value = value.replace("{0}", "<interfaceName>"); value = value + " " + temp;
 * 
 * break; case "ViewGaugeFormat": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1527) + "X"; break; case
 * "ViewGaugeFormatPopUpMessageForSingleFormat": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(731) + "X";
 * 
 * temp = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(4030) + "X";
 * 
 * value = value.replace("{1}", temp); value = value.toLowerCase(); value =
 * value.replace("{0}", "<Count>"); temp = value; value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1528) + "X";
 * 
 * value = value.replace("{0}", "<interfaceName>"); value = value + " " + temp;
 * 
 * break; case "ViewGaugeFormatPopUpMessageForMultipleFormat": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(728) + "X";
 * 
 * temp = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1577) + "X";
 * 
 * value = value.replace("{1}", temp); value = value.toLowerCase(); value =
 * value.replace("{0}", "<Count>"); temp = value; value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1528) + "X";
 * 
 * value = value.replace("{0}", "<interfaceName>"); value = value + " " + temp;
 * 
 * break; case "EntityAlreadyExistMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(300) + "X"; value =
 * value.replace("{0}", "X" + "<Entity Name>" + "X");
 * 
 * break; case "Permissions_Configure": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2926) + "X"; break;
 * 
 * case "Odd": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1765) + "X"; break; case
 * "Even": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1766) + "X"; break; case
 * "Space": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1768) + "X"; break; case
 * "Mark": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1767) + "X"; break; case
 * "XON/XOFF": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1777) + "X";
 * 
 * break; case "CTS/RTS": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1778) + "X"; break; case
 * "RTS=off/DTR=on": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1779) + "X"; break;
 * 
 * case "View_Code_Types": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2918) + "X"; break; case
 * "Configure_Code_Types": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2940) + "X"; break; case
 * "ASCIICharacterValues": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1542) + "X"; break; case
 * "DataPurge": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(4008) + "X"; break; case
 * "AccordionItem_AssignedEventCodes": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(3010) + "X"; break; case
 * "RemoveConfirmationMessage_CodeTypeAssociatedWithEventCode": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(3009) + "X";
 * 
 * value = value.replace("{0}", "<CodeTypeName>"); break; case
 * "Message_AtleastOneRequired": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(69) +
 * "XAt least 1 <entity> required.X" + "X"; break; case
 * "Entity_AlreadyExistAsRemoved": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1023) + "X";
 * 
 * value = value.replace("{0}", "<EntityName>"); break; case
 * "ValidationForGaugeAgentGaugeInterfaceAndComPortCombination": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(1883) + "X";
 * break; case "SubValidationForGaugeAgentGaugeInterfaceAndComPortCombination":
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1884) + "X"; break; case
 * "Less": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(824) + "X"; break; case
 * "LevelWithCount": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(3074) + "X"; value =
 * value.replace("{0}", "<Count>");
 * 
 * break; case "Analysis": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2059) + "X"; break; case
 * "Data Management": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(4006) + "X"; break;
 * 
 * case "BasicInformation": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1316) + "X"; break; case
 * "Advanced": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1576) + "X"; break; case
 * "FormatDescription": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1630) + "X"; value =
 * value.toUpperCase(); break; case "RecordDescription": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(1605) + "X";
 * value = value.toUpperCase(); break; case "MultiFieldOutputSection": value =
 * "X" + UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(1611) +
 * "X"; value = value.toUpperCase(); break;
 * 
 * case "Port_Initialization_String": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1503) + "X"; break; case
 * "Port_Termination_String": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1584) + "X"; break; case
 * "Delay(ms)": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1520) + "X"; break; case
 * "MDC_HelpSectionDefaultMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(313) + "X"; value =
 * value.replace("{0}", "<FeatureName>"); value = value.replace("{1}",
 * "<PartName>");
 * 
 * break; case "OK": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(69) + "XOKX" + "X"; break; case
 * "GaugeIntefaceConnectionMsgForSingleGaugeDevice": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(1725) + "X" +
 * ": <AgentName> - <InterfaceName> (<ComPortSetting>) ";
 * 
 * temp = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(731) + "X";
 * 
 * temp = temp .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1505) + "X"); temp =
 * temp.toLowerCase(); temp = temp.replace("{0}", "<count>");
 * 
 * value = value + temp;
 * 
 * break; case "ModifyingAGaugeInterfaceConnectionWillAffect2GaugeDevices":
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1991) + "X";
 * 
 * value = value.replace("{0}", "2");
 * 
 * break; case "RawData": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1473) + "X"; break; case
 * "HexData": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2148) + "X"; break; case
 * "SpecialCharacters": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2154) + "X"; break; case
 * "CarriageReturn": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2150) + "X"; break; case
 * "LineFeed": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2151) + "X"; break; case
 * "SerialDataMonitor": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2146) + "X"; break; case
 * "Compliance": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2622) + "X"; break; case
 * "StreamSummary": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2022) + "X"; break; case
 * "ControlCharts": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1718) + "X"; break; case
 * "NetContent": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2434) + "X"; break; case
 * "Within": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1985) + "X"; break; case
 * "Deviation": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2435) + "X"; break;
 * 
 * case "MDC_DefectiveCount": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(3033) + "X"; value =
 * value.replace("{0}", "<count>"); break; case "MDC_DefectiveViolationHeader":
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(3034) + "X"; value =
 * value.replace("{0} - {1}", "<PartFeatureName>"); break; case
 * "MDC_AddLotDetails_SubHeading": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(3078) + "X"; value =
 * value.replace("{0}", "<partName>"); break;
 * 
 * case "MDC_Piece_Info": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(312) + "X"; value =
 * value.replace("{0}", "<PieceNo>"); value = value.replace("{1}", "<Total>");
 * break; case "MDC_PieceNumber": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(360) + "X"; value =
 * value.replace("{0}", "<PieceNo>"); break; case "MDC_LotIsUnavailable": value
 * = "X" + UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(3086)
 * + "X"; break; case "MDC_TotalCount_SummaryHeader": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(239) + "X";
 * value = value.replace("{0}", "<FeatureName>"); break; case "MDC_TotalCount":
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(243) + "X" + " : <count>";
 * break; case
 * "ValidationForGaugeAgentGaugeInterfaceComPortCombinationAndGaugeFormat":
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1880) + "X"; break;
 * 
 * case "Gauge_Agent": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2074) + "X"; break; case
 * "Process_Name": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(240) + "X"; break; case
 * "ProcessView_PopUp_Header": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(731) + "X";
 * 
 * temp = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(194) + "X";
 * 
 * value = value.replace("{1}", temp);
 * 
 * value = value.toLowerCase(); value = value.replace("{0}", "<Count>"); temp =
 * value;
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1505) + "X" +
 * ": <GaugeDeviceName> " + temp;
 * 
 * break; case "ProcessView_PopUp_Header_For_Multiple_Process":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(728) + "X";
 * 
 * temp = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1080) + "X";
 * 
 * value = value.replace("{1}", temp); value = value.toLowerCase(); value =
 * value.replace("{0}", "<Count>");
 * 
 * temp = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1505) + "X"; value = temp +
 * ": <GaugeDeviceName> " + value; break; case "Compliance_Values_Heading":
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2622) + "X" + " (" + "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2564) + "X" +
 * ")";
 * 
 * break; case "ComplianceDataCollections_Heading":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2622) + "X" + " (" + "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(732) + "X" +
 * ")"; break;
 * 
 * case "DeleteConfirmaitonMessageWhenProcessAssociationWillNotRemove": value =
 * "X" + UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2005) +
 * "X"; break; case "DeleteConfirmaitonMessageWhenProcessIsNotAssociate": value
 * = "X" + UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2006)
 * + "X"; break; case "DeleteConfirmaitonMessageWithAssociationswithDC": value =
 * "X" + UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(567) +
 * "X" + "\n\n";
 * 
 * value = value.replace("{0}", "<Element Name>");
 * 
 * temp = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(4125) + "X";
 * 
 * value = value + temp;
 * 
 * break; case "AccordionItem_AssignedDC": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2300) + "X"; break; case
 * "Received": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2624) + "X"; break; case
 * "Gauge Initialization String": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1638) + "X"; break; case
 * "Measurement Initialization String": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1640) + "X"; break; case
 * "Measurement Start String": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1642) + "X"; break; case
 * "Measurement End String": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1644) + "X"; break; case
 * "Measurement Read String": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1646) + "X"; break; case
 * "Measurement Post String": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1648) + "X"; break; case
 * "Measurement Request String": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1650) + "X"; break; case
 * "Data Collection Start String": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1652) + "X"; break; case
 * "Data Collection End String": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1654) + "X"; break; case
 * "GaugeFormatNameAlreadyExists": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1609) + "X"; break; case
 * "0 - ASCII/Text": value = "0 - " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1632) + "X"; break; case
 * "1 - ASCII (16 bit)": value = "1 - " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1633) + "X"; break; case
 * "2 - Binary (LSByte First)": value = "2 - " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1634) + "X"; break; case
 * "3 - Binary (MSByte First)": value = "3 - " + "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1635) + "X"; break; case
 * "GaugeMultiFieldValidation": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1697) // + // "XItem is
 * improperly configured in multi field output // section // grid.X" + "X";
 * value = value.replace("{0} ", "");
 * 
 * break; case "EditGaugeFormatConfirmaitonMessageWhenAttachedToGaugeDevice":
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(69) + "X" + "\n" + "\n" + "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(1808) +
 * "XModifying a gauge format will affect all the gauge devices using this gauge format.X"
 * + "\n" + "\n" + "XDo you still want to continue?X" + "X"; break; case
 * "ViewGaugeDevicePopUpForGaugeFormat": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(731) + "X"; value =
 * value.replace("{0}", "<Count>");
 * 
 * temp = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(4030) + "X";
 * 
 * value = value.replace("{1}", temp);
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(69) +
 * "XGauge Format: <formatName>X x(1 xgauge devicex exists.)x" + "X"; break;
 * case "removeGaugeFormatConfirmaitonMessageWhenAttachedToGaugeDevice": value =
 * "X" + UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(567) +
 * "X" + "\n" + "\n"; value = value.replace("{0}", "<formatName>");
 * 
 * temp = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2025) + "X";
 * 
 * temp = temp .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1504) + "X"); temp =
 * temp.toLowerCase();
 * 
 * value = value + temp;
 * 
 * break;
 * 
 * case "AssociationMessage_RemovedSingleGaugeDevice":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2027) + "X" + " (1)"; value =
 * value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1505) + "X");
 * 
 * break; case "GaugeFormatTesting_TestText": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1619)
 * 
 * + "X"; break; case "GaugeFormatTesting_TestingArea": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(1620)
 * 
 * + "X"; break; case "Field# = ": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(69) + "XFieldX# =" + "X";
 * break; case "Start Position = ": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1614) + "X" + " ="; break; case
 * "Length = ": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1615) + "X" + " ="; break;
 * 
 * case "ManufacturingLimitViolation": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(4126) + "X"; break;
 * 
 * case "WorkFlow_Header_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(4022) + "X"; break; case
 * "CreateWorkFlow_Page_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(4027) + "X"; break; case
 * "Lbl_EventCategory": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(4071) + "X"; break; case
 * "Msg_WorkFlow_CodeTypehaveAtleastOneEventCode": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(4065) + "X";
 * break; case "Msg_WorkFlow_AtLeastOneCodeTypeInOptionalRequiredPanel": value =
 * "X" + UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(4064) +
 * "X"; break;
 * 
 * case "WorkFlow_Status_Active": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(451) + "X"; break; case
 * "WorkFlow_Status_Inactive": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(421) + "X"; break; case
 * "WorkFlow_Status_Disabled": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(4074) + "X"; break; case
 * "columnName_WorkflowName": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(4028) + "X"; break; case
 * "WorkFlowAssignment_Header_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(4023) + "X"; break; case
 * "CreateWorkFlowAssignment_Page_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(4075) + "X"; break; case
 * "EditWorkFlowAssignment_Page_Title": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(4104) + "X"; break;
 * 
 * case "AccessCode": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1006) + "X";
 * 
 * case "DataView": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1450) + "X"; break;
 * 
 * case "CL": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1437) + "X"; break; case "UCL":
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1436) + "X"; break; case "LCL":
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1438) + "X"; break;
 * 
 * case "Histogram Chart": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1564) + "X"; break;
 * 
 * case "Maximum Value": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1909) + "X"; break;
 * 
 * case "Minimum Value": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1910) + "X"; break;
 * 
 * case "Mean": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1699) + "X"; break;
 * 
 * case "Mean - 3SD (lt)": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1912) + "X"; break;
 * 
 * case "Mean + 3SD (lt)": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1919) + "X"; break;
 * 
 * case "Short term SD": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1913) + "X"; break;
 * 
 * case "Long term SD": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1914) + "X"; break;
 * 
 * case "Robustness": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1915) + "X"; break;
 * 
 * case "CoVar": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1916) + "X"; break;
 * 
 * case "Z-bench": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1917) + "X"; break;
 * 
 * case "Target ratio": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1918) + "X"; break;
 * 
 * case "Specification": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1895) + "X"; break;
 * 
 * case "Z USL": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1923) + "X"; break;
 * 
 * case "Z Target": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1924) + "X"; break;
 * 
 * case "Z LSL": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1925) + "X"; break;
 * 
 * case "Actual Above": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1926) + "X"; break;
 * 
 * case "Actual Below": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1927) + "X"; break;
 * 
 * case "Actual Total": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1928) + "X"; break;
 * 
 * case "Actual PPM": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1929) + "X"; break;
 * 
 * case "Expected Above": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1930) + "X"; break;
 * 
 * case "Expected Below": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1931) + "X"; break;
 * 
 * case "Expected Total": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1932) + "X"; break;
 * 
 * case "Expected PPM": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1933) + "X"; break;
 * 
 * case "Potential Indices": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1898) + "X"; break;
 * 
 * case "Cp": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1961) + "X"; break;
 * 
 * case "Cr (1/Cp)": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1962) + "X"; break;
 * 
 * case "Pp": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1963) + "X"; break; case
 * "Pr (1/Pp)": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1964) + "X"; break;
 * 
 * case "Performance Indices": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1899) + "X"; break;
 * 
 * case "Cpk": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1965) + "X"; break; case
 * "Cpk Upper": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1966) + "X"; break;
 * 
 * case "Cpk Lower": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1967) + "X"; break;
 * 
 * case "Cpm": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1968) + "X"; break;
 * 
 * case "SIGL (st)": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1969) + "X"; break;
 * 
 * case "Ppk": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1970) + "X"; break;
 * 
 * case "Ppk Upper": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1971) + "X"; break;
 * 
 * case "Ppk Lower": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1972) + "X"; break;
 * 
 * case "Ppm": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1973) + "X"; break;
 * 
 * case "SIGL (lt)": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1974) + "X"; break;
 * 
 * case "Moments of Distribution": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1901) + "X"; break;
 * 
 * case "Avg Deviation": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1956) + "X"; break;
 * 
 * case "Std Deviation": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1957) + "X"; break;
 * 
 * case "Variance": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1958) + "X"; break;
 * 
 * case "Skewness": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1959) + "X"; break;
 * 
 * case "Kurtosis": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1960) + "X"; break;
 * 
 * case "Chi squared Goodness of Fit": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1902) + "X"; break; case
 * "Chi-Squared": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2447) + "X"; break;
 * 
 * case "DF": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2448) + "X"; break;
 * 
 * case "Chi Sq Prob": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2449) + "X"; break;
 * 
 * case "Analysis of Variance": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1903) + "X"; break;
 * 
 * case "d.f": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1987) + "X"; break;
 * 
 * case "Plot Point Value": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1475) + "X"; break;
 * 
 * case "French - France": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(4096) + "X"; break;
 * 
 * case "ExclusionRule":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1617) + "X"; break;
 * 
 * case "URL_CreateProcessingTemplatePageHelpLink":
 * 
 * value = "ProcessingTemplates/CreatingProcessingTemplates.htm"; break; case
 * "URL_EditProcessingTemplatePageHelpLink":
 * 
 * value = "ProcessingTemplates/EditingProcessingTemplates.htm"; break;
 * 
 * case "EntryMethodGDErrorMessage":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2337) + "X"; value =
 * value.replace("{0}", "<Element Name>"); break;
 * 
 * case "ValidationForMultifieldSelectSendBox":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2565) + "X"; break; case
 * "ValidationForMultifieldNumericSelect":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2261) + "X"; break; case
 * "ValidationForGaugeDeviceGaugeAgentGaugeInterfaceComPortCombination":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(3050) + "X"; break; case
 * "DeleteConfirmaitonMessageWithAssociationsForGaugeInterfaceForNonRemovableGD"
 * :
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2051) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1500) + "X");
 * 
 * break; case "AccordionItem_AssignedNonRemovableGaugeFormat":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2030) + "X"; break; case
 * "AccordionItem_AssignedNonRemovableGaugeDevice":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2029) + "X"; break; case
 * "port_Initialization_String":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1503) + "X";
 * 
 * break; case "delay(ms)":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1520) + "X"; break; case
 * "SystemAlerts":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(3016) + "X"; break;
 * 
 * case "exclude":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1462) + "X"; break;
 * 
 * case "include":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1461) + "X"; break;
 * 
 * case "SubGroupSize":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1432) + "X"; break; case
 * "Defectives":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1955) + "X"; break; case
 * "Defects":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1532) + "X"; break; case
 * "Spec_Limit_Value":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(4030) + "X"; break; case
 * "< [Field]":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2414) + "X"; break; case
 * "<= [Field]":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2416) + "X"; break; case
 * "<> [Field]":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2412) + "X"; break; case
 * "= [Field]":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2411) + "X"; break; case
 * "> [Field]":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2413) + "X"; break; case
 * ">= [Field]":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2415) + "X"; break; case
 * "Contains":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2417) + "X"; break; case
 * "Dashboard_Header_Title_Spanish":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(66) + "X"; break; case "Send":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2149) + "X"; break; case
 * "ColumnName_Reason": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(4002) + "X"; break; case
 * "ColumnName_Assigned_Work_Dashboard": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2228) + "X"; break; case
 * "ColumnName_Assigned_License": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(570) + "X"; break; case "Date":
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(4083) + "X"; break;
 * 
 * case "MostRecentRecord": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2632) + "X"; break; case
 * "Static_xpathDCType": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(3067) + "X"; break;
 * 
 * case "ProcessInformation": value = UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2924); break;
 * 
 * case "EventReviews": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(4109) + "X"; break;
 * 
 * case "EventDetails": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2931) + "X"; break; case
 * "label_SelectEventCodeType": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(4110) + "X"; break; case
 * "label_AddEventCode": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(4111) + "X"; break;
 * 
 * case "ProcessCantBeRemovedAsItIsAssignedToUser(s)OrWorkstation(s)": value =
 * "X" + UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(3088) +
 * "X"; value = value.replace("{0}", "<Process Name>"); break;
 * 
 * case "MDC_PartPopUp_SelectThePartMakingFromOD": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2045) + "X";
 * value = value.replace("{0}", "<ODName>"); break;
 * 
 * case "MDC_ProcessPopUp_SelectTheProcessForOP": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2048) + "X"; value =
 * value.replace("{0}", "<OpName>"); break;
 * 
 * case "Restore Manufacturing Limit": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1922) + "X"; break;
 * 
 * case "DataCollectionTypes": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(3068) + "X"; break;
 * 
 * case "Day": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(766) + "X"; break; case
 * "DatCollectionType_Exclude": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1460) + "X"; value = value
 * .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(3068) + "X"); value = value
 * .replace( "{1}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1462) + "X");
 * 
 * break;
 * 
 * case "UserReactivationConfirmationMessageWithSingleReason":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(3098) + "X" + "\n" + "\n" + "X"
 * + UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(3099) + "X";
 * 
 * value = value.replace("<i>", ""); value = value.replace("</i>", "");
 * 
 * value = value.replace("{0}", "<UserFullName>"); value = value.replace("{1}",
 * "<DateTimeStamp>"); value = value.replace("{2}", "<ReasonName>");
 * 
 * break;
 * 
 * case "NoRecentLogins": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(4005) + "X"; break;
 * 
 * case "ReActivationSuccessMessage": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(4001) + "X"; value =
 * value.replace("{0}", "<UserFullName>");
 * 
 * break; case "In": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2335) + "X";
 * 
 * break;
 * 
 * case "Above USL": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1842) + "X";
 * 
 * break;
 * 
 * case "msg_bulkDeleteSubgroupDataSuccess": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(3090) + "X"; value =
 * value.replace("{0}", "<entityTime>");
 * 
 * break; case "ManageLicenseReport": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(4147) + "X";
 * 
 * break;
 * 
 * case "Language_labels_of_process_state(s)_saved_successfully": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(2892) + "X";
 * value = value .replace( "{0}", "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2908) + "X"); break;
 * 
 * case "ViewReport": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1597) + "X"; break;
 * 
 * case "ControlChart": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1445) + "X"; break; case
 * "Collection": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2883) + "X"; break;
 * 
 * case "OOS": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1799) + "X"; break;
 * 
 * case "OOC": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2179) + "X"; break; case
 * "Piece Number": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1694) + "X";
 * 
 * break; case "User": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(508) + "X";
 * 
 * break; case "Time Stamp": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1693) + "X";
 * 
 * break; case "NoItemsFound": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2457) + "X"; break; case
 * "Label_All": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1711) + "X"; break;
 * 
 * case "ConfirmationMessageForLicenseAssignment": value = "X" +
 * UtilityFunctions .getValueOnBasisOfUserPrefferedLanguageAndKey(4095) + "X";
 * break;
 * 
 * case "EmailForDueReminderForDC":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2078) + "X"; break;
 * 
 * case "EmailForLateReminderForDC":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(3003) + "X"; break;
 * 
 * case "EmailForMissedReminderForDC":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(3004) + "X"; break;
 * 
 * case "EmailForManufactoringLimitViolationForDC":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(4116) + "X"; break;
 * 
 * case "Values":
 * 
 * value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(2564) + "X"; break;
 * 
 * case "CodeType_Camera": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(4145) + "X"; break; case
 * "Danish - Denmark": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(4179) + "X"; break; case
 * "Swedish - Sweden": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(4180) + "X"; break; case
 * ">USL": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(1976) + "X"; break; case
 * "CodeList": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(4195) + "X"; break;
 * 
 * case "CodeGridIncrement": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(4197) + "X"; break; case
 * "CodeGridNumeric": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(4198) + "X"; break; case
 * "RequireCodeforEachPiece": value = "X" + UtilityFunctions
 * .getValueOnBasisOfUserPrefferedLanguageAndKey(4196) + "X"; break;
 * 
 * }
 * 
 * } catch (Exception e) { e.printStackTrace(); } return value; } }
 */