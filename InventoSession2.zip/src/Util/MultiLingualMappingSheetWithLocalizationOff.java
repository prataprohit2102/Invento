package Util;

public class MultiLingualMappingSheetWithLocalizationOff {

	// This method maps mulilingual sheet entries with Resource string excel,
	// We have created 2 methods, becase single method was too large to save ,
	// as we cannot save a method after a certain size.
	// Author : yogendra Rathore
	public static String mapMultiLingualSheet(String key) {

		String value = "";
		String temp = "";
		String temp1 = "";
		String temp2 = "";
		String temp3 = "";

		try {
			switch (key) {
			case "BackButton":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1);
				break;

			case "ShortnameUniquenessValidationMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(154);
				break;
			case "Code_Already_Exists":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(458);
				break;
			case "CodeGroup_Already_Exists":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(492);
				break;
			case "Required":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(96);
				break;
			case "RevisionnameUniquenessValidationMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(426);
				break;
			case "InvalidFormatValidationMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(69);
				break;
			case "ResetPasswordLinkSendSuccessfully":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1134)

				;
				break;
			case "InvalidLoginCredentials":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(636)

				;
				break;
			case "ProcessState_Already_Exists":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(950);
				break;
			case "ForgotPassword_DefaultMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1130);
				break;
			case "UsernameUniquenessValidationMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(607);
				break;
			case "EmaiUniquenessValidationMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(608);
				break;
			case "SaveSuccessfullyMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(102);
				value = value.replace("{0}", "<Element Name>");
				break;
			case "ProcessState_Configurations_Save_Successfully":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(966);
				break;
			case "AccountDeactivationMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(635);
				break;
			case "ForgotPasswordLinkSendSuccessfully":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1143);
				break;
			case "PartCountMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1388);

				value = value.replace("{0}", "<count>");
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(76));

				break;
			case "ProcessCountMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1388);

				value = value.replace("{0}", "<count>");
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(194));

				break;
			case "ParameterSet_NoProcessMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1832);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(194));

				break;
			case "ParameterSet_NoFeatureMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1832);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(33));

				break;
			case "FeatureCountMessage":

				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1388);

				value = value.replace("{0}", "<count>");
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(33));

				break;
			case "TagValueAlreayExists":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2377);
				break;
			case "ParameterSet_NoPartMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1832);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(68));

				break;
			case "ParameterSet_NoCodeMessage":

				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1832);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(398));

				break;
			case "CodeCountMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1388);

				value = value.replace("{0}", "<count>");
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(398));

				break;
			case "ParameterSet_SelectedParts":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2036);
				break;

			case "ParameterSet_SelectedTags":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1463);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(43));
				break;
			case "ParameterSet_NoTagMessage":

				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1832);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(399));

				break;
			case "MultiProcessCountMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1388);

				value = value.replace("{0}", "<count>");
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(237));

				break;
			case "SinglePartCountMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1388);

				value = value.replace("{0}", "<count>");
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(76));

				break;
			case "MultiFeatureCountMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1388);

				value = value.replace("{0}", "<count>");
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(80));

				break;
			case "EndDateSmallerThanStartDate":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1404);
				break;
			case "Part_AlreadyExists":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(331);
				break;
			case "ValidationMessageForInvalidImage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1404);
				break;
			case "ValidationMessageForGreaterThan600KBImage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(110);
				break;
			case "ValidationMessage_CreateSpecificationPage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(107);
				break;
			case "AccordionItem_OnlyInputPart":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(670);
				break;
			case "AccordionItem_OnlyOutputPart":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(671);
				break;
			case "Feature_DeleteConfirmaitonMessageWithAssociations":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(569);
				break;
			case "SpecLimit_DeleteConfirmaitonMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(143);
				value = value.replace("{0}", "<Part,Revision,Feature,Lot,Process>");
				break;
			case "Part_DeleteConfirmaitonMessageWithAssociations":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(665);
				break;
			case "Part_DeleteConfirmaitonMessageWithOutAssociations":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(567);

				value = value.replace("{0}", "<PartName,Revision>");
				break;
			case "Tag_DeleteConfirmaitonMessageWithAssociations":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(478);
				break;
			case "Feature_DeleteConfirmaitonMessageWithOutAssociations":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(567);

				value = value.replace("{0}", "<Element Name>");

				break;
			case "CollectionAid_DeleteConfirmationMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(944);
				value = value.replace("{0} - {1}", "<Part,Revision,Feature>");

				break;
			case "RemovedSuccessfullyMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(472);
				value = value.replace("{0}", "<Element Removed>");

				break;
			case "Process_DeleteConfirmaitonMessageWithAssociations":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(573);
				break;
			case "ConfirmationMessageForUnsavedData":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(91);
				// below line is replacing a special character with space -
				// don't remove this line- Yogendra Rathore
				value = value.replace("�", " ");
				break;
			case "EditPartRevision_ConfirmationMessageForUnsavedDataOnClickingCreateSpecButton":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(580);
				break;
			case "ValidationDisplayedOnGivingEndDateLessThanStartDate":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(489);
				break;
			case "ConfirmationMessage_EditFeaturePage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(580);
				break;
			case "AccordionItem_AssignedODMessage_Feature":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(564);
				break;
			case "AccordionItem_AssignedDCMessage_Feature":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(565);
				break;
			case "AccordionItem_AssignedProcessMessage_Tag":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(496);
				break;
			case "AccordionItem_AssignedPartMessage_Tag":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(497);
				break;
			case "AccordionItem_AssignedFeatureMessage_Tag":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(498);
				break;
			case "AccordionItem_AssignedCodeMessage_Tag":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(500);
				break;
			case "AccordionItem_AssignedUserMessage_Tag":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(970);
				break;
			case "AccordionItem_AssignedCodeGroupMessage_Tag":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(501);
				break;
			case "Feature_SpecLimit_ConfirmationMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1012);
				break;
			case "TagGroup_DeleteConfirmaitonMessageWithAssociations":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(558);
				break;
			// for feature dont change as message varies in feature and part\
			// process
			case "Feature_SubGroup_ConfirmationMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1116);
				break;
			// for part and process
			case "SubGroup_ConfirmationMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(654);
				break;
			case "Part_SubGroup_ConfirmationMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(655);
				break;
			case "ConfirmatioPopUp_MessageHeader":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(221);
				break;
			case "ConfirmationMessageForTotalCountGreaterThanSubGroupSize":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(699);
				break;
			case "ConfirmationMessage_ParametSetSelectEntityPage_Dynamic_Feature":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1717);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(33));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1390));

				break;
			case "ConfirmationMessage_ParametSetSelectEntityPage_Dynamic_Process":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1717);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(194));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1390));

				break;
			case "ConfirmationMessage_ParametSetSelectEntityPage_Static_Feature":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1717);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(33));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1391));

				break;
			case "ConfirmationMessage_ParametSetSelectEntityPage_Static_Process":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1717);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(194));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1391));

				break;
			case "AccordionItem_AssignedParameterSetMessage_Tag":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1202);
				break;
			case "ConfirmationMessage_ParametSetSelectEntityPage_Dynamic_Part":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1717);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(76));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1390));
				break;
			case "ConfirmationMessage_ParametSetSelectEntityPage_Static_Part":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1717);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(76));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1391));

				break;
			case "ValidationDisplayedOnGivingCreateToDateLessThanFromDate":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(346);
				break;
			case "SingleDCModalBoxMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(731);

				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(75);

				value = value.replace("{1}", temp);

				value = value.toLowerCase();
				value = value.replace("{0}", "<Count>");
				break;
			case "DCModalBoxMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(728);

				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(792);
				value = value.replace("{1}", temp);
				value = value.toLowerCase();
				value = value.replace("{0}", "<Count>");
				break;
			case "SpecLimitModalBoxMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(728);

				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(4030);
				value = value.replace("{1}", temp);
				value = value.toLowerCase();
				value = value.replace("{0}", "<Count>");

				break;
			case "SingleSpecLimitModalBoxMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(728);

				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(4029));

				value = value.toLowerCase();
				value = value.replace("{0}", "<Count>");

				break;
			case "OperationModalBoxMessage":

				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(728);

				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(729);

				value = value.replace("{1}", temp);
				value = value.toLowerCase();
				value = value.replace("{0}", "<Count>");
				break;
			case "SinglePartRecipeModalBoxMessage":

				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(731);

				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(70);

				value = value.replace("{1}", temp);

				value = value.toLowerCase();
				value = value.replace("{0}", "<Count>");
				break;
			case "OperationDiagramModalBoxMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(728);

				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(774);

				value = value.replace("{1}", temp);
				value = value.toLowerCase();
				value = value.replace("{0}", "<Count>");
				break;
			case "SingleOperationDiagramModalBoxMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(731);

				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(67);

				value = value.replace("{1}", temp);
				value = value.toLowerCase();
				value = value.replace("{0}", "<Count>");
				break;
			case "Process_Can'tBeDeletedMessage_OnlyProcess":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1164)

				;
				value = value.replace("{0}", "<Process Name>");
				break;
			case "Process_Can'tBeDeletedMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1186);
				value = value.replace("{0}", "<Entity Name>");
				break;
			case "TagModalBoxMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(728);

				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(43);

				value = value.replace("{1}", temp);
				value = value.toLowerCase();
				value = value.replace("{0}", "<Count>");
				break;
			case "SingleTagModalBoxMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(731);

				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(399);

				value = value.replace("{1}", temp);
				value = value.toLowerCase();
				value = value.replace("{0}", "<Count>");
				break;
			case "SingleDCDefModalBoxMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(731);

				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(75);

				value = value.replace("{1}", temp);

				value = value.toLowerCase();
				value = value.replace("{0}", "<Count>");
				break;
			case "DCDefModalBoxMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(728);

				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(792);

				value = value.replace("{1}", temp);

				value = value.toLowerCase();
				value = value.replace("{0}", "<Count>");
				break;
			case "ModalBox_PartRecipe_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(799);
				break;
			case "PromptForSampleSize":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(714);
				break;
			case "OnStart":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(856);
				break;
			case "OnSave":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(857);
				break;
			case "SampleSizeValidatonMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(772);
				value = value.replace("{0}", "<SampleSize>");

				break;
			case "SytemEnteredSampleTime":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(854);
				break;
			case "UserEnteredSampleTime":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(855);
				break;
			case "TimeStamp_ValidationForFutureDate":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1368);
				break;
			case "EnterSampleTime":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(716);
				break;
			case "PartRecipeModalBoxMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(728);
				value = value.replace("{0}", "<Count>");

				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(739);

				value = value.replace("{1}", temp);
				value = value.toLowerCase();
				break;
			case "ModalBox_OperationDiagram_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(775);
				break;
			case "SingleOperationModalBoxMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(731);

				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(52);

				value = value.replace("{1}", temp);
				value = value.toLowerCase();
				value = value.replace("{0}", "<Count>");
				break;
			case "ProcessPage_TagCount_MulitpleTag_Message":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(728);
				value = value.replace("{0}", "<TagCount>");

				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(43);

				value = value.replace("{1}", temp);
				value = value.toLowerCase();
				temp = value;
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(194);

				value = value + ": <ProcessName> ";
				value = value + temp;
				value = value.replace("<tagcount>", "<TagCount>");

				break;
			case "Unauthorized_Access_Page_Message":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(69)
						+ "XYou don't have permission to view this page.X";
				break;
			case "ProcessPage_TagCount_SingleTag_Message":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(731);

				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(399);

				value = value.replace("{1}", temp);
				value = value.toLowerCase();
				value = value.replace("{0}", "<TagCount>");
				temp = value;
				value = "X" + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(194) + "X";

				value = value + ": <ProcessName> ";
				value = value + temp;
				value = value.replace("<tagcount>", "<TagCount>");

				break;
			case "SaveSuccessfullyMessageForLimit":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(213);
				value = value.replace("{0}", "<PartName> - <FeatureName>");

				break;
			case "Password_Change_Successful":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1028);
				break;
			case "UserConfiguredTagSaveSuccessfullyMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(623);
				break;
			case "ModalBox_SpecLimit_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(724);
				break;
			case "AllowModification":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(429);
				break;
			case "SpecNotificationMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(441)

						+ "," + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(442)

						+ "," + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(443)

						+ "," + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2145)
						+ " Notification Rule(s)";

				break;
			case "ModalBox_DC_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(725);
				break;
			case "PS_SelectCodeHeaderTitle":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1460);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(843));

				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1461));

				break;
			case "PS_SelectProcessPopUpHeader_OpeationTitle":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(52)

						+ " - " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1472);

				break;
			case "PS_SelectedProcessPopUpHeader_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1472);
				break;
			case "AccordionItem_AssignedODMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(664);
				break;
			case "AccordionItem_ImpactedPartRecipe":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(596);
				break;
			case "Default_ParentProcess":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(601);
				break;
			case "AccordionItem_AssignedChildProcess":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1189);
				break;
			case "actualAccordionItem_AssignedSpecLimitMessage_Feature":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(566);
				break;
			case "AccordionItem_AssignedSpecLimit":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(566);
				break;
			case "Create_Feature_Page_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(37);
				break;
			case "Spec_Page_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(182);
				break;
			case "Unauthorized_Access_Page_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(773);
				break;
			case "Role_Header_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(579);
				break;
			case "Create_Role_Page_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(546);
				break;

			case "Create_Part_Page_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(59);
				break;
			case "Set_Process_State_Page_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(943);
				break;
			case "Create_Part_Revision_Page_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(494);
				break;
			case "CodeGroup_Page_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(395);
				break;
			case "UserLandingPageTitle":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(646);
				break;
			case "Edit_Limit_Page_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(246);
				break;
			case "Edit_CodeGroup_Page_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(416);
				break;
			case "Create_Process_Page_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(238);
				break;
			case "ManualDCLandingPageTitle":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(732);
				break;
			case "TagGroup_Page_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(402);
				break;
			case "Configure_User_Tags_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(527);
				break;
			case "ModalBox_ViewCode_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(840);
				break;
			case "Create_User_Page_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(506);
				break;
			case "DCTagPopUpTitle_AllPieces":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1257);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(687));

				break;
			case "CollectionAids_Page_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(844);
				break;
			case "Create_CollectionAids_Page_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(845);
				break;
			case "Edit_CollectionAids_Page_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(997);
				break;
			case "TagCount":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(399) + "XTag 1 of 1";
				break;
			case "ParameterSet_Page_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1083);
				break;
			case "ModalBox_Operation_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(726);
				break;
			case "ModalBox_Tag_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(723);
				break;
			case "SelectProcessEntity_Page_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1460);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1080));

				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1461));
				break;
			case "ModalBox_Reset_Password":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1029);
				break;
			case "ModalBox_Change_Password":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1340);
				break;
			case "Part_Header_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(76);

				break;
			case "Process_Header_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1080);
				break;
			case "Spec_Header_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(4030);
				break;
			case "Feature_Header_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(80);
				break;
			case "DataCollectionConfiguration_Header_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(308);
				break;
			case "DataCollection_Header_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(732);
				break;
			case "CodeGroup_Header_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(393);
				break;
			case "TagGroup_Header_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1077);
				break;
			case "PartRecipeQuickAddition_Header_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(353);
				break;
			case "DCSetting_Header_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(427);
				break;
			case "Process_States_Grid_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(972);
				break;
			case "Configure_Process_States_Page_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(861);
				break;
			case "PartRevision_Header_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1211);
				break;
			case "Process_States_Header_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(832);
				break;
			case "Dashboard_Header_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(66);
				break;

			case "Individual_Settings_Page_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(600);
				break;
			case "ColumnName_Piece":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(195);
				break;
			case "ParameterSet_Header_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1082);
				break;
			case "GridProcessSelectedEntity":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1885);
				break;
			case "SelectProcessEntity_Header_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1463);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1080));
				break;
			case "SelectFeatureEntity_Header_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1463);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(80));
				break;
			case "SelectPartsEntity_Header_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1463);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(76));

				break;
			case "ResponseGroup_Header_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2496);
				break;
			case "ControlLimit_Header_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1263);
				break;

			case "ColumnName_Part_Name":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(141);
				break;
			case "ColumnName_USL":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(184);
				break;
			case "ColumnName_LSL":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(188);
				break;
			case "ColumnName_Target":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(186);
				break;
			case "ColumnName_FeatureName":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(140);
				break;
			case "ColumnName_FeatureName_Spec":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2491);
				break;
			case "ColumnName_Lot":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(192);
				break;
			case "ColumnName_Process":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(194);
				break;
			case "ColumnName_URL":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(183);
				break;
			case "ColumnName_UWL":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(185);
				break;
			case "ColumnName_LWL":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(187);
				break;
			case "ColumnName_LRL":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(189);
				break;
			case "ColumnName_UWP":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(87);
				break;
			case "ColumnName_LWP":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(88);
				break;
			case "ColumnName_USG":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(89);
				break;
			case "ColumnName_LSG":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(90);
				break;
			case "ColumnName_TagGroup":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(871);
				break;
			case "ColumnName_CurrentState_Part":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(956);
				break;
			case "ColumnName_PreviousState_Part":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(957);
				break;
			case "ColumnName_ProcessState":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(933);
				break;
			case "ColumnName_StateType":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(870);
				break;
			case "ColumnName_ChangeIntitiation":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(839);
				break;
			case "ColumnName_MAVUpper":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(801);
				break;
			case "ColumnName_Max_MAVUpper":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(802);
				break;
			case "ColumnName_MAV_LSC":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(800);
				break;
			case "ColumnName_MAVLower":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(803);
				break;
			case "ColumnName_Max_MAVLower":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(804);
				break;
			case "ColumnName_T2Upper":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(806);
				value = value.replace("<sub>", "");
				value = value.replace("</sub>", "");
				break;
			case "ColumnName_T1Upper":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(807);
				value = value.replace("<sub>", "");
				value = value.replace("</sub>", "");
				break;
			case "ColumnName_T1T2Upper":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(808);
				value = value.replace("<sub>", "");
				value = value.replace("</sub>", "");
				break;
			case "ColumnName_Max_T2Upper":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(809);
				value = value.replace("<sub>", "");
				value = value.replace("</sub>", "");
				break;
			case "ColumnName_T1T2_LSC":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(805);
				break;
			case "ColumnName_T1Lower":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(811);
				value = value.replace("<sub>", "");
				value = value.replace("</sub>", "");

				break;
			case "ColumnName_T2Lower":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(810);
				value = value.replace("<sub>", "");
				value = value.replace("</sub>", "");
				break;
			case "ColumnName_Max_BetweenT1T2Lower":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(812);
				value = value.replace("<sub>", "");
				value = value.replace("</sub>", "");

				break;
			case "ColumnName_MaxT2Lower":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(813);
				value = value.replace("<sub>", "");
				value = value.replace("</sub>", "");
				break;
			case "ColumnName_UpdatedDate":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(136);
				break;
			case "ColumnName_LastUpdatedBy":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(711);
				break;
			case "ColumnName_CreationDate":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(134);
				break;
			case "ColumnName_CreatedBy":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(133);
				break;
			case "ColumnName_Image":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(50);
				break;
			case "ColumnName_FeatureType":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(139);
				break;
			case "ColumnName_Tag":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(399);
				break;
			case "ColumnName_DataCollection":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(21);
				break;
			case "ColumnName_SpecificationLimit":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(4029);
				break;
			case "ColumnName_Operation":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(52);
				break;
			case "ColumnName_ProcessName":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(240);
				break;
			case "ColumnName_ProcessCategory":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(69) + "XProcess CategoryX";
				break;
			case "ColumnName_OperationDiagram":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(67);
				break;
			case "ColumnName_Status":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(453);
				break;
			case "ColumnName_PartRecipe":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(70);
				break;

			case "ColumnName_PartRevision":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(190);
				break;
			case "ColumnName_Units":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(191);
				break;
			case "ColumnName_DataCollectionDefinition":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(75);
				break;
			case "ColumnName_OperationDiagramName":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(132);
				break;
			case "ColumnName_Feature":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(33);
				break;
			case "ColumnName_PartFamily":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(32);
				break;
			case "ColumnName_Code":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(398);
				break;
			case "ColumnName_CodeGroup":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(42);
				break;
			case "ColumnName_Active":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(451);
				break;
			case "ColumnName_CodeName":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(396);
				break;
			case "ColumnName_Role":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(538);
				break;
			case "ColumnName_Supervisor_Name":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(541);
				break;
			case "ColumnName_Preferred_Language":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(543);
				break;
			case "ColumnName_Username":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(535);
				break;
			case "ColumnName_Email":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(534);
				break;
			case "ColumnName_Access_Level":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(539);
				break;
			case "ColumnName_Name":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(563);
				break;

			case "ColumnName_Weight":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(450);
				break;
			case "ColumnName_TagType":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(404);
				break;
			case "ColumnName_TextingNumber":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(540);
				break;
			case "ColumnName_TagGroupName":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(403);
				break;
			case "ColumnName_PartFamilyTitle":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(858);
				value = value.replace("{0}", "<Element Name>");

				break;
			case "ColumnName_Part":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(68);
				break;
			case "ColumnName_ CollectionAid":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(844);
				break;
			case "ColumnName_ParentPrcoessName":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(35);
				break;
			case "ColumnName_Part_Family":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(576);
				break;
			case "PartNotExistsValidationMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2553);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(68));

				break;
			case "ColumnName_ParameterSetName":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1086);
				break;
			case "ColumnName_Summary":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1095);
				break;
			case "ColumnName_Criteria":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1097);
				break;
			case "ColumnName_AssignedWorkDashboard":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2228);
				break;
			case "ManualDCLandingPageGridHeader":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(316);
				break;
			case "ColumnName_SelectedFeature":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1823);
				break;
			case "CodeGroupNotExist":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(462);
				break;
			case "ResponseGroupNotExist":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2501);
				break;
			case "ContextMenuUploadImage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(81);
				break;
			case "ContextMenuChangeImage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(48);
				break;
			case "ContextMenuRemoveImage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(49);
				break;
			case "LandingPage_ContextMenu_CreatePartRevisionIconText":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(389);
				break;
			case "LandingPage_ContextMenu_HistoryIconText":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2368);
				break;

			case "LandingPage_ContextMenu_RemoveIconText":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(245);
				break;
			case "StateType_Idle":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(927);
				break;
			case "StateType_Pause":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(929);
				break;
			case "StateType_Run":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(926);
				break;
			case "StateType_ScheduledDown":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(930);
				break;
			case "StateType_Start":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(925);
				break;
			case "StateType_Stop":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(928);
				break;
			case "StateType_UnscheduledDown":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(931);
				break;
			case "TagType_Numeric":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(820);
				break;
			case "TagType_Textual":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(821);
				break;
			case "Status_Active":
				value = "0 - " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(451);
				break;
			case "Status_Inactive":
				value = "1 - " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(421);
				break;
			case "Status_Inactive_User":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(452);
				break;
			case "FeatureType_Variable":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(177);
				break;
			case "FeatureType_Defect":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(176);
				break;
			case "FeatureType_Defective":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(175);
				break;
			case "FeatureType_CheckList":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(127);
				break;

			case "ChangeIntitiation_Manual":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(951);
				break;
			case "FeatureType_Time":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(178);
				break;
			case "ChangeIntitiation_Automatic":
				value = "2 - " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(953);
				break;
			case "ChangeIntitiation_Event":
				value = "1 - " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(952);
				break;
			case "ParameterSetTimeZone_Latest":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1394);
				break;
			case "ParameterSetTimeZone_Current":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1392);
				break;
			case "ParameterSetTimeZone_Earlier":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1393);
				break;
			case "ParameterSetTimeUnit_Minute":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1395);
				break;
			case "ParameterSetTimeUnit_Hour":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1396);
				break;
			case "ParameterSetTimeUnit_Day":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1397);
				break;
			case "ParameterSetTimeUnit_Week":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1398);
				break;
			case "ParameterSetTimeUnit_Month":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1399);
				break;
			case "ParameterSetTimeUnit_Quarter":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1410);
				break;
			case "ParameterSetTimeUnit_Year":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1400);
				break;
			case "TimeSelectionType_Dynamic":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1390);
				break;
			case "TimeSelectionType_Static":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1391);
				break;
			case "Module_PartRevision":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(488);
				break;
			case "Module_Part":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(68);
				break;
			case "ResponseType_SingleAnswer":
				value = "1 - " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2487);
				break;
			case "ResponseType_MultipleAnswer":
				value = "2 - " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2488);
				break;
			case "FilterButtonTitle":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(797);
				break;

			case "ColumnName_ConfigureColumnTitle":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(697);
				break;
			case "CodeGroup_AddCodes":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(397);
				break;
			case "CodeGroup_CheckBoxLabel":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(454);
				break;
			case "Lable_SampleSize":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(255);
				break;
			case "Quantity":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2359);
				break;
			case "LBL_All_Pieces":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(687);
				break;
			case "Lable_Edit":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(85);
				break;
			case "Lable_Delete":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(29);
				break;
			case "Condition_And":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1152);
				break;
			case "Condition_OR":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(650);
				break;
			case "Condition_XOR":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1154);
				break;
			case "Condition_Is_Not":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1161);
				break;
			case "Condition_State_Is":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1183);
				break;
			case "Condition_State_Is_Not":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1184);
				break;
			case "Condition_Between":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1163);
				break;
			case "TotalCount":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(686);

				value = value.replace("{0}", "<count>");

				break;
			case "Condition_Equals":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1162);
				break;
			case "Condition_Is":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1160);
				break;
			case "Label_Part":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(68);
				break;
			case "LicenseType_Username":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(535);
				break;
			case "LicenseType_Workstation":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1049);
				break;
			case "SelectFeature_Exclude":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1460);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(80));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1462));

				break;
			case "SelectPart_Exclude":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1460);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(76));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1462));

				break;
			case "SelectProcess_Exclude":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1460);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1080));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1462));
				break;
			case "SelectTag_Exclude":

				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1460);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(43));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1462));

				break;
			case "SelectFeature_Include":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1460);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(80));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1461));

				break;
			case "SelectPart_Include":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1460);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(76));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1461));

				break;
			case "SelectProcess_Include":

				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1460);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1080));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1461));

				break;
			case "SelectTag_Include":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1460);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(43));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1461));

				break;
			case "ColumnName_SelectAll":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1455);
				break;
			case "Lable_Process":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(194);
				break;
			case "AssignedDashboard_No":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(460);
				break;
			case "ParameterSet_None":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1524);
				break;
			case "ParameterSet_TagNotExists":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2553);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(871));

				break;
			case "GridFeatureSelectedEntity":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1887);
				break;
			case "To":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(344);
				break;
			case "SelectCode_Exclude":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1460);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(843));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1462));

				break;
			case "HelperText_TypeSelect":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(63);
				break;
			case "HelperText_Select":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(30);
				break;
			case "No_Record_Found":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(65);
				break;
			case "Password_Guidelines":
				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1026);
				temp = temp.replace("{0}", "8");

				temp1 = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1307);
				temp1 = temp1 + " [ ] ? / < > ~ # ` ! @ _ - $ % ^ & * ( ) + = { } | : \" ; ' ,";

				temp2 = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1025);
				temp2 = temp2.replace("{0}", "365");

				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1020)

						+ "\n" + temp

						+ "\n" + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1021)

						+ "\n" + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1308)

						+ "\n" + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1315) + "\n" + temp1
						+ "\n" + temp2;
				break;
			case "Password_Guidelines_Change_Password":

				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1026);
				temp = temp.replace("{0}", "8");

				temp1 = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1307);
				temp1 = temp.replace("{0}", "{}[]^$@%()...");

				temp2 = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1309);
				temp2 = temp.replace("{0}", "5");

				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1020)

						+ "\n\n" + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1314)

						+ "\n" + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1314)

						+ "\n" + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1308)

						+ "\n" + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1315) + "\n" + temp1
						+ "\n" + temp2;
				break;
			case "HelperText_Type":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(41);
				break;
			case "PS_FilterCountText":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2445);
				break;
			case "CodeName_PlaceHolder":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(455);
				break;
			case "USL_gt_LRL_LWL_Target_UWL_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(149);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(184));
				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(189)

						+ ", " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(187)

						+ ", " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(186);
				value = value.replace("{1}", temp);

				value = value.replace("{2}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(185));

				break;
			case "Target_lt_USL_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(214);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(186));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(184));

				break;
			case "UWL_lt_USL_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(214);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(185));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(184));

				break;
			case "LWL_lt_USL_ErrorMessage":

				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(214);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(187));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(184));

				break;
			case "LRL_lt_USL_ErrorMessage":

				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(214);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(189));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(184));

				break;
			case "URL_gt_Target_UWL_USL_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(149);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(183));
				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(186)

						+ ", " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(185);
				value = value.replace("{1}", temp);

				value = value.replace("{2}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(184));

				break;
			case "LSL_lt_LWL_Target_UWL_URL_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(150);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(188));
				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(187)

						+ ", " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(186)

						+ ", " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(185) + ", "
						+ UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(184);
				value = value.replace("{1}", temp);

				value = value.replace("{2}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(183));

				break;
			case "LSG_lt_USG_ErrorMessage":

				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(214);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(90));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(89));

				break;
			case "USG_gt_LSG_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(215);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(89));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(90));

				break;
			case "LWP_lt_UWP_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(214);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(88));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(87));

				break;
			case "UWP_gt_LWP_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(215);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(87));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(88));

				break;
			case "UWL_gt_LWL_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(215);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(185));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(187));

				break;
			case "LWL_lt_UWL_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(214);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(187));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(185));

				break;
			case "LSL_gt_LRL_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(215);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(188));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(189));

				break;
			case "LRL_lt_LSL_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(214);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(189));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(188));

				break;
			case "USL_lt_URL_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(214);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(184));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(183));

				break;
			case "URL_gt_USL_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(215);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(183));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(184));

				break;
			case "LSL_lt_LWL_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(214);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(188));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(187));

				break;
			case "LWL_gt_LRL_LSL_ErrorMessage":

				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(149);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(187));
				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(189);
				value = value.replace("{1}", temp);

				value = value.replace("{2}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(188));

				break;
			case "LRL_lt_LWL_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(214);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(189));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(187));

				break;
			case "UWL_lt_USL_URL_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(150);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(185));
				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(184);
				value = value.replace("{1}", temp);

				value = value.replace("{2}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(183));

				break;
			case "URL_gt_UWL_USL_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(149);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(183));
				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(185);
				value = value.replace("{1}", temp);

				value = value.replace("{2}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(184));

				break;
			case "USL_gt_LWL_Target_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(149);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(184));
				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(187);
				value = value.replace("{1}", temp);

				value = value.replace("{2}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(186));

				break;
			case "LWL_lt_Target_USL_URL_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(150);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(187));
				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(186)

						+ ", " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(184);
				value = value.replace("{1}", temp);

				value = value.replace("{2}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(183));

				break;
			case "URL_gt_LWL_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(215);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(183));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(187));

				break;
			case "LSL_lt_Target_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(214);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(188));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(186));

				break;
			case "Target_gt_LRL_LSL_LWL_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(149);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(186));
				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(189)

						+ ", " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(188);
				value = value.replace("{1}", temp);

				value = value.replace("{2}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(187));

				break;
			case "LWL_lt_Target_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(214);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(187));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(186));

				break;
			case "LRL_lt_LSL_Target_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(150);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(189));
				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(188);
				value = value.replace("{1}", temp);

				value = value.replace("{2}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(186));

				break;
			case "Target_lt_UWL_USL_URL_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(150);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(186));
				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(185) + ", "
						+ UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(184);
				value = value.replace("{1}", temp);

				value = value.replace("{2}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(183));

				break;
			case "LSL_lt_UWL_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(214);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(188));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(185));

				break;
			case "Target_lt_UWL_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(214);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(186));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(185));

				break;
			case "UWL_gt_LRL_LSL_LWL_Target_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(149);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(185));
				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(189)

						+ ", " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(188)

						+ ", " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(187);
				value = value.replace("{1}", temp);

				value = value.replace("{2}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(186));

				break;
			case "LRL_lt_UWL_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(214);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(189));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(185));
				break;
			case "URL_gt_LRL_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(215);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(183));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(189));

				break;
			case "LRL_lt_URL_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(214);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(189));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(183));

				break;
			case "USL_gt_LSL_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(215);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(184));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(188));

				break;
			case "LSL_lt_USL_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(214);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(188));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(184));

				break;
			case "LWL_lt_Target_UWL_USL_URL_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(150);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(187));
				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(186)

						+ ", " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(185)

						+ ", " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(184);
				value = value.replace("{1}", temp);

				value = value.replace("{2}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(183));

				break;
			case "URL_gt_LRL_LSL_LWL_Target_UWL_USL_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(149);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(183));
				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(189)

						+ ", " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(188)

						+ ", " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(187)

						+ ", " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(186)

						+ ", " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(185);
				value = value.replace("{1}", temp);

				value = value.replace("{2}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(184));

				break;
			case "LRL_lt_LSL_LWL_Target_UWL_USL_URL_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(150);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(189));
				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(188)

						+ ", " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(187) + ", "
						+ UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(186) + ", "
						+ UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(185) + ", "
						+ UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(184);
				value = value.replace("{1}", temp);

				value = value.replace("{2}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(183));

				break;
			case "UWL_lt_URL_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(214);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(185));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(183));

				break;
			case "LWL_lt_URL_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(214);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(187));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(183));

				break;
			case "URL_gt_LSL_LWL_Target_UWL_USL_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(149);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(183));
				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(188)

						+ ", " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(187)

						+ ", " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(186)

						+ ", " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(185);
				value = value.replace("{1}", temp);

				value = value.replace("{2}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(184));

				break;
			case "USL_gt_UWL_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(215);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(184));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(185));

				break;
			case "URL_gt_UWL_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(215);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(183));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(185));

				break;
			case "Password_Not_Changed_Successfully":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(69)
						+ "XPassword reset unsuccessful. Please try again.X";
				break;
			case "InvalidCode":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1212);
				break;
			case "InvalidValueValidationMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(464);
				break;
			case "Password_Changed_Successfully":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1216);
				break;
			case "Activation_Start_Date_Greater_Than_End_Date":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(594);
				break;
			case "LWL_gt_LSL_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(215);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(187));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(188));

				break;
			case "URL_gt_LSL_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(215);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(183));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(188));

				break;
			case "Password_Reset_Unsuccessful":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1027);
				break;
			case "Password_Change_Unsuccessful":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1346);
				break;
			case "Password_Expired_Message":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(633);

				break;
			case "T2_lt_T1_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(214);

				value = value.replace("{0}",
						"T2 " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(518));
				value = value.replace("{1}",
						"T1 " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(518));

				break;
			case "T2_lt_LSC_T1_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(150);
				value = value.replace("{0}",
						"T2 " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(518));
				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(511);
				value = value.replace("{1}", temp);

				value = value.replace("{2}",
						"T1 " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(518));

				break;
			case "LSC_gt_T1_T2_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(149);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(511));
				temp = "T1 " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(518);
				value = value.replace("{1}", temp);

				value = value.replace("{2}",
						"T2 " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(518));
				break;
			case "T1_lt_LSC_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(214);

				value = value.replace("{0}",

						"T1 " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(518));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(511));

				break;
			case "LSC_gt_MAVLower_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(215);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(511));
				value = value.replace("{1}",
						"MAV " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(518));

				break;
			case "MAVUpper_gt_MAVLower_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(215);

				value = value.replace("{0}",
						"MAV " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(517));
				value = value.replace("{1}",
						"MAV " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(518));

				break;
			case "MAVLower_lt_LSC_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(214);

				value = value.replace("{0}",
						"MAV " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(518));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(511));

				break;
			case "MAVLower_lt_LSC_MAVUpper_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(150);
				value = value.replace("{0}",
						"MAV " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(518));
				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(511);
				value = value.replace("{1}", temp);

				value = value.replace("{2}",
						"MAV " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(517));

				break;
			case "LSC_lt_MAVUpper_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(214);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(511));
				value = value.replace("{1}",
						"MAV " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(517));

				break;
			case "MAVUpper_gt_LSC_MAVLower_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(149);
				value = value.replace("{0}",
						"MAV " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(517));
				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(511);
				value = value.replace("{1}", temp);

				value = value.replace("{2}",
						"MAV " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(518));
				break;
			case "MAVLower_lt_MAVUpper_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(214);

				value = value.replace("{0}",
						"MAV " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(518));
				value = value.replace("{1}",
						"MAV " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(517));

				break;
			case "T1Lower_lt_T2Upper_T1Upper_LSC_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(150);
				value = value.replace("{0}",
						"T1 " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(518));
				temp = "T2 " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(517)

						+ ", " + "T1 " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(517);
				value = value.replace("{1}", temp);

				value = value.replace("{2}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(511));

				break;
			case "T2Lower_lt_T2Upper_T1Upper_LSC_T1Lower_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(150);
				value = value.replace("{0}",
						"T2 " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(518));
				temp = "T2 " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(517)

						+ ", " + "T1 " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(517)

						+ ", " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(511);
				value = value.replace("{1}", temp);

				value = value.replace("{2}",
						"T1 " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(518));

				break;
			case "T2Lower_lt_LSC_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(214);

				value = value.replace("{0}",
						"T2 " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(518));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(511));

				break;

			case "T2Lower_lt_T1Upper_LSC_T1Lower_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(150);
				value = value.replace("{0}",
						"T2 " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(518));
				temp = "T1 " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(517)

						+ ", " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(511);
				value = value.replace("{1}", temp);

				value = value.replace("{2}",

						"T1 " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(518));

				break;
			case "T1Lower_lt_T1Upper_LSC_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(150);
				value = value.replace("{0}",
						"T1 " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(518));
				temp = "T1 " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(517);
				value = value.replace("{1}", temp);

				value = value.replace("{2}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(511));

				break;
			case "T1_gt_T2_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(215);

				value = value.replace("{0}",
						"T1 " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(518));
				value = value.replace("{1}",
						"T2 " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(518));

				break;
			case "T2Lower_lt_T1Upper_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(214);

				value = value.replace("{0}",
						"T2 " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(518));
				value = value.replace("{1}",
						"T1 " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(517));

				break;
			case "T1Lower_lt_T1Upper_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(214);

				value = value.replace("{0}",
						"T1 " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(518));
				value = value.replace("{1}",
						"T1 " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(517));

				break;
			case "T1Upper_lt_T2Upper_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(214);

				value = value.replace("{0}",
						"T1 " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(517));
				value = value.replace("{1}",
						"T2 " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(517));

				break;
			case "T2Lower_gt_T1Upper_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(215);

				value = value.replace("{0}",
						"T2 " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(517));
				value = value.replace("{1}",
						"T1 " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(517));

				break;
			case "LSC_lt_T2Upper_T1Upper_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(150);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(511));
				temp = "T2 " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(517);
				value = value.replace("{1}", temp);

				value = value.replace("{2}",
						"T1 " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(517));

				break;
			case "T2Upper_gt_LSC_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(215);

				value = value.replace("{0}",
						"T2 " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(517));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(511));

				break;
			case "LSC_gt_T1Lower_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(215);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(511));
				value = value.replace("{1}",
						"T1 " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(518));

				break;
			case "T2Upper_gt_T1Lower_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(215);

				value = value.replace("{0}",
						"T2 " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(517));
				value = value.replace("{1}",
						"T1 " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(518));

				break;
			case "T1Upper_gt_T1Lower_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(215);

				value = value.replace("{0}",
						"T1 " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(517));
				value = value.replace("{1}",
						"T1 " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(518));

				break;
			case "T1Upper_gt_Lsc_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(215);

				value = value.replace("{0}",
						"T1 " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(517));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(511));

				break;
			}

			// call second method
			if (value.equals(""))
				value = mapMultiLingualSheet1(key);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return value;
	}

	private static String mapMultiLingualSheet1(String key) {

		String value = "";
		String temp = "";

		try {

			switch (key) {
			case "T1Upper_gt_T2Lower_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(215);
				value = value.replace("{0}",
						"T1 " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(517));
				value = value.replace("{1}",
						"T2 " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(518));

				break;
			case "LSC_gt_T2Lower_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(215);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(511));
				value = value.replace("{1}",
						"T2 " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(518));

				break;
			case "T2Upper_gt_T2Lower_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(215);

				value = value.replace("{0}", "T2 "

						+ UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(517));
				value = value.replace("{1}",
						"T2 " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(518));

				break;
			case "MAVUpper_gt_LSC_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(215);
				value = value.replace("{0}", UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(4035) + " "
						+ UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(517));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(511));

				break;
			case "T2Upper_gt_T1Upper_LSC_T1Lower_T2Lower_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(149);

				value = value.replace("{0}", "T2 "

						+ UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(517));
				value = value.replace("{1}", "T1 " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(517)

						+ ", " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(511)

						+ ", T1 " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(518));

				value = value.replace("{2}",
						"T2 " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(518));

				break;
			case "T1Upper_gt_LSC_T1Lower_T2Lower_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(149);

				value = value.replace("{0}", "T1 "

						+ UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(517));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(511)

								+ ", T1 " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(518));

				value = value.replace("{2}",
						"T2 " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(518));

				break;
			case "LSC_lt_T1Upper_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(214);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(511));
				value = value.replace("{1}",
						"T1 " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(517));

				break;
			case "Part_Is_Inactive":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(476);
				break;
			case "Part_Feature_Existing_Combination_Message":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(959);

				break;
			case "Process_Not_Exists":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2553);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(194));

				break;
			case "TagGroupName_Already_Exists":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(465);

				break;
			case "MinValue_lt_MaxValue":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(448);

				break;
			case "MaxValue_gt_MinValue":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(449);

				break;
			case "FeatureNotExistsValidationMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2553);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(33));

				break;
			case "InvalidMaxValueValidationMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2374);

				break;
			case "InvalidMinValueValidationMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2375);

				break;
			case "EndDateTimeCannotLessThanStartDateTime":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1404);

				break;
			case "NewAndConfirmPasswordMismatch":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2540);

				break;
			case "Part_Not_Exists":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2533);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(68));

				break;
			case "PopOverPieceSpecLimit":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(108);
				break;
			case "Selected_Process":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1144);

				break;
			case "Would_You_Like_To_Continue":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(470);

				break;
			case "ValueBelowReasonableLimit_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2393);
				break;
			case "ValueAboveReasonableLimit_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(430);

				break;
			case "OutOfSpecificationLimits_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(314);
				value = value.replace("{0}", "<Part>");

				value = value.replace("{1}", "<Feature>");
				break;
			case "SelectPartPopUpHeader_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(32)

						+ " - " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1431);

				break;
			case "UnreasonableValueEntered":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(939);
				break;
			case "ValueMustBeWithinResonableLimit":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(940);
				break;
			case "OutOfWarningLimits_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(474);
				value = value.replace("{0}", "<Part>");

				value = value.replace("{1}", "<Feature>");

				break;
			case "RemoveEntityPopupTitle":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(568);
				value = value.replace("{0}", "<Element Name>");
				break;
			case "IndividualSettings_AllValueRequired":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(610);
				break;
			case "IndividualSettings_AtLeastOneValueRequired":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(611);
				break;
			case "IndividualSettings_NoValueRequired":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(612);
				break;
			case "IndividualSettings_ValueOnly":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(622);
				break;
			case "IndividualSettings_ValueAndRequiredCode":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(616);
				break;
			case "IndividualSettings_ValueAndOptionalCode":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(617);
				break;
			case "IndividualSettings_AllValues":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(853);
				break;
			case "IndividualSettings_ReasonableValuesOnly":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(852);
				break;
			case "IndividualSettings_CodeOnly":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(619);
				break;
			case "ProcessState_History_Last_20":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2368)

						+ " (" + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1062) + ")";

				break;
			case "Part_InActivation_Validation_Message":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1253);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(4083));
				break;
			case "Process_State_Idle":
				value = "3 - " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(927);
				break;
			case "Process_State_Pause":
				value = "5 - " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(929);

				break;
			case "Process_State_Run":
				value = "2 - " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(926);

				break;
			case "Process_State_ScheduledDown":
				value = "6 - " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(930);

				break;
			case "Process_State_Start":
				value = "1 - " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(925);

				break;
			case "Process_State_Stop":
				value = "4 - " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(928);

				break;
			case "Process_State_UnscheduledDown":
				value = "7 - " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(931);

				break;

			case "Permissions_Create":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(522);
				break;
			case "Permissions_View":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(523);
				break;
			case "Permissions_CreateRevision":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(389);
				break;
			case "Permissions_Edit":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(85);
				break;
			case "Permissions_Remove":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(245);
				break;
			case "Permissions_EditUniqueId":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(524);
				break;
			case "Permissions_Release":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(589);
				break;
			case "Permissions_ViewHistory":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(3032);
				break;
			case "FilterApplied":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2445);
				break;
			case "FiltersApplied":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2420);
				break;
			case "InActivation_Date_Message":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(971);
				break;
			case "MDC_AddLotDetails":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1544);
				break;
			case "MDC_ConfirmationMessageDataCollection":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1655);
				break;
			case "OutOfWithInPieceLimits_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2031)

				;
				value = value.replace("{0}", "<Part>");
				value = value.replace("{1}", "<Feature>");

				break;
			case "Lot_TestingReleased":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2351);
				break;
			case "ViewCodeModalBoxMessage":

				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(842);
				value = value.replace("{0}", "<CodeGroupName>");

				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(731);

				temp = temp.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(398));
				temp = temp.toLowerCase();
				temp = temp.replace("{0}", "<Count>");

				value = value + " " + temp;

				break;
			case "MDC_MissingValue_HeaderTitle":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2013);
				break;
			case "MDC_MissingValueConfirmationMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2014)

				;
				break;
			case "Create_Lot_Page_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2349);
				break;
			case "MDC_CreateLot_ConfirmationMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2595);
				value = value.replace("{0}", "<LotName>");
				break;
			case "Checklist_Default_Processes_Selected":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1832);
				value = value.replace("{0}", UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1245));
				break;
			case "Checklist_Assignment_Grid_Label":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(354)

				;
				break;
			case "Checklist_Process_Label":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(194);
				break;
			case "Checklist_Name_Header":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(563);
				break;
			case "Checklist_Assignee_Header":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1285);
				break;
			case "Checklist_Header_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2650);
				break;
			case "Checklist_BasicInformation_Section_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1316);
				break;
			case "Checklist_ProcessSelection_Section_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2533);
				break;
			case "Checklist_EventGeneration_Section_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2535);
				break;
			case "Checklist_Assignment_Section_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1288);
				break;
			case "Checklist_Preview":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2554);
				break;
			case "ColumnName_Checklist":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(127);
				break;
			case "Checklist_Create":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2524);
				break;
			case "DefineCondition":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1056);
				break;
			case "DefineAction":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1102);
				break;
			case "RequirementCondition":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1103);
				break;
			case "RequirementWindow":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1233);
				break;
			case "Test Requirement Condition":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1219);
				break;
			case "Clear":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(51);
				break;
			case "If True":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1282);
				break;

			case "DefineActionTabTitle":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1109);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2598));
				break;
			case "SpecifyTime":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1107);
				break;
			case "RunOnce":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1110);
				break;
			case "DefineFrequency":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1111);
				break;
			case "Every":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1112);
				break;
			case "SpecifyTime_FromLastDataCollection":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1113);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(21));
				break;
			case "SpecifyTime_BasedOnReference":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1114);
				break;
			case "Days":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1120);
				break;
			case "Hours":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1119);
				break;
			case "Minutes":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1118);
				break;
			case "SpecifyTime_ResetFrequencyOnPartChange":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1115);
				break;
			case "SpecifyProcess":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1108);
				break;
			case "Deadline":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1228);
				break;
			case "SetWindowTabTitle":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1227);
				break;
			case "SetWindow_AfterScheduledOccurrence":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1229);
				break;
			case "SetWindow_BeforeScheduledOccurrence":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1232);
				break;
			case "SetWindow_MarkTheDataCollectionLateIfNotCollected":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1230)

				;

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2598));
				break;
			case "EarlyReminder":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1231);
				break;
			case "Reminder":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1332);
				break;
			case "Occurrence":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1333);
				break;
			case "EditExisting":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1099);
				break;
			case "CreateNew":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(409);
				break;

			case "Feature_AlreadyExists":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(300);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(33));

				break;
			case "Checklist_DefectTypeFeatureCannotBeSelected":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2498);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(176));

				break;
			case "Checklist_DefectiveTypeFeatureCannotBeSelected":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2498);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(175));

				break;
			case "Checklist_VariableTypeFeatureCannotBeSelected":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2498);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(177));
				break;
			case "ColumnName_None":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1524);
				break;
			case "Checklist_AlreayExists":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(128);
				break;
			case "Checklist_Role":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(538);
				break;
			case "Checklist_User":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(508);
				break;
			case "Checklist_Workstation":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1049);
				break;
			case "Months":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1289);
				break;
			case "Weeks":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1249);
				break;
			case "Years":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1250);
				break;
			case "Late":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1334);
				break;
			case "LotNotExistsValidationMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2553);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(192));
				break;
			case "LotUniquenessValidationMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2361);
				break;
			case "MDC_DataCollectionType_PopupTitle":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2823);
				break;

			case "Checklist_RoleAlreadyExists":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(300);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(538));

				break;
			case "Checklist_UserAlreadyExists":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(300);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(508));

				break;
			case "Checklist_WorkstationAlreadyExists":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(300);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1049));

				break;
			case "Checklist_RoleNotExists":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2553);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(538));

				break;
			case "Checklist_UserNotExists":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2553);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(508));

				break;
			case "Checklist_WorkstationNotExists":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2553);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1049));
				break;

			case "Checklist_PreviewHeader":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2555);
				value = value.replace("{0}", "<Element Name>");
				break;
			case "Preview":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2554);
				break;
			case "AccordionItem_ChecklistFeature":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(605);
				value = value.replace("{0}", "<Element Name>");

				break;
			case "Checklist_DeleteConfirmaitonMessageWithAssociations":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2557);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2610));

				break;
			case "DeleteConfirmaitonMessageWithOutAssociations":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(567);
				value = value.replace("{0}", "<Element Name>");
				break;
			case "RemovalTitle":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(568);
				value = value.replace("{0}", "<Element Name>");
				break;
			case "Checklist_SingleTagPopUp_Header":

				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(127) + ": <ChecklistName> ";

				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(731);

				temp = temp.replace("{1}", UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(399));
				temp = temp.toLowerCase();
				temp = temp.replace("{0}", "<Count>");

				value = value + temp;
				break;

			case "Preview_Comment_Placeholder":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2560);
				break;
			case "Preview_Response_Placeholder":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2561);
				break;
			case "User_Popup_Header":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(829);
				break;
			case "SelectProcesses":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1123);
				break;
			case "ConditionDoenstExist":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2553);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1155));

				break;
			case "LateTimeMustBeLessThanDeadline":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1294);
				break;
			case "Conditions":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1059);
				break;
			case "USL_gt_LRL_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(215);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(184));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(189));

				break;
			case "TSL_gt_LRL_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(215);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(186));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(189));

				break;
			case "LWL_gt_LRL_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(215);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(187));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(189));

				break;
			case "UWL_gt_LRL_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(215);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(185));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(189));

				break;
			case "Target_gt_LSL_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(215);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(186));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(188));

				break;
			case "UWL_gt_LSL_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(215);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(185));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(188));

				break;
			case "LRL_lt_Target_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(214);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(189));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(186));

				break;
			case "USL_gt_Target_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(215);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(184));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(186));

				break;
			case "URL_gt_Target_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(215);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(183));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(186));

				break;
			case "UWL_gt_Target_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(215);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(185));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(186));

				break;

			case "DCRequirement_PageTitle":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1073);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(21));

				break;
			case "ContinueButton":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(734);
				break;
			case "SampleSize_SubTitle":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(733);
				break;

			case "ConfirmationMessageForTotalCountLessThanOrEqualTo999":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(814);
				value = value.replace("{0}", "100000000");
				break;
			case "ResponseGroup_OneActiveChoiceMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2507);
				break;
			case "ResponseGroup_FeaturePopUp_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2518);
				break;
			case "ResponseGroup_SingleFeaturePopUp_Header":

				value = "X" + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2517) + "X";
				value = value.replace("{0}", "<RespGroupName>");

				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(731);

				temp = temp.replace("{1}", UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(33));
				temp = temp.toLowerCase();
				temp = temp.replace("{0}", "<Count>");

				value = value + " " + temp;

				break;
			case "ResponseGroup_RemovalMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(567);
				value = value.replace("{0}", "<RespGroupName>");

				break;
			case "ResponseGroup_RemovalTitle":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(568);
				value = value.replace("{0}", "<RespGroupName>");
				break;
			case "ResponseGroup_RemovedSuccessfullyMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(472);
				value = value.replace("{0}", "<RespGroupName>");
				break;
			case "ColumnName_QuestionText":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2489);
				break;

			case "CreateResponseGroup_Header_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2492);
				break;
			case "EditResponseGroup_Header_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(69) + "XEdit Response GroupX";
				break;
			case "ColumnName_ResponseType":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2494);
				break;
			case "ColumnName_ResponseGroup":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2493);
				break;
			case "ColumnName_Choice":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2502);
				break;
			case "ColumnName_Comment":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2504);
				break;
			case "ColumnName_Track":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2503);
				break;
			case "RuleTemplateNotExists":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2390);
				break;
			case "FeatureTypeNotApplicale":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2388);
				break;
			case "ProceesingTemplateNotExists":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2389);
				break;
			case "ControlLimit_SaveSuccessfullyMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(4166);
				value = value.replace("{0}", "<Date>");
				break;
			case "ControlLimit_EffectiveDateMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2386);
				value = value.replace("{0}", "<Date>");

				break;
			case "ControlLimit_EffectiveLesserDateMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2387);
				value = value.replace("{0}", "<Date>");
				break;
			case "ControlLimit_PopUpRemovalTitle":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2398);
				break;
			case "ControlLimit_RemoveMessageAtEdit":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2395)

				;
				value = value.replace("{0}", "<Date>");
				break;

			case "Operation_Not_Exists":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2553);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(52));
				break;
			case "ColumnName_EffectiveFrom":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1414);
				break;
			case "ColumnName_ProcessSigma":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2371);
				break;
			case "ColumnName_ProcessMean":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1300);
				break;
			case "ColumnName_WithinPieceSigma":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2372);
				break;
			case "ColumnName_RuleTemplate":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2066);
				break;
			case "ColumnName_ProcessingTemplate":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2382);
				break;
			case "CL_DataStream":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1266);
				break;
			case "CL_AssociatedCLPopUp":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2380);
				break;

			case "ViewRequirementConditions":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(69)
						+ "XView Requirement ConditionsX";
				break;
			case "Requirements":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2573);
				break;
			case "Active":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(451);
				break;
			case "DefectiveTypeFeatureCan'tBeSelected":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2498);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(175));
				break;
			case "DefectTypeFeatureCan'tBeSelected":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2498);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(176));
				break;
			case "ChecklistTypeFeatureCan'tBeSelected":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2498);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(127));
				break;
			case "ColumnName_Shift":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1385);
				break;
			case "ParameterSet_TagAlreadyExists":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2377);
				break;
			case "PS_PartPopUpHeader_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1431);
				break;
			case "Shift_Exclude":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1460);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1477));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1462));

				break;
			case "Shift_Include":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1460);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1477));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1461));

				break;
			case "ParameterSet_NoShiftMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1832);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1385));

				break;
			case "GridShiftSelectedEntity":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(69) + "XShifts Selected:X";
				break;
			case "SelectShiftEntity_Header_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1463);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1477));

				break;
			case "Lot_Header_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2458);
				break;
			case "SelectLot_Include":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1460);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2458));
				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1461));

				break;
			case "GridLotSelectedEntity":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(302);
				break;
			case "SelectLotEntity_Header_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1463);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2458));

				break;
			case "Criteria_LotStatus":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(254);
				break;
			case "Criteria_TagGroup":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(871);
				break;
			case "ColumnName_Category":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1698);
				break;
			case "LotStatusType_Created":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2369);
				break;
			case "ColumnName_LotName":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(740);
				break;
			case "PS_SelectedLotPopUpHeader_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1411);
				break;
			case "PS_DeleteConfirmaitonMessageWithAssociations":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2304)

				;
				break;
			case "AccordionItem_AssignedToDashboard":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2294);
				break;
			case "PS_RemovedSuccessfullyMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(472);
				value = value.replace("{0}", "<ParameterSetName>");
				break;
			case "PS_RemovalMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(567);
				value = value.replace("{0}", "<ParameterSetName>");

				break;
			case "PS_RemovalTitle":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(568);
				value = value.replace("{0}", "<ParameterSetName>");
				break;
			case "EditKeyboardEnteredValuesDuringDataEntry":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(439)

				;
				break;
			case "EditGaugeEnteredValuesDuringDataEntry":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2143);
				break;
			case "DisplayScale":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(3052)

				;
				break;
			case "HighlightGridNotification":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(3053);
				break;
			case "HighlightPopupNotification":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(3054);
				break;
			case "PlaySoundWhenAGaugeValueIsEntered":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2145);
				break;
			case "SpecificationLimitNotification":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(3051)

				;
				break;
			case "GaugeEnteredValueNotification":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2144);
				break;
			case "Default":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(601);

				break;
			case "Custom":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(342);
				value = value.toUpperCase();
				break;
			case "DcConfigSaveSuccessmsg":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2615);
				value = value.replace("{0}", "<Element Name>");
				break;
			case "DcConfigSaveSuccessmsg2":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2615);
				value = value.replace("{0}", "<Element Name>");
				break;
			case "ColumnName_ChildProcess":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1820);
				break;
			case "ShiftCountMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1388);

				value = value.replace("{0}", "<count>");

				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1385));

				break;
			case "LotCountMessage":

				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1388);

				value = value.replace("{0}", "<count>");

				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(192));
				break;

			case "DC_DataCollectionType_ChkBoxLabel":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(556);
				break;
			case "DC_AllowLotCreation_ChkBoxLabel":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2596);
				break;
			case "DC_InputPartFaimily1_ChkboxLabel":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(69)
						+ "<DC Test Name>_InputPartFamily1";
				break;
			case "DCIndSetting_EntryMethod":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2142);
				break;
			case "DCIndSetting_EntryMethod_NextValue":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2134);
				break;
			case "DCIndSetting_EntryMethod_CurrentValue":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2135);
				break;
			case "DCIndSetting_EntryMethod_NewestUnusedValue":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2136);
				break;
			case "DCIndSetting_EntryMethod_OldestUnusedValue":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2137);
				break;
			case "DCIndSetting_EntryMethod_DispListOfValues":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2138);
				break;
			case "DCSetting_Assignment_AllowOnly":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1284)

				;
				break;
			case "GaugeDev_CurrentValue":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2135);
				break;
			case "DCIndSetting_Custom":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(342);
				break;
			case "DCIndSetting_Default":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(601);
				break;
			case "IndividualSettings_WithinPieceMeasurement":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1995);
				break;
			case "DCConfig_GlobalSampleSizeMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2619)

				;
				break;

			case "DataCollectionConfig_SaveSuccessfullyMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2615)

				;
				value = value.replace("{0}", "<Element Name>");

				break;

			case "AccordionItem_ResponseGroupFeature":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(498);
				break;
			case "ResponseGroup_DeleteConfirmaitonMessageWithAssociations":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2557)

				;

				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2493);

				temp = temp.toLowerCase();
				value = value.replace("{0}", temp);

				break;
			case "ColumnName_ControlLimit":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2381);
				break;
			case "SingleCLModalBoxMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(731);

				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2381));
				value = value.toLowerCase();
				value = value.replace("{0}", "<Count>");

				break;
			case "EditControlLimit_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2394);
				break;
			case "AccordionItem_AssignedProcessStateMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1226);
				break;

			case "FeatureTypeDrpDwn_Variable":
				value = "1 - " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(177);
				break;
			case "GaugeValue_ShowNewestOnTop":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2139);
				break;
			case "GaugeValue_SpecifyMaximumNumberOfValuesIn the list":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2141)

				;
				break;
			case "GaugeValue_AllowPreviouslyUsedValuesToBeDisplayed":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2140)

				;
				break;
			case "EntryMethod_NotificationMsgWhenBothCheckBoxUnchecked":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2221)

				;
				break;
			case "DynamicLabel":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2662);
				break;
			case "GaugeDevice":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1505);
				break;
			case "DCRequirementAlreadyExistsMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1201);
				break;
			case "NoNewChangeIsSaved":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(980);
				break;
			case "ResponseType_SingleAnswer_Checklist":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2487);
				break;
			case "ColumnName_Requirements":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2573);
				break;
			case "Assignee_Role":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(538);
				break;
			case "Feature_DCModalBoxMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(728);

				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(732);

				value = value.replace("{1}", temp);
				value = value.toLowerCase();
				value = value.replace("{0}", "<Count>");
				break;
			case "Feature_SingleDCModalBoxMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(731);

				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2598);

				value = value.replace("{1}", temp);
				value = value.toLowerCase();
				value = value.replace("{0}", "<Count>");

				break;
			case "ResponseType_MultipleAnswer_Checklist":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2488);
				break;
			case "User_Status_Active":
				value = "1 - " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(451);
				break;
			case "User_Status_Inactive":
				value = "0 - " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(421);

				break;
			case "ShiftLandingPageTitle":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1477);
				break;
			case "createShiftPageHeaderTitle":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1477);
				break;
			case "ColumnShiftName":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1384);
				break;
			case "CreateShiftTitle":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1386);
				break;
			case "ProcessShiftSchedule_CreateShiftPage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1428);
				break;
			case "ColumnName_Monday":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1419);
				break;
			case "ColumnName_Tuesday":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1420);
				break;
			case "ColumnName_Wednesday":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1421);
				break;
			case "ColumnName_Thursday":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1422);
				break;
			case "ColumnName_Friday":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1423);
				break;
			case "ColumnName_Saturday":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1424);
				break;
			case "ColumnName_Sunday":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1418);
				break;
			case "lbl_Schedule":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1454);
				break;
			case "lbl_DefineSchedule":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1412);
				break;
			case "lbl_DerivedFromParentProcess":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1553);
				break;
			case "lbl_EffectiveFrom":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1414);
				break;
			case "lbl_ViewProcesses":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1306);
				break;
			case "lbl_SelectProcess":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(328);
				break;
			case "lbl_PlusOneDay":
				value = "+1 " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2107);
				break;
			case "error_TimeOverLapWithPreviousDay":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1425);
				break;
			case "error_TimeOverLapWithNextDay":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1426);
				break;
			case "column_StartTime":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1415);
				break;
			case "column_EndTime":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1416);
				break;
			case "ShiftAlreadyExists":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1459);
				break;
			case "createShift_MessageForAtleastOneProcessSelection":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1466)

				;
				break;
			case "AccordionItem_AssignedShift":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1540);
				break;
			case "AccordionItem_ShiftDeleteSingleProcess":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1541)

				;
				break;

			case "ShiftCantBeRemoved_Process":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(798)

				;
				break;
			case "Part_Is_Inactive_PFDetail":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(476);
				break;
			case "Global_Configuration":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2526);
				break;
			case "Label_SpecificationLimits":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(730);
				break;
			case "Label_WarningLimit":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(180);
				break;
			case "Label_ReasonableLimit":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(199);
				break;
			case "Label_Auto-fill":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2539);
				break;
			case "Label_%for'WarningLimits'":
				value = "% " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2531);
				break;
			case "Label_xfor'ReasonableLimits'":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2548);
				break;
			case "Label_DefaultCapabilityTargetValues":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2527);
				break;
			case "Label_CpTarget":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2252);
				break;
			case "Label_PpTarget":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2254);
				break;
			case "Label_CpkTarget":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2253);
				break;
			case "Label_PpkTarget":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2255);
				break;
			case "SecurityPolicyPageTitle":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(974);
				break;
			case "SecurityPolicyPageHeaderText":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(976);
				break;
			case "SecurityPolicyPage_UserloginSettingsTab":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(977);
				break;
			case "SecurityPolicyPage_CredentialSettingsTab":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(978);
				break;
			case "SecurityPolicyPage_DataAuthenticationSettingsTab":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(979);
				break;
			case "SecurityPolicyPage_UserNameValidation_LengthHigherThanAllowed":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(836) + " 90.";

				break;
			case "SecurityPolicyPage_UserNameValidation_LengthLowerThanAllowed":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1668) + " 5.";

				break;
			case "SecurityPolicyPage_SaveSuccessMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1035);
				break;
			case "Yes":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(459);
				break;
			case "No":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(460);
				break;
			case "ManageSettingsPageTitle":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(427);
				break;
			case "ManageSettingsPageHeaderText":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(427);
				break;
			case "CPK_Target_Range":
				value = "<LowerValue> <= " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2253)
						+ " <= <UpperValue>";
				break;
			case "CP_Target_Range":
				value = "<LowerValue> <= " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2252)
						+ " <= <UpperValue>";
				break;
			case "PP_Target_Range":
				value = "<LowerValue> <= " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2254)
						+ " <= <UpperValue>";

				break;
			case "PPK_Target_Range":
				value = "<LowerValue> <= " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2255)
						+ " <= <UpperValue>";

				break;
			case "Warning_Limit_Range":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(69)
						+ "XRange should be between <LowerValue>% to <UpperValue>%X";
				break;
			case "Reasonable_Limit_Range":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(69)
						+ "XRange should be between <LowerValue> to <UpperValue>X";
				break;

			case "SecurityPolicy_Header_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(974);
				break;
			case "SecurityPolicy_IdleForOneDay":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1042);
				break;
			case "SecurityPolicy_UseEmailIdNo":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(460);
				break;
			case "GeneralSetting":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1626);
				break;
			case "UnitOfMeasurementAlreadyExists":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(253);
				break;
			case "AbbreviationAlreadyExists":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(242);
				break;
			case "GC_DataCollectionType_TabHeader":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(556);
				break;
			case "Lbl_ChkBox_EnableDataCollectionType":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2570);
				break;
			case "ColumnName_Type":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(41);
				break;
			case "GC_SaveSuccessMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2541);
				break;
			case "GC_RemoveDCType_ConfirmationMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(567);
				value = value.replace("{0}", "<DCTypeName>");
				break;
			case "GC_DCType_AlreadyExistMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2739);
				break;
			case "SecurityPolicy_MissingInfoMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1030)

				;
				break;
			case "GlobalConfiguration_Header_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2526);
				break;
			case "ColumnName_Abbreviation":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(872);
				break;
			case "ColumnName_Unit_Of_Measurement":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1468);
				break;
			case "ColumnName_UnitType":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(193);
				break;
			case "UnitType_Angle":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(105);
				break;
			case "UnitType_Area":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(57);
				break;
			case "UnitType_Count":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(241);
				break;
			case "UnitType_Currency":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(111);
				break;
			case "UnitType_Current":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1392);
				break;
			case "UnitType_Data":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(69) + "XDataX";
				break;
			case "UnitType_Density":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(112);
				break;
			case "UnitType_Energy":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(174);
				break;
			case "UnitType_Force":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(181);
				break;
			case "UnitType_Height":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(69) + "XHeightX";
				break;
			case "UnitType_Length":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1615);
				break;
			case "UnitType_Luminosity":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(152);
				break;
			case "UnitType_Mass":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(26);
				break;
			case "UnitType_Power":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(157);
				break;
			case "UnitType_Pressure":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(158);
				break;
			case "UnitType_Speed":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(103);
				break;
			case "UnitType_Temperature":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(79);
				break;
			case "UnitType_Time":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(178);
				break;
			case "UnitType_Torque":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(159);
				break;
			case "UnitType_Viscosity":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(162);
				break;
			case "UnitType_Volume":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(74);
				break;
			case "UnitType_Width":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(69) + "XWidthX";
				break;
			case "UnitType_Work":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(160);
				break;
			case "UnitWillBeRemovedContinue":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(69)
						+ "XUnit will be removed. Continue?X";
				break;

			case "Events":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1905);
				break;
			case "Status_Removed":
				value = "2 - " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2762);
				break;
			case "Status_All":
				value = "3 - " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1711);
				break;

			case "GCAbbr_DeleteConfirmaitonMessageWithAssociations":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(350)

				;
				break;
			case "AccordionItem_Impacted_Lot":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(637);
				break;

			case "SecurityPolicyPage_Forever":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1060);
				break;
			case "SecurityPolicy_IdleForFiveDay":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1044);
				break;
			case "SecurityPolicy_IdleForThreeDay":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1043);
				break;
			case "SecurityPolicy_IdleFor15Min":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1036);
				break;
			case "SecurityPolicy_IdleFor30Min":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1037);
				break;
			case "SecurityPolicy_IdleFor1Hour":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1038);
				break;
			case "SecurityPolicy_IdleFor4Hour":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1039);
				break;
			case "SecurityPolicy_IdleFor8Hour":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1040);
				break;
			case "SecurityPolicy_IdleFor15Hour":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1041);
				break;
			case "Aggregated":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2483);
				break;
			case "Raw":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2482);
				break;
			case "URL_CreateSpecHelpLink":
				value = "SpecLimits/CreatingSpecLimits.htm";
				break;
			case "RequiredAnswersMissing":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2594);
				break;
			case "ConfirmationMessage_NoResponseEntered":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2593)

				;
				break;
			case "URL_SpecLimitLandingPageHelpLink":
				value = "SpecLimits/ManagingSpecLimits.htm";
				break;
			case "URL_EditSpecLimitPageHelpLink":
				value = "SpecLimits/EditingSpecLimits.htm";
				break;
			case "UserPage_UserNameValidation_LengthLowerThanAllowed":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(375)

				;
				value = value.replace("{0}", "<SetLength>");

				break;
			case "uRL_SecurityPolicyPageHelpLink":
				value = "Security/ConfiguringSecurityPolicy.htm";
				break;
			case "SecurityPolicyPage_validationForPasswordLength_HigherThanAllowed":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1033) + " 20.";

				break;
			case "SecurityPolicyPage_validationForPasswordLength_LowerThanAllowed":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1034) + " 5.";

				break;
			case "ManageSettingsPage_BasicInformation":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1316);
				break;
			case "ManageSettingsPage_Notifications":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1317);
				break;
			case "Removed":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2762);
				break;

			case "ActiveDCToBeDefined":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2581)

				;
				break;
			case "Role_Management":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(521);
				break;
			case "Authentication":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2694);
				break;
			case "User_Management":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(520);
				break;
			case "AccessDeniedText":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(790)

				;
				break;

			case "NoAccessLevelMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1203);
				break;
			case "InvalidPermissionMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2466)

				;
				break;
			case "FifteenMinutes":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1036);
				break;
			case "ThirtyMinutes":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1037);
				break;
			case "OneHour":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1038);
				break;
			case "FourHours":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1039);
				break;
			case "EightHours":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1040);
				break;
			case "FifteenHours":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1041);
				break;
			case "OneDay":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1042);
				break;
			case "ThreeDays":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1043);
				break;
			case "FiveDays":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1044);
				break;
			case "RoleNameUniquenessValidationMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(592);
				break;
			case "ValidationMessage_PasswordAdvanceNotification":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1045)

				;
				break;
			case "NoSystemAccess":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(585);
				break;
			case "LastLogin":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2574);
				break;
			case "d":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2187);
				break;
			case "m":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2188);
				break;
			case "y":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2575);
				value = value.toLowerCase();
				break;
			case "Ago":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2332);
				break;
			case "Count-TimeUnit-Ago":
				value = "<count><TimeUnit> " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2332);
				break;
			case "Today":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(338);
				break;
			case "w":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2576);
				break;
			case "ParameterSet":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1185);
				break;
			case "NotificationRule":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2399);
				break;
			case "PermissionTabText":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(549);
				break;
			case "Role_AlreayExists":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(592);
				break;
			case "GC_Chart":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2437);
				break;
			case "GC_CodeGroup":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(42);
				break;
			case "GC_Condition":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1155);
				break;
			case "GC_ControlLimit":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2381);
				break;
			case "GC_Feature":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(33);
				break;
			case "GC_GaugeSetup":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2224);
				break;
			case "GC_GlobalConfiguration":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2526);
				break;
			case "GC_License":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1191);
				break;
			case "GC_MenuTemplate":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1358);
				break;
			case "GC_NotificationRule":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2399);
				break;
			case "GC_ParameterSet":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1185);
				break;
			case "GC_ShiftLog":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(742);
				break;
			case "GC_StatisticalRule":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2401);
				break;
			case "MenuTemplate_Not_Exist":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2553);
				value = value.replace("{0}", UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1358));
				break;
			case "ManageSettingsPageMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(427);
				break;

			case "URL_CloneRolePageHelpLink":
				value = "Roles/CloningRoles.htm";
				break;
			}

			// call second method
			if (value.equals(""))
				value = mapMultiLingualSheet2(key);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return value;
	}

	private static String mapMultiLingualSheet2(String key) {

		String value = "";
		String temp = "";

		try {

			switch (key) {
			case "URL_CreateRolePageHelpLink":
				value = "Roles/CreatingRoles.htm";
				break;
			case "URL_EditRolePageHelpLink":
				value = "Roles/EditingRoles.htm";
				break;
			case "URL_RoleLandingPageHelpLink":
				value = "Roles/ManagingRoles.htm";
				break;
			case "Roles_PopUp_AvailableUsers":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(659);
				break;
			case "Roles_PopUp_HelperMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(658);
				break;
			case "Roles_PopUp_AssignedUsers":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(660);
				break;
			case "Roles_PopUp_AssignRoleToUsers":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(642);
				break;
			case "RolesLandingPage_RoleName":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(548);
				break;
			case "RolesLandingPage_Users":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(646);
				break;
			case "RolesLandingPage_User":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(508);
				break;
			case "Roles_Permissions_ActionOrientedAlignment":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(555);
				break;

			case "Permissions_Authentication":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2694);
				break;
			case "Permissions_ConfigureParameters":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(293);
				break;
			case "ColumnName_FirstName":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(532);
				break;
			case "ColumnName_LastName":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(533);
				break;
			case "RolesLandingPage_UserPopUp_EntityHeading":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(830);

				value = value.replace("{0}", "<RoleName>");

				break;
			case "RolesLandingPage_UserPopUp_UsersCount":
				value = "(<count> ";
				value = value.toLowerCase();
				break;
			case "Roles_RemoveRole_ConfirmationMessage1":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(679);
				value = value.replace("{0}", "<RoleName>");
				break;
			case "Roles_RemoveRole_AssociationConfirmationMessage1":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2557);
				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(538);
				temp = temp.toLowerCase();
				value = value.replace("{0}", temp);
				break;

			case "Roles_AssignedToDcMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(565);
				break;
			case "Roles_AssignedToCheckListMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2558);
				break;
			case "ProcessStateLandingPageTimeZoneLabel":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1279);
				break;
			case "Date&Time(Local)_Label":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(319)

						+ " "

						+ "(" + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2070) + ")";

				break;
			case "ShowRemovedRecords":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2766);
				break;
			case "Permissions_Manage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1196);
				break;
			case "License":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1191);
				break;
			case "MenuTemplate":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1358);
				break;
			case "Workstation":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1049);
				break;
			case "MenuTemplates_HeaderTitle":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1298);
				break;
			case "CreateMenuTemplate_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1343);
				break;
			case "Create_Condition_PageTitle":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1054);
				break;
			case "Gauge_Interface":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1240);
				break;
			case "Create_Gauge_Interface":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1501);
				break;
			case "Gauge_Formats":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1577);
				break;
			case "Create_Gauge_Format":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1578);
				break;
			case "Gauge_Devices":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1728);
				break;
			case "Gauge_Interface_Connection":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1725);
				break;
			case "Gauge_Initialization":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1637);
				break;
			case "Measurement_Initialization":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1639);
				break;
			case "Measurement_Start ":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1641);
				break;
			case "Measurement_End":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1643);
				break;
			case "Measurement_Read":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1645);
				break;
			case "Measurement_Post":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1647);
				break;
			case "Measurement_Request":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1649);
				break;
			case "Data_Collection_Start":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1651);
				break;
			case "Data_Collection_End":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1653);
				break;
			case "RuleTemplateLandingPage_Header_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2171);
				break;
			case "ColumnName_Rule_Template_Name":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2063);
				break;
			case "ColumnName_TimeToTimeRule":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2513);
				break;
			case "ColumnName_BetweenPieceRule":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2514);
				break;
			case "ColumnName_WithinPieceRule":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2515);
				break;
			case "Create_RuleTemplate_Page_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2064);
				break;

			case "AboveUpperControlLimit":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1857);
				break;

			case "LicenseManagement":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1051);
				break;
			case "AddLicenseAssignment":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1251);
				break;
			case "UsernameAndWorkstation":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1093);
				break;
			case "RemainingLicenses":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1121);
				break;

			case "Agent":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2074);
				break;
			case "Gauge_Interface_Name":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1502);
				break;
			case "Data_Port_Configuration":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1745);
				break;
			case "Port_Initialization":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1582);
				break;
			case "Port_Termination":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1583);
				break;
			case "Gauge_Format":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1504);
				break;
			case "WorkstationLandingPageTitle":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2588);
				break;
			case "Configure_Workstation_Page_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2771);
				break;
			case "ColumnName_Workstation_Name":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1003);
				break;
			case "Workstation_Configurations_Save_Successfully":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2773);
				break;

			case "ProcessModels":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(774);
				break;
			case "Security":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1241);
				break;
			case "ShiftLogs":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1480);
				break;
			case "Calculations":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2281);
				break;
			case "Licenses":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1248);
				break;
			case "Workstations":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2588);
				break;
			case "NotificationRules":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1713);
				break;
			case "StatisticalRules":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2061);
				break;
			case "ProcessingTemplates":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2195);
				break;
			case "GaugeAgentInstaller":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2621);
				break;
			case "Global":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2529);
				break;
			case "MenuTemplateName":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1341);
				break;
			case "NotificationRulesLandingPage_HeaderTitle":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1713);
				break;
			case "CreateNotificationRulesPage_PageTitle":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1714);
				break;
			case "NCC_Violation":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1872);
				break;
			case "SpecificationViolation":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1873);
				break;
			case "StatisticalViolation":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1874);
				break;
			case "ChecklistViolation":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2608);
				break;
			case "Defective":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(175);
				break;
			case "NotificationRules_StatusTabHeadingForDataCollection":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1806);
				break;
			case "Due":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1877);
				break;

			case "Missed":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1878);
				break;
			case "Success":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1879);
				break;
			case "AlarmType":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1750);
				break;
			case "DataStream":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2611);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1266));

				break;
			case "Recipients":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1804);
				break;
			case "NotificationRules_RecipientsTabHeading":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(508)

						+ "/" + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1049)

						+ "/" + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(538);
				break;
			case "Configuration":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1238);
				break;
			case "RealTimeAnalytics":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(69) + "XReal Time AnalyticsX";
				break;
			case "Labels":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1242);
				break;
			case "Downloads":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2620);
				break;
			case "NotificationRuleName":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1715);
				break;

			case "Username":
				value = "1 - " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(535);
				break;
			case "License_Workstation":
				value = "2 - " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1049);
				break;
			case "License_RemoveEntityPopupMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1149);

				value = value.replace("{0}", "<Element Name>");

				break;
			case "ModifyLicenseAssignment":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1053);
				break;

			case "LotNumber":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2347);
				break;
			case "CurrentStatus":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(420);
				break;
			case "StatusTime":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2348);
				break;
			case "Sound":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1318);
				break;
			case "DefineNotificationPlatform":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1320);
				break;
			case "PlaySound":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1319);
				break;
			case "StatisticalRulesLandingPageTitle":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2060);
				break;
			case "ColumnName_Priority":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2073);
				break;
			case "ColumnName_RuleType":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2068);
				break;
			case "ColumnName_Hits":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2069);
				break;
			case "ColumnName_Count":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(241);
				break;
			case "ColumnName_Label":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2071);
				break;
			case "TimeToTimeRule_TabTitle":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2510);
				break;
			case "BetweenPieceRule_TabTitle":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2511);
				break;
			case "WithinPieceRule_TabTitle":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2512);
				break;
			case "ProcessingTemplateLandingPage_Header_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2195);
				break;
			case "ColumnName_Processing_Template_Name":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2092);
				break;
			case "ColumnName_Feature_Type":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(139);
				break;
			case "ColumnName_Normalization":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2093);
				break;
			case "ColumnName_Control_Limit_Confidence_Interval":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2094);
				break;
			case "ColumnName_Processing_Option":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2099);
				break;
			case "ColumnName_Initialize_on_Part_Change":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2097);
				break;
			case "priority":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2073);
				break;
			case "ruleType":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2068);
				break;
			case "hits":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2069);
				break;
			case "count":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(241);
				break;
			case "label":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2071);
				break;
			case "enabled":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2174);
				break;
			case "Create_ProcessingTemplate_Page_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2091);
				break;
			case "Password_Guidelines_ChangePassword_ManageSettings":

				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1026);
				temp = temp.replace("{0}", "8");

				String temp1 = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1307);
				temp1 = temp + " [ ] ? / < > ~ # ` ! @ _ - $ % ^ & * ( ) + = { } | : \" ; ' ,";

				String temp2 = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1025);
				temp2 = temp.replace("{0}", "365");

				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1020)

						+ "\n\n"

						+ temp + "\n" + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1021)

						+ "\n" + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1308) + "\n"
						+ UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1315) + "\n" + temp1 + "\n"
						+ temp2;

				break;

			case "URL_WorkStationLandingPageHelpLink":
				value = "Workstations/ManagingWorkstations.htm";
				break;
			case "Workstation_AlreayExists":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2772);
				break;
			case "Label_Already_Exists":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2207);
				break;
			case "CountGreaterThanHits":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2208);
				break;
			case "HitsLessThanCount":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2209);
				break;
			case "Statistical_Rule_Delete_Message":

				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2364);
				value = value.replace("{0}", "<Element Name>");
				value = value.replace("<br/> ", "\n");

				value = value.replace("<br />", "\n");

				break;
			case "HelperText_Date":
				value = "M/d/yyyy h:mm:ss tt";
				break;
			case "CombinationAlreadyExists":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2210);
				break;
			case "WorkStation_Header_AccessLevel_PopUp":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1145);
				break;
			case "Workstation_AccessLevelCount_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(731);

				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(539);

				value = value.replace("{1}", temp);
				value = value.toLowerCase();
				value = value.replace("{0}", "<Element Name>");

				break;
			case "Menu_Template_Name_already_exists":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1374);
				break;

			case "Workstation_errorMsg_WorkStationNotAutothorizedAndUserNotAbleToAuthorize":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2695);
				break;
			case "GC_Workstation":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1049);
				break;
			case "View_Workstation_Page_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2774);
				break;

			case "Menu_Template_Name_already_exists.":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1374);
				break;
			case "WorkstationSavedSuccessfullyMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(102);

				value = value.replace("{0}", "<Element Name>");

				break;
			case "WorkStation_Header_Checklist_PopUp":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2586);
				break;
			case "Workstation_ChecklistCount_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(731);

				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(127);

				value = value.replace("{1}", temp);

				value = value.toLowerCase();
				value = value.replace("{0}", "<Element Name>");
				break;
			case "viewPopUpTitleWorkstation":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2585);

				value = value.replace("{0}", "<Element Name>");
				;
				break;
			case "Workstation_DCCount_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(731);

				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(21);

				value = value.replace("{1}", temp);

				value = value.toLowerCase();
				value = value.replace("{0}", "<Element Name>");

				break;
			case "WorkStation_Header_NotificationRule_PopUp":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2587);
				break;
			case "Workstation_NotificationRuleCount_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(731);
				value = value.replace("{0}", "<Element Name>");

				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2399);

				value = value.replace("{1}", temp);
				value = value.toLowerCase();
				break;
			case "Column_Assigned_License":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(570);
				break;
			case "Column_Last_Authenticated_By":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2583);
				break;
			case "View_Role":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1629);
				break;
			case "View_User":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(829);
				break;
			case "Menu_Template":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1358);
				break;
			case "MenuTemplateViewPopUpHeading":

				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(731);
				value = value.toLowerCase();
				value = value.replace("{0}", "<Count>");
				value = value.replace("{1}", "<Module>");

				temp = value;

				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1358) + ": <MenuTemplateName> "
						+ temp;
				break;
			case "Search":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(710);
				break;
			case "StatisticalRule_HitsGreaterThanOne_Message":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2523);
				break;
			case "URL_StatisticalPageHelpLink":
				value = "StatisticalRules/ManagingStatisticalRules.htm";
				break;
			case "URL_MenuTemplatelandingPage_HelpLink":
				value = "MenuTemplates/ManagingMenuTemplates.htm";
				break;
			case "URL_CreateMenuTemplatePage_HelpLink":
				value = "MenuTemplates/CreatingMenuTemplates.htm";
				break;
			case "URL_EditMenuTemplatePage_HelpLink":
				value = "MenuTemplates/EditingMenuTemplates.htm";
				break;
			case "Qty":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(698);
				break;
			case "Lot":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(192);
				break;
			case "MenuTemplate_DeleteConfirmaitonMessage_WithAssociation":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(567);
				value = value.replace("{0}", "<Element Name>");

				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(138);

				value = value + "\n" + "\n" + temp;
				break;
			case "AccordionItem_AssignedRoleMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2000);
				break;
			case "Process_ProcessWithSameNameMsg":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2108);
				break;
			case "Shifts_ProcessDeletetionMsg_IfOnlyOneProcessAssigned":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1541);
				break;
			case "URL_LotLandingPageHelpLink":
				value = "Lots/ManagingLots.htm";
				break;
			case "URL_CreateLotPageHelpLink":
				value = "Lots/CreatingLots.htm";
				break;
			case "URL_EditLotPageHelpLink":
				value = "Lots/EditingLots.htm";
				break;
			case "Lot_LotAlreadyExistAsRemoved":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2734);
				break;
			case "CurrentProcess":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2367);
				break;
			case "Lot_LotAlreadyExistForPart":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2361);
				break;
			case "NotificationRuleNameAlreadyExists":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1734);
				break;
			case "OnHold":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2353);
				break;
			case "TestingComplete":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2352);
				break;
			case "ParameterSet_Time_InfoIconMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1405);
				value = value.replace("<br/> �  ", "\n");
				value = value.replace("<br/>  ", "\n");
				value = value.replace("<b>", "");
				value = value.replace("</b>", "");

				break;

			case "StartDate&Time":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(423);
				break;
			case "EndDate&Time":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(424);
				break;
			case "DataCollectionS":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2611);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(21));

				break;
			case "CheckListS":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2611);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(127));

				break;
			case "SelectCheckLlistsEntity_Header_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1463);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(127));
				break;
			case "SelectDataCollectionEntity_Header_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1463);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(732));

				break;
			case "Above_T2_upper":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1851);
				break;
			case "Below_T2_lower":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1854);
				break;
			case "Above_MAV_upper":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1852);
				break;
			case "Below_MAV_lower":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1855);
				break;
			case "Above_USL":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1842);
				break;
			case "Below_LSL":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1876);
				break;
			case "Above_URL":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1843);
				break;
			case "Below_LRL":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1847);
				break;
			case "Above_UWL":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1875);
				break;
			case "Below_LWL":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1848);
				break;
			case "Above_UWP":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1844);
				break;
			case "Below_LWP":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1849);
				break;
			case "Above_USG":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1845);
				break;
			case "Below_LSG":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1850);
				break;
			case "Notify_When":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1807);
				break;
			case "Upper":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(517);
				break;
			case "Lower":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(518);
				break;
			case "Below_Lower_Control_Limit":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1861);
				break;
			case "In_or_Above_Upper_Zone_A":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1858);
				break;
			case "In_or_Below_Lower_Zone_A":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1862);
				break;
			case "In or_Above_Upper_Zone_B":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1859);
				break;
			case "In_or_Below_Lower_Zone_B":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1863);
				break;
			case "Run_Above_Centerline":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1860);
				break;
			case "Run_Below_Centerline":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1864);
				break;
			case "Others":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1732);
				break;
			case "Run_within_Zone_C":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1865);
				break;
			case "Avoidance_of_Zone_C":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1866);
				break;
			case "Consecutive_Points_Rising":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1867);
				break;
			case "Consecutive_Points_Falling":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1868);
				break;
			case "Oscillating_Up_and_Down":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1869);
				break;
			case "No_Variation_in_Values":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1870);
				break;
			case "DC_Assigned_Users":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2035);
				break;
			case "Error_AtleastOneSelect_NotificationRule":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1733);

				value = value.replace("status", "<element>");
				break;
			case "Error_ExistingSelectLost_NotificationRule":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1735);
				break;
			case "Lot_ClosedAccepted":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2354);
				break;
			case "Lot_ClosedRejected":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2355);
				break;
			case "Notification_Rule_Any_Data_Collection":

				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1832);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(21));

				break;
			case "Lots_Association_Message":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(557);
				break;
			case "No_License_Available_Message_For_User":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(999);
				break;
			case "NotificationRule_NoDcMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1832);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(21));

				break;
			case "AnyCheckList":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1832);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(127));

				break;
			case "RecipientDoesNotExist":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2553);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2571));

				break;
			case "WorkstationLicenseAssociatedConfirmationMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(525);
				break;
			case "No_License_Available_Message_For_Machine":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2718);
				break;
			case "Username/Workstation_doesn't_exist":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2553);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1093));

				break;
			case "License_already_exists.":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1148);
				break;

			case "You_have_been_logged_out_from_this_session.":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2568);
				break;

			case "NotInListMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2049);
				break;

			case "Change":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1824);
				break;
			case "URL_NotificationLandingPageHelpLink":
				value = "NotificationRules/ManagingNotificationRules.htm";
				break;
			case "URL_CreateNotificationPageHelpLink":
				value = "NotificationRules/CreatingNotificationRules.htm";
				break;
			case "URL_EditNotificationPageHelpLink":
				value = "NotificationRules/EditingNotificationRules.htm";
				break;
			case "TrackCountExceeded":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2609);
				break;
			case "NotificationRules_ChecklistTabHeading":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2015);
				break;
			case "NotificationRules_Checklist_Pageheader":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1460);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(127));

				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1461));

				break;
			case "NotificationRules_DataCollection_Pageheader":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1460);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(732));

				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1461));

				break;
			case "Workstation_doesn�t_exist":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2778);
				break;
			case "URL_LicenseLandingPageHelpLink":
				value = "Licenses/AssigningLicenses.htm";
				break;
			case "EntityCountMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1388);

				value = value.replace("{0}", "<count>");

				value = value.replace("{1}", "<entity>");
				break;

			case "NotificationRule_UpdateSuccessMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2310);
				break;
			case "NotificationRule_AlreadyExistAsRemoved":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2747);
				break;

			case "ViewRequirements":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2577);
				break;
			case "CreateRequirements":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2549);
				break;
			case "MoreRequirements":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2802);
				break;
			case "Create_Calculation":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2033);
				break;
			case "Calculation_Name":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2152);
				break;
			case "Save_as_Feature":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2193);
				break;
			case "Initiators":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2257);
				break;
			case "Add_Below":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2783);
				break;
			case "Add_Above":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2782);
				break;
			case "Calculation":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2058);
				break;
			case "Calculation_RemoveStepMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2754);
				value = value.replace("{0}", "<StepNumber>");

				break;
			case "Calculation_StepNumber":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2753);
				value = value.replace("{0}", "<StepNumber>");

				break;
			case "Calculation_RemovePopUptTitle":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(69)
						+ "XRemove Step <StepNumber>X";
				break;

			case "RuleTemplateNameAlreadyExistsErrorMsg":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2230);
				break;
			case "RuleTemplateNameAlreadyExistsAsRemoveRecordErrorMsg":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2751);
				break;
			case "URL_RuleTemplateLandingPageHelpLink":
				value = "RuleTemplates/ManagingRuleTemplates.htm";
				break;
			case "URL_CreateRuleTemplatePageHelpLink":
				value = "RuleTemplates/CreatingRuleTemplates.htm";
				break;
			case "URL_EditRuleTemplatePageHelpLink":
				value = "RuleTemplates/EditingRuleTemplates.htm";
				break;
			case "RuleTemplate_ViewPopUp_SubHeading":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2066) + ": <Element Name>";

				break;
			case "RuleTemplate_ViewPopUp_SubHeadingWithOneCount":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(731);
				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2062);
				value = value.replace("{1}", temp);
				value = value.toLowerCase();
				value = value.replace("{0}", "<Count>");
				break;
			case "RuleTemplate_ViewPopUp_SubHeadingWithMoreThanOneCount":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(728);
				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2177);

				value = value.replace("{1}", temp);
				value = value.toLowerCase();
				value = value.replace("{0}", "<Count>");
				break;
			case "RuleTemplate_TimeToTimeViewPopUpHeader":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2519);
				break;
			case "RuleTemplate_BetweenPieceViewPopUpHeader":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2520);
				break;
			case "RuleTemplate_WithinPieceViewPopUpHeader":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2521);
				break;

			case "Tag_Group_Name_already exists_as_removed_record":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1023);
				value = value.replace("{0}", UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(403));
				break;
			case "Tag_already exists_as_removed_record":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2724);
				break;

			case "CodeGroupRemoval_Success":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(948);

				value = value.replace("{0}", "<Element Name>");
				break;
			case "CodeGroupRemoval_ConfirmationWithoutAssociation":
				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(947);
				temp = temp.replace("{0}", "<Element Name>");
				value = temp + "\n" + "\n" + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1070);
				break;
			case "Condition_Name":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1055);

				break;
			case "SettingSaveSuccessfullyMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(102);
				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(427);
				temp = temp.toLowerCase();
				value = value.replace("{0}", "<Element Name> " + temp);
				break;
			case "Condtions_DeleteConfirmaitonMessage_WithAssociation":

				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(567);

				temp = temp.replace("{0}", "<Element Name>");
				value = temp + "\n" + "\n" + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1344);

				break;

			case "AssignedToDcRequirementMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1369);
				break;
			case "Day_of_week":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2550);
				break;
			case "Gauge_Interface_Connection_saved_successfully.":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1882)

				;
				break;
			case "TCP/IP":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1809);
				break;
			case "Com_Port":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1737);
				break;
			case "Gauge_Format_Name":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1579);
				break;
			case "RuleTemplate_Association_Message":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1106);
				break;
			case "Associated_ControlLimit_ConfirmationMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1129);
				break;

			case "ProcessingTemplateNameAlreadyExistsAsRemoveRecordErrorMsg":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2743);
				break;

			case "URL_CreateProcessPageHelpLink":
				value = "Processes/CreatingProcesses.htm";
				break;
			case "message_RestoreConfirmation_WithoutAssociation":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2701);

				value = value.replace("{0}", "<Element Name>");
				value = value.replace(" <br>", "\n");
				value = value.replace("<br>", "\n");
				break;
			case "RestoredSuccessfullyMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2700);

				value = value.replace("{0}", "<Element Name>");
				break;

			case "RestorePopUpTitle":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2698);
				value = value.replace("{0}", "<Element Name>");
				break;
			case "Create_Gauge_Device":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1726);
				break;
			case "Gauge_Device_Name":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1727);
				break;
			case "DeleteConfirmaitonMessageWithAssociationsForGaugeInterface":

				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(567);

				temp = temp.replace("{0}", "<Element Name>");

				value = temp + "\n" + "\n" + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2025);

				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1500);
				value = value.replace("{0}", temp.toLowerCase());

				break;

			case "AccordionItem_AssignedGaugeFormat":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2027);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1504));

				break;

			case "AccordionItem_AssignedGaugeDevice":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2027);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1505));

				break;

			case "ProcessingOption_ShewhartCUSUM":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2128);
				break;
			case "ProcessingOption_Exponentially_Weighted_Moving_Average":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2131);
				break;
			case "ProcessingOption_EconomicControlLimit":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2130);
				break;
			case "ProcessingOption_TabularCUSUM":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2129);
				break;
			case "ProcessingOption_CoefficientOfVariation":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2155);
				break;

			case "Modifying_a_gauge_interface_connection_will_affect_1_gauge_device.":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1889);
				value = value.replace("{0}", "1");

				break;
			case "Modifying_a_gauge_interface_connection_will_affect_N_gauge_devices.":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1991);
				value = value.replace("{0}", "<count>");

				break;
			case "NormalizationOption_Nominal":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1299);
				break;
			case "NormalizationOption_Target":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(186);
				break;
			case "NormalizationOption_ProcessMean":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1300);
				break;
			case "NormalizationOption_Standardized":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1301);
				break;
			case "AtLeastOneMeanShiftDetectionLimit_ErrorMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2101);
				break;
			case "Part - Feature combination already exists as removed record":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2738);
				break;

			case "SelectParentProcess":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1075);
				break;
			case "Msg_ParentProcessWithSameChildName":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2172);
				break;
			case "Msg_ProcesslAlreadyContainsChildAsRemovedRecord":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2697);
				break;
			case "Msg_ResponseAlreadyExistAsRemovedRecord":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1023);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2493));

				break;
			case "Msg_ChoiceAlreadyExistAsRemovedRecord":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2727);
				break;
			case "Restore_Confirmation_Message_For_PartRevision":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2699);

				value = value.replace("{0}", "<Element Name>");
				value = value.replace("<br/> ", "\n");
				value = value.replace(" <br>", "\n");
				value = value.replace("<br>", "\n");

				break;

			case "message_SpecLimitRestoreConfirmation_WithoutAssociation":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1986);

				value = value.replace("{0}", "<Element Name>");
				value = value.replace(" <br>", "\n");
				value = value.replace("<br>", "\n");
				break;

			case "message_RestoreConfirmation_WithoutAssociation_Feature":

				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2767);

				value = value.replace("{0}", "<Element Name>");
				value = value.replace(" <br>", "\n");
				value = value.replace("<br>", "\n");
				break;

			case "message_RestoreConfirmation_WithoutAssociation_Process":

				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2701);

				value = value.replace("{0}", "<Element Name>");
				value = value.replace(" <br>", "\n");
				value = value.replace("<br>", "\n");
				break;

			case "Msg_ChecklistAlreadyExistAsRemovedRecord":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2730);
				break;
			case "Msg_LabelAlreadyExistAsRemovedRecord":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2750);
				break;

			case "ShortName_AlreadyExistAsRemoved":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(461);
				break;

			case "ProcessingTemplateNameAlreadyExistsErrorMsg":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2231);
				break;
			case "FeatureType_Attribute":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2479);
				break;
			case "AccessLevelPopUp":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1193);
				break;
			case "ToolTip_ControlLimitConfidenceInterval_Probability":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2241);
				value = value.replace("<br/>", "\n");
				value = value.replace("{0}", "90.0");

				value = value.replace("{1}", "99.999");
				break;
			}

			// call third method
			if (value.equals(""))
				value = mapMultiLingualSheet3(key);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return value;
	}

	private static String mapMultiLingualSheet3(String key) {

		String value = "";
		String temp = "";

		try {
			switch (key) {

			case "ToolTip_WaitingFactor":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2247);
				value = value.replace("<br/>", "\n");
				value = value.replace("{0}", "0");

				value = value.replace("{1}", "1");
				break;
			case "ToolTip_FastInitialResponse":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2246);
				value = value.replace("<br/>", "\n");
				value = value.replace("{0}", "0");

				value = value.replace("{1}", "99");
				break;
			case "URL_ProcessingTemplateLandingPageHelpLink":
				value = "ProcessingTemplates/ManagingProcessingTemplates.htm";
				break;
			case "errorMessage_MSZLGreaterThanMSZU":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2202);
				break;
			case "errorMessage_MSZULessThanMSZL":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2203);
				break;
			case "ProcessingTemplate_Association_Message":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1150);
				break;
			case "URL_CalculationsLandingPageHelpLink":
				value = "Calculations/ManagingCalculations.htm";
				break;
			case "URL_CreateCalculationPageHelpLink":
				value = "Calculations/CreatingCalculations.htm";
				break;
			case "URL_EditCalculationPageHelpLink":
				value = "Calculations/EditingCalculations.htm";
				break;
			case "SelectAnOutputOption":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2197);
				break;
			case "ConfigureOutput":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2282);
				break;
			case "Collect_Data":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2831);
				break;
			case "ChecklistRequirement_PageTitle":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1073);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(127));

				break;
			case "URL_GlobalConfigurationPageHelpLink":
				value = "GlobalConfiguration/ConfiguringGlobalSettings.htm";
				break;
			case "Workstation_doesn't_exist":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2778);
				break;

			case "ErrorMessage_InputAlreadyExistsInEquation":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(961);
				break;
			case "View_CollectionAids_Page_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2800);
				break;
			case "Static_NoEntitySelected":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1832);
				value = value.replace("{0}", "<entity>");

				break;
			case "ConfirmationMessage_Static_StaticToDynamic":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1717);

				value = value.replace("{0}", "<entity>");

				break;

			case "Static_xpathProcess":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1830);
				break;
			case "Static_xpathPart":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2344);
				break;
			case "Static_xpathFeature":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1886);
				break;
			case "Static_xpathCheckList":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2618);
				break;
			case "Static_xpathDC":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2054);
				break;
			case "FeatureUpdate_ConfirmationMessageHeader":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(941);
				break;
			case "AccordionItem_AssignedControlLimit_Feature":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(949);
				break;
			case "AccordionItem_AssignedPartFeature_Feature":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(955);
				break;
			case "FeatureUpdate_PopUpTitle":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(938);
				break;
			case "WarningLimitToolTip":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2546);
				break;
			case "ReasonableLimitToolTip":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2547);
				break;
			case "StaticEntityPage_PageTitle":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1463);

				value = value.replace("{0}", "<EntityName>");

				break;
			case "DynamicEntity_PageTitle":

				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1460);

				value = value.replace("{0}", "<EntityName>");

				value = value.replace("{1}", "<Condition>");

				break;
			case "ValueAlreadySelected":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1464);
				break;
			case "Entity_DoesNot_Exist":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2553);

				value = value.replace("{0}", "<EntityName>");

				break;
			case "NoTagAvailableForSelection":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2661);
				break;
			case "CountSelectedMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1388);

				value = value.replace("{0}", "<count>");
				value = value.replace("{1}", "<entity>");

				break;
			case "label_EntitySelected":
				value = "X<EntityName> Selected:X";
				break;
			case "dynamicCriteria_DefaultMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2684)

						+ "\n"

						+ "<CriteriaName>"

						+ "\n" + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2685)

						+ "\n" + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(871)

						+ "\n" + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2686);
				break;

			case "CalculationNameAlreadyExists":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2259);
				break;
			case "AddInput":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(874);
				break;
			case "Alert":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(220);
				break;
			case "UsedEntityCantBeChangedInEquationMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(965);

				value = value.replace("{0}", "<Entity Name>");
				break;
			case "UsedEntityCantBeDeletedInEquationMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(964);
				value = value.replace("{0}", "<Entity Name>");
				break;
			case "viewPopUpTitleCalculation":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2156);

				value = value.replace("{0}", "<Entity Name>");
				break;
			case "lbl_ViewProcess":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1833);
				break;
			case "ViewProcessModalBoxMoreThanOneCountMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(728);

				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1080);

				value = value.replace("{1}", temp);
				value = value.toLowerCase();
				value = value.replace("{0}", "<Count>");
				break;
			case "ViewPartModalBoxMoreThanOneCountMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(728);

				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(76);

				value = value.replace("{1}", temp);

				value = value.toLowerCase();
				value = value.replace("{0}", "<Count>");
				break;
			case "lbl_ViewPart":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2167);
				break;
			case "CalculationViewPopUpModalBoxTitle":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2156);
				value = value.replace("{0}", "<Entity Name>");
				break;
			case "CalculationNameAlreadyExistsAsRemovedRecord":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2277);
				break;
			case "SAYT_NoRecordFoundMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(65);
				value = value.toUpperCase();
				break;
			case "ErrorMessage_FeatureDoesntExists":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(104);
				break;
			case "ErrorMessage_FeatureUsedAsOutput":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2780);
				break;
			case "ColumnName_Output":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(25);
				break;
			case "Initiators_Header_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2257);
				break;
			case "lbl_ViewInitiator":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2244);
				break;
			case "ViewInitiatorModalBoxMoreThanOneCountMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(728);

				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2257);

				value = value.replace("{1}", temp);

				value = value.toLowerCase();
				value = value.replace("{0}", "<Count>");
				break;
			case "ViewFeatureModalBoxMoreThanOneCountMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(728);

				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(80);

				value = value.replace("{1}", temp);

				value = value.toLowerCase();
				value = value.replace("{0}", "<Count>");
				break;
			case "Step1":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2753);
				value = value.replace("{0}", "1");
				value = value.toUpperCase();
				break;
			case "Step2":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2753);
				value = value.replace("{0}", "2");
				value = value.toUpperCase();
				break;
			case "errorMessage_AtLeastOneStepIsRequired":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2309);
				break;
			case "errorMessage_AllInitiatorsMustBeDefined":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2787);
				break;
			case "errorMessage_AtLeastOneOutputMustBeDefined":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2745);
				break;
			case "toolTipOnlyOneOperatorIsAllowed":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2790);
				break;
			case "CalculationName_AlreayExists":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2259);
				break;
			case "ErrorMessage_NestedFunctionNotAllowedWithMoreButton":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2789);
				break;
			case "ErrorMessage_NestedFunctionNotAllowed":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2789);
				break;
			case "StepCount":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2753);

				value = value.replace("{0}", "<count>");
				break;
			case "errorMessage_AtLeastOneStepIsRequiredWithOutMoreButton":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2309);
				break;
			case "ErrorMessage_OutputMustBeDefined":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2793);
				break;
			case "Long Name":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(40);
				break;
			case "AccordionItem_AssignedChecklist":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2559);
				break;
			case "URL_FeatureLandingPageHelpLink":
				value = "Features/ManagingFeatures.htm";
				break;
			case "URL_CreateFeaturePageHelpLink":
				value = "Features/CreatingFeatures.htm";
				break;
			case "URL_EditFeaturePageHelpLink":
				value = "Features/EditingFeatures.htm";
				break;
			case "ErrorMessage_ThisItemWasRemoved":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2792);
				break;
			case "FeatureAlreadyDefinedInOtherCalculation":
				value = "<Entity Name> " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2788)

						+ " " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2748) + "."

				;
				break;
			case "ErrorMessage_InvalidEntry":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1194);
				break;
			case "ErrorMessage_OutputAlreadyDefinedInStep":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2795);

				value = value.replace("{0}", "<Count>");

				break;
			case "toolTipParameterMustBeInputOrSavedFeature":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2794);
				break;
			case "Backspace":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(868);
				break;
			case "FeatureAlreadyDefinedInOtherCalculationInStep":

				value = "<Entity Name> " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2788)

						+ " " + "<Entity Name1> - "
						+ UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2753) + "."

				;
				value = value.replace("{0}", "<Step Count>");

				break;
			case "PopUp_RemoveStepTitle":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2757);

				value = value.replace("{0}", "<Count>");
				break;
			case "PopUp_RemoveStepMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2755);

				value = value.replace("{0}", "<Count>");

				break;
			case "ErrorMessage_FeatureAlsoDefinedInStep":

				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2752);

				value = value.replace("{0}", "<Entity Name>");

				value = value.replace("{1}", "<Count>");

				break;
			case "productionAssignments":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2874);
				break;
			case "English - US":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2870);
				break;
			case "English - UK":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2871);
				break;
			case "German - Germany":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2872);
				break;
			case "Spanish - Mexico":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2873);
				break;
			case "Vietnamese - Vietnam":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2886);
				break;
			case "Header_Purge":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2813);
				break;
			case "Purge_HelperMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2814)

						+ UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2815);

				break;
			case "Header_PurgeAllItems":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2817);
				break;
			case "msg_PurgePopUp_ConfirmationMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2818)

						+ "\n" + "\n" + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2819);
				break;

			case "Msg_NoRemovedItemAvailable":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2820);
				break;
			case "GC_DCType_AlreadyExistAsRemovedMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2740);
				break;
			case "UnitOfMeasurementAlreadyExistsAsRemovedRecord":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2733);
				break;
			case "AbbreviationAlreadyExistsAsRemovedRecord":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2732);
				break;
			case "msg_PurgeRunning":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2825)

						+ "\n" + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2826);
				break;
			case "msg_CantRestoreMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2829);
				value = value.replace("{0}", "<EntityName>");
				break;
			case "msg_PurgeFailed":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2828);
				value = value.replace("{0}", "");
				break;
			case "msg_PurgeSuccess":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2827);
				value = value.replace("{0}", "");

				break;
			case "lbl_AllRemovedItems":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2812);
				break;
			case "lbl_ProcessCollection":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2860);
				break;
			case "lbl_Appearance":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2703);
				break;
			case "URL_CodeGroupLandingPageHelpLink":
				value = "CodeGroups/ManagingCodeGroups.htm";
				break;
			case "URL_EditCodeGroupLandingPageHelpLink":
				value = "CodeGroups/EditingCodeGroups.htm";
				break;
			case "URL_CreateCodeGroupLandingPageHelpLink":
				value = "CodeGroups/CreatingCodeGroups.htm";
				break;
			case "CodeGrp_AlreadyExistAsRemoved":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1023);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(42));
				break;
			case "CodeName_AlreadyExistAsRemoved":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2725);
				break;
			case "TagGrp_AlreadyAssigned":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2832);
				break;
			case "ErrorMessage_FeatureAlreadySelected":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1458);
				break;
			case "AccordionItem_AssignedControlLimitMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1063);
				break;
			case "AccordionItem_AssignedUserAccessLevelMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1200);
				break;
			case "AccordionItem_AssignedWorkstationAccessLevelMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2706);
				break;
			case "AccordionItem_AssignedGaugeDeviceMessage_Process":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2707);
				break;
			case "AccordionItem_AssignedLotMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2562);
				break;
			case "AccordionItem_AssignedCalculationMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1371);
				break;
			case "AccordionItem_AssignedProductionAssignmentsWillBeImpacted":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2884);
				break;
			case "txtPartProcessHeading":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2786);
				break;
			case "Label_LimitParameterSet":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2673)

						+ UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1394)

						+ "\n" + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2672);
				break;
			case "lblFeatureInCapitals":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(33);
				break;
			case "lblTestCaluclationPopUpTitle":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(864);
				break;
			case "lblValues":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2564);
				break;
			case "txtMessageIsALsoDefinedInOtherCalculations":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2749);
				break;
			case "Step1_InCamelLetters":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2753);
				value = value.replace("{0}", "1");
				break;
			case "Data Collection - Features":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(744);
				break;
			case "LandingPage_ContextMenu_LanguageIconText":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2891);
				break;
			case "Lbl_AssignedChecklist":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2558);
				break;
			case "Lbl_ParentProcessUpdateConfirmationMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1101);
				break;
			case "Associated control limit records will be impacted":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1129);
				break;
			case "lblWorkDashboard":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2421);
				break;
			case "lblError_TestCalculationPopUp":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1287);
				break;
			case "Static_xpathShift":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2651);
				break;
			case "ChecklistInCaps":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(127);
				break;
			case "lblEditSubGroup":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2366);
				break;
			case "lblDataTable":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1706);
				break;
			case "columnName_TimeZone":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1413);
				break;
			case "msg_ParentAndChildCantExistWithSameName":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2173);
				break;
			case "msg_CantBeAssignedAsParentProcess":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2465);

				value = value.replace("{0}", "<EntityName>");
				break;
			case "msg_ParentProcesslAlreadyContainsChildAsRemovedRecord":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2696);
				break;
			case "msg_ProcessCantBeRestoredUntilParentIsRestored":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2702);

				value = value.replace("{0}", "<ChildProcessName>");

				value = value.replace("{1}", "<ParentProcessName>");

				break;
			case "user":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(508);
				value = value.toLowerCase();
				break;
			case "MenuTemplateName_AlreadyExistAsRemoved":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2741);
				break;
			case "ParentProcessPopUp_CompanyDivisionCanNotSelect_Msg":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1100);
				break;
			case "ResponseGroupAlreadyExists":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2505);
				break;
			case "ChoiceAlreadyExists":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2506);
				break;
			case "AccessCodeIsIncorrect":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1000);
				break;
			case "AuthenticateWorkstation":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1002);
				break;
			case "PleaseEnterTheAccessCodeSentToYourEmailId":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1007);
				break;
			case "Permissions_Assign":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2911);
				break;
			case "DC_Config_Common_NotificationMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(258);
				break;
			case "ShowingResult_Lbl":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(717);

				value = value.replace("{0}",
						"<count>" + " " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(719));

				break;

			case "LanguagelabelsSavedSuccesssfullyMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2892);
				value = value.replace("{0}", "<languageLabel>");

				break;
			case "Lbl_SequenceRule":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(428);
				break;
			case "WorkStation_RemoteAuthentication":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2928);
				break;
			case "WorkStation_LocalAuthentication":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2927);
				break;
			case "Lbl_Notification":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(431);
				break;
			case "Lbl_PromptForSampleSize":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(432)

						+ " " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(255);

				break;
			case "Lbl_SampleTime":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(715);
				break;
			case "Lbl_RequiredInformation":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(962);
				break;
			case "Lbl_Application":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2761);
				break;
			case "Lbl_CodeType":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2920);
				break;
			case "Lbl_EventCode":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2917);
				break;
			case "Lbl_EventCodes":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2921);
				break;
			case "Error_NoAccess_DataEntry":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1304);

				value = value.replace("{0}", "<EntityName>");

				break;
			case "OneProcessSelectedMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1117);
				value = value.replace("{0}", "1");
				break;
			case "PartRecipe(s)SavedSuccessfullyMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(337);
				value = value.replace("{0}", "<OutputPart>");

				break;
			case "PartRecipes":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(739);
				break;
			case "CreatePartRecipe":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(217);
				break;
			case "SelectProcessModel":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(578);
				break;
			case "CreatePartRecipePageNoticiationMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(229);
				break;
			case "ProcessModelDoesntExist":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2553);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(67));

				break;

			case "EditTotalLicense_NotificationMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2914);
				break;
			case "License_ValidationMinCount":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2905);

				value = value.replace("{0}", "<count>");

				break;
			case "SelectPart&ItsRevisionToCopyPartRecipe(s)":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(582);
				break;
			case "AccordionItem_AssignedParameterSet":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1202);
				break;
			case "Production_Assignments":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2874);
				break;
			case "CreateProductionAssignment":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2939);
				break;
			case "EditProductionAssignment":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2946);
				break;
			case "ActiveAssignments":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2913);
				break;
			case "Assigments(Latest30Days)":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2955)

						+ " ("

						+ UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1094) + ")";

				break;
			case "OverlappingCombinationWillNotBeAllowed":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2952);

				value = value.replace("{0}", "<part lot combination>");

				break;
			case "ProductionAssignmentSavedSuccessfullyMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2951);
				value = value.replace("{0}", "<processName>");

				break;
			case "ProductionAssignmentDeleteConfirmationMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2979);
				value = value.replace("{0}", "<processName>");
				break;
			case "ProductionAssignmentDeletePopUpTitle":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2983)

				;

				value = value.replace("{0}", "<processName>");

				break;
			case "ProductionAssignmentDeleteSuccessfullyMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2980);
				value = value.replace("{0}", "<processName>");
				break;
			case "Lbl_EventCodeName":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2919);
				break;
			case "Lbl_ConfigureCodeTypes":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2940);
				break;
			case "LanguageLabelSavedSuccessfullyForCodeType":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2892);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2943));

				break;
			case "LanguageLabelSavedSuccessfullyForCode":

				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2892);

				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2936));

				break;
			case "Pareto":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1722);
				break;
			case "Hierarchy":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2599);
				break;
			case "Violation":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2600);
				break;
			case "CollectedDataType":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1481);
				break;
			case "CollectionName":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1482);
				break;
			case "EventCodeType":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2942);
				break;
			case "CollectedData":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(321);
				break;
			case "ProcessEvents":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2034);
				break;
			case "SubgroupData":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1092);
				break;
			case "undefined":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2024);

				break;
			case "ParetoChart":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1994);
				break;
			case "Select View Type":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1592);
				break;
			case "Graph":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1819);
				break;
			case "GraphAndReport":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1788);
				break;
			case "Report":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1789);
				break;
			case "Pieces":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2011);
				break;
			case "SIGL":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1801);
				break;
			case "Total":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(243);
				break;

			case "ToolTip_ControlLimitConfidenceInterval_Sigma":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1910);
				value = value + " = 1.632" + "\n" + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1909)
						+ " = 4.417";

				break;
			case "productionAssignment":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2925);
				break;
			case "PartNotExistsWithoutX":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(216);
				break;
			case "Company":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2601);
				break;
			case "ProductionAssignmentRemovalConfirmationMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2950);

				value = value.replace("{0}", "<PartLotName>");

				value = value.replace("{1}", "<StartEndTime>");

				break;
			case "ProductionAssignmentRemovalConfirmationMessageWithoutTime":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2957);

				value = value.replace("{0}", "<PartLotName>");

				break;
			case "ProductionAssignmentRemovalConfirmationMessageBlankRow":
				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(567);
				temp = temp.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2925));
				value = temp;
				break;
			case "ProductionAssignmentStartTimeCantGreaterMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2953);
				break;
			case "ProductionAssignment_AtLeastOneAssingmentMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2954);
				break;
			case "ProductionAssignment_RemovePopUp_Header":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2948);
				break;
			case "ConfigureFilters":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(709);
				break;
			case "PartActiveAssignment":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(68)

						+ " (" + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2913) + ")";

				break;
			case "LotActiveAssignment":

				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(192)

						+ " (" + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2913) + ")";

				break;
			case "Percent of Total (Count)":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2056);
				break;
			case "Pareto Chart":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1994);
				break;
			case "Chart Summary":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1601);
				break;
			case "Total Subgroups":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1811);
				break;
			case "Total Pieces":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1812);
				break;
			case "Date Range":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1813);
				break;
			case "Part(s)":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1814);
				break;
			case "Process(es)":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1815);
				break;
			case "Feature(s)":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1816);
				break;
			case "Total Events":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2422);
				break;
			case "Portuguese_Brazil":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(3042);
				break;
			case "Spanish_Spain":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(3045);
				break;
			case "Define Levels":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1591);
				break;
			case "No data to display. Please":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2301);
				break;
			case "select Parameter Set":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2302);
				break;
			case "Division":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2602);
				break;
			case "Region":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2603);
				break;
			case "Site":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2563);
				break;
			case "Department":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2604);
				break;
			case "Area":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(57);
				break;
			case "Process Unit":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2605);
				break;
			case "Process":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(194);
				break;
			case "Sub Process":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2606);
				break;
			case "No data to display":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2201);
				break;
			case "Please select a chart to view details":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1471);
				break;
			case "Select Level":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(129);
				break;
			case "Manual":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(951);
				break;
			case "EnterTag":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(456);
				break;
			case "TagValueCharacterLimitMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2373);
				value = value.replace("{0}", "<limit>");

				break;
			case "TagValueMaximumValueMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2374);
				break;
			case "errorMessage_AtLeastOneOutputMustBeDefinedWithoutMoreButton":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2745);
				break;

			case "Lot_DeleteConfirmation_Message":

				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(567);

				value = value.replace("{0}", "<Element Name>");

				value = value + "\n" + "\n" + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(557);
				break;

			case "ChangeHistory":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(3028);
				break;
			case "Assign/Unassign":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(3064);
				break;
			case "ChangeType":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(3031);
				break;
			case "Restore":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2219);
				break;
			case "Column_RecordDate":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(3029);
				break;
			case "ASCII_LABEL":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1521);
				break;
			case "PreviousValue":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(3041);
				break;
			case "LowerLSL":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(202);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(188));

				break;
			case "UpperUSL":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(201);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(184));

				break;
			case "Changes":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(3030);
				break;
			case "Collections":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2904);
				break;
			case "LowerToggleState":

				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(202);

				value = value.replace("{0}", "<limit>") + " "
						+ UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(3038);

				break;
			case "UpperToggleState":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(201);

				value = value.replace("{0}", "<limit>") + " "
						+ UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(3038);
				break;
			case "LowerLimit":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(202);

				value = value.replace("{0}", "<limit>");

				break;
			case "UpperLimit":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(201);

				value = value.replace("{0}", "<limit>");
				break;
			case "MAVLSC":
				value = "MAV" + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(519)

						+ " - " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(510);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(511));

				break;
			case "T1T2LSC":

				value = "T1T2" + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(519)

						+ " - " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(510);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(511));

				break;
			case "MAVUnitSameAsSpec":
				value = "MAV" + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(519) + " - "
						+ UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(509)

						+ UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(3039);

				break;
			case "T1T2UnitSameAsSpec":
				value = "T1T2" + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(519) + " - "
						+ UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(509)

						+ UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(3039);

				break;
			case "MAVUnit":

				value = "MAV" + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(519)

						+ " - " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(191);

				break;
			case "T1T2Unit":

				value = "T1T2" + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(519)

						+ " - " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(191);

				break;
			case "MaxGreaterUpper":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(802);
				break;
			case "MaxLessLower":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(804);
				break;
			case "MAVUpperToggleState":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(801)

						+ " " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(3038);// removed
																									// space
																									// at
																									// end

				break;
			case "MAVLowerToggleState":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(803)

						+ " " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(3038);// removed
																									// space
																									// at
																									// end

				break;
			case "MAVUpper":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(801);
				break;
			case "MAVLower":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(803);
				break;
			case "MAXBetweenT1T2Upper":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(808);
				value = value.replace("<sub>", "");
				value = value.replace("</sub>", "");

				break;
			case "MAXBetweenT1T2Lower":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(812);
				value = value.replace("<sub>", "");
				value = value.replace("</sub>", "");

				break;
			case "View_Limit_Page_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2799);
				break;
			case "Default Name":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2902);
				break;
			case "Message_RestoreConfirmation_WithoutAssociation_SpecLimit":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1986);
				value = value.replace("{0}", "<Element Name>");
				value = value.replace(" <br>", "\n");
				value = value.replace("<br>", "\n");
				value = value.replace("<br/>", "\n");

				break;

			case "Message_RestoreSuccess_SpecLimit":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1996);
				value = value.replace("{0}", "<Element Name>");

				break;
			case "Message_SpecAlreadyExistForGivenCombination":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2716);
				value = value.replace("{0} - {1} - {2}", "<Element Name>");

				break;
			case "BulkDeleteSubgroupData":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(3072);
				break;
			case "Prompt":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(3058);
				break;
			case "Prompt (Limited)":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(3059);
				break;
			case "No Prompt":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(3060);
				break;
			case "DataCollectionTypeCountMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1388);

				value = value.replace("{0}", "<count>");

				value = value.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2823));

				break;
			case "GaugeInterfaceNameAlreadyExists":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1548);
				break;
			case "GaugeInterfaceModifyMessageWhenDeviceIsAssociated":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1730)

						+ "\n" + "\n" + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1808);
				break;
			case "ViewGaugeDevice":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1888);
				break;
			case "ViewGaugeDevicePopUpMessageForSingleDevice":

				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(731);
				value = value.replace("{0}", "<Count>");

				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(4030);

				temp = temp.toLowerCase();

				value = value.replace("{1}", temp);

				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1528);
				temp = temp.replace("{0}", "<interfaceName>");

				value = temp + value;
				break;
			case "ViewGaugeDevicePopUpMessageForMultipleDevices":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(728);
				value = value.replace("{0}", "<Count>");

				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1728);

				value = value.replace("{1}", temp);
				value = value.toLowerCase();
				temp = value;
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1528);

				value = value.replace("{0}", "<interfaceName>");
				value = value + " " + temp;

				break;
			case "ViewGaugeFormat":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1527);
				break;
			case "ViewGaugeFormatPopUpMessageForSingleFormat":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(731);
				value = value.replace("{0}", "<Count>");

				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(4030);

				value = value.replace("{1}", temp);
				value = value.toLowerCase();
				temp = value;
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1528);

				value = value.replace("{0}", "<interfaceName>");
				value = value + " " + temp;

				break;
			case "ViewGaugeFormatPopUpMessageForMultipleFormat":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(728);

				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1577);

				value = value.replace("{1}", temp);
				value = value.toLowerCase();
				value = value.replace("{0}", "<Count>");
				temp = value;
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1528);

				value = value.replace("{0}", "<interfaceName>");
				value = value + " " + temp;

				break;
			case "EntityAlreadyExistMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(300);
				value = value.replace("{0}", "<Entity Name>");

				break;
			case "Permissions_Configure":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2926);
				break;

			case "Odd":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1765);
				break;
			case "Even":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1766);
				break;
			case "Space":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1768);
				break;
			case "Mark":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1767);
				break;
			case "XON/XOFF":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1777);

				break;
			case "CTS/RTS":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1778);
				break;
			case "RTS=off/DTR=on":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1779);
				break;

			case "View_Code_Types":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2918);
				break;
			case "Configure_Code_Types":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2940);
				break;
			case "ASCIICharacterValues":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1542);
				break;
			case "DataPurge":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(4008);
				break;
			case "AccordionItem_AssignedEventCodes":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(3010);
				break;
			case "RemoveConfirmationMessage_CodeTypeAssociatedWithEventCode":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(3009);

				value = value.replace("{0}", "<CodeTypeName>");
				break;
			case "Message_AtleastOneRequired":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(69)
						+ "XAt least 1 <entity> required.X";
				break;
			case "Entity_AlreadyExistAsRemoved":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1023);

				value = value.replace("{0}", "<EntityName>");
				break;
			case "ValidationForGaugeAgentGaugeInterfaceAndComPortCombination":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1883);
				break;
			case "SubValidationForGaugeAgentGaugeInterfaceAndComPortCombination":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1884);
				break;
			case "Less":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(824);
				break;
			case "LevelWithCount":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(3074);
				value = value.replace("{0}", "<Count>");

				break;
			case "Analysis":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2059);
				break;
			case "Data Management":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(4006);
				break;

			case "BasicInformation":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1316);
				break;
			case "Advanced":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1576);
				break;
			case "FormatDescription":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1630);
				value = value.toUpperCase();
				break;
			case "RecordDescription":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1605);
				value = value.toUpperCase();
				break;
			case "MultiFieldOutputSection":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1611);
				value = value.toUpperCase();
				break;

			case "Port_Initialization_String":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1503);
				break;
			case "Port_Termination_String":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1584);
				break;
			case "Delay(ms)":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1520);
				break;
			case "MDC_HelpSectionDefaultMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(313);
				value = value.replace("{0}", "<FeatureName>");
				value = value.replace("{1}", "<PartName>");

				break;
			case "OK":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(69) + "XOKX";
				break;
			case "GaugeIntefaceConnectionMsgForSingleGaugeDevice":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1725)
						+ ": <AgentName> - <InterfaceName> (<ComPortSetting>) ";

				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(731);
				temp = temp.replace("{0}", "<count>");

				temp = temp.replace("{1}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1505));
				temp = temp.toLowerCase();

				value = value + temp;

				break;
			case "ModifyingAGaugeInterfaceConnectionWillAffect2GaugeDevices":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1991);

				value = value.replace("{0}", "2");

				break;
			case "RawData":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1473);
				break;
			case "HexData":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2148);
				break;
			case "SpecialCharacters":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2154);
				break;
			case "CarriageReturn":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2150);
				break;
			case "LineFeed":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2151);
				break;
			case "SerialDataMonitor":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2146);
				break;
			case "Compliance":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2622);
				break;
			case "StreamSummary":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2022);
				break;
			case "ControlCharts":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1718);
				break;
			case "NetContent":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2434);
				break;
			case "Within":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1985);
				break;
			case "Deviation":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2435);
				break;

			case "MDC_DefectiveCount":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(3033);
				value = value.replace("{0}", "<Count>");
				break;
			case "MDC_DefectiveViolationHeader":
				value = "X" + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(3034) + "X";
				value = value.replace("{0} - {1}", "<PartFeatureName>");
				break;
			case "MDC_AddLotDetails_SubHeading":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(3078);
				value = value.replace("{0}", "<partName>");
				break;

			case "MDC_Piece_Info":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(312);
				value = value.replace("{0}", "<PieceNo>");
				value = value.replace("{1}", "<Total>");
				break;
			case "MDC_PieceNumber":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(360);
				value = value.replace("{0}", "<PieceNo>");
				break;
			case "MDC_LotIsUnavailable":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(3086);
				break;
			case "MDC_TotalCount_SummaryHeader":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(239);
				value = value.replace("{0}", "<FeatureName>");
				break;
			case "MDC_TotalCount":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(243) + " : <count>";
				break;
			case "ValidationForGaugeAgentGaugeInterfaceComPortCombinationAndGaugeFormat":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1880);
				break;

			case "Gauge_Agent":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2074);
				break;
			case "Process_Name":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(240);
				break;
			case "ProcessView_PopUp_Header":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(731);

				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(194);

				value = value.replace("{1}", temp);

				value = value.toLowerCase();
				value = value.replace("{0}", "<Count>");
				temp = value;

				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1505) + ": <GaugeDeviceName> "
						+ temp;

				break;
			case "ProcessView_PopUp_Header_For_Multiple_Process":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(728);

				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1080);

				value = value.replace("{1}", temp);
				value = value.toLowerCase();
				value = value.replace("{0}", "<Count>");

				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1505);
				value = temp + ": <GaugeDeviceName> " + value;
				break;
			case "Compliance_Values_Heading":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2622)

						+ " (" + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2564) + ")";

				break;
			case "ComplianceDataCollections_Heading":

				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2622)

						+ " (" + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(732) + ")";
				break;

			case "DeleteConfirmaitonMessageWhenProcessAssociationWillNotRemove":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2005);
				break;
			case "DeleteConfirmaitonMessageWhenProcessIsNotAssociate":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2006);
				break;
			case "DeleteConfirmaitonMessageWithAssociationswithDC":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(567) + "\n\n";

				value = value.replace("{0}", "<Element Name>");

				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(4125);

				value = value + temp;

				break;
			case "AccordionItem_AssignedDC":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2300);
				break;
			case "Received":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2624);
				break;
			case "Gauge Initialization String":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1638);
				break;
			case "Measurement Initialization String":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1640);
				break;
			case "Measurement Start String":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1642);
				break;
			case "Measurement End String":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1644);
				break;
			case "Measurement Read String":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1646);
				break;
			case "Measurement Post String":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1648);
				break;
			case "Measurement Request String":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1650);
				break;
			case "Data Collection Start String":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1652);
				break;
			case "Data Collection End String":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1654);
				break;
			case "GaugeFormatNameAlreadyExists":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1609);
				break;
			case "0 - ASCII/Text":
				value = "0 - " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1632);
				break;
			case "1 - ASCII (16 bit)":
				value = "1 - " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1633);
				break;
			case "2 - Binary (LSByte First)":
				value = "2 - " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1634);
				break;
			case "3 - Binary (MSByte First)":
				value = "3 - " + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1635);
				break;
			case "GaugeMultiFieldValidation":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(69)
						+ "XItem is improperly configured in multi field output section grid.X";
				break;
			case "EditGaugeFormatConfirmaitonMessageWhenAttachedToGaugeDevice":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(69)

						+ "\n" + "\n" + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1808)
						+ "XModifying a gauge format will affect all the gauge devices using this gauge format.X" + "\n"
						+ "\n" + "XDo you still want to continue?X";
				break;
			case "ViewGaugeDevicePopUpForGaugeFormat":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(731);
				value = value.replace("{0}", "<Count>");

				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(4030);

				value = value.replace("{1}", temp);

				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(69)
						+ "XGauge Format: <formatName>X x(1 xgauge devicex exists.)x";
				break;
			case "removeGaugeFormatConfirmaitonMessageWhenAttachedToGaugeDevice":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(567) + "\n" + "\n";
				value = value.replace("{0}", "<formatName>");

				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2025);

				temp = temp.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1504));
				temp = temp.toLowerCase();

				value = value + temp;

				break;

			case "AssociationMessage_RemovedSingleGaugeDevice":

				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2027) + " (1)";
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1505));

				break;
			case "GaugeFormatTesting_TestText":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1619)

				;
				break;
			case "GaugeFormatTesting_TestingArea":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1620)

				;
				break;
			case "Field# = ":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(69) + "XFieldX# =";
				break;
			case "Start Position = ":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1614) + " =";
				break;
			case "Length = ":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1615) + " =";
				break;

			case "ManufacturingLimitViolation":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(4126);
				break;

			case "WorkFlow_Header_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(4022);
				break;
			case "Lbl_WorkflowName":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(4028);
				break;
			case "CreateWorkFlow_Page_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(4027);
				break;
			case "Lbl_EventCategory":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(4071);
				break;
			case "Msg_WorkFlow_CodeTypehaveAtleastOneEventCode":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(4065);
				break;
			case "Msg_WorkFlow_AtLeastOneCodeTypeInOptionalRequiredPanel":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(4064);
				break;

			case "WorkFlow_Status_Active":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(451);
				break;
			case "WorkFlow_Status_Inactive":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(421);
				break;
			case "WorkFlow_Status_Disabled":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(4074);
				break;
			case "columnName_WorkflowName":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(4028);
				break;
			case "WorkFlowAssignment_Header_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(4023);
				break;
			case "CreateWorkFlowAssignment_Page_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(4075);
				break;
			case "EditWorkFlowAssignment_Page_Title":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(4104);
				break;
			case "URL_CreateProcessingTemplatePageHelpLink":
				value = "ProcessingTemplates/CreatingProcessingTemplates.htm";
				break;
			case "URL_EditProcessingTemplatePageHelpLink":
				value = "ProcessingTemplates/EditingProcessingTemplates.htm";
				break;
			case "SystemAlerts":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(3016);
				break;

			case "AccessCode":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1006);

				break;
			case "DataView":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1450);
				break;

			case "CL":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1437);
				break;
			case "UCL":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1436);
				break;
			case "LCL":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1438);
				break;

			case "Histogram Chart":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1564);
				break;

			case "Maximum Value":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1909);
				break;

			case "Minimum Value":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1910);
				break;

			case "Mean":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1699);
				break;

			case "Mean - 3SD (lt)":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1912);
				break;

			case "Mean + 3SD (lt)":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1919);
				break;

			case "Short term SD":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1913);
				break;

			case "Long term SD":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1914);
				break;

			case "Robustness":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1915);
				break;

			case "CoVar":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1916);
				break;

			case "Z-bench":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1917);
				break;

			case "Target ratio":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1918);
				break;

			case "Specification":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1895);
				break;

			case "Z USL":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1923);
				break;

			case "Z Target":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1924);
				break;

			case "Z LSL":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1925);
				break;

			case "Actual Above":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1926);
				break;

			case "Actual Below":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1927);
				break;

			case "Actual Total":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1928);
				break;

			case "Actual PPM":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1929);
				break;

			case "Expected Above":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1930);
				break;

			case "Expected Below":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1931);
				break;

			case "Expected Total":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1932);
				break;

			case "Expected PPM":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1933);
				break;

			case "Potential Indices":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1898);
				break;

			case "Cp":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1961);
				break;

			case "Cr (1/Cp)":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1962);
				break;

			case "Pp":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1963);
				break;
			case "Pr (1/Pp)":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1964);
				break;

			case "Performance Indices":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1899);
				break;

			case "Cpk":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1965);
				break;
			case "Cpk Upper":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1966);
				break;

			case "Cpk Lower":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1967);
				break;

			case "Cpm":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1968);
				break;

			case "SIGL (st)":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1969);
				break;

			case "Ppk":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1970);
				break;

			case "Ppk Upper":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1971);
				break;

			case "Ppk Lower":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1972);
				break;

			case "Ppm":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1973);
				break;

			case "SIGL (lt)":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1974);
				break;

			case "Moments of Distribution":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1901);
				break;

			case "Avg Deviation":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1956);
				break;

			case "Std Deviation":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1957);
				break;

			case "Variance":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1958);
				break;

			case "Skewness":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1959);
				break;

			case "Kurtosis":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1960);
				break;

			case "Chi squared Goodness of Fit":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1902);
				break;
			case "Chi-Squared":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2447);
				break;

			case "DF":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2448);
				break;

			case "Chi Sq Prob":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2449);
				break;

			case "Analysis of Variance":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1903);
				break;

			case "d.f":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1987);
				break;
			case "Plot Point Value":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1475);
				break;

			case "French - France":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(4096);
				break;

			case "ExclusionRule":

				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1617);
				break;
			case "EntryMethodGDErrorMessage":

				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2337);
				value = value.replace("{0}", "<Element Name>");
				break;

			case "ValidationForMultifieldSelectSendBox":

				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2565);
				break;
			case "ValidationForMultifieldNumericSelect":

				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2261);
				break;
			case "ValidationForGaugeDeviceGaugeAgentGaugeInterfaceComPortCombination":

				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(3050);
				break;
			case "DeleteConfirmaitonMessageWithAssociationsForGaugeInterfaceForNonRemovableGD":

				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2051);
				value = value.replace("{0}",

						UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1500));

				break;
			case "AccordionItem_AssignedNonRemovableGaugeFormat":

				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2030);
				break;
			case "AccordionItem_AssignedNonRemovableGaugeDevice":

				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2029);
				break;
			case "port_Initialization_String":

				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1503);

				break;
			case "delay(ms)":

				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1520);
				break;
			case "exclude":

				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1462);
				break;

			case "include":

				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1461);
				break;
			case "SubGroupSize":

				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1432);
				break;
			case "Defectives":

				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1955);
				break;
			case "Defects":

				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1532);
				break;
			case "Spec_Limit_Value":

				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(4030);
				break;
			case "< [Field]":

				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2414);
				break;

			case "<= [Field]":

				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2416);
				break;
			case "<> [Field]":

				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2412);
				break;
			case "= [Field]":

				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2411);
				break;
			case "> [Field]":

				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2413);
				break;
			case ">= [Field]":

				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2415);
				break;
			case "Contains":

				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2417);
				break;
			case "Dashboard_Header_Title_Spanish":

				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(66);
				break;
			case "Send":

				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2149);
				break;
			case "ColumnName_Reason":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(4002);
				break;
			case "ColumnName_Assigned_Work_Dashboard":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2228);
				break;
			case "ColumnName_Assigned_License":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(570);
				break;
			case "Date":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(4083);
				break;
			case "MostRecentRecord":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2632);
				break;
			case "Static_xpathDCType":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(3067);
				break;

			case "ProcessInformation":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2924);
				break;
			case "EventReviews":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(4109);
				break;
			case "EventDetails":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2931);

				break;
			case "label_SelectEventCodeType":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(4110);
				break;
			case "label_AddEventCode":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(4111);
				break;
			case "ProcessCantBeRemovedAsItIsAssignedToUser(s)OrWorkstation(s)":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(3088);
				value = value.replace("{0}", "<Process Name>");
				break;
			case "MDC_PartPopUp_SelectThePartMakingFromOD":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2045);
				value = value.replace("{0}", "<ODName>");
				break;

			case "MDC_ProcessPopUp_SelectTheProcessForOP":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2048);
				value = value.replace("{0}", "<OpName>");
				break;

			case "Restore Manufacturing Limit":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1922);
				break;
			case "DatCollectionType_Exclude":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1460);
				value = value.replace("{0}", UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(3068));
				value = value.replace("{1}", UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1462));
				break;

			case "DataCollectionTypes":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(3068);
				break;
			case "Day":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(766);
				break;

			case "UserReactivationConfirmationMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(3098);
				break;

			case "UserReactivationConfirmationMessageWithSingleReason":

				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(3098)

						+ "\n" + "\n"

						+ UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(3099);

				value = value.replace("<i>", "");
				value = value.replace("</i>", "");

				value = value.replace("{0}", "<UserFullName>");
				value = value.replace("{1}", "<DateTimeStamp>");
				value = value.replace("{2}", "<ReasonName>");

				break;

			case "NoRecentLogins":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(4005);
				break;

			case "ReActivationSuccessMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(4001);
				value = value.replace("{0}", "<UserFullName>");

				break;
			case "In":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2335);
				break;
			case "msg_bulkDeleteSubgroupDataSuccess":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(3090);
				value = value.replace("{0}", "<entityTime>");

				break;
			case "Above USL":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1842);
				break;

			case "Language_labels_of_process_state(s)_saved_successfully":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2892);
				value = value.replace("{0}", UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2908));
				break;
			case "ViewReport":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1597);
				break;
			case "ControlChart":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1445);
				break;
			case "Collection":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2883);
				break;
			case "OOS":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1799);
				break;
			case "OOC":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2179);
				break;
			case "Piece Number":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1694);
				break;
			case "User":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(508);
				break;
			case "Time Stamp":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1693);
				break;
			case "NoItemsFound":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2457);
				break;
			case "Label_All":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1711);
				break;
			case "ConfirmationMessageForLicenseAssignment":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(4095);
				break;
			case "EmailForDueReminderForDC":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2078);
				break;
			case "EmailForLateReminderForDC":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(3003);
				break;
			case "EmailForMissedReminderForDC":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(3004);
				break;
			case "EmailForManufactoringLimitViolationForDC":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2999);
				break;
			case "Values":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2564);
				break;
			case "CodeType_Camera":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(4145);
				break;
			case "Danish - Denmark":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(4179);
				break;
			case "Swedish - Sweden":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(4180);
				break;
			case ">USL":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1976);
				break;
			case "CodeList":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(4195);
				break;
			case "CodeGridIncrement":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(4197);
				break;
			case "CodeGridNumeric":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(4198);
				break;
			case "RequireCodeforEachPiece":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(4196);
				break;
			case "BoxAndWhiskerChart":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1568);
				break;
			case "Box&WhiskerChart":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1581);
				break;
			case "Lbl_SubgroupLabelGroups":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(4184);
				break;

			case "ManageLicenseReport":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(4147);

				break;
			case "Lbl_Comments":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1533);
				break;
			case "Lbl_Comment":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2504);
				break;
			case "Lbl_UpdatedBy":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(135);
				break;
			case "msg_SelectProcessToCopyOperationAssociations":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(4231);
				break;
			case "DCTypesSavedSuccessfully":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(4214);
				break;

			case "ProcessModel_DeleteConfirmaitonMessageWithAssociations":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(674);
				break;
			case "OD_Del_Cnf_Msg_WithAssociations":
				temp = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(673);
				temp = temp.replace("{0}", "<Element Name>");
				value = temp + "\n" + "\n" + UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(674);
				break;
			case "EmailForEnact_Checklist_Violation":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(3002);

				break;

			case "EmailForEnact_Checklist_Due":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(4174);

				break;

			case "CheckList_Events":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2889);
				break;

			// No Record found - without altering the case
			// email for missed checklist
			case "EmailForEnact_Checklist_Missed":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(4177);
				break;
			// email for late checklist
			case "EmailForEnact_Checklist_Late":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(4176);
				break;

			// No Record found - without altering the case
			case "msg_NoRecordFoundMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(65);
				break;

			// XOne or more xfeaturesx do not exist. Please modify the Parameter Set.X
			case "msg_ModifyParameterSet":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2400);
				temp = temp.replace("{0}", "<Element Name>");

				break;

			case "Lbl_SelectDashboard":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1708);
				break;

			case "Lbl_Dashboards":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(3056);
				break;

			case "Lbl_Dashboard":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(130);
				break;

			case "msg_LanguageLabelSavedSuccessfullyForDashboards":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2892);
				value = value.replace("{0}", UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(3056));

				break;
			// features
			case "lbl_Features":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(80);
				break;

			// processes
			case "lbl_Processes":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(237);
				break;

			// parts
			case "lbl_Parts":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(76);
				break;

			// codes
			case "lbl_Codes":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(843);
				break;
			// "Enact":
			case "Enact":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(4124);
				break;
			// start window
			case "lbl_StartWindow":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(3061);
				break;

			// start window
			case "lbl_EndWindow":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(3062);
				break;

			// >UCL
			case "lbl_GreaterThanSymUCL":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2263);
				break;

			case "DC_SubgroupLabelGroup_ChkBoxLabel":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(4194);
				break;

			case "Maximumlimit":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(4009);
				value = value.replace("{0}", "<count>");
				break;

			case "Lbl_ActivationDetails":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(419);
				break;
			case "Workflow":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(4016);
				break;

			// Selected password cannot be reused before <<30>> days
			case "msg_ProhibitPasswordReuseMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1563);
				value = value.replace("{0}", "<DaysCount>");
				break;

			// Data Summary
			case "lbl_DataSummaryTile":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1453);
				break;

			// Subgroups
			case "lbl_Subgroups":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2654);
				break;

			// LSL
			case "lbl_LSL":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(188);
				break;

			// USL
			case "lbl_USL":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(184);
				break;

			// USL
			case "lbl_OOS":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1799);
				break;

			// NCC
			case "lbl_NCC":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1685);
				break;

			// Yield
			case "lbl_Yield":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1894);
				break;

			case "StreamAnalysisTable":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2809);
				break;
			case "ProcessesSelected":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2910);
				value = value.replace("{0}", "<Count>");

				break;
			// Remove confirmation message for Workflow assignment
			case "msg_RemovethisWorkflowAssignmentConfirmationMessage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(4101);
				break;
			// Remove Workflow assignment confirmation pop up title
			case "lbl_RemoveWorkflowAssignmentPopupTitle":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(4102);
				break;
			// Workflow assignment removed successfully
			case "msg_WorkflowassignmentRemovedSuccessfully":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(4103);
				break;

			case "msg_AddCommentSuccessfully":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2278);
				value = value.replace("{0}", UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2504));
				break;
			case "ColumnName_SDST":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2295);
				break;
			case "ColumnName_SDLT":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2296);
				break;
			case "ColumnName_SubgroupCount":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2837);
				break;
			case "ColumnName_PieceCount":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2838);
				break;
			case "ColumnName_LSLZ":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2839);
				break;
			case "ColumnName_USLZ":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2840);
				break;
			case "ColumnName_Weighted_FractionLessThanLSL":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2841);
				break;
			case "ColumnName_Weighted_FractionGrtThanUSL":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2842);
				break;
			case "ColumnName_FractionLessThanLSL":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2424);
				break;
			case "ColumnName_FractionGrtThanUSL":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2425);
				break;
			case "ColumnName_PDPM":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1672);
				break;
			case "ColumnName_Yield":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1894);
				break;
			case "ColumnName_SpecZ":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2843);
				break;
			case "ColumnName_Weighted_Fraction_OOS":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2844);
				break;
			case "ColumnName_Fraction_OOS":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2845);
				break;
			case "ColumnName_Grade":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2846);
				break;
			case "ColumnName_Expected_Yield":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2848);
				break;
			case "ColumnName_Yield_Performance":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2849);
				break;
			case "ColumnName_Percentage":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2850);
				break;
			case "ColumnName_DPM":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1673);
				break;

			case "NotificationRules_StatusTabHeadingForChecklists":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2613);
				break;
			case "lbl_Low":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2857);
				break;
			case "lbl_High":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2855);
				break;
			case "lbl_NotifiationCategory":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(1716);
				break;
			case "lbl_SDST":
				value = UtilityFunctions.getValueOnBasisOfUserPrefferedLanguageAndKey(2459);
				break;
			}

		} catch (

		Exception e) {
			e.printStackTrace();
		}
		return value;
	}
}
