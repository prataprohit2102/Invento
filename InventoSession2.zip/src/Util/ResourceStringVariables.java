package Util;

public class ResourceStringVariables {
	public static String rs_lbl_BackButton, rs_lbl_EarlyReminder, rs_lbl_ColumnName_DataCollection, rs_lbl_Due;

	public static String rs_lbl_ColumnName_SDST, rs_lbl_ColumnName_SDLT, rs_lbl_ColumnName_LSL, rs_lbl_ColumnName_USL,
			rs_lbl_ColumnName_SubgroupCount, rs_lbl_ColumnName_LSLZ, rs_lbl_ColumnName_USLZ,
			rs_lbl_ColumnName_Weighted_FractionLessThanLSL, rs_lbl_ColumnName_Weighted_FractionGrtThanUSL,
			rs_lbl_ColumnName_FractionLessThanLSL, rs_lbl_ColumnName_PieceCount, rs_lbl_Cpk, rs_lbl_Cp, rs_lbl_Ppk;

	public static String rs_lbl_ColumnName_FractionGrtThanUSL, rs_lbl_ColumnName_PDPM, rs_lbl_ColumnName_Yield,
			rs_lbl_ColumnName_SpecZ, rs_lbl_ColumnName_Weighted_Fraction_OOS, rs_lbl_ColumnName_Fraction_OOS,
			rs_lbl_ColumnName_Grade, rs_lbl_ColumnName_Expected_Yield, rs_lbl_ColumnName_Yield_Performance,
			rs_lbl_ColumnName_Percentage, rs_lbl_ColumnName_DPM;

	public static String rs_msg_OD_Del_Cnf_Msg_WithAssociations, rs_msg_RemovedSuccessfullyMessage,
			rs_lbl_RemoveEntityPopupTitle, rs_lbl_Process_Name, msg_ModifyParameterSet, lbl_Features, lbl_Processes,
			lbl_WorkflowName, lbl_Active, rs_lbl_ProductionAssignment, lbl_SelectDashboard, rs_lbl_GreaterThanSymUCL,
			rs_lbl_RemoveWorkflowAssignmentPopupTitle, rs_msg_RemovethisWorkflowAssignmentConfirmationMessage,
			rs_msg_WorkflowassignmentRemovedSuccessfully, rs_msg_LanguageLabelSavedSuccessfullyForDashboards,
			rs_msg_AddCommentSuccessfully;

	public static String rs_lbl_ProcessInformation, rs_lbl_StreamAnalysisTable, rs_lbl_ProcessesSelected,
			rs_lbl_Aggregated, rs_lbl_Raw, rs_lbl_StreamSummary, rs_lbl_ColumnName_Category, rs_lbl_ColumnName_Process,
			rs_lbl_ColumnName_Part, rs_lbl_ColumnName_Feature, rs_lbl_ColumnName_Shift, rs_lbl_ColumnName_Lot,
			rs_lbl_DataSummaryTile, rs_Label_Delete;
			
	public static String rs_lbl_Parts, rs_lbl_Codes;

	public static String rs_lbl_EnglishUS, rs_lbl_EnglishUK, rs_lbl_France, rs_lbl_Germany, rs_lbl_Spanish,
			rs_lbl_Vietnamese, rs_lbl_Spanish_Spain, rs_lbl_Portuguese_Brazil, rs_lbl_Danish_Denmark,
			rs_lbl_Swedish_Sweden;

	public static String rs_lbl_ColumnName_Mean;

	public static void resetResourceStringVariables() {
		rs_lbl_BackButton = UtilityFunctions.getMultilingualData("BackButton");
		rs_lbl_EarlyReminder = UtilityFunctions.getMultilingualData("EarlyReminder");

		// XData CollectionX
		rs_lbl_ColumnName_DataCollection = UtilityFunctions.getMultilingualData("ColumnName_DataCollection");
		rs_lbl_Due = UtilityFunctions.getMultilingualData("Due");

		// Process model
		rs_msg_OD_Del_Cnf_Msg_WithAssociations = UtilityFunctions
				.getMultilingualData("OD_Del_Cnf_Msg_WithAssociations");
		rs_msg_RemovedSuccessfullyMessage = UtilityFunctions.getMultilingualData("RemovedSuccessfullyMessage");
		rs_lbl_RemoveEntityPopupTitle = UtilityFunctions.getMultilingualData("RemoveEntityPopupTitle");

		rs_lbl_Process_Name = UtilityFunctions.getMultilingualData("Process_Name");
		msg_ModifyParameterSet = UtilityFunctions.getMultilingualData("msg_ModifyParameterSet");
		lbl_Features = UtilityFunctions.getMultilingualData("lbl_Features");
		lbl_Processes = UtilityFunctions.getMultilingualData("lbl_Processes");
		rs_lbl_Parts = UtilityFunctions.getMultilingualData("lbl_Parts");
		rs_lbl_Codes = UtilityFunctions.getMultilingualData("lbl_Codes");
		lbl_WorkflowName = UtilityFunctions.getMultilingualData("Lbl_WorkflowName");
		lbl_Active = UtilityFunctions.getMultilingualData("Active");
		rs_lbl_ProductionAssignment = UtilityFunctions.getMultilingualData("productionAssignment");
		// Dashboard tiles
		rs_lbl_ProcessInformation = UtilityFunctions.getMultilingualData("ProcessInformation");
		rs_lbl_StreamAnalysisTable = UtilityFunctions.getMultilingualData("StreamAnalysisTable");
		rs_lbl_StreamSummary = UtilityFunctions.getMultilingualData("StreamSummary");

		// My processes responsibility
		rs_lbl_ProcessesSelected = UtilityFunctions.getMultilingualData("ProcessesSelected");

		// Aggregate Dashboard
		rs_lbl_Aggregated = UtilityFunctions.getMultilingualData("Aggregated");
		rs_lbl_ColumnName_Category = UtilityFunctions.getMultilingualData("ColumnName_Category");
		// Raw Dashboard
		rs_lbl_Raw = UtilityFunctions.getMultilingualData("Raw");
		lbl_SelectDashboard = UtilityFunctions.getMultilingualData("Lbl_SelectDashboard");
		rs_lbl_RemoveWorkflowAssignmentPopupTitle = UtilityFunctions
				.getMultilingualData("lbl_RemoveWorkflowAssignmentPopupTitle");
		rs_msg_RemovethisWorkflowAssignmentConfirmationMessage = UtilityFunctions
				.getMultilingualData("msg_RemovethisWorkflowAssignmentConfirmationMessage");
		rs_msg_WorkflowassignmentRemovedSuccessfully = UtilityFunctions
				.getMultilingualData("msg_WorkflowassignmentRemovedSuccessfully");
		rs_msg_LanguageLabelSavedSuccessfullyForDashboards = UtilityFunctions
				.getMultilingualData("msg_LanguageLabelSavedSuccessfullyForDashboards");
		rs_msg_AddCommentSuccessfully = UtilityFunctions.getMultilingualData("msg_AddCommentSuccessfully");

		// language name settings
		rs_lbl_EnglishUS = UtilityFunctions.getMultilingualData("English - US");
		rs_lbl_EnglishUK = UtilityFunctions.getMultilingualData("English - UK");
		rs_lbl_France = UtilityFunctions.getMultilingualData("French - France");
		rs_lbl_Germany = UtilityFunctions.getMultilingualData("German - Germany");
		rs_lbl_Spanish = UtilityFunctions.getMultilingualData("Spanish - Mexico");
		rs_lbl_Vietnamese = UtilityFunctions.getMultilingualData("Vietnamese - Vietnam");
		rs_lbl_Spanish_Spain = UtilityFunctions.getMultilingualData("Spanish_Spain");
		rs_lbl_Portuguese_Brazil = UtilityFunctions.getMultilingualData("Portuguese_Brazil");
		rs_lbl_Danish_Denmark = UtilityFunctions.getMultilingualData("Danish - Denmark");
		rs_lbl_Swedish_Sweden = UtilityFunctions.getMultilingualData("Swedish - Sweden");

		// Aggregate Dashboard Stream analysis tile column name entry
		rs_lbl_Cpk = UtilityFunctions.getMultilingualData("Cpk");
		rs_lbl_Cp = UtilityFunctions.getMultilingualData("Cp");
		rs_lbl_Ppk = UtilityFunctions.getMultilingualData("Ppk");
		rs_lbl_ColumnName_SDST = UtilityFunctions.getMultilingualData("ColumnName_SDST");
		rs_lbl_ColumnName_SDLT = UtilityFunctions.getMultilingualData("ColumnName_SDLT");
		rs_lbl_ColumnName_SubgroupCount = UtilityFunctions.getMultilingualData("ColumnName_SubgroupCount");
		rs_lbl_ColumnName_PieceCount = UtilityFunctions.getMultilingualData("ColumnName_PieceCount");
		rs_lbl_ColumnName_LSLZ = UtilityFunctions.getMultilingualData("ColumnName_LSLZ");
		rs_lbl_ColumnName_USLZ = UtilityFunctions.getMultilingualData("ColumnName_USLZ");
		rs_lbl_ColumnName_Weighted_FractionLessThanLSL = UtilityFunctions
				.getMultilingualData("ColumnName_Weighted_FractionLessThanLSL");
		rs_lbl_ColumnName_Weighted_FractionGrtThanUSL = UtilityFunctions
				.getMultilingualData("ColumnName_Weighted_FractionGrtThanUSL");
		rs_lbl_ColumnName_FractionLessThanLSL = UtilityFunctions.getMultilingualData("ColumnName_FractionLessThanLSL");
		rs_lbl_ColumnName_FractionGrtThanUSL = UtilityFunctions.getMultilingualData("ColumnName_FractionGrtThanUSL");
		rs_lbl_ColumnName_PDPM = UtilityFunctions.getMultilingualData("ColumnName_PDPM");
		rs_lbl_ColumnName_Yield = UtilityFunctions.getMultilingualData("ColumnName_Yield");
		rs_lbl_ColumnName_SpecZ = UtilityFunctions.getMultilingualData("ColumnName_SpecZ");
		rs_lbl_ColumnName_Weighted_Fraction_OOS = UtilityFunctions
				.getMultilingualData("ColumnName_Weighted_Fraction_OOS");
		rs_lbl_ColumnName_Fraction_OOS = UtilityFunctions.getMultilingualData("ColumnName_Fraction_OOS");
		rs_lbl_ColumnName_Grade = UtilityFunctions.getMultilingualData("ColumnName_Grade");
		rs_lbl_ColumnName_Expected_Yield = UtilityFunctions.getMultilingualData("ColumnName_Expected_Yield");
		rs_lbl_ColumnName_Yield_Performance = UtilityFunctions.getMultilingualData("ColumnName_Yield_Performance");
		rs_lbl_ColumnName_Percentage = UtilityFunctions.getMultilingualData("ColumnName_Percentage");
		rs_lbl_ColumnName_DPM = UtilityFunctions.getMultilingualData("ColumnName_DPM");
		rs_lbl_GreaterThanSymUCL = UtilityFunctions.getMultilingualData("lbl_GreaterThanSymUCL");
		
		rs_lbl_ColumnName_LSL = UtilityFunctions.getMultilingualData("ColumnName_LSL");
		rs_lbl_ColumnName_USL = UtilityFunctions.getMultilingualData("ColumnName_USL");
		rs_lbl_ColumnName_Mean = UtilityFunctions.getMultilingualData("Mean");
		rs_lbl_ColumnName_Process = UtilityFunctions.getMultilingualData("ColumnName_Process");
		rs_lbl_ColumnName_Part = UtilityFunctions.getMultilingualData("ColumnName_Part");
		rs_lbl_ColumnName_Feature = UtilityFunctions.getMultilingualData("ColumnName_Feature");
		rs_lbl_ColumnName_Shift = UtilityFunctions.getMultilingualData("ColumnName_Shift");
		rs_lbl_ColumnName_Lot = UtilityFunctions.getMultilingualData("ColumnName_Lot");
		rs_lbl_DataSummaryTile = UtilityFunctions.getMultilingualData("lbl_DataSummaryTile");
		rs_Label_Delete = UtilityFunctions.getMultilingualData("Lable_Delete");
	}

}
