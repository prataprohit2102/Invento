package Util;

import java.io.*;
import java.util.Calendar;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFCreationHelper;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFHyperlink;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.xmlbeans.impl.values.XmlValueDisconnectedException;

public class ExcelUtility {
	public String path;
	public FileInputStream fis = null;
	public FileOutputStream fileOut = null;
	public XSSFWorkbook workbook = null;
	public XSSFSheet sheet = null;
	public XSSFRow row = null;
	public XSSFCell cell = null;

	// Test data config sheet row column values and their names
	public static final int CONFIG_VALUE_COLUMN = 2;
	public static final int CONFIG_TestSiteURL_ROW = 1;
	public static final int CONFIG_UserName_ROW = 2;
	public static final int CONFIG_Password_ROW = 3;
	public static final int CONFIG_CompanyID_ROW = 4;
	public static final int CONFIG_Browser_ROW = 5;
	public static final int CONFIG_Device_ID_ROW = 6;
	public static final int CONFIG_DatabaseUrl_ROW = 7;
	public static final int CONFIG_DatabaseUserName_ROW = 8;
	public static final int CONFIG_DatabasePassword_ROW = 9;
	public static final int CONFIG_DatabaseName_ROW = 10;
	public static final int CONFIG_DataBaseBackUP_ROW = 11;
	public static final int CONFIG_NumberOfRecordsInGenericData_ROW = 12;
	public static final int CONFIG_UserEmail_ROW = 13;
	public static final int CONFIG_NumberOfCIParallelExecution_ROW = 14;
	// Email details row numbers
	public static final int CONFIG_SendGridHostName_ROW = 1;
	public static final int CONFIG_SendGridPortNumber_ROW = 2;
	public static final int CONFIG_SendGridPassword_ROW = 4;
	public static final int CONFIG_SendGridUserName_ROW = 3;
	public static final int CONFIG_FromMailUser_ROW = 5;
	public static final int CONFIG_RecipientsList_ROW = 6;
	public static final int CONFIG_UserPrefferedLanguage_Row = 15;
	public static final int CONFIG_DeploymentName_ROW = 7;
	public static final String CONFIG_UserEmail = "UserEmail";
	public static final String CONFIG_TestSiteURL = "TestSiteURL";
	public static final String CONFIG_UserName = "UserName";
	public static final String CONFIG_Password = "Password";
	public static final String CONFIG_CompanyID = "CompanyID";
	public static final String CONFIG_Browser = "Browser";
	public static final String CONFIG_Device_ID = "Device ID";
	public static final String CONFIG_DatabaseUrl = "DatabaseUrl";
	public static final String CONFIG_DatabaseUserName = "DatabaseUserName";
	public static final String CONFIG_DatabasePassword = "DatabasePassword";
	public static final String CONFIG_DatabaseName = "DatabaseName";
	public static final String CONFIG_DataBaseBackUP = "DataBase BackUP";
	public static final String CONFIG_NumberOfRecordsInGenericData = "NumberOfRecordsInGenericData";
	public static final String CONFIG_NumberOfCIParallelExecution = "NumberOfCIParallelExecution";
	public static final String CONFIG_UserPrefferedLanguage = "UserPrefferedLanguage";

	// Email details
	public static final String CONFIG_SendGridHostName = "SendGridHostName";
	public static final String CONFIG_SendGridPortNumber = "SendGridPortNumber";
	public static final String CONFIG_SendGridPassword = "SendGridPassword";
	public static final String CONFIG_SendGridUserName = "SendGridUserName";
	public static final String CONFIG_FromMailUser = "FromMailUser";
	public static final String CONFIG_RecipientsList = "RecipientsList";
	public static final String CONFIG_DeploymentName = "DeploymentName";

	public ExcelUtility(String path) {

		this.path = path;
		try {

			fis = new FileInputStream(path);
			workbook = new XSSFWorkbook(fis);
			sheet = workbook.getSheetAt(0);
			fis.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	// returns the row count in a sheet
	public int getRowCount(String sheetName) {
		int index = workbook.getSheetIndex(sheetName);
		if (index == -1)
			return 0;
		else {
			sheet = workbook.getSheetAt(index);
			int number = sheet.getLastRowNum() + 1;
			return number;
		}

	}

	// returns the data from a cell
	public String getCellData(String sheetName, String colName, int rowNum) {
		try {
			if (rowNum <= 0)
				return "";

			int index = workbook.getSheetIndex(sheetName);
			int col_Num = -1;
			if (index == -1)
				return "";

			sheet = workbook.getSheetAt(index);
			row = sheet.getRow(0);
			for (int i = 0; i < row.getLastCellNum(); i++) {

				if (row.getCell(i).getStringCellValue().trim().equals(colName.trim())) {
					col_Num = i;
					break;
				}
			}
			if (col_Num == -1)
				return "";

			sheet = workbook.getSheetAt(index);
			row = sheet.getRow(rowNum - 1);
			if (row == null)
				return "";
			cell = row.getCell(col_Num);

			if (cell == null)
				return "";

			if (cell.getCellType() == Cell.CELL_TYPE_STRING) {
				return cell.getStringCellValue();
			} else if (cell.getCellType() == Cell.CELL_TYPE_NUMERIC || cell.getCellType() == Cell.CELL_TYPE_FORMULA) {

				String cellText = String.valueOf(cell.getNumericCellValue());
				if (HSSFDateUtil.isCellDateFormatted(cell)) {
					// format in form of M/D/YY
					double d = cell.getNumericCellValue();

					Calendar cal = Calendar.getInstance();
					cal.setTime(HSSFDateUtil.getJavaDate(d));
					cellText = (String.valueOf(cal.get(Calendar.YEAR))).substring(2);
					cellText = cal.get(Calendar.DAY_OF_MONTH) + "/" + cal.get(Calendar.MONTH) + 1 + "/" + cellText;

					// System.out.println(cellText);

				}

				return cellText;
			} else if (cell.getCellType() == Cell.CELL_TYPE_BLANK)
				return "";
			else
				return String.valueOf(cell.getBooleanCellValue());

		} catch (XmlValueDisconnectedException xml) {
			xml.printStackTrace();
			return "row " + rowNum + " or column " + colName + " does not exist in xls";
		} catch (Exception e) {
			e.printStackTrace();
			return "row " + rowNum + " or column " + colName + " does not exist in xls";
		}

	}

	// returns the data from a cell
	public String getCellData(String sheetName, int colNum, int rowNum) {
		try {
			if (rowNum <= 0)
				return "";
			if (colNum <= 0)
				return "";

			int index = workbook.getSheetIndex(sheetName);

			if (index == -1)
				return "";

			sheet = workbook.getSheetAt(index);
			row = sheet.getRow(rowNum - 1);
			if (row == null)
				return "";
			cell = row.getCell(colNum - 1);
			if (cell == null)
				return "";

			if (cell.getCellType() == Cell.CELL_TYPE_STRING)
				return cell.getStringCellValue();
			else if (cell.getCellType() == Cell.CELL_TYPE_FORMULA) {
				switch (cell.getCachedFormulaResultType()) {
				case Cell.CELL_TYPE_NUMERIC:
					return String.valueOf(cell.getNumericCellValue());
				case Cell.CELL_TYPE_STRING:
					return cell.getRichStringCellValue().toString();
				}
				return "";
			} else if (cell.getCellType() == Cell.CELL_TYPE_NUMERIC) {

				String cellText = String.valueOf(cell.getNumericCellValue());
				if (HSSFDateUtil.isCellDateFormatted(cell)) {
					// format in form of M/D/YY
					double d = cell.getNumericCellValue();

					Calendar cal = Calendar.getInstance();
					cal.setTime(HSSFDateUtil.getJavaDate(d));
					cellText = (String.valueOf(cal.get(Calendar.YEAR))).substring(2);
					cellText = cal.get(Calendar.MONTH) + 1 + "/" + cal.get(Calendar.DAY_OF_MONTH) + "/" + cellText;

					// System.out.println(cellText);

				}

				return cellText;
			} else if (cell.getCellType() == Cell.CELL_TYPE_BLANK)
				return "";
			else
				return String.valueOf(cell.getBooleanCellValue());
		} catch (Exception e) {

			e.printStackTrace();
			return "row " + rowNum + " or column " + colNum + " does not exist  in xls";
		}
	}

	// returns true if data is set successfully else false
	public boolean setCellData(String sheetName, String colName, int rowNum, String data) {
		try {
			fis = new FileInputStream(path);
			workbook = new XSSFWorkbook(fis);

			if (rowNum <= 0)
				return false;

			int index = workbook.getSheetIndex(sheetName);
			int colNum = -1;
			if (index == -1)
				return false;

			sheet = workbook.getSheetAt(index);

			row = sheet.getRow(0);
			if (row != null) {
				for (int i = 0; i < row.getLastCellNum(); i++) {
					cell = row.getCell(i, Row.RETURN_BLANK_AS_NULL);
					if (cell != null)
						if (row.getCell(i).getStringCellValue().trim().equals(colName)) {
							colNum = i;
							break;
						}

				}
			}
			if (colNum == -1)
				return false;

			sheet.autoSizeColumn(colNum);
			row = sheet.getRow(rowNum - 1);
			if (row == null)
				row = sheet.createRow(rowNum - 1);

			cell = row.getCell(colNum);
			if (cell == null)
				cell = row.createCell(colNum);

			// cell style
			// CellStyle cs = workbook.createCellStyle();
			// cs.setWrapText(true);
			// cell.setCellStyle(cs);
			cell.setCellValue(data);

			fileOut = new FileOutputStream(path);

			workbook.write(fileOut);

			fileOut.close();

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

	// returns true if data is set successfully else false
	public boolean setCellData(String sheetName, String colName, int rowNum, String data, String url) {
		// System.out.println("setCellData setCellData******************");
		try {
			fis = new FileInputStream(path);
			workbook = new XSSFWorkbook(fis);

			if (rowNum <= 0)
				return false;

			int index = workbook.getSheetIndex(sheetName);
			int colNum = -1;
			if (index == -1)
				return false;

			sheet = workbook.getSheetAt(index);
			// System.out.println("A");
			row = sheet.getRow(0);
			for (int i = 0; i < row.getLastCellNum(); i++) {
				// System.out.println(row.getCell(i).getStringCellValue().trim());
				if (row.getCell(i).getStringCellValue().trim().equalsIgnoreCase(colName))
					colNum = i;
			}

			if (colNum == -1)
				return false;
			sheet.autoSizeColumn(colNum); // ashish
			row = sheet.getRow(rowNum - 1);
			if (row == null)
				row = sheet.createRow(rowNum - 1);

			cell = row.getCell(colNum);
			if (cell == null)
				cell = row.createCell(colNum);

			cell.setCellValue(data);
			XSSFCreationHelper createHelper = workbook.getCreationHelper();

			// cell style for hyperlinks
			// by default hypelrinks are blue and underlined
			CellStyle hlink_style = workbook.createCellStyle();
			XSSFFont hlink_font = workbook.createFont();
			hlink_font.setUnderline(XSSFFont.U_SINGLE);
			hlink_font.setColor(IndexedColors.BLUE.getIndex());
			hlink_style.setFont(hlink_font);
			// hlink_style.setWrapText(true);

			XSSFHyperlink link = createHelper.createHyperlink(XSSFHyperlink.LINK_FILE);
			link.setAddress(url);
			cell.setHyperlink(link);
			cell.setCellStyle(hlink_style);

			fileOut = new FileOutputStream(path);
			workbook.write(fileOut);

			fileOut.close();

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

	// returns true if sheet is created successfully else false
	public boolean addSheet(String sheetname) {

		FileOutputStream fileOut;
		try {
			workbook.createSheet(sheetname);
			fileOut = new FileOutputStream(path);
			workbook.write(fileOut);
			fileOut.close();
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

	// returns true if sheet is removed successfully else false if sheet does
	// not exist
	public boolean removeSheet(String sheetName) {
		int index = workbook.getSheetIndex(sheetName);
		if (index == -1)
			return false;

		FileOutputStream fileOut;
		try {
			workbook.removeSheetAt(index);
			fileOut = new FileOutputStream(path);
			workbook.write(fileOut);
			fileOut.close();
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

	// returns true if column is created successfully
	public boolean addColumn(String sheetName, String colName) {
		// System.out.println("**************addColumn*********************");

		try {
			fis = new FileInputStream(path);
			workbook = new XSSFWorkbook(fis);
			int index = workbook.getSheetIndex(sheetName);
			if (index == -1)
				return false;

			XSSFCellStyle style = workbook.createCellStyle();
			style.setFillForegroundColor(HSSFColor.GREY_40_PERCENT.index);
			style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);

			sheet = workbook.getSheetAt(index);

			row = sheet.getRow(0);
			if (row == null)
				row = sheet.createRow(0);

			// cell = row.getCell();
			// if (cell == null)
			// System.out.println(row.getLastCellNum());
			if (row.getLastCellNum() == -1)
				cell = row.createCell(0);
			else
				cell = row.createCell(row.getLastCellNum());

			cell.setCellValue(colName);

			if (colName.equals("FailureCause")) {
				style.setWrapText(true);
				sheet.setDefaultColumnWidth(30);
			}

			cell.setCellStyle(style);

			fileOut = new FileOutputStream(path);
			workbook.write(fileOut);
			fileOut.close();

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}

		return true;

	}

	// removes a column and all the contents
	public boolean removeColumn(String sheetName, int colNum) {
		try {
			if (colNum != 0) {
				if (!isSheetExist(sheetName))
					return false;
				fis = new FileInputStream(path);
				workbook = new XSSFWorkbook(fis);
				sheet = workbook.getSheet(sheetName);
				XSSFCellStyle style = workbook.createCellStyle();
				style.setFillForegroundColor(HSSFColor.GREY_40_PERCENT.index);
				style.setFillPattern(HSSFCellStyle.NO_FILL);

				for (int i = 0; i < getRowCount(sheetName); i++) {
					row = sheet.getRow(i);
					if (row != null) {
						cell = row.getCell(colNum);
						if (cell != null) {
							cell.setCellStyle(style);
							row.removeCell(cell);
						}
					}
				}
				fileOut = new FileOutputStream(path);
				workbook.write(fileOut);
				fileOut.close();
			} else
				return false;
		} catch (Exception e) {

			return false;
		}
		return true;

	}

	// find whether sheets exists
	public boolean isSheetExist(String sheetName) {
		int index = workbook.getSheetIndex(sheetName);
		if (index == -1) {
			index = workbook.getSheetIndex(sheetName.toUpperCase());
			if (index == -1)
				return false;
			else
				return true;
		} else
			return true;
	}

	// returns number of columns in a sheet
	public int getColumnCount(String sheetName) {
		// check if sheet exists
		if (!isSheetExist(sheetName))
			return -1;

		sheet = workbook.getSheet(sheetName);
		row = sheet.getRow(0);

		if (row == null)
			return -1;

		return row.getLastCellNum();

	}

	// String sheetName, String testCaseName,String keyword ,String URL,String
	// message
	public boolean addHyperLink(String sheetName, String screenShotColName, String testCaseName, int index, String url,
			String message) {
		// System.out.println("ADDING addHyperLink******************");

		url = url.replace('\\', '/');
		if (!isSheetExist(sheetName))
			return false;

		sheet = workbook.getSheet(sheetName);

		for (int i = 2; i <= getRowCount(sheetName); i++) {
			if (getCellData(sheetName, 0, i).equalsIgnoreCase(testCaseName)) {
				// System.out.println("**caught "+(i+index));
				setCellData(sheetName, screenShotColName, i + index, message, url);
				break;
			}
		}

		return true;
	}

	public int getCellRowNum(String sheetName, String colName, String cellValue) {

		for (int i = 2; i <= getRowCount(sheetName); i++) {
			if (getCellData(sheetName, colName, i).equalsIgnoreCase(cellValue)) {
				return i;
			}
		}
		return -1;

	}

	// ------------------------------------------------------------
	// return column number on basis of column Name
	// returns the data from a cell
	// Author: Yogendra Rathore
	public int getColumnNumber(String sheetName, String colName) throws Exception {
		try {

			int index = workbook.getSheetIndex(sheetName);
			int col_Num = -1;

			sheet = workbook.getSheetAt(index);
			row = sheet.getRow(0);
			if (row == null)
				throw new Exception("TestCases Sheet in TestExecutionSheet is Blank.");

			for (int i = 0; i < row.getLastCellNum(); i++) {
				cell = row.getCell(i, Row.RETURN_BLANK_AS_NULL);
				if (cell != null)
					if (cell.getStringCellValue().trim().equals(colName.trim())) {
						col_Num = i;
						break;
					}

			}

			return col_Num;

		} catch (Exception e) {
			throw e;
		}
	}

	// -------------------------------------------------------------------------------------
	// Insert test data in excel on basis of sheetname, colNum , rowNum and data
	// Author: Yogendra Rathore
	public boolean setCellData(String sheetName, int colNum, int rowNum, String data) {
		try {

			fis = new FileInputStream(path);
			workbook = new XSSFWorkbook(fis);

			if (rowNum <= 0)
				return false;

			int index = workbook.getSheetIndex(sheetName);

			if (index == -1)
				return false;

			sheet = workbook.getSheetAt(index);

			sheet.autoSizeColumn(colNum);

			row = sheet.getRow(rowNum - 1);
			if (row == null)
				row = sheet.createRow(rowNum - 1);

			cell = row.getCell(colNum);
			if (cell == null)
				cell = row.createCell(colNum - 1);

			cell.setCellValue(data);

			fileOut = new FileOutputStream(path);

			workbook.write(fileOut);

			fileOut.close();

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

	// ---------------------------------------------------------------------------------------------------------------------
	// Author : Yogendra Rathore
	// returns true if sheet exists

	public boolean checkSheetExists(String sheetName) {
		int index = workbook.getSheetIndex(sheetName);
		if (index == -1)
			return false;

		return true;
	}

	// ---------------------------------------------------------------------------------------------------------------------
	// Author : Yogendra Rathore
	// returns row number based on columnNumber and

	public int getCellRowNum(String sheetName, int colNumber, String cellValue) {

		for (int i = 2; i <= getRowCount(sheetName); i++) {
			if (getCellData(sheetName, colNumber, i).equalsIgnoreCase(cellValue)) {
				return i;
			}
		}
		return -1;

	}

	// ---------------------------------------------------------------------------------------------------------------------
	// Author : Yogendra Rathore

	// returns true if sheet is clone successfully else false
	public boolean cloneSheet(String sheetname) {

		FileOutputStream fileOut;
		try {
			int index = workbook.getSheetIndex(sheetname);
			workbook.cloneSheet(index);
			fileOut = new FileOutputStream(path);
			workbook.write(fileOut);
			fileOut.close();
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

	// ---------------------------------------------------------------------------------------------------------------------
	// Author : Yogendra Rathore

	// returns true if sheet is clone successfully else false
	public boolean checkSheetIsHidden(String sheetname) {

		try {
			int index = workbook.getSheetIndex(sheetname);

			return workbook.isSheetHidden(index);

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}

	}

}
