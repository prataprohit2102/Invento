package Util;

// Class contains all generic methods related to DataBase

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import org.apache.log4j.Logger;

import Base.BasePage;

public class DataBaseFunctionsLibraray {

	// Class variables
	private static Statement stmt = null;
	public static Connection conn = null;
	private static SimpleDateFormat formatter = null;
	private static boolean isDBConnected = false;

	// Initialize Logger Class object
	static final Logger log = Logger.getLogger("DataBaseFunctionsLibraray");

	// --------------------------------------------------------------------------------------------------------------------------------
	// Creates data base connection based on the database connection values
	// available in the config file
	// Last Modified By: Yogendra Rathore
	// Modified by : Chanchal Jain
	// Modified By :Tanmay -- Added condition to check if connection is closed
	// in between
	// Modified By :Rakesh -- Added condition to check if connection is still
	// valid
	// Modifed by :Yogendra Rathore
	// Added VPN connection automation code for alpha
	private static boolean connectToDatabase() throws Exception {
		try {
			if (!isDBConnected || conn == null || !conn.isValid(10)) {
				System.out.println("MESSAGE: connecting to db");
				connectToDatabaseAndGetConnectionObject();
				isDBConnected = true;
			} else if (conn.isClosed()) {
				System.out.println("MESSAGE: connecting is closed so connecting to db");
				connectToDatabaseAndGetConnectionObject();
				isDBConnected = true;
			}
		} // end of try
		catch (Exception se) {
			System.out.println("MESSAGE: in catch exception of connectToDatabase method ");
			int i = 0;
			// Reset isDBConnected variable false
			isDBConnected = false;
			conn = null;

			// Yogendra's Addition
			if (BasePage.appURL.contains("alpha")) {
				System.out.println("Test Enviorment is Alpha, so checking for VPN Connection");
				String nameOfVPNForAlpha = "alfa1EnactVNet";
				UtilityFunctions.connectVPNFromUI(nameOfVPNForAlpha);
			}
			do {
				// Again attempt to connect to Database
				if (!isDBConnected || conn == null) {
					// get DB connection
					conn = connectToDatabaseAndGetConnectionObject();
					isDBConnected = true;
				}

				log.error("MESSAGE: " + se.getMessage());
				i++;
			} while (i < 5);

		} // end of catch

		return isDBConnected;

	}// end of function

	// --------------------------------------------------------------------------------------------------------------------------------

	// Returns the rowcount of the table name
	public static int getTableRowCount(String Query) throws Exception {

		int rowCount = -1;
		ResultSet rs = null;

		if (connectToDatabase() == true) {
			try {
				rs = stmt.executeQuery(Query);

				while (rs.next()) {

					rowCount = rs.getInt("COUNT");
				} // end of while

			} catch (SQLException sqlEx) {
				sqlEx.printStackTrace();
			}

		} // end of if

		// closeDatabaseConnection();
		return rowCount;

	}// end of function

	// --------------------------------------------------------------------------------------------------------------------------------

	// Executes the query and pass the result set object containing the rows
	public static ResultSet executeSelectQuery(String Query) throws Exception {
		try {
			// Method variables
			ResultSet rs = null; // To store the result set of the query
			if (connectToDatabase() == true) {
				try {
					stmt = conn.createStatement();
					rs = stmt.executeQuery(Query);

				} // end of try
				catch (Exception se) {
					log.error("Query :" + Query);
					System.out.println("MESSAGE: " + se.getMessage());
					throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), se));
				} // end of catch

			} // end of if
			return rs;
		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}

	}// end of function

	// --------------------------------------------------------------------------------------------------------------------------------
	// Closes the database connection
	public static void closeDatabaseConnection() {
		try {
			conn.close();
		} // end of if
		catch (SQLException sqlEX) {
			System.out.println("Already closed");
		} // end of else
	}// end of function

	// --------------------------------------------------------------------------------------------------------------------------------

	// To convert String value containg a date into a date data type based on
	// the date format passed
	public static Date convertStringToDate(String dateInString, String dateFormat) {
		Date date = null;
		try {
			date = formatter.parse(dateInString);
		} catch (ParseException e) {

		}
		return date;

	}

	// --------------------------------------------------------------------------------------------------------------------------------
	public static Connection connectToDatabaseAndGetConnectionObject() throws Exception {
		// Creates connection string
		String dbURL = BasePage.TestConfiguration.getProperty("DatabaseUrl");
		String dbUserName = BasePage.TestConfiguration.getProperty("DatabaseUserName");
		String dbPassword = BasePage.TestConfiguration.getProperty("DatabasePassword");
		Properties connectionProps = new Properties();
		connectionProps.put("user", dbUserName);
		connectionProps.put("password", dbPassword);

		System.out.println("dbURL = " + dbURL);
		try {
			DriverManager.registerDriver(new com.microsoft.sqlserver.jdbc.SQLServerDriver());
			conn = DriverManager.getConnection(dbURL, connectionProps);
			if (conn != null) {
				stmt = conn.createStatement();
				System.out.println("database connected successfully");

			} // end of if

		} // end of try
		catch (Exception se) {
			log.error("MESSAGE: " + se.getMessage());
			throw se;
		} // end of catch

		return conn;

	}

	// --------------------------------------------------------------------------------------------------------------------
	// method to restore Database.
	// Parameters- DB back name
	// Author: Yogendra Rathore
	public static void restoreDatabase(String dbName, String backUpSource) throws Exception {
		try {
			String query = "USE [master] ALTER DATABASE [" + dbName
					+ "] SET SINGLE_USER WITH ROLLBACK IMMEDIATE RESTORE DATABASE [" + dbName + "] FROM  DISK = N'"
					+ backUpSource + "'WITH  FILE = 1,  NOUNLOAD,  REPLACE,  STATS = 5 ALTER DATABASE [" + dbName
					+ "] SET MULTI_USER";

			DataBaseFunctionsLibraray

					.executeDeleteUpdatedAndInsertQuery(query);
			DataBaseFunctionsLibraray.executeSelectQuery("GO");
			DataBaseFunctionsLibraray.executeSelectQuery("USE [" + dbName + "]");
		} catch (Exception e) {

			throw e;
		}
	}

	// --------------------------------------------------------------------------------------------------------------------
	// method to check data base restored successfully.
	// Author: Yogendra Rathore
	public static boolean checkDBRestoredSuccessfully(String dbName, int countOfTablesBeforeRestore) throws Exception {
		try {

			ResultSet resultSet = null;
			int count = 0, countOfTablesAfterRestore = 0;
			// check number of tables restored successfully
			while (countOfTablesAfterRestore != countOfTablesBeforeRestore) {
				resultSet = DataBaseFunctionsLibraray.executeSelectQuery("Select count(*) as countTables from " + dbName
						+ ".information_schema.tables WHERE table_type = 'base table'");

				if (resultSet.next()) {
					countOfTablesAfterRestore = resultSet.getInt("countTables");
				}
			}
			// check no data should be present.
			resultSet = DataBaseFunctionsLibraray
					.executeSelectQuery("select count(*) as count from specificationlimit");

			if (resultSet.next()) {
				count = resultSet.getInt("count");
			} // end of while

			return count == 0;
		} catch (Exception e) {

			throw e;
		}
	}

	// --------------------------------------------------------------------------------------------------------------------
	// method to test data inserted.
	// Author: Yogendra Rathore
	public static boolean checkTestDataInsertedProperly() throws Exception {
		try {
			ResultSet resultSet = null;
			int count = 0;
			// check no data should be present.
			resultSet = DataBaseFunctionsLibraray
					.executeSelectQuery("select count(*) as count from specificationlimit");

			if (resultSet.next()) {
				count = resultSet.getInt("count");
			} // end of while

			return count != 0;
		} catch (Exception e) {

			throw e;
		}
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// Executes the query and pass the result set object containing the rows
	// modified by Rakesh Sharma on 19-08-19
	// updated code to print message on console in case of sql exception
	public static int executeDeleteUpdatedAndInsertQuery(String Query) throws Exception {
		// Method variables
		int affectedRowCount = 0;
		PreparedStatement preparedStatement = null;

		if (connectToDatabase() == true) {
			try {

				preparedStatement = conn.prepareStatement(Query);

				affectedRowCount = preparedStatement.executeUpdate();

			} // end of try
			catch (SQLException se) {

				log.error("SQL STATE: " + se.getSQLState());
				log.error("ERROR CODE: " + se.getErrorCode());
				log.error("MESSAGE: " + se.getMessage());
				log.error("Query :" + Query);
				if (se.getMessage().contains("A result set was generated for update"))
					affectedRowCount = 1;
				else {
					System.out.println(se.getMessage());
				}

			} // end of catch

		} // end of if
			// closeDatabaseConnection();
		return affectedRowCount;

	}// end of function

	// --------------------------------------------------------------------------------------------------------------------------------

	// Executes the query apart from update delete and select
	// Author :Yogendra Rathore
	public static boolean executeQueryApartFromUpdateDeleteAndSelect(String Query) throws Exception {

		if (connectToDatabase() == true) {
			try {
				stmt = conn.createStatement();

				return stmt.execute(Query);
			} // end of try
			catch (Exception se) {
				log.error("Query :" + Query);
				System.out.println("MESSAGE: " + se.getMessage());
				throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), se));

			} // end of catch

		} // end of if
		return false;
	}// end of function

}
