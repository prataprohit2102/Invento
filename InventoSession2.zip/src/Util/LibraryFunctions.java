package Util;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.log4j.Logger;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import Base.BasePage;


public class LibraryFunctions extends BasePage {
	
	public static String xPath_ErrorHandlingHeader = "//*[@data-selector='error-handling-header']";
	
	private static String xPath_headerTitle = "//*[@data-selector='header-title']";
	public static String xPath_PageTitle = "//*[@class='modal-title']";
	public static String xPath_PopOverContent = "//*[@class='popover-content']";

	// xPath Grayed Out Screen
	private static String xPathGrayedOutScreen = "//*[@data-selector='background-overlay']";
	private static String xPath_iconEdit = "//*[@data-selector='edit-entity']";

	static final Logger log = Logger.getLogger("LibraryFunctions");
	// X-paths of the box and button

	private static String xpath_lblConfirmationBox = "//*[@class='modal-view']//p";
	private static String xpath_alertConfirmationBox = "//*[@class='modal-view']";
	private static String xpath_lblDocumentUploadProgressBar = "//*[@data-selector='document-progress-bar']";

	// xPath of Buttons
	protected static String xPath_btnConfirmationCancel = "//*[@data-selector='confirm-cancel']";
	protected static String xPath_btnConfirmationOk = "//*[@data-selector='ok']";
	protected static String xPath_btnConfirmationCross = "//*[@data-selector='popup-close']";
	protected static String xPath_lblConfirmationHeaderText = "//*[@class='modal-title']";

	// X-paths of the box and button
	public static String xpath_btnOKButtton = "//*[contains(@data-selector, 'ok')]";
	private static String xPath_btnClose = "//*[@data-selector='popup-close']";
	private static String xpath_btnCancelButtton = "//*[contains(@data-selector,'cancel')]";
	private static String xpath_btnCrossButton = "//*[@class='close']";
	public static String xPath_btnConfigureColumn = "//*[@data-selector='configure-columns-btn']";
	public static String xPath_ConfigureColumnCheckbox = "//*[@class='modal-view']//*[@class='checkbox']";
	public static String xPath_btnConfigureColumnDone = "//*[@data-selector='btn-done-configure-columns']";
	private static String xPath_lblGridHeader = "//*[@class='k-grid-header-wrap k-auto-scrollable']";
	private static String xpath_btnDeleteCancelButtton = "//*[@data-selector='btn-cancel-entity-dependency']";
	private static String xpath_btnDeleteOKButtton = "//*[@data-selector='btn-update-entity-dependency']";
	private static String xPath_lblGrid = "//*[@class='k-grid-header']";
	private static String xPath_iconLoading = "//*[@class='k-icon k-i-loading']";
	private static String xPath_iconTileSpinner = "//*[@data-selector='tile-spinner']";
	private static String xPath_imgLoadingSpinner = "//*[@data-selector='spinner']";
	private static String xPath_imgErrorIcon = "//*[@data-selector='content-holder']//img";
	private static String xPath_progressBarMarquee = "//*[@data-selector='progress-bar-marquee']";
	public static String xPath_btnHelpButton = "//*[@data-selector='help-button']";

	public static String xpath_lblGridViewPopUp = "//*[@data-selector='popup1']" + xPath_lblGrid;
	private static String xPath_dataGrid = "//*[@class='k-grid-content k-auto-scrollable']";
	// -----------------------------------------------------------------------------------------------------------------------------
	public static String xpath_lblDocumentUplodationProgressBar = "//*[@data-selector='document-progress-bar']";

	public static String xpath_imgLoading = "//*[@class='k-loading-image']";
	private static String xPath_Notification_Message = "//*[@class='notification-container']";
	private static String xPath_Notification_Close = "//*[@data-selector='notification-close']";
	private static String xPath_ListOf_Notification_Messages = "//*[@data-selector='notification-wrapper']";
	public static String notification_Message;
	public static String xPath_btnMoreNotifications = "//*[@data-selector='show-more']";
	public static String xPath_btnLessNotifications = "//*[@data-selector='show-less' and contains(@style,'display: inline-block;')]";

	public static List<String> notification_MessageList = new ArrayList<String>();
	public static String confirmationMessage = "";
	public static boolean copyPasteEnterText = false;
	public static int n = 1;
	private static String xpath_btnUpdateOKButtton = "//*[@data-selector='btn-update-entity-dependency']";

	protected static String xpath_PopUp = "//*[@data-selector='popup-content']";
	protected static String xPath_btnPopUpClose = "//*[@data-selector='popup-close']";
	protected static String xpath_UnsavedChangePopUp = "//*[@class='modal-content']";
	static Actions act;
	public static String xPath_FrozenGridHeader = "//*[@class='k-grid-header-locked']";
	public static String xpath_SelectEntityPage_Search_MulitSelectDropDown = "//*[@data-selector='configure-columns-search']";

	// check whether element with given XPath is present or not
	public static boolean isElementPresent(String XPath) {
		try {
			// TODO
			// Instead of isElementDisplayed
			WebDriverWait wait = new WebDriverWait(BasePage.driver, 1);

			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(XPath)));

		} catch (Exception e) {
			return false;

		}
		return true;
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// check whether element with given XPath is present or not
	// Modified By: Yogendra Rathore
	public static boolean isElementPresent(String XPath, int timeInSec) {

		try {
			// TODO
			// Instead of isElementDisplayed
			WebDriverWait wait = new WebDriverWait(BasePage.driver, timeInSec);

			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(XPath)));
			return true;

		} catch (Exception e) {
			return false;

		}
	}

	// --------------------------------------------------------------------------------------------------------------------------------

	// To check whether a link is present or not
	public static boolean isLinkPresent(String XPath) {
		try {
			BasePage.driver.findElement(By.linkText(XPath));
		} catch (Exception e) {
			return false;
		}
		return true;
	}

	//

	// Refresh Current Browser Page
	public static void refresh() throws InterruptedException {
		BasePage.driver.navigate().refresh();

		// Insert thread .sleep
		try {
			Thread.sleep(3000);
		} catch (Exception e) {

		}
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// Author - Chanchal Jain
	// Modified By: Yogendra Rathore
	// Use to insert data in text field
	// Modified By: Yogendra Rathore
	// Update throw new exception
	// Modified By : Rakesh Sharma
	// added focus out after clear
	// Modified By : Yogendra Rathore
	// removed focus out after clear
	// Modified By : Harshita Shaktawat
	// removed focus out after clear in case of copy paste
	public static void enterText(String xPathOfTextField, String textToBeEntered, boolean copyPaste) throws Exception {
		try {
			// check field in which value is to be entered is visible or not.
			if (LibraryFunctions.isElementDisplayed(xPathOfTextField, 5)) {
				if (!copyPaste) {

					// use to replace '(' with key chord
					textToBeEntered = textToBeEntered.replaceAll("\\(", Keys.chord(Keys.SHIFT, "9"));

					// click on the Field
					UtilityFunctions.applicationWait(1000);
					checkLoadingIconIsDisplayed("TextField", 45);
					LibraryFunctions.click(xPathOfTextField, "", 5);
					UtilityFunctions.applicationWait(1000);
					// Clear Field

					LibraryFunctions.clearUsingKeyboard(xPathOfTextField);
					/*
					 * BasePage.driver.findElement(By.xpath(xPathOfTextField)) .clear();
					 */

					UtilityFunctions.applicationWait(2000);
					checkLoadingIconIsDisplayed("TextField", 45);
					LibraryFunctions.click(xPathOfTextField, "", 5);

					UtilityFunctions.applicationWait(500);

					// enter text into field
					BasePage.driver.findElement(By.xpath(xPathOfTextField)).sendKeys(textToBeEntered);

					// Provide wait So that Save button functionality works fine
					UtilityFunctions.applicationWait(5000);

					checkLoadingIconIsDisplayed("TextField", 45);
				} else {
					// Copy Selected Data from clipboard.

					LibraryFunctions.setClipboardData(textToBeEntered);
					// Paste Copied value into Source Location
					LibraryFunctions.click(xPathOfTextField, "", 5);
					LibraryFunctions.clearUsingKeyboard(xPathOfTextField);
					/*
					 * BasePage.driver.findElement(By.xpath(xPathOfTextField)) .clear();
					 */

					LibraryFunctions.click(xPathOfTextField, "", 5);
					UtilityFunctions.applicationWait(500);
					BasePage.driver.findElement(By.xpath(xPathOfTextField)).sendKeys(Keys.CONTROL, "v");

					// Provide wait So that Save button functionality works fine
					UtilityFunctions.applicationWait(3000);

				}
			} else
				throw new Exception("Xpath Doesn't exists :" + xPathOfTextField);

		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// --------------------------------------------------------------------------------------------------------------------------------

	// To checks whether the count of rows in the database table matches the
	// count of rows on any landing page data grid
	public static void copyAndPasteValues(String sourceLocationXpath, String destinationLocationXpath,
			int pasteNumberOfTimes) {
		// Copy Selected Data from Source Location
		BasePage.driver.findElement(By.xpath(sourceLocationXpath)).sendKeys(Keys.CONTROL, "a");
		BasePage.driver.findElement(By.xpath(sourceLocationXpath)).sendKeys(Keys.CONTROL, "c");

		// Compare Source and Destination Locations are same
		/*
		 * if(sourceLocation.equals(destinationLocation)) UtilityFunctions.refresh();
		 */

		// Clear Destination Location
		BasePage.driver.findElement(By.xpath(destinationLocationXpath)).clear();

		// Check Destination Field clear
		if (BasePage.driver.findElement(By.xpath(destinationLocationXpath)).getAttribute("value").length() != 0)
			BasePage.driver.findElement(By.xpath(destinationLocationXpath)).clear();

		for (int i = 1; i <= pasteNumberOfTimes; i++)

			// Paste Copied value into Source Location
			BasePage.driver.findElement(By.xpath(destinationLocationXpath)).sendKeys(Keys.CONTROL, "v");
	}

	// --------------------------------------------------------------------------------------------------------------------------------------

	// This method handle the confirmation message which appears when there is
	// some dirty data on page and we are trying to
	// navigate away from that page
	// Modified By: Yogendra
	// Changes done: If Ok button Xpath is not present click on [X] icon to
	// close the pop up
	// Modified By: Chanchal Jain
	// Changes done: add i<5 condition in while loop for prevent infinite loop.
	// updated while condition , because on login page to popup elements
	// presents in backgroud
	// Modified by : Yogendra Rathore
	// Updated get confirmation message code.
	// updated by: Rakesh Sharma
	// Change: added condition for size_CancelBtn > index
	// change: added check for null driver
	public static void handlingConfirmationBoxMessage(String action) throws Exception {

		try {
			if (BasePage.driver == null) {
				throw new Exception("base page driver is null");
			}

			// Added code to handle browser popups\alerts
			WebDriverWait wait = new WebDriverWait(BasePage.driver, 1);
			try {
				wait.until(ExpectedConditions.alertIsPresent());
				Alert alert = BasePage.driver.switchTo().alert();
				if (action.equalsIgnoreCase("ok"))
					alert.accept();
				else
					alert.dismiss();

				return;
			} catch (Exception e) {

			}

			if (LibraryFunctions.isElementPresent(xPathGrayedOutScreen)) {

				getFieldInFocus().sendKeys(Keys.ESCAPE);
			}

			int i = 0;
			while ((LibraryFunctions.isElementDisplayed("//div[starts-with(@class,'modal fade')]", 2)
					|| LibraryFunctions.isElementDisplayed(
							"//div[starts-with(@class,'modal fade')][contains(@aria-hidden,'false')]", 2))
					&& i < 5) {

				// get confirmation message in a variable so that it can be
				// used.
				confirmationMessage = getConfirmationBoxMessage();
				// Check if Action Selected is OK - Means to accept the
				// Confirmation Box
				if (action.toUpperCase().equals("OK")) {

					if (LibraryFunctions.isElementDisplayed(xpath_btnOKButtton, 5)) {
						// Clicking On OK button

						LibraryFunctions.click(xpath_btnOKButtton, "", 5);

						i = 0;
						while (isElementPresent("//*[contains(@class,'progress-bar-marquee')]") && i <= 30) {
							UtilityFunctions.applicationWait(500);
							i++;
						}

						// set notification_Message blank.
						notification_Message = "";
						if (LibraryFunctions.isElementDisplayed(xPath_Notification_Message, 15)) {
							// get value of actual notification message
							notification_Message = BasePage.driver.findElement(By.xpath(xPath_Notification_Message))
									.getText();
						} else
							notification_Message = "No Notificiaiton Message Displayed";

					}

					else if (LibraryFunctions.isElementDisplayed(xpath_btnUpdateOKButtton, 5)) {
						click(xpath_btnUpdateOKButtton, "ProgressBarMarqueeIcon", 5);
					} else {
						getFieldInFocus().sendKeys(Keys.ESCAPE);
					}
				}
				// Check if Action Selected is CANCEL - Means to decline the
				// Confirmation Box
				else if (action.toUpperCase().equals("CANCEL")) {
					// apply wait till not visible button.
					List<WebElement> listOfCancel = driver.findElements(By.xpath(xpath_btnCancelButtton));
					int index = 0;
					int size_CancelBtn = listOfCancel.size();

					while (size_CancelBtn > index && index < 4 && !LibraryFunctions
							.isElementIsClickable(UtilityFunctions.generateXPATH(listOfCancel.get(index), "")))
						index++;
				}

				// Check if Action Selected is Cross - Means to decline the
				// Confirmation Box
				else if (action.toUpperCase().equals("CROSS")) {
					// apply wait till not visible button.
					LibraryFunctions.isElementDisplayed(xPath_btnClose, 5);
					// Clicking On CANCEL button
					LibraryFunctions.click(xPath_btnClose, "", 5);
				}
				i++;
			}

		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		} finally {
			LibraryFunctions.checkLoadingIconIsDisplayed("SpinningLoadingIcon", 60);
		}
	}

	// This method Get the Message appears on Confirmation Box
	// changed to check isDisplayed
	public static String getConfirmationBoxMessage() {

		try {
			// Check Confirmation Box present
			if (LibraryFunctions.isElementDisplayed(xpath_alertConfirmationBox, 8)) {
				UtilityFunctions.applicationWait(500);

				// Return the Actual Message On Confirmation Message Box
				if (LibraryFunctions.isElementDisplayed(xpath_lblConfirmationBox, 3))
					return BasePage.driver.findElement(By.xpath(xpath_lblConfirmationBox)).getText();

				return "";

			}
		} catch (Exception e) {
			e.printStackTrace();
			return ConstantsUtility.errSomeErrorOccured;

		}

		return ConstantsUtility.errNoMessageDisplayed;

	}

	// -----------------------------------------------------------------------------------------------------------
	// Method to copy text of clip board

	public static void setClipboardData(String string) {
		StringSelection stringSelection = new StringSelection(string);
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringSelection, null);
	}

	// -----------------------------------------------------------------------------------------------------
	// Method to check anagrams i.e. cab equals bac.
	public static boolean checkStringsAreAnagram(String str1, String str2) {
		char[] charArray1 = str1.toCharArray();
		char[] charArray2 = str2.toCharArray();
		int charArray1Length = charArray1.length;
		int charArray2Length = charArray2.length;
		int k = 0;

		if (charArray1Length == charArray2Length) {
			for (int i = 0; i < charArray1.length; i++) {
				for (int j = 0; j < charArray2.length; j++) {

					if (charArray1[i] == charArray2[j]) {
						k++;
					}
				}
			}
			return charArray1Length == k;
		}

		return false;
	}

	// -----------------------------------------------------------------------------------------------------

	// Method to verify helper text of Text box \ area \Search As you Type Field
	// is correct.
	// It can't be verified that helper text
	// Parameters :-f
	// xPathTextField _ xPath of the text field you want to get helper text
	// expectedHelperText - helper text
	// Author : Yogendra Rathore
	// mOdified By: Priyanka

	public static boolean checkDefaultHelperTextOfField(

			String xPath_Field, String expectedHelperText) throws Exception {

		// Declare Variables

		String actualHelperText = null;

		try {
			// Modification: Added the code snippet to cover the scenario where
			// placeholder does not occur
			// get actual helper text of the field
			if (BasePage.driver.findElement(By.xpath(xPath_Field)).getAttribute("placeholder").equals("")) {
				actualHelperText = BasePage.driver.findElement(By.xpath(xPath_Field)).getAttribute("value");

			} else {
				actualHelperText = BasePage.driver.findElement(By.xpath(xPath_Field)).getAttribute("placeholder");
			}

			// Logic for comparing the expected value of Helper Text with Actual
			// Value

			return actualHelperText.equals(expectedHelperText);

		} catch (Exception e) {

			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));

		}

	} // End of method

	// ---------------------------------------------------------------------------------------------------------------------
	// method to focus out of the field.
	// author : Yogendra rathore
	// Modified BY: Yogendra Rathore
	// Action : Added for pop up
	// change by : Rakesh Sharma on 20-02-2019
	// Action: added check for mutiselect drop down
	public static void focusOutOfTheField() throws Exception {
		try {// get xpath of the title of the page and click on that xPath.
				// checking xpath of pop up title because in case of chrome
				// ,driver
				// is not able to click on background.
			UtilityFunctions.applicationWait(1000);
			if (LibraryFunctions.isElementIsClickable(xPath_headerTitle))

				UtilityFunctions.applicationWait(1000);
			else if (LibraryFunctions.checkPopupIsPresent()) {
				LibraryFunctions.isElementIsClickable(xPath_PageTitle);
			} else if (LibraryFunctions.checkPopOverIsPresent()) {
				LibraryFunctions.isElementIsClickable(xPath_PopOverContent);
			} else if (LibraryFunctions.checkMultiSelectDropDownIsOpen()) {
				LibraryFunctions.getFieldInFocus().sendKeys(Keys.ESCAPE);
				LibraryFunctions.checkLoadingIconIsDisplayed("SpinningLoadingIcon", 30);
			}

		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------
	// check element is clickable
	// author : Yogendra rathore
	public static boolean isElementIsClickable(String xPath) throws Exception {
		try {

			if (LibraryFunctions.isElementDisplayed(xPath, 5)) {
				BasePage.driver.findElement(By.xpath(xPath)).click();
				UtilityFunctions.applicationWait(1000);
				return true;
			} else
				return false;
		} catch (Exception e) {
			return false;
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------
	// method to check document is uploaded wait till 15 mins
	// author : Bhupendra Singh Chauhan
	public static void checkDocumentsAreUploaded() {

		if (!(isElementPresent(xpath_lblDocumentUploadProgressBar) && (isElementPresent(xpath_alertConfirmationBox)))) {

			for (int i = 1000, j = 1000; LibraryFunctions.isElementPresent(xpath_lblDocumentUploadProgressBar)
					&& j <= 90000;) {
				try {
					// Wait for one second
					Thread.sleep(i);
					// increase value by one second
					j = i + 1000;
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
	}

	// -------------------------------------------------------------------------------------------------------------
	// check value of cell of grid on part landing page
	// Author: Yogendra Rathore
	// modified by : Rakesh
	// added condition to check if language label present for given cell
	// modified by Rakesh Sharma
	// added code to scroll in grid
	// modifiedBy Rakesh on 07-03-2019
	// Reverted the scroll changes
	// modifiedBy Yogendra on 14-04-2019
	// added sop in last
	// modified by : Yamini <13-08-2019>
	// added code to scroll only if grid cell not visible, added page refresh if
	// page is scrolled. commenting changes for now, to be verified first
	public static String getValueOfGridCell(String xPath_dataGrid, int row, int column) throws Exception {
		// boolean refresh = false;
		try {
			String xPath_GridCell = xPath_dataGrid + "//tr[" + row + "]//td[" + column + "]";

			/*
			 * if (!LibraryFunctions.isElementDisplayed(xPath_GridCell, 5)) { refresh =
			 * LibraryFunctions .scrollInGridByElementVisibility(xPath_GridCell); }
			 */
			if (LibraryFunctions.isElementDisplayed(xPath_GridCell, 5)) {

				if (LibraryFunctions.isElementDisplayed(xPath_GridCell + "//span//span[ not(@style='display: none;')]",
						1))
					return BasePage.driver
							.findElement(By.xpath(xPath_GridCell + "//span//span[ not(@style='display: none;')]"))
							.getText();
				else
					return BasePage.driver.findElement(By.xpath(xPath_GridCell)).getText();
			}

			System.out.println("Cell Doesn't exist for row :" + row + " and column :" + column + "  for grid xpath :"
					+ xPath_dataGrid);
			return "Cell Doesn't exist";
		} catch (Exception e) {
			throw new Exception("error in getValueOfGridCell" + e);
		} /*
			 * finally { if (refresh) LibraryFunctions.refreshPage(); }
			 */

	}

	// -------------------------------------------------------------------------------------------------------------
	// check number of rows and columns grid on part landing page
	// Author: Yogendra Rathore
	public static int[] getNumberOfColumnsAndRows(String xPath_dataGrid) throws Exception {
		int[] numberOfRowsAndColumn = new int[2];
		List<WebElement> tableHeaderColumns = null;
		List<WebElement> tableHeaderRows = null;

		try {
			tableHeaderColumns = BasePage.driver.findElements(By.xpath(xPath_dataGrid + "//tr[1]//td"));
			tableHeaderRows = BasePage.driver.findElements(By.xpath(xPath_dataGrid + "//tr"));

			numberOfRowsAndColumn[0] = tableHeaderColumns.size();
			numberOfRowsAndColumn[1] = tableHeaderRows.size();
			return numberOfRowsAndColumn;
		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));

		}
	}

	// ------------------------------------------------------------------------------------------------------------------------
	// Verify Validation message occurs for mandatory fields.
	// Parameters:
	// xPath_Field= xPath of the field to be validated
	// validationMessage
	// xPath_Action = xPath of Action button (Save , Save&Close, FocusOut(Xpath
	// should be blank in case of FocusOut)),
	// xPath_ValidationMessageHolder = xPath of validation message holder
	// xPath_ValidationMessageCrossIcon= xPath of [X] button on validation
	// message
	// xPath_MissingField = xPath of Missing Field icon on top right of page.
	// Modified by: Yogendra Rathore

	// ------------------------------------------------------------------------------------------------------------------------
	// Verify Validation message occurs for mandatory fields.
	// Parameters:
	// xPath_Field= xPath of the field to be validated
	// validationMessage
	// xPath_Action = xPath of Action button (Save , Save&Close, FocusOut(Xpath
	// should be blank in case of FocusOut)),
	// xPath_ValidationMessageHolder = xPath of validation message holder
	// xPath_ValidationMessageCrossIcon= xPath of [X] button on validation
	// message
	// xPath_MissingField = xPath of Missing Field icon on top right of page.
	// Modified by: Yogendra Rathore

	public static Hashtable<String, String> verifyValidaitonMessageForMandatoryField(String xPath_Field,
			String validationMessage, String xPath_Action, String xPath_ValidationMessageHolder,
			String xPath_ValidationMessageCrossIcon, String xPath_MissingField) throws Exception {

		Hashtable<String, String> result = new Hashtable<String, String>();
		try {
			LibraryFunctions.click(xPath_Field, "", 5);
			UtilityFunctions.applicationWait(1000);
			BasePage.driver.findElement(By.xpath(xPath_Field)).clear();
			result = checkValidationMessageForFields(xPath_Field, validationMessage, xPath_Action,
					xPath_ValidationMessageHolder, xPath_ValidationMessageCrossIcon, xPath_MissingField);

			return result;

		} // end of try
		catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// -------------------------------------------------------------------------------------------------------------------------------------
	// verify validation message for unique field
	// Parameters:
	// xPath_Field= xPath of the field to be validated
	// validationMessage
	// xPath_Action = xPath of Action button (Save , Save&Close, FocusOut(Xpath
	// should be blank in case of FocusOut)),
	// xPath_ValidationMessageHolder = xPath of validation message holder
	// xPath_ValidationMessageCrossIcon= xPath of [X] button on validation
	// message
	// existingValue = exisitng value of that specific field.
	// Modified by: Yogendra Rathore
	public static Hashtable<String, String> verifyValidationMessageForUniqueField(String xPath_Field,
			String validationMessage, String xPath_ValidationMessageHolder, String existingValue, String xPath_Action,
			String xPath_ValidationMessageCrossIcon) throws Exception {

		Hashtable<String, String> result = new Hashtable<String, String>();
		try {
			// pass existing value
			LibraryFunctions.enterText(xPath_Field, "", false);
			LibraryFunctions.enterText(xPath_Field, existingValue, copyPasteEnterText);

			UtilityFunctions.applicationWait(1000);
			if (xPath_Action.equalsIgnoreCase(""))
				// focus out of the field
				LibraryFunctions.focusOutOfTheField();
			else if (xPath_Action.equalsIgnoreCase("TAB"))
				// focus out of the field
				LibraryFunctions.getFieldInFocus().sendKeys(Keys.TAB);
			else
				// click on button
				click(xPath_Action, "ProgressBarMarqueeIcon", 5);

			UtilityFunctions.applicationWait(1000);

			// Validation Message Check
			if (LibraryFunctions.isElementPresent(xPath_ValidationMessageHolder)) {
				System.out.println(validationMessage);
				System.out.println(BasePage.driver.findElement(By.xpath(xPath_ValidationMessageHolder)).getText());

				if (!validationMessage
						.equals((BasePage.driver.findElement(By.xpath(xPath_ValidationMessageHolder)).getText())))
					result.put("Is_Validation_Message_Correct", "No");
				if (!(LibraryFunctions.isElementPresent(xPath_ValidationMessageCrossIcon)))
					result.put("Is_Cross_Icon_Present", "No");
				else {// check validation disappear on clicking [x] button of
						// validation
						// message
						// click on cross button
					LibraryFunctions.click(xPath_ValidationMessageCrossIcon, "", 5);
					UtilityFunctions.applicationWait(1000);

					if (isElementPresent(xPath_ValidationMessageHolder, 10))
						result.put("Is_Validation_Closed", "No");
				}
			}

			else
				result.put("Is_Validation_Occurs", "No");

			return result;
		} catch (Exception e) {
			throw new Exception("LibraryFunctions in method : verifyValidationMessageForUniqueField " + e);
		}
	}

	// -----------------------------------------------------------------------------------------------------------------
	// verify column is present on landing page or not.
	// this column won't verify frozen columns are present or not.
	// Author: Yogendra Rathore
	public static boolean verifyColumnIsPresentOnLandingPage(String columnName) throws Exception {
		int numberOfColumnsInGrid;
		try {
			Actions act = new Actions(BasePage.driver);

			List<WebElement> tableHeaderColumns = BasePage.driver.findElements(By.xpath(xPath_lblGrid + "//th"));
			LibraryFunctions.click(tableHeaderColumns.get(1), "", 10);
			// tableHeaderColumns.get(1).click();
			checkLoadingIconIsDisplayed("GridLoadingIcon", 60);
			LibraryFunctions.click(tableHeaderColumns.get(1), "", 10);
			// tableHeaderColumns.get(1).click();
			checkLoadingIconIsDisplayed("GridLoadingIcon", 60);
			// verify column is displayed on landing page
			numberOfColumnsInGrid = tableHeaderColumns.size();

			for (int i = 0; i < numberOfColumnsInGrid; i++) {

				act.sendKeys(Keys.RIGHT).build().perform();

				if (columnName.equalsIgnoreCase(tableHeaderColumns.get(i).getText()))
					return true;
			}
			return false;
		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// -------------------------------------------------------------------------------------------------------------
	// select column from configure column list.
	// Author: Yogendra Rathore
	public static boolean selectColumnFromConfigureColumnListOnLandingPage(String columnName) throws Exception {

		try {
			if (!verifyColumnIsPresentOnLandingPage(columnName)) {
				// click on configure column
				LibraryFunctions.click(xPath_btnConfigureColumn, "", 5);
				UtilityFunctions.applicationWait(1000);
				if (LibraryFunctions.isElementPresent(xpath_alertConfirmationBox)) {

					List<WebElement> configureColumnListLabel = BasePage.driver
							.findElements(By.xpath(xPath_ConfigureColumnCheckbox + "//span"));

					List<WebElement> configureColumnList = BasePage.driver
							.findElements(By.xpath(xPath_ConfigureColumnCheckbox + "//label"));

					for (int i = 0; i < configureColumnList.size(); i++) {
						if (columnName.equalsIgnoreCase(configureColumnListLabel.get(i).getText())) {
							configureColumnList.get(i).click();
							break;
						}
					}

					// click on Done button
					LibraryFunctions.click(xPath_btnConfigureColumnDone, "", 5);
					// verify column should be added on landingPage
					return verifyColumnIsPresentOnLandingPage(columnName);
				} else
					return false;
			} else

				return true;

		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// -------------------------------------------------------------------------------------------------------------
	// This method verify the Save successfully notification message.
	// Author: Yogendra Rathore
	// Modified by: Yogendra Rathore

	public static boolean verifySaveSuccessfullyNotificationIsDisplayed(String expectedValidation) throws Exception {

		try {
			if (!notification_Message.equalsIgnoreCase("")) {

				if (expectedValidation.equals(notification_Message))
					return true;
				else
					throw new Exception(
							"Actual Message :- " + notification_Message + "Expected Message :- " + expectedValidation);
			} else
				throw new Exception("Notification Message Is Blank");
		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// -----------------------------------------------------------------------------------------------------------------
	// This method gives the index of column
	// this method won't work for frozen column.
	// Author: Yogendra Rathore
	// Modified by - chanchal Jain
	// updated xPath , removed 'a' tag from xPath
	public static int getIndexOfColumn(String columnName) throws Exception {
		int numberOfColumnsInGrid, index = 0;
		try {
			boolean columnImagePresent = false;
			List<WebElement> tableHeaderColumns = BasePage.driver.findElements(By.xpath(xPath_lblGridHeader + "//th"));

			for (WebElement headerText : tableHeaderColumns) {
				if ((headerText.getText().equals(UtilityFunctions.getMultilingualData("ColumnName_Image")))) {
					tableHeaderColumns.get(0).click();
					LibraryFunctions.handlingConfirmationBoxMessage("CROSS");
					columnImagePresent = true;
					break;
				}
			}

			if (!columnImagePresent && LibraryFunctions.isElementDisplayed(xPath_dataGrid + "//tr[1]//td[1]", 3)) {
				/*
				 * BasePage.driver.findElement( By.xpath(xPath_dataGrid +
				 * "//tr[1]//td[1]")).click();
				 * LibraryFunctions.handlingConfirmationBoxMessage("CROSS");
				 */

				if (LibraryFunctions.isElementIsClickable(xPath_dataGrid + "//tr[1]//td[1]"))
					LibraryFunctions.handlingConfirmationBoxMessage("CROSS");
				else if (LibraryFunctions.isElementIsClickable(xPath_lblGridHeader + "//tr[1]//td[1]"))
					LibraryFunctions.handlingConfirmationBoxMessage("CROSS");
			}

			Actions act = new Actions(BasePage.driver);
			// verify column is displayed on landing page
			numberOfColumnsInGrid = tableHeaderColumns.size();

			for (int i = 0; i < numberOfColumnsInGrid; i++) {
				if (!tableHeaderColumns.get(i).getAttribute("style").contains("none")) {
					if (columnName.equalsIgnoreCase(tableHeaderColumns.get(i).getText())) {
						index = i + 1;
						break;
					}

					act.sendKeys(Keys.RIGHT).build().perform();
				}
			}

			return index;
		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));

		}
	}

	// -------------------------------------------------------------------------------------------------------------
	// check value of cell of grid
	// Author: Priyanka Kundu
	// Modified By: Yogendra Rathore
	// Action *1 : Updated code , getting Attribute instead of get text.
	// Modidfed By: Chanchal JAin
	// updated xPath
	// Modified By : harshita shaktawat
	// changed condition for frozen grid headers when expected value is blank
	// changed by Rakesh Sharma
	// commented code for scroll right due to application bug
	// Modified By: Yogendra Rathore
	// Added Actual value to replacing tag <b> n </b> with blank.
	// Modified By: Yogendra Rathore <13-03-2019>
	// changed waiting time from 3 secs to 1 sec and removed commented code
	public static int getColumnNumberOnColumnHeader(String xPath_dataGrid, String expectedValue) throws Exception {
		try {
			// handling scroll right

			if (LibraryFunctions.checkPopupIsPresent())
				xPath_dataGrid = "//*[@data-selector='popup1']" + xPath_dataGrid;
			int columnNumber = 0, numberOfColumns;
			List<WebElement> tableHeaderRows = null;
			tableHeaderRows = BasePage.driver.findElements(By.xpath(xPath_dataGrid + "//th"));
			// get number of columns
			numberOfColumns = tableHeaderRows.size();

			for (int colNum = 1; colNum <= numberOfColumns; colNum++) {
				scrollInGridByElementVisibility(xPath_dataGrid + "//tr/th[" + colNum + "]");
				String actualValue = "";
				if (expectedValue == "") {
					actualValue = BasePage.driver.findElement(By.xpath(xPath_dataGrid + "//tr/th[" + colNum + "]"))
							.getText();
				} else if (LibraryFunctions.isElementDisplayed(xPath_dataGrid + "//tr/th[" + colNum + "]//span", 3)) {
					actualValue = BasePage.driver.findElement(By.xpath(xPath_dataGrid + "//tr/th[" + colNum + "]"))
							.getText();
				} else if (LibraryFunctions.isElementDisplayed(xPath_dataGrid + "//tr/th[" + colNum + "]//span", 1)) {
					actualValue = BasePage.driver
							.findElement(By.xpath(xPath_dataGrid + "//tr/th[" + colNum + "]//span")).getText();
				} else if (LibraryFunctions.isElementDisplayed(xPath_dataGrid + "//tr/th[" + colNum + "]", 1)) {
					actualValue = BasePage.driver.findElement(By.xpath(xPath_dataGrid + "//tr/th[" + colNum + "]"))
							.getText();
				}

				if (!actualValue.equals(expectedValue) && !expectedValue.equals("")) {

					if (LibraryFunctions.isElementDisplayed(xPath_dataGrid + "//tr/th[" + colNum + "]", 1))
						actualValue = BasePage.driver.findElement(By.xpath(xPath_dataGrid + "//tr/th[" + colNum + "]"))
								.getAttribute("data-title");
				}
				if (actualValue != null) {
					actualValue = actualValue.replace("<b>", "");
					actualValue = actualValue.replace("</b>", "");
				}
				if (expectedValue.equals(actualValue)) {
					columnNumber = colNum;
					break;
				}

			}

			if (!(columnNumber > 0))
				throw new Exception(expectedValue + " column not found on grid ");

			return columnNumber;

		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			throw new Exception(
					UtilityFunctions.throwException(Thread.currentThread(), ex) + " for column Name :" + expectedValue);

		}
	}

	// --------------------------------------------------------------------------------------------------------------------------------------

	// This method handle the confirmation message which appears when there is
	// some dirty data on page and we are trying to
	// navigate away from that page
	// Author : Priyanka Kundu
	public static void handlingDeleteConfirmationBoxMessage(String action) throws Exception {

		try {
			if (LibraryFunctions.isElementDisplayed(xpath_alertConfirmationBox, 10)) {
				// Check if Action Selected is OK - Means to accept the
				// Confirmation Box
				if (action.toUpperCase().equals("OK")) {
					// Provide wait to click on OK button
					UtilityFunctions.applicationWait(1500);
					// Clicking On OK button
					LibraryFunctions.click(xpath_btnDeleteOKButtton, "", 5);
				}
				// Check if Action Selected is CANCEL - Means to decline the
				// Confirmation Box
				else if (action.toUpperCase().equals("CANCEL")) {
					// Clicking On CANCEL button
					LibraryFunctions.click(xpath_btnDeleteCancelButtton, "", 5);
				}

				LibraryFunctions.checkLoadingIconIsDisplayed("GridLoadingIcon", 10);
			}

		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// --------------------------------------------------------------------------------------------------------------------------------------

	// This method handle the confirmation message which appears when there is
	// some dirty data on page and we are trying to
	// navigate away from that page
	// Author : Priyanka Kundu
	// modify: rakesh
	// change: added code to check isdisplayed
	public static boolean checkDeleteConfirmationPopUpIsDisplayed() throws Exception {

		try {
			return !LibraryFunctions.isElementDisplayed(xpath_alertConfirmationBox, 10);

		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));

		}

	}

	// -----------------------------------------------------------------------------------------------------------------------------------
	// check collapse /expanded field is collapsed or expanded
	// this method returns whether collapse expand body is expanded.
	// Return True: expanded
	// Author: Yogendra Rathore
	public static boolean checkCollapseExpandFieldIsExpanded(String xPath_body) throws Exception {

		return BasePage.driver.findElement(By.xpath(xPath_body)).getAttribute("class").contains("collapse in");

	}

	// ------------------------------------------------------------------------------------------------------------------------------
	// Method to move focus back to the control and return validation message
	// indicating if error message disappeared
	// Author- Tanmay
	public static Hashtable<String, String> checkValidationMessageDisappearOnFocusBack(String xPath_Field,
			String xPath_ValidationField, Hashtable<String, String> result) throws Exception {
		try {
			// Move focus back to the same field
			UtilityFunctions.applicationWait(1000);
			LibraryFunctions.click(xPath_Field, "", 5);
			if (LibraryFunctions.isElementDisplayed(xPath_ValidationField, 2)) {
				if (result == null)
					result = new Hashtable<String, String>();
				result.put("Is_Validation_Closed", "No");
			}
			return result;
		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// ------------------------------------------------------------------------------------------------------------------------
	// Verify Validation message occurs Date fields
	// Parameters:
	// xPath_StartDate= xPath of the start Date field to be validated
	// StartDate - vlaue to be inserted in the start date field
	// xPath_StartDate -xPath of End Date field
	// EndDate - value to be put into end date field
	// validationMessage
	// xPath_Action = xPath of Action button (Save , Save&Close, FocusOut(Xpath
	// should be blank in case of FocusOut)),
	// xPath_ValidationMessageHolder = xPath of validation message holder
	// xPath_ValidationMessageCrossIcon= xPath of [X] button on validation
	// message(to be left blank if cross icon is not to be clicked
	// Modified by: Tanmay
	public static Hashtable<String, String> verifyValidaitonMessageForStartDateGreaterThanEndDate(
			String xPath_StartDate, String StartDate, String xPath_EndDate, String EndDate, String validationMessage,
			String xPath_Action, String xPath_ValidationMessageHolder, String xPath_ValidationMessageCrossIcon)
			throws Exception {

		Hashtable<String, String> result = new Hashtable<String, String>();
		try {
			LibraryFunctions.enterText(xPath_StartDate, StartDate, false);

			UtilityFunctions.applicationWait(1000);
			LibraryFunctions.enterText(xPath_EndDate, EndDate, false);

			if (xPath_Action.equalsIgnoreCase(""))
				// focus out of the field
				LibraryFunctions.focusOutOfTheField();
			else
				// click on button
				LibraryFunctions.click(xPath_Action, "ProgressBarMarqueeIcon", 5);

			UtilityFunctions.applicationWait(2000);

			// Validation Message Check
			if (LibraryFunctions.isElementPresent(xPath_ValidationMessageHolder, 1)) {

				if (!validationMessage
						.equals((BasePage.driver.findElement(By.xpath(xPath_ValidationMessageHolder)).getText())))
					result.put("Is_Validation_Message_Correct", "No");
				if (!xPath_ValidationMessageCrossIcon.equals("")) {
					if (!(LibraryFunctions.isElementPresent(xPath_ValidationMessageCrossIcon)))
						result.put("Is_Cross_Icon_Present", "No");
				}

			}

			else
				result.put("Is_Validation_Occurs", "No");

			// check validation disappear on clicking [x] button of validation
			// message
			// click on cross button
			if (!xPath_ValidationMessageCrossIcon.equals("")) {
				LibraryFunctions.click(xPath_ValidationMessageCrossIcon, "", 5);
				UtilityFunctions.applicationWait(1000);

				if ((LibraryFunctions.isElementPresent(xPath_ValidationMessageCrossIcon)))
					result.put("Is_Validation_Closed", "No");
			}

			return result;

		} // end of try
		catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// check whether element with given XPath is displayed on screen or not.
	// Created By: Yogendra Rathore
	public static boolean isElementDisplayed(String XPath, int timeInSec) {

		try {
			// TODO
			// Instead of isElementDisplayed
			WebDriverWait wait = new WebDriverWait(BasePage.driver, timeInSec);

			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(XPath)));

			return true;

		} catch (Exception e) {
			return false;
		} // end of catch
	}// end of method

	// --------------------------------------------------------------------------------------------------------------------------------
	// To check status of State Toggle button.
	// Parameter : Toggle button container
	// Returns True : if active
	// Author Name: Yogendra Rathore

	public static boolean checkStatusOfStateToggleButton(String xPath_ToggleStateContainer) throws Exception {
		try {
			if (LibraryFunctions.isElementDisplayed(xPath_ToggleStateContainer, 3))
				// check status of button cross
				return BasePage.driver.findElement(By.xpath(xPath_ToggleStateContainer)).getAttribute("style")
						.contains("margin-left: 0px;");

			else
				throw new Exception("Xpath of container doesn't exists");
		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}

	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// This method set status of State button to Active \ Inactive
	// Returns "true" if active
	// Author Name: Yogendra Rathore
	// modified by rakesh. changed condition 3
	public static boolean setStatusOfToggleStateButton(String xPath_btnToggleState, String xPath_ToggleStateContainer,
			String changeState) throws Exception {

		// check status of toggle button
		boolean currentStatus = checkStatusOfStateToggleButton(xPath_ToggleStateContainer);
		// check current state and changeState are same then return true
		if (changeState.equalsIgnoreCase("Active") && currentStatus)
			return true;

		else if (changeState.equalsIgnoreCase("Active") && !currentStatus)
			LibraryFunctions.click(xPath_btnToggleState, "", 5);

		else if (changeState.equalsIgnoreCase("InActive") && !currentStatus)
			return true;

		else
			LibraryFunctions.click(xPath_btnToggleState, "", 5);

		UtilityFunctions.applicationWait(2000);
		return checkStatusOfStateToggleButton(xPath_ToggleStateContainer);

	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// This method is used to scroll up and scroll down
	// Author Name: Chanchal Jain
	public static void setVerticalScrollBar(String action) throws Exception {
		try {
			Actions act = new Actions(BasePage.driver);
			focusOutOfTheField();

			if (action.equalsIgnoreCase("Down"))
				act.sendKeys(Keys.PAGE_DOWN).build().perform();
			else
				act.sendKeys(Keys.PAGE_UP).build().perform();

		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}

	}

	// ------------------------------------------------------------------------------------------------------------------------
	// Verify Validation message occurs for fields.
	// Parameters:
	// xPath_Field= xPath of the field to be validated
	// validationMessage
	// xPath_Action = xPath of Action button (Save , Save&Close, FocusOut(Xpath
	// should be blank in case of FocusOut)),
	// xPath_ValidationMessageHolder = xPath of validation message holder
	// xPath_ValidationMessageCrossIcon= xPath of [X] button on validation
	// message
	// xPath_MissingField = xPath of Missing Field icon on top right of page.
	// Modified by: Priyanka Kundu
	// Modified by : Tanmay
	// Added if condition for verifying the cross icon of validation message
	// within the if block which verifies presence of the
	// validation message
	// Modified by : Harshita Shaktawat

	// Modified by: rakesh sharma
	// change: added condition to check notification message when server
	// hit/response comes first

	// Modified By : Harshita shaktawat
	// Added action enter

	// Modified By : HArshita Shaktawat Date : <23 SEP 2017>
	// Set xpath to save incase validation message is present in overlay and we
	// don't have to perform save action
	// changed by: Rakesh on 6th july 2018
	// added condition for "Enter" key action
	// Modified By: Neha Goyal<19-09-2019>
	// Added Save&CloseF

	public static Hashtable<String, String> checkValidationMessageForFields(String xPath_Field,
			String validationMessage, String xPath_Action, String xPath_ValidationMessageHolder,
			String xPath_ValidationMessageCrossIcon, String xPath_MissingField) throws Exception {

		Hashtable<String, String> result = new Hashtable<String, String>();
		try {
			if (xPath_Action.equalsIgnoreCase(""))
				// focus out of the field
				LibraryFunctions.focusOutOfTheField();
			else if (xPath_Action.equalsIgnoreCase("TabOut")) {
				// tab out of the field
				LibraryFunctions.getFieldInFocus().sendKeys(Keys.TAB);

			} else if (xPath_Action.equalsIgnoreCase("Enter")) {
				// press enter key
				LibraryFunctions.getFieldInFocus().sendKeys(Keys.ENTER);
			} else if (xPath_Action.equalsIgnoreCase("Save")) {// click on button
				LibraryFunctions.click(xPath_Action, "ProgressBarMarqueeIcon", 5);
				UtilityFunctions.applicationWait(300);
				xPath_Action = "Save";
			} else {// click on button
				LibraryFunctions.click(xPath_Action, "ProgressBarMarqueeIcon", 5);
				UtilityFunctions.applicationWait(300);
				xPath_Action = "Save&Close";
			}

			if (xPath_Field.equals("overlay"))
				xPath_Action = "Save";

			UtilityFunctions.applicationWait(1000);

			// Validation Message Check
			if (LibraryFunctions.isElementPresent(xPath_ValidationMessageHolder, 5)) {
				System.out
						.println("MESSAGE IS " + driver.findElement(By.xpath(xPath_ValidationMessageHolder)).getText());

				if (!validationMessage.equals((driver.findElement(By.xpath(xPath_ValidationMessageHolder)).getText())))
					result.put("Is_Validation_Message_Correct", "No");
				if (!xPath_ValidationMessageCrossIcon.equals("")) {
					if (!(LibraryFunctions.isElementPresent(xPath_ValidationMessageCrossIcon)))
						result.put("Is_Cross_Icon_Present", "No");
				}
				// Tanmay Modification -- Code block commented as Missing field
				// has been removed from the application
				/*
				 * if (!xPath_MissingField.equals("")) { if (!BasePage.driver
				 * .findElement(By.xpath(xPath_MissingField))
				 * .getAttribute("style").equals("display: block;"))
				 * result.put("Is_Missing_Field_Present", "No"); }
				 */

				// check validation disappear on clicking [x] button of
				// validation
				// message
				// click on cross button
				if (!xPath_ValidationMessageCrossIcon.equals("")) {
					LibraryFunctions.click(xPath_ValidationMessageCrossIcon, "", 5);

					UtilityFunctions.applicationWait(1000);

					if (!xPath_Action.equalsIgnoreCase("Enter")) {

						if ((LibraryFunctions.isElementPresent(xPath_ValidationMessageCrossIcon, 10)))
							result.put("Is_Validation_Closed", "No");
					}

				}
			} else if (xPath_Action.equalsIgnoreCase("Save"))

			{
				if (!validationMessage.equals(LibraryFunctions.getNotificationMessage()))
					result.put("Is_Validation_Message_Correct", "No");
				if (!(driver.findElements(By.xpath(xPath_Notification_Close)).get(0).isDisplayed()))
					result.put("Is_Cross_Icon_Present", "No");
				else {
					List<WebElement> listOfCloseIcons = driver.findElements(By.xpath(xPath_Notification_Close));
					for (int i = 0; i < listOfCloseIcons.size(); i++) {
						driver.findElements(By.xpath(xPath_Notification_Close)).get(0).click();
						UtilityFunctions.applicationWait(1000);
					}
				}
				UtilityFunctions.applicationWait(1000);

				if ((LibraryFunctions.isElementPresent(xPath_Notification_Close, 10)))
					result.put("Is_Validation_Closed", "No");
			} else if (xPath_Action.equalsIgnoreCase("Save&Close"))

			{
				if (!validationMessage.equals(LibraryFunctions.getNotificationMessage()))
					result.put("Is_Validation_Message_Correct", "No");
				if (!(driver.findElements(By.xpath(xPath_Notification_Close)).get(0).isDisplayed()))
					result.put("Is_Cross_Icon_Present", "No");
				else {
					List<WebElement> listOfCloseIcons = driver.findElements(By.xpath(xPath_Notification_Close));
					for (int i = 0; i < listOfCloseIcons.size(); i++) {
						driver.findElements(By.xpath(xPath_Notification_Close)).get(0).click();
						UtilityFunctions.applicationWait(1000);
					}
				}
				UtilityFunctions.applicationWait(1000);

				if ((LibraryFunctions.isElementPresent(xPath_Notification_Close, 10)))
					result.put("Is_Validation_Closed", "No");
			} else
				result.put("Is_Validation_Occurs", "No");

			return result;

		} // end of try
		catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// Close browser
	// Author Name: Bhupendra Singh
	// Modified By: Yogendra Rathore
	// Action: Navigating to dashboard before closing browser to avoid dirty
	// check browser pop up.
	// changed by: rakesh
	// removed navigation to dashboard page.
	// Modified by : Yogendra Rathore
	// Action : added BasePage.dr.quit(); BasePage.dr=null;
	// BasePage.driver=null; <22-Mar-2018>
	// reAdded basepage.dr null check
	public static void closeBrowser() {
		try {

			if (BasePage.driver != null) {
				BasePage.driver.quit();
				BasePage.driver = null;
			}

			if (BasePage.dr != null) {
				BasePage.dr.quit();
				BasePage.dr = null;
			}

			BasePage.IsLoggedIn = false;
			BasePage.current_LoggedIn_User = "";
			//RolesAndPermissionTestCases.isLoggedInWithDefaultUser = false;

		} catch (Exception e) {

			log.error("Not able to close broswer " + e.getMessage());
		}
	}

	




	// --------------------------------------------------------------------------------------------------------------------------------
	// This method is used to check loading icons
	// Author Name: Chanchal Jain
	// Modified BY; Yogendra Rathore
	// Action: updated method for progress marque.
	public static void checkLoadingIconIsDisplayed(String loadingIconType, int waitTimeInSec) throws Exception {

		waitTimeInSec = 100;
		int i = 0;
		// Instead of isElementDisplayed

		try {
			// Check Progress Bar Marquee Icon, for click event
			if (loadingIconType.equalsIgnoreCase("ProgressBarMarqueeIcon")) {

				while (isElementPresent("//*[contains(@class,'progress-bar-marquee')]") && i <= waitTimeInSec) {
					UtilityFunctions.applicationWait(500);
					i++;
				}

				// set notification_Message blank.
				notification_Message = "";
				if (LibraryFunctions.isElementDisplayed(xPath_Notification_Message, 5)) {
					// get value of actual notification message
					notification_Message = BasePage.driver.findElement(By.xpath(xPath_Notification_Message)).getText();
				} else
					notification_Message = "No Notificiaiton Message Displayed";

			}

			// text field and Search as you type field
			if (loadingIconType.equalsIgnoreCase("TextField")
					|| loadingIconType.equalsIgnoreCase("SearchAsYouTypeField"))

				while (LibraryFunctions.isElementDisplayed(xPath_iconLoading, 1) && i <= waitTimeInSec) {
					UtilityFunctions.applicationWait(1000);
					i++;
				}

			// Grid Loading icon
			if (loadingIconType.equalsIgnoreCase("GridLoadingIcon"))
				while (LibraryFunctions.isElementDisplayed(xpath_imgLoading, 1) && i <= waitTimeInSec) {
					UtilityFunctions.applicationWait(1000);
					i++;
				}

			// spinning loading icon, for remove
			if (loadingIconType.equalsIgnoreCase("SpinningLoadingIcon"))
				while (LibraryFunctions.isElementDisplayed(xPath_imgLoadingSpinner, 1) && i <= waitTimeInSec) {
					UtilityFunctions.applicationWait(1000);
					i++;
				}

			// tile loading icon
			if (loadingIconType.equalsIgnoreCase("TileLoading"))

				while (LibraryFunctions.isElementDisplayed(xPath_iconTileSpinner, 1) && i <= waitTimeInSec) {
					UtilityFunctions.applicationWait(1000);
					i++;
				}

		} catch (Exception e) {
			throw new Exception("Error in LibraryFunctions in method : checkLoadingIconIsDisplayed " + e);
		}
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// This method is used to click on a given xPath
	// Author Name: Chanchal Jain
	// Modified by : Rakesh Sharma
	// added scroll up if element not clickable
	// Modified by :Yogendra Rathore <16-08-2018>
	// added throw exception if element not displayed
	public static void click(String xPathOfButton, String loadingIconType, int waitTimeInSec) throws Exception {
		try {
			if (isElementDisplayed(xPathOfButton, 3)) {

				if (!LibraryFunctions.isElementIsClickable(xPathOfButton)) {
					LibraryFunctions.setVerticalScrollBar("UP");
					LibraryFunctions.setVerticalScrollBar("UP");
					LibraryFunctions.focusOutOfTheField();
					BasePage.driver.findElement(By.xpath(xPathOfButton)).click();
				}

				if (loadingIconType != "")
					checkLoadingIconIsDisplayed(loadingIconType, waitTimeInSec);
			} else
				throw new Exception("Method Name click _Xpath Not present _ " + xPathOfButton);

		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}

	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// This method is used to get the notification message
	// Author Name: Tanmay
	public static String getNotificationMessage() throws Exception {
		try {

			notification_Message = "";
			if (LibraryFunctions.isElementDisplayed(xPath_Notification_Message, 2))
				// get value of actual notification message

				notification_Message = BasePage.driver.findElement(By.xpath(xPath_Notification_Message)).getText();
			else
				notification_Message = "No Notificiaiton Message Displayed";

			return notification_Message;

		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));

		}

	}

	
	// --------------------------------------------------------------------------------------------------------------------------------
	// Check Ok and Cancel button present on confirmation message
	// Author Name: Chanchal Jain
	public static ArrayList<String> checkOkAndCancelButtonPresentOnConfirmationMessage() throws Exception {
		ArrayList<String> errorMessage = new ArrayList<String>();
		try {
			if (!LibraryFunctions.isElementPresent(xpath_btnOKButtton))
				errorMessage.add("OK ");
			if (!LibraryFunctions.isElementPresent(xpath_btnCancelButtton))
				errorMessage.add("Cancel ");

		} catch (Exception ex) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), ex));

		}
		return errorMessage;

	}

	// -------------------------------------------------------------------------------------------------------------
	// check row number on the basis of column number and value. landing page
	// Its searches only for 52 rows
	// Author: Yogendra Rathore

	public static int getRowNumberOnBasisOfValue(String xPath_dataGrid, String expectedValue, int column)
			throws Exception {
		try {
			// get number of rows in grid.
			int[] numberOfRowsAndColumn = new int[2];
			numberOfRowsAndColumn = getNumberOfColumnsAndRows(xPath_dataGrid);

			for (int i = 1; i <= numberOfRowsAndColumn[1]; i++) {
				String actualValue = BasePage.driver
						.findElement(By.xpath(xPath_dataGrid + "//tr[" + i + "]//td[" + column + "]")).getText();

				if (expectedValue.equals(actualValue))
					return i;

			}

			return 0;
		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));

		}

	}

	// -------------------------------------------------------------------------------------------------------------------------------------
	// Confirmation Pop elements Verification
	// Author: Priyanka Kundu
	public static String checkConfirmationPopUpComponents() throws Exception {

		// Array List will store all the elements which are not displayed on the
		// pop up
		ArrayList<String> listOfElementsNotPresent = new ArrayList<String>();

		try {
			// verify confirmation header
			if (!LibraryFunctions.isElementPresent(xPath_lblConfirmationHeaderText)) {
				listOfElementsNotPresent.add("Confirmation Header not present");
			} else if (LibraryFunctions.isElementPresent(xPath_lblConfirmationHeaderText)) {
				{
					if (!(BasePage.driver.findElement(By.xpath(xPath_lblConfirmationHeaderText)).getText()
							.equals(UtilityFunctions.getMultilingualData("ConfirmatioPopUp_MessageHeader")))) {
						listOfElementsNotPresent.add("Confirmation Header text is incorrect");
					}
				}
			}

			// verify cancel button
			if (!LibraryFunctions.isElementPresent(xPath_btnConfirmationCancel))
				listOfElementsNotPresent.add("Cancel Button");
			else {
				if (!BasePage.driver.findElement(By.xpath(xPath_btnConfirmationCancel))
						.equals(LibraryFunctions.getFieldInFocus())) {
					listOfElementsNotPresent.add("Default focus is not on Cancel Button");
				}

			}

			// verify Ok button
			if (!LibraryFunctions.isElementPresent(xPath_btnConfirmationOk))
				listOfElementsNotPresent.add("Ok Button");

			// verify cross button
			if (!LibraryFunctions.isElementPresent(xpath_btnCrossButton))
				listOfElementsNotPresent.add("Cross Button");

		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));

		}

		return UtilityFunctions.convertStringArrayListToCommaSeparatedString(listOfElementsNotPresent);
	}

	// --------------------------------------------------------------------------------------------------------------
	// checks for whether confirmation box is closed or not
	// Author: Priyanka Kundu
	public static boolean isConfirmationBoxPresent() throws Exception {
		try {
			return LibraryFunctions.isElementPresent(xpath_alertConfirmationBox);
		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// -------------------------------------------------------------------------------------------------------------
	// check column header of grid
	// Author: Priyanka Kundu
	public static ArrayList<String> getColumnHeader(String xPath_dataGrid) throws Exception {
		try {
			ArrayList<String> columnHeaderList = new ArrayList<String>();
			int numberOfColumns;
			List<WebElement> tableHeaderRows = null;
			tableHeaderRows = BasePage.driver.findElements(By.xpath(xPath_dataGrid));

			// get number of columns
			numberOfColumns = tableHeaderRows.size();
			for (int colNum = 0; colNum < numberOfColumns; colNum++) {
				columnHeaderList.add(tableHeaderRows.get(colNum).getText());
			}
			return columnHeaderList;
		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// Method check for 404 Error Page is displayed
	// Author Name: Yogendra Rathore
	// Modified BY;Yogendra Rathore <20-09-2017>
	// Changed the approach.
	public static boolean check404ServerErrorPageIsDisplayed() {
		try {
			// get current URL.
			String currentUrl = BasePage.driver.getCurrentUrl();
			String appUrl = BasePage.appURL;

			return !currentUrl.contains(appUrl);
		} catch (Exception ex) {
			log.error(
					"Error Occurred: While navigating on Logout Page when Error Page is displayed " + ex.getMessage());

		}
		return false;

	}

	
	// --------------------------------------------------------------------------------------------------------------------------------
	// Method to return the field having the focus
	// Author Name: Tanmay Bhatnagar
	public static WebElement getFieldInFocus() throws Exception {
		try {
			return BasePage.driver.switchTo().activeElement();
		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));

		}

	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// Check popup is present
	// Author Name: Chanchal Jain
	// Updated BY Yogendra Rathore :- 24-05-2018

	public static boolean checkPopupIsPresent() {
		if (LibraryFunctions.isElementDisplayed("//div[starts-with(@class,'modal fade')]", 2) || LibraryFunctions
				.isElementDisplayed("//div[starts-with(@class,'modal fade')][contains(@aria-hidden,'false')]", 10))
			return true;

		return false;
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// Clear value from numeric field.
	// Author Name: Yogendra Rathore
	public static void clearScientificValueFromGivenField(String xPathOfTheField) throws Exception {
		try {
			String spiltArrary[] = new String[2];
			spiltArrary = UtilityFunctions.splitString(xPathOfTheField, "='");
			spiltArrary = UtilityFunctions.splitString(spiltArrary[1], "'");
			// check for data selector or id
			if (xPathOfTheField.contains("data-selector=")) {

				BasePage.driver.executeScript(
						"var tt=$('[data-selector=" + spiltArrary[0] + "]');" + "tt.clearScientificValue()");
			} else if (xPathOfTheField.contains("id=")) {

				BasePage.driver.executeScript("var tt=$(\"#" + spiltArrary[0] + "\") ;" + "tt.clearScientificValue()");
			} else if (xPathOfTheField.contains("class=")) {
				BasePage.driver.executeScript("var tt=$(\"." + spiltArrary[0] + "\") ;" + "tt.clearScientificValue()");
			} else
				throw new Exception();

			UtilityFunctions.applicationWait(1000);
			// focus in the field to fire validatons as value is deleted by java
			// script validaitons wont be fire
			isElementIsClickable(xPathOfTheField);

		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}

	}

	// -----------------------------------------------------------------------------------------------------------------
	// get list of column present on landing page
	// Author: Yogendra Rathore
	public static List<String> getListOfColumnsPresentOnLandingPage() throws Exception {
		try {
			UtilityFunctions.getFocusOnBrowserWindow();
			Actions act = new Actions(BasePage.driver);
			if (LibraryFunctions.checkPopupIsPresent())
				xPath_lblGrid = xpath_lblGridViewPopUp;

			List<WebElement> tableHeaderColumns = BasePage.driver.findElements(By.xpath(xPath_lblGrid + "//th"));
			List<String> columnNames = new ArrayList<String>();
			// if column is not visible.scroll left to make it visible.
			if (!LibraryFunctions.isElementDisplayed(UtilityFunctions.generateXPATH(tableHeaderColumns.get(1), ""),
					1)) {
				int j = 2;

				while (!LibraryFunctions
						.isElementDisplayed(UtilityFunctions.generateXPATH(tableHeaderColumns.get(j), ""), 1)) {
					j++;
				}
				tableHeaderColumns.get(j).click();
				UtilityFunctions.applicationWait(1000);

				for (int i = j; i > 1; i--) {

					act.sendKeys(Keys.LEFT).build().perform();
				}
			}

			// clicking twice as on click 1 colum is sorted

			LibraryFunctions.checkLoadingIconIsDisplayed("GridLoadingIcon", 60);

			tableHeaderColumns.get(1).click();
			LibraryFunctions.checkLoadingIconIsDisplayed("GridLoadingIcon", 60);

			tableHeaderColumns.get(1).click();

			for (int i = 0; i < tableHeaderColumns.size(); i++) {

				act.sendKeys(Keys.RIGHT).build().perform();

				if (LibraryFunctions.isElementDisplayed(UtilityFunctions.generateXPATH(tableHeaderColumns.get(i), ""),
						1))
					columnNames.add(tableHeaderColumns.get(i).getText());

			}
			return columnNames;
		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));

		}
	}

	// -------------------------------------------------------------------------------------------------------------------------------
	// refresh page
	// Author: Priyanka kndu
	// Added condition for driver not null
	public static void refreshPage() throws Exception {
		try {
			if (driver != null) {
				driver.navigate().refresh();
				UtilityFunctions.applicationWait(5000);

				if (!isBrowserAlertMessageIsPresent()) {
					LibraryFunctions.checkLoadingIconIsDisplayed("SpinningLoadingIcon", 60);
					LibraryFunctions.checkLoadingIconIsDisplayed("GridLoadingIcon", 60);
				}

				UtilityFunctions.applicationWait(5000);
			}
		} catch (Exception ex) {

			throw new Exception("Refresh pagePage - refreshPage " + ex);
		}
	}

	// --------------------------------------------------------------------------------------------------------------------------------------
	// Perform required Key Action on MDC Screen
	// Author: Tanmay
	public static void performKeyBoardAction(String action, int noOfTimes) throws Exception {
		System.out.println(LibraryFunctions.getFieldInFocus());
		try {
			for (int i = 0; i < noOfTimes; i++) {
				UtilityFunctions.applicationWait(2000);
				if (action.equalsIgnoreCase("BackSpace"))
					LibraryFunctions.getFieldInFocus().sendKeys(Keys.BACK_SPACE);
				else if (action.equalsIgnoreCase("CTRL+B"))
					LibraryFunctions.getFieldInFocus().sendKeys(Keys.CONTROL, "B");
				else if (action.equalsIgnoreCase("escape"))
					LibraryFunctions.getFieldInFocus().sendKeys(Keys.ESCAPE);
				else if (action.equalsIgnoreCase("Tab"))
					LibraryFunctions.getFieldInFocus().sendKeys(Keys.TAB);
				else if (action.equalsIgnoreCase("Shift+Tab"))
					LibraryFunctions.getFieldInFocus().sendKeys(Keys.SHIFT, Keys.TAB);
				else if (action.equalsIgnoreCase("Enter"))
					LibraryFunctions.getFieldInFocus().sendKeys(Keys.ENTER);
				else if (action.equalsIgnoreCase("F5"))
					LibraryFunctions.getFieldInFocus().sendKeys(Keys.F5);
				else if (action.equalsIgnoreCase("CTRL+F"))
					LibraryFunctions.getFieldInFocus().sendKeys(Keys.CONTROL, "F");
				else if (action.equalsIgnoreCase("ArrowDown"))
					LibraryFunctions.getFieldInFocus().sendKeys(Keys.ARROW_DOWN);
			}
			UtilityFunctions.applicationWait(4000);

		} catch (Exception e) {
			throw new Exception("Exception while pressing " + action + " on default control -- " + e);

		}
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// check whether element with given XPath is Enabled or not.
	// Created By: Harsha Goyal
	public static boolean isElementEnabled(String xPath) throws Exception {

		try {
			return BasePage.driver.findElement(By.xpath(xPath)).isEnabled();

		} catch (Exception ex) {
			throw new Exception("LibraryFunctions - isElementEnabled " + ex);
		} // end of catch
	}// end of method

	// --------------------------------------------------------------------------------------------------------------------------------------
	// check alert message present
	// Author: Chanchal Jain
	public static boolean isBrowserAlertMessageIsPresent() throws Exception {

		try {
			BasePage.driver.switchTo().alert();
			return true;

		} catch (Exception e) {
			return false;

		}
	}

	// --------------------------------------------------------------------------------------------------------------------------------------
	// check alert message present
	// Author: Chanchal Jain
	public static String getValidationMessageOfBrowserAlert() throws Exception {

		try {

			if (isBrowserAlertMessageIsPresent()) {
				return BasePage.driver.switchTo().alert().getText();
			}

		} catch (Exception e) {

			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));

		}
		return "";
	}

	// --------------------------------------------------------------------------------------------------------------------------------------
	// check alert message present
	// Author: Chanchal Jain
	public static String performActionOnBrowserAlert(String action) throws Exception {

		try {
			if (isBrowserAlertMessageIsPresent()) {
				if (action.equalsIgnoreCase("OK")) {
					BasePage.driver.switchTo().alert().accept();
				} else {
					BasePage.driver.switchTo().alert().dismiss();
				}
			}

		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
		return "";
	}

	// --------------------------------------------------------------------------------------------------------------------------------------
	// navigate browser back
	// Author: Priyanka Kundu
	// Modified by: YOgendra Rathore
	// Action : added throws exception.
	// Modified by: Priyanka Kundu
	// Action : replace the code to go browser back
	public static void browserBack() throws Exception {
		try {
			// BasePage.driver.navigate().back();
			driver.executeScript("window.history.go(-1)");// Modified the code
															// because of
															// exception :cannot
															// determine loading
															// status from
															// unexpected alert
															// open

			UtilityFunctions.applicationWait(1000);
		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// --------------------------------------------------------------------------------------------------------------------------------------
	// check Radio and return the Label
	// Author -Yogendra Rathore
	public static Hashtable<String, String> checkRadioButtonAndReturnLabel(String xPath, String checkRadioButton)
			throws Exception {
		try {
			boolean state = BasePage.driver.findElement(By.xpath(xPath + "//input")).isSelected();

			if (checkRadioButton.equalsIgnoreCase("check"))
				LibraryFunctions.click(xPath + "//label", "", 5);
			Hashtable<String, String> result = new Hashtable<String, String>();
			result.put("Default_Selected", String.valueOf(state));
			result.put("RadioButton_Label", BasePage.driver.findElement(By.xpath(xPath + "//span")).getText());
			return result;
		} catch (Exception e) {
			log.error("Error occurred - checkRadioButtonAndReturnLabel - " + BasePage.currentMethodName);
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));

		}
	}

	// --------------------------------------------------------------------------------------------------------------------------------------
	// select/deselect checkbox and return the Text of checkbox
	// Author -Yogendra Rathore
	// Modified by :Yogendra Rathore
	// Action 1- check checkbox is checked \ unchecked properly.

	public static Hashtable<String, String> selectDeselectCheckBoxAndReturnLabel(String xPath, String selectDeselect)
			throws Exception {
		try {

			boolean state = BasePage.driver.findElement(By.xpath(xPath + "//input")).isSelected();
			if (!selectDeselect.equals("")) {
				if (state && !selectDeselect.equalsIgnoreCase("select"))
					LibraryFunctions.click(xPath + "//label", "", 5);

				else if (state && selectDeselect.equalsIgnoreCase("deselect"))
					LibraryFunctions.click(xPath + "//label", "", 5);

				else if (!state && !selectDeselect.equalsIgnoreCase("deselect"))
					LibraryFunctions.click(xPath + "//label", "", 5);

				else if (!state && selectDeselect.equalsIgnoreCase("select"))
					LibraryFunctions.click(xPath + "//label", "", 5);
			}
			Hashtable<String, String> result = new Hashtable<String, String>();
			result.put("Default_Checked", String.valueOf(state));

			if (LibraryFunctions.isElementDisplayed(xPath + "//span", 3))
				result.put("Checkbox_label", BasePage.driver.findElement(By.xpath(xPath + "//span")).getText());

			// Action 1- check checkbox is checked \ unchecked properly.

			boolean currentState = BasePage.driver.findElement(By.xpath(xPath + "//input")).isSelected();
			boolean expectedState = false;

			if (selectDeselect.equalsIgnoreCase("select"))
				expectedState = true;

			if ((!selectDeselect.equals("")) && (currentState != expectedState)) {
				throw new Exception("Not able to select deselect checkbox with Label" + result.get("Checkbox_label"));
			}

			return result;
		} catch (Exception e) {
			log.error("Error occurred - selectDeselectCheckBoxAndReturnLabel - " + BasePage.currentMethodName);
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}



	// ------------------------------------------------------------------------------------------------------------------------
	// -------
	// refresh page with all actions
	// Author: Yogendra Rathore
	public static void refreshPage(String action) throws Exception {
		try {
			if (action.equalsIgnoreCase("DriverRefresh"))
				BasePage.driver.navigate().refresh();
			else if (action.equalsIgnoreCase("F5")) {
				LibraryFunctions.getFieldInFocus().sendKeys(Keys.F5);
			} else if (action.equalsIgnoreCase("CTRL+F"))
				LibraryFunctions.getFieldInFocus().sendKeys(Keys.CONTROL, "F");
			LibraryFunctions.checkLoadingIconIsDisplayed("SpinningLoadingIcon", 60);
			UtilityFunctions.applicationWait(1000);
			LibraryFunctions.checkLoadingIconIsDisplayed("SpinningLoadingIcon", 60);
			UtilityFunctions.applicationWait(1000);
			LibraryFunctions.checkLoadingIconIsDisplayed("GridLoadingIcon", 60);
		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// -------------------------------------------------------------------------------------------------------------------------------
	// browser back using keyboard
	// Author: Yogendra Rathore
	// Modified By: Rakesh Sharma
	// Modified By: Rakesh Sharma
	// Changes : Changed the approach for pressing (ALT+LEFT) key. used robot
	// class in new approach becuase sendkeys approach was not working
	// Added wait after getFocusonBrowserWindow method
	// Modified By : Harshita Shaktawat
	// removed keyboard code to check if it is working fine with normal code.

	public static void browserBackUsingKeyboard() throws Exception {
		try {

			/*
			 * // addtion to find out all list of test cases
			 * System.out.println("Test Case Using keyboard events. :-" +
			 * BasePage.currentMethodName);
			 * 
			 * LibraryFunctions.focusOutOfTheField(); // get focus on browser
			 * UtilityFunctions.getFocusOnBrowserWindow();
			 * UtilityFunctions.applicationWait(1000);
			 * 
			 * Robot r = new Robot();
			 * 
			 * r.keyPress(KeyEvent.VK_ALT); r.keyPress(KeyEvent.VK_LEFT);
			 * 
			 * r.keyRelease(KeyEvent.VK_ALT); r.keyRelease(KeyEvent.VK_LEFT);
			 */

			browserBack();
			UtilityFunctions.applicationWait(1000);
		} catch (Exception e) {
			throw new Exception("LibraryFunctions : error in browserBackUsingKeyboard" + e);
		}
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// Method undo user preference for last dashboard access
	// Modifed by : Chanchal Jain
	public static void removeUserPreferenceOfDashboard() throws Exception {

		boolean closeBroswer = false;
		try {

			String query = "select up.id as id from userpreference up inner join [user] u on u.id=up.userid where u.name ='"
					+ BasePage.TestConfiguration.getProperty("UserName")
					+ "' and up.isdeleted=0 and [key] = 'LastAccessedDashboard'";

			String deleteQuery = "update UserPreference set IsDeleted=1 where id=";
			String deleteQuery1;
			ResultSet resultSet = DataBaseFunctionsLibraray.executeSelectQuery(query);
			while (resultSet.next()) {
				// set variable to true to close the browser
				closeBroswer = true;
				deleteQuery1 = deleteQuery + resultSet.getInt("id");
				UtilityFunctions.applicationWait(1000);
				int affectedRowCount = DataBaseFunctionsLibraray.executeDeleteUpdatedAndInsertQuery(deleteQuery1);
				if (affectedRowCount == 0)
					throw new SQLException();
			}

			if (closeBroswer)
				closeBrowser();

		} catch (Exception e) {
			log.error("Error Occurred: While Removing user preference." + e.getMessage());
		}
	}

	// ----------------------------------------------------------------------------------------------------------------------

	// verify Help Link
	// Author: Rakesh Sharma
	// Return true if opens correct help link
	// Modified by: Harshita Shaktawatr
	// Changed the return condition to contains
	public static boolean verifyHelpLink(String helpUrl) throws Exception {
		try {

			LibraryFunctions.focusOutOfTheField();
			// Store the current window handle
			String winHandleBefore = BasePage.driver.getWindowHandle();

			// Perform the click operation that opens new window
			LibraryFunctions.click(xPath_btnHelpButton, "", 5);
			UtilityFunctions.applicationWait(2000);

			// Switch to new window opened
			for (String winHandle : BasePage.driver.getWindowHandles()) {
				BasePage.driver.switchTo().window(winHandle);
			}

			// addtion to find out all list of test cases
			System.out.println("Test Case Using keyboard events. :-" + BasePage.currentMethodName);

			Robot r = new Robot();
			r.keyPress(KeyEvent.VK_ESCAPE);
			r.keyRelease(KeyEvent.VK_ESCAPE);
			UtilityFunctions.applicationWait(300);
			LibraryFunctions.click("//html/body", "", 5);

			String winUrl = BasePage.driver.getCurrentUrl();

			// Close the new window, if that window no more required
			BasePage.driver.close();

			// Switch back to original browser (first window)
			BasePage.driver.switchTo().window(winHandleBefore);

			return winUrl.contains(helpUrl);

		} catch (Exception e1) {
			throw new Exception("Exception On Speclimit Page -  verifyHelpLink  Method" + e1);
		}

	}

	// -----------------------------------------------------------------------------------------------------------------
	// This method gives the index of column
	// Author: Priyanka Kundu
	public static int getIndexOfGridColumn(String xPath_GridHeader, String columnName) throws Exception {
		int index = 0;
		try {
			xPath_lblGridHeader = xPath_GridHeader;
			index = getIndexOfColumn(columnName);
			return index;
		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));

		}
	}

	// ----------------------------------------------------------------------------------------------------------
	// this method scroll down or up in grid
	// Author: Yogendra Rathore
	public static void gridScroller(String dataGrid, String action, int numberOfRows) throws Exception {

		try {
			Actions act = new Actions(BasePage.driver);

			int i = 0;
			LibraryFunctions.isElementIsClickable(dataGrid + "//tr[1]//td[1]");
			UtilityFunctions.applicationWait(1000);
			if (action.equalsIgnoreCase("Down")) {
				while (numberOfRows >= i) {
					act.sendKeys(Keys.DOWN).build().perform();
					UtilityFunctions.applicationWait(500);
					i++;
				}
			} else
				while (numberOfRows >= i) {
					act.sendKeys(Keys.UP).build().perform();
					UtilityFunctions.applicationWait(500);
					i++;
				}
		} catch (Exception e) {
			log.error("Error occurred in gridscroller " + BasePage.currentMethodName);
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}

	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// Method check for 404 UI Page
	// Author Name: Rakesh Kumar Sharma
	// Added checkLoadingIconIsDisplayed
	public static boolean check404UIPageIsDisplayed() throws Exception {

		try {
			checkLoadingIconIsDisplayed("SpinningLoadingIcon", 10);
			if (LibraryFunctions.isElementDisplayed(xPath_ErrorHandlingHeader, 3)) {
				return driver.findElement(By.xpath(xPath_ErrorHandlingHeader)).getText().equals("404");
			}

		} catch (Exception ex) {
			throw new Exception(" error in Library function check404UIPageIsDisplayed method " + ex);
		}
		return false;

	}

	// --------------------------------------------------------------------------------------------------------------------------------------
	// get row count from grid
	// Author: Rakesh sharma
	public static int getRowCount(String xpathGrid) throws Exception {
		try {

			// get number of rows in grid.
			int[] numberOfRowsAndColumn = new int[2];
			numberOfRowsAndColumn = LibraryFunctions.getNumberOfColumnsAndRows(xpathGrid);

			return numberOfRowsAndColumn[1];

		} catch (Exception e) {
			throw new Exception("getRowCount " + e);
		}

	}

	// ------------------------------------------------------------------------------------------------------------------------------------------
	// Verify field in focus
	// Author : Harshita Shaktawat
	public static boolean verifyFieldInFocus(String xpath) throws Exception {
		try {

			return driver.findElement(By.xpath(xpath)).equals(LibraryFunctions.getFieldInFocus());
		} catch (Exception e) {
			throw new Exception("LibraryFunctions exception in method :verifyFieldInFocus " + e);

		}
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// Open another window and switch to newly open window.
	// user login in the new open window and intinalize a vairable with parent
	// window handle

	// Author Name: Yogendra Rathore
	public static boolean openNewWindowAndNavigateToAppURL() throws Exception {

		try {

			// addtion to find out all list of test cases
			System.out.println("Test Case Using keyboard events. :-" + BasePage.currentMethodName);
			// get focus on browser
			UtilityFunctions.getFocusOnBrowserWindow();

			Robot r = new Robot();
			r.keyPress(KeyEvent.VK_CONTROL);
			r.keyPress(KeyEvent.VK_N);

			r.keyRelease(KeyEvent.VK_N);
			r.keyRelease(KeyEvent.VK_CONTROL);

			UtilityFunctions.applicationWait(1000);

			ArrayList<String> newTab = new ArrayList<String>(driver.getWindowHandles());

			// change focus to new tab
			driver.switchTo().window(newTab.get(1));

			driver.navigate().to(BasePage.TestConfiguration.getProperty("TestSiteURL"));

			return false;

		} catch (Exception ex) {
			throw new Exception(" error in Library function openNewWindowAndLoginTheApplicaiton method " + ex);
		}

	}

	// ------------------------------------------------------------------------------------------------------------------------------------------
	// check If Entity Is Soft Deleted
	// Author : Rakesh Kumar Sharma
	// TODO: add if condition on basis of entitytype in case uniquecolumnname
	// changes
	// Modiifed by : Yogendra Rathore
	// added entry for Part revision
	// Modiifed by : Yogendra Rathore
	// added entry for Spec
	public static boolean checkIfEntityIsSoftDeleted(String entityType, String entityName) throws Exception {
		try {
			ResultSet resultSet;
			String selectQuery = "", uniqueColumName = "name";

			selectQuery = "select * from " + entityType + " where isdeleted=1 and " + uniqueColumName + " = '"
					+ entityName + "'";

			// for part revision
			if (entityType.equals("PartRevision"))
				selectQuery = "select * from partrevision pr inner join part p on p.id = pr.partid where pr.isdeleted=1 and  p.name='"
						+ entityName + "'";

			if (entityType.equals("specificationlimit"))
				selectQuery = "select * from specificationlimit where isdeleted=1 and id=" + entityName;

			if (entityType.equals("ProductionAssignment"))
				selectQuery = "select * from Productionassignment where processid=" + entityName;

			resultSet = DataBaseFunctionsLibraray.executeSelectQuery(selectQuery);
			System.out.println("8");

			return resultSet.next();

		} catch (Exception e) {
			throw new Exception("LibraryFunctions exception in method :checkIfEntityIsSoftDeleted " + e);
		}
	}

	// ------------------------------------------------------------------------------------------------------------------------------------------
	// check If its required to create data for sorting or not
	// Author : Yogendra Rathore
	public static boolean checkIfItsRequiredToCreateDataForSorting(int expectedNumberOfData) throws Exception {
		try {

			if (getNumberOfColumnsAndRows(xPath_dataGrid)[1] >= expectedNumberOfData)
				return false;
			else
				return true;

		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// ------------------------------------------------------------------------------------------------------------------------------------------
	// get tool tip of edit entity button
	// Author : Yogendra Rathore
	public static String getToolTipOfEditEntityButton(int rowNumber) throws Exception {
		try {

			return driver.findElements(By.xpath(xPath_iconEdit)).get(rowNumber - 1).getAttribute("title");

		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// ------------------------------------------------------------------------------------------------------------------------------------------
	// clear the field with keyboard event
	// Author : Rakesh Sharma
	public static void clearUsingKeyboard(String xpathOfField) throws Exception {
		try {
			LibraryFunctions.click(xpathOfField, "", 5);
			UtilityFunctions.applicationWait(500);
			if (!xpathOfField.equalsIgnoreCase(""))
				driver.findElement(By.xpath(xpathOfField)).sendKeys(Keys.chord(Keys.CONTROL, "a", Keys.BACK_SPACE));
			else
				LibraryFunctions.getFieldInFocus().sendKeys(Keys.chord(Keys.CONTROL, "a", Keys.BACK_SPACE));
			UtilityFunctions.applicationWait(100);
		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// ------------------------------------------------------------------------------------------------------------------------------------------
	// closes first notification message
	// Author : harshita shaktawat
	public static void closeFirstNotificationMessage() throws Exception {
		try {

			if (driver.findElements(By.xpath(xPath_Notification_Close)).get(0).isDisplayed())
				driver.findElements(By.xpath(xPath_Notification_Close)).get(0).click();
			else
				throw new Exception("Notification message not present");

			UtilityFunctions.applicationWait(1000);
		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// ------------------------------------------------------------------------------------------------------------------------
	// Verify Validation message occurs for fields.
	// Parameters:
	// validationMessage
	// xPath_Action = xPath of Action button
	// Author : Harshita shaktawat
	// modified by Rakesh Sharma
	// Added condition in 'for' loop to reset the elements and check for first
	// element
	public static Hashtable<String, String> checkValidationMessageWhenThereAreMultipleNotificationMessages(
			String validationMessage, String xPath_Action

	) throws Exception {
		int index = -1, numberOfValidationMessages = 0;
		Hashtable<String, String> result = new Hashtable<String, String>();
		try {
			List<WebElement> listOfNotificationMessagesElement;
			List<WebElement> listOfCrossButton;

			// click on button
			if (!xPath_Action.equals(""))
				LibraryFunctions.click(xPath_Action, "ProgressBarMarqueeIcon", 5);

			if (LibraryFunctions.isElementDisplayed(xPath_ListOf_Notification_Messages, 2)) {
				listOfNotificationMessagesElement = driver.findElements(By.xpath(xPath_ListOf_Notification_Messages));
				listOfCrossButton = driver.findElements(By.xpath(xPath_Notification_Close));
				numberOfValidationMessages = listOfNotificationMessagesElement.size();

				for (int i = 0; i < numberOfValidationMessages; i++) {
					listOfNotificationMessagesElement = driver
							.findElements(By.xpath(xPath_ListOf_Notification_Messages));
					listOfCrossButton = driver.findElements(By.xpath(xPath_Notification_Close));

					// get value of actual notification message
					if (listOfNotificationMessagesElement.get(0).getText().equals(validationMessage)) {
						index = 1;
						break;
					} else {
						driver.findElements(By.xpath(xPath_Notification_Close)).get(0).click();
					}
				}

				if (index == -1)
					result.put("Is_Validation_Message_Correct", "No");
				else {
					listOfCrossButton = driver.findElements(By.xpath(xPath_Notification_Close));
					if (LibraryFunctions.isElementDisplayed(
							UtilityFunctions.generateXPATH(listOfCrossButton.get(index - 1), ""), 1))
						driver.findElements(By.xpath(xPath_Notification_Close)).get(index - 1).click();
					else

						result.put("Is_Cross_Icon_Present", "No");
				}
				if (numberOfValidationMessages == driver.findElements(By.xpath(xPath_ListOf_Notification_Messages))
						.size())
					result.put("Is_Validation_Message_Closed", "No");

				return result;
			}

			// if notification message is not displayed
			else
				result.put("Is_Validation_Occurs", "No");

			return result;

		} // end of try
		catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// ------------------------------------------------------------------------------------------------------------------------
	// To verify validation message and also the tab error state
	// rakesh sharma
	//

	public static Hashtable<String, String> verifyValidationMessage(String xPath_Field, String validationMessage,
			String xPath_ValidationMessageHolder, String existingValue, String xPath_Action,
			String xPath_ValidationMessageCrossIcon, String xpathOfTab, String Action_Message) throws Exception {

		Hashtable<String, String> result = new Hashtable<String, String>();
		try {
			// pass existing value
			LibraryFunctions.clearUsingKeyboard(xPath_Field);
			LibraryFunctions.enterText(xPath_Field, existingValue, copyPasteEnterText);

			UtilityFunctions.applicationWait(1000);
			if (xPath_Action.equalsIgnoreCase(""))
				// focus out of the field
				LibraryFunctions.focusOutOfTheField();
			else if (xPath_Action.equalsIgnoreCase("TAB"))
				// focus out of the field
				driver.findElement(By.xpath(xPath_Field)).sendKeys(Keys.TAB);
			else
				// click on button
				LibraryFunctions.click(xPath_Action, "", 5);

			UtilityFunctions.applicationWait(1000);

			// Validation Message Check
			if (LibraryFunctions.isElementPresent(xPath_ValidationMessageHolder)) {

				if (!validationMessage
						.equals((BasePage.driver.findElement(By.xpath(xPath_ValidationMessageHolder)).getText())))
					result.put("Is_Validation_Message_Correct", "No");
				if (!(LibraryFunctions.isElementPresent(xPath_ValidationMessageCrossIcon)))
					result.put("Is_Cross_Icon_Present", "No");
				if (!xpathOfTab.equals("")) {
					if (!BasePage.driver.findElement(By.xpath(xpathOfTab)).getAttribute("class").contains("error"))
						result.put("Tab_Error_Present_WithErrorMessage", "No");
				}

				else {

					if (Action_Message.equalsIgnoreCase("Focus_Back"))
						LibraryFunctions.click(xPath_Field, "", 5);
					else {
						// check validation disappear on clicking [x] button of
						// validation
						// message
						// click on cross button
						LibraryFunctions.click(xPath_ValidationMessageCrossIcon, "", 5);
					}

					UtilityFunctions.applicationWait(1000);
					if (isElementPresent(xPath_ValidationMessageHolder))
						result.put("Is_Validation_Closed", "No");
					else if (!xpathOfTab.equals("")) {
						if (BasePage.driver.findElement(By.xpath(xpathOfTab)).getAttribute("class").contains("error"))
							result.put("Tab_Error_Present_WithoutErrorMessage", "Yes");
					}
				}
			} else
				result.put("Is_Validation_Occurs", "No");

			if (!LibraryFunctions.getFieldInFocus().equals(driver.findElement(By.xpath(xPath_Field))))
				result.put("Is_Focus_OnField", "No");

			return result;
		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// -------------------------------------------------------------------------------------------------------------------------------------
	// apply sorting on given column
	// Author -Rakesh sharma
	// Modified By : Harshita Shaktawat Date : <29-AUG-2017>
	// Added static modifier to the method
	public static void applySorting(String xPath_gridHeader, String columnName, String sortType) throws Exception {
		try {
			int columnIndex;
			List<WebElement> tableHeaderColumns = null;

			tableHeaderColumns = driver.findElements(By.xpath(xPath_gridHeader + "//th"));

			columnIndex = LibraryFunctions.getColumnNumberOnColumnHeader(xPath_gridHeader, columnName);
			String sortProperty = tableHeaderColumns.get(columnIndex - 1).getAttribute("aria-sort");

			if ((sortProperty == null && sortType.equalsIgnoreCase("DESC"))) {
				tableHeaderColumns.get(columnIndex - 1).findElement(By.tagName("a")).click();

				// wait for loading icon present on the grid
				LibraryFunctions.checkLoadingIconIsDisplayed("GridLoadingIcon", 10);

				tableHeaderColumns.get(columnIndex - 1).findElement(By.tagName("a")).click();

			} else if ((sortProperty == null && sortType.equalsIgnoreCase("ASC"))
					|| (sortProperty.equalsIgnoreCase("ascending") && sortType.equalsIgnoreCase("DESC"))
					|| (sortProperty.equalsIgnoreCase("descending") && sortType.equalsIgnoreCase("ASC")))
				tableHeaderColumns.get(columnIndex - 1).findElement(By.tagName("a")).click();

			// wait for loading icon present on the grid
			LibraryFunctions.checkLoadingIconIsDisplayed("GridLoadingIcon", 15);

		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}



	// -------------------------------------------------------------------------------------------------------------
	// get app base url
	// Author: Rakesh Sharma

	public static String getAppURL() throws Exception {
		try {
			String currentURL = BasePage.driver.getCurrentUrl();
			currentURL = currentURL.split("#")[0];
			return currentURL;

		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	
	// method to get the row number in a grid which has the data matching for
	// all given columns in the columnValuesData hashtable searches only for
	// rows as per lazy loading
	// uniqueDataColumn is the column which has most unique data (not
	// necessarily single row for that column value)

	// Author: Rakesh Sharma
	public static int getRowNumberForGivenColumnAndValueCombinations(Hashtable<String, String> columnValuesData,
			String xpath_DataGrid, String xPath_lblGridHeader, String uniqueDataColumn) throws Exception {
		Hashtable<String, String> columnValuesDataTemp = new Hashtable<String, String>();
		columnValuesDataTemp.putAll(columnValuesData);
		try {
			int columnNoUniqueColumn = LibraryFunctions.getColumnNumberOnColumnHeader(xPath_lblGridHeader,
					uniqueDataColumn);
			String valueUniqueDataColumn = columnValuesData.get(uniqueDataColumn);
			int rowNumber = getRowNumberOnBasisOfValue(xpath_DataGrid, valueUniqueDataColumn, columnNoUniqueColumn);

			while (rowNumber > 0) {
				if (checkIfRowHasMatchingData(columnValuesData, xPath_lblGridHeader, rowNumber, xpath_DataGrid)) {
					return rowNumber;
				}
				rowNumber = rowNumber + 1;
				rowNumber = getRowNumberOnBasisOfValue(xpath_DataGrid, valueUniqueDataColumn, columnNoUniqueColumn,
						rowNumber);
				columnValuesData.clear();
				columnValuesData.putAll(columnValuesDataTemp);
			}

		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
		return -1;
	}

	// -------------------------------------------------------------------------------------------------------------
	// check row number on the basis of column number and value. landing page
	// Its start searching from given row numer on grid and searches only for 52
	// rows
	// Author: Rakesh Sharma
	public static int getRowNumberOnBasisOfValue(String xPath_dataGrid, String expectedValue, int column,
			int startRowNumber) throws Exception {
		try {
			// get number of rows in grid.
			int[] numberOfRowsAndColumn = new int[2];
			numberOfRowsAndColumn = getNumberOfColumnsAndRows(xPath_dataGrid);

			for (int i = startRowNumber; i <= numberOfRowsAndColumn[1]; i++) {
				String actualValue = BasePage.driver
						.findElement(By.xpath(xPath_dataGrid + "//tr[" + i + "]//td[" + column + "]")).getText();

				if (expectedValue.equals(actualValue))
					return i;
			}
			return 0;
		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));

		}
	}

	// -------------------------------------------------------------------------------------------------------------
	// check if data in datasheet match at given row number
	// rturn true if row has matching data else return false;
	// Author: Rakesh Sharma
	public static boolean checkIfRowHasMatchingData(Hashtable<String, String> columnValuesDataTemp,
			String xPath_lblGridHeader, int rowNumber, String xPath_dataGrid) throws Exception {
		try {
			// get first column header from columnValuesDataTemp and column no
			// on grid
			// TODO : check if it works for hidden row like rowno 35
			if (columnValuesDataTemp.size() > 0) {
				String columnName = (String) columnValuesDataTemp.keySet().toArray()[0];
				int columnNoColumn = LibraryFunctions.getColumnNumberOnColumnHeader(xPath_lblGridHeader, columnName);

				// if given row has matching data for given columnName then
				// check
				// for next column else return false
				if (getValueOfGridCell(xPath_dataGrid, rowNumber, columnNoColumn)
						.equals(columnValuesDataTemp.get(columnName))) {
					columnValuesDataTemp.remove(columnName);
					if (columnValuesDataTemp.size() > 0) {
						return checkIfRowHasMatchingData(columnValuesDataTemp, xPath_lblGridHeader, rowNumber,
								xPath_dataGrid);
					} else
						return true;
				} else
					return false;
			}
			return false;

		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// Check pop over is present
	// Author Name: Rakesh Sharma
	public static boolean checkPopOverIsPresent() {
		if (LibraryFunctions.isElementDisplayed("//div[starts-with(@class,'popover fade')]", 2) || LibraryFunctions
				.isElementDisplayed("//div[starts-with(@class,'popover fade')][contains(@aria-hidden,'false')]", 10))
			return true;

		return false;
	}

	// -------------------------------------------------------------------------------------------------------------------------------
	// reload page
	// Author: Rakesh Sharma
	public static void reloadPage() throws Exception {
		try {
			if (driver != null) {
				driver.executeScript("location.reload()");
				UtilityFunctions.applicationWait(5000);

				if (!isBrowserAlertMessageIsPresent()) {
					LibraryFunctions.checkLoadingIconIsDisplayed("SpinningLoadingIcon", 60);
					LibraryFunctions.checkLoadingIconIsDisplayed("GridLoadingIcon", 60);
				}
			}
		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// -------------------------------------------------------------------------------------------------------------------------------
	// Click on More Button
	// Author: Neha Goyal
	public static boolean clickOnMoreButton() throws Exception {
		try {
			click(xPath_btnMoreNotifications, "", 5);

			UtilityFunctions.applicationWait(2000);
			System.out.println(!isElementDisplayed(xPath_btnMoreNotifications, 2));
			return !isElementDisplayed(xPath_btnMoreNotifications, 2);

		} catch (Exception ex) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), ex));

		}

	}

	// -------------------------------------------------------------------------------------------------------------
	// check tab behaviour on unsaved Confiramtion MessagePopUp
	// Author: Rakesh Sharma
	public static String checkTabBehaviourOnUnsavedChangesConfirmationPopUp() throws Exception {
		xpath_UnsavedChangePopUp = "//*[@class='modal-content']";
		try {
			if (!LibraryFunctions.isElementDisplayed(xpath_UnsavedChangePopUp + xPath_btnConfirmationCancel, 6))
				return "pop up not displayed";

			if (!LibraryFunctions.getFieldInFocus()
					.equals(driver.findElement(By.xpath(xpath_UnsavedChangePopUp + xPath_btnConfirmationCancel))))
				return "focus not on cancel";
			else {
				LibraryFunctions.getFieldInFocus().sendKeys(Keys.TAB);
				if (!LibraryFunctions.getFieldInFocus()
						.equals(driver.findElement(By.xpath(xpath_UnsavedChangePopUp + xPath_btnConfirmationOk))))
					return "focus not on ok";
				else {
					LibraryFunctions.getFieldInFocus().sendKeys(Keys.TAB);
					if (!LibraryFunctions.getFieldInFocus().equals(
							driver.findElement(By.xpath(xpath_UnsavedChangePopUp + xPath_btnConfirmationCross))))
						return "focus not on close";
				}
			}

			return "";
		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		} finally {
			LibraryFunctions.handlingConfirmationBoxMessage("Cross");
		}
	}

	// -----------------------------------------------------------------------------------------------------------------
	// This method gives the index of column even if column is hidden in grid
	// Author: Rakesh sharma
	public static int getIndexOfColumnEvenifHidden(String columnName) throws Exception {
		int numberOfColumnsInGrid, index = 0;
		try {
			boolean columnImagePresent = false;
			List<WebElement> tableHeaderColumns = BasePage.driver.findElements(By.xpath(xPath_lblGridHeader + "//th"));

			for (WebElement headerText : tableHeaderColumns) {
				if ((headerText.getText().equals(UtilityFunctions.getMultilingualData("ColumnName_Image")))) {
					tableHeaderColumns.get(0).click();
					LibraryFunctions.handlingConfirmationBoxMessage("CROSS");
					columnImagePresent = true;
					break;
				}
			}

			if (!columnImagePresent && LibraryFunctions.isElementDisplayed(xPath_dataGrid + "//tr[1]//td[1]", 3)) {
				/*
				 * BasePage.driver.findElement( By.xpath(xPath_dataGrid +
				 * "//tr[1]//td[1]")).click();
				 * LibraryFunctions.handlingConfirmationBoxMessage("CROSS");
				 */

				if (LibraryFunctions.isElementIsClickable(xPath_dataGrid + "//tr[1]//td[1]"))
					LibraryFunctions.handlingConfirmationBoxMessage("CROSS");
				else if (LibraryFunctions.isElementIsClickable(xPath_lblGridHeader + "//tr[1]//td[1]"))
					LibraryFunctions.handlingConfirmationBoxMessage("CROSS");
			}

			Actions act = new Actions(BasePage.driver);
			// verify column is displayed on landing page
			numberOfColumnsInGrid = tableHeaderColumns.size();

			for (int i = 0; i < numberOfColumnsInGrid; i++) {
				if (!tableHeaderColumns.get(i).getAttribute("style").contains("none")) {
					if (columnName.equalsIgnoreCase(tableHeaderColumns.get(i).getText())) {
						index = i + 1;
						break;
					}

					act.sendKeys(Keys.RIGHT).build().perform();
				}
			}

			return index;
		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));

		}
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// drag source element to target locator
	// Modifed by : Rakesh Sharma
	public static void dragAndDrop(String xPath_SourceElement, String xPath_TargetLocator) throws Exception {
		try {
			Actions action = new Actions(driver);

			// To get source locator
			WebElement sourceLocator = driver.findElement(By.xpath(xPath_SourceElement));
			// To get target locator
			WebElement targetLocator = driver.findElement(By.xpath(xPath_TargetLocator));
			// dragAndDrop(source, target) method accepts two parameters source
			// and locator.
			// used dragAndDrop method to drag and drop the source locator to
			// target locator
			action.dragAndDrop(sourceLocator, targetLocator).build().perform();

		} catch (Exception e) {

			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// Check multi select drop down is open
	// Author Name: Rakesh Sharma
	public static boolean checkMultiSelectDropDownIsOpen() {

		if (LibraryFunctions.isElementDisplayed(xpath_SelectEntityPage_Search_MulitSelectDropDown, 3))
			return true;

		return false;
	}

	// -------------------------------------------------------------------------------------------------------------
	// scroll for element in grid, return false if element not found or not able
	// to scroll
	// modified by : Rakesh
	public static boolean scrollInGridByElementVisibility(String xPath_Element) throws Exception {
		try {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			WebElement Element = driver.findElement(By.xpath(xPath_Element));
			js.executeScript("arguments[0].scrollIntoView();", Element);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	// -------------------------------------------------------------------------------------------------------------
	// check value of cell of grid on part landing page and also handle scroll
	// only use when need specific scroll
	// Author: Rakesh Sharma
	public static String getValueOfGridCellWithScroll(String xPath_dataGrid, int row, int column) throws Exception {
		try {
			scrollInGridByElementVisibility(xPath_dataGrid + "//tr[" + row + "]//td[" + column + "]");
			if (LibraryFunctions.isElementDisplayed(xPath_dataGrid + "//tr[" + row + "]//td[" + column + "]", 5)) {

				if (LibraryFunctions.isElementDisplayed(xPath_dataGrid + "//tr[" + row + "]//td[" + column + "]"
						+ "//span//span[ not(@style='display: none;')]", 1))
					return BasePage.driver.findElement(By.xpath(xPath_dataGrid + "//tr[" + row + "]//td[" + column + "]"
							+ "//span//span[ not(@style='display: none;')]")).getText();
				else
					return BasePage.driver
							.findElement(By.xpath(xPath_dataGrid + "//tr[" + row + "]//td[" + column + "]")).getText();
			}

			return "Cell Doesn't exist";
		} catch (Exception e) {
			throw new Exception("error in getValueOfGridCell" + e);
		}
	}

	// -------------------------------------------------------------------------------------------------------------
	// check row number on the basis of column number and containing a unique
	// value. cell data can have extra string too. landing page
	// Its searches only for 52 rows
	// Author: Rakesh Sharma

	public static int getRowNumberOnBasisOfContainsValue(String xPath_dataGrid, String expectedValue, int column)
			throws Exception {
		try {
			// get number of rows in grid.
			int[] numberOfRowsAndColumn = new int[2];
			numberOfRowsAndColumn = getNumberOfColumnsAndRows(xPath_dataGrid);

			for (int i = 1; i <= numberOfRowsAndColumn[1]; i++) {
				String actualValue = BasePage.driver
						.findElement(By.xpath(xPath_dataGrid + "//tr[" + i + "]//td[" + column + "]")).getText();

				if (actualValue.contains(expectedValue))
					return i;

			}

			return 0;
		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));

		}

	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// reset UserResponsibilityLevel
	// Modifed by : Rakesh Sharma
	public static void resetUserResponsibility() throws Exception {
		try {
			String query = "select id from [user] where name in ('" + BasePage.current_LoggedIn_User + "','"
					+ BasePage.excel_User + "')";

			ResultSet resultSet = DataBaseFunctionsLibraray.executeSelectQuery(query);
			while (resultSet.next()) {
				String deleteQuery = "delete from UserResponsibilityLevel where UserId=" + resultSet.getInt("id");
				DataBaseFunctionsLibraray.executeDeleteUpdatedAndInsertQuery(deleteQuery);
			}
		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
	}

	// -------------------------------------------------------------------------------------------------------------
	// check value of cell of grid
	// Author: Rakesh Sharma
	public static Hashtable<String, String> getColumnIndexesOnColumnHeader(String xPath_HeaderOfGrid,
			String headerPresentAtFirst) throws Exception {
		Hashtable<String, String> listColumnAndIndex = new Hashtable<String, String>();
		String xPath_dataGrid = xPath_HeaderOfGrid;
		xPath_dataGrid="//*[@class='k-grid-header-wrap']";
		try {
			// handling scroll right
			if (LibraryFunctions.checkPopupIsPresent())
				xPath_dataGrid = "//*[@data-selector='popup1']" + xPath_dataGrid;
			int numberOfColumns;
			List<WebElement> tableHeaderRows = null;
			tableHeaderRows = BasePage.driver.findElements(By.xpath(xPath_dataGrid + "//th"));
			// get number of columns
			numberOfColumns = tableHeaderRows.size();
			String xpathToRefer = "";

			boolean isXpathFound = false;
			String actualValue = "LRL";
			int colNum = 1;

			for (colNum = 1; colNum <= numberOfColumns; colNum++) {
				xpathToRefer = "";
				if (!actualValue.equals(""))
					scrollInGridByElementVisibility(xPath_dataGrid + "//tr/th[" + colNum + "]");

				if (LibraryFunctions.isElementDisplayed(xPath_dataGrid + "//tr/th[" + colNum + "]//span", 1)) {
					xpathToRefer = xPath_dataGrid + "//tr/th[" + colNum + "]//span";
				} else if (LibraryFunctions.isElementDisplayed(xPath_dataGrid + "//tr/th[" + colNum + "]", 1)) {
					xpathToRefer = xPath_dataGrid + "//tr/th[" + colNum + "]";
				}

				if (!xpathToRefer.equals("")) {
					actualValue = BasePage.driver.findElement(By.xpath(xpathToRefer)).getText();

					if (actualValue.equals(""))
						actualValue = BasePage.driver.findElement(By.xpath(xPath_dataGrid + "//tr/th[" + colNum + "]"))
								.getAttribute("data-title");

					if (actualValue != null) {
						actualValue = actualValue.replace("<b>", "");
						actualValue = actualValue.replace("</b>", "");
					}

					if (actualValue.equals(headerPresentAtFirst)) {
						isXpathFound = true;
					}
					if (isXpathFound) {
						listColumnAndIndex.put(actualValue, Integer.toString(colNum));
					}
				}
			}

			if (!isXpathFound) {
				for (colNum = 1; colNum <= numberOfColumns; colNum++) {
					scrollInGridByElementVisibility(xPath_dataGrid + "//tr/th[" + colNum + "]");
					if (LibraryFunctions.isElementDisplayed(xPath_dataGrid + "//tr/th[" + colNum + "]", 1))
						actualValue = BasePage.driver.findElement(By.xpath(xPath_dataGrid + "//tr/th[" + colNum + "]"))
								.getAttribute("data-title");
					if (actualValue != null) {
						actualValue = actualValue.replace("<b>", "");
						actualValue = actualValue.replace("</b>", "");
						listColumnAndIndex.put(actualValue, Integer.toString(colNum));
					}
				}
			}
		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}
		return listColumnAndIndex;
	}

	// ---------------------------------------------------------------------------------------------------------------------
	// This method whether webelement is clickable
	// author : Yogendra rathore
	public static boolean isElementIsClickable(WebElement element) throws Exception {
		try {

			if (element.isDisplayed()) {
				element.click();
				UtilityFunctions.applicationWait(1000);
				return true;
			} else
				return false;
		} catch (Exception e) {
			return false;
		}
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	// This method is used to click on a given webelement by first focusing out
	// Author Name: Yamini Jain

	public static void click(WebElement element, String loadingIconType, int waitTimeInSec) throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(BasePage.driver, waitTimeInSec);
			if (wait.until(ExpectedConditions.visibilityOf(element)) != null) {

				if (!isElementIsClickable(element)) {
					LibraryFunctions.setVerticalScrollBar("UP");
					LibraryFunctions.setVerticalScrollBar("UP");
					LibraryFunctions.focusOutOfTheField();
					element.click();
				}
			} else
				throw new Exception("Element not located within timeout");
			if (loadingIconType != "")
				checkLoadingIconIsDisplayed(loadingIconType, waitTimeInSec);

		} catch (Exception e) {
			throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));
		}

	}

}// end of class
