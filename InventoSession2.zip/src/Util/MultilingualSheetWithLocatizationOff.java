/*
 * package Util;
 * 
 * import java.util.Hashtable;
 * 
 * public class MultilingualSheetWithLocatizationOff {
 * 
 * public static final Hashtable<String, String> MultilingualSheetEntries = new
 * Hashtable<String, String>() { {
 * 
 * put("ShortnameUniquenessValidationMessage", "Short name already exists.");
 * put("Code_Already_Exists", "Code Name already exists.");
 * put("CodeGroup_Already_Exists", "Code Group already exists.");
 * put("Required", "Required"); put("RevisionnameUniquenessValidationMessage",
 * "Part revision already exists."); put("InvalidFormatValidationMessage",
 * "Invalid format."); put("ResetPasswordLinkSendSuccessfully",
 * "Please check your registered e-mail for the link to reset your password.");
 * put("InvalidLoginCredentials",
 * "Invalid Login Credentials. Please try again.");
 * put("ProcessState_Already_Exists", "Process state already exists.");
 * put("ForgotPassword_DefaultMessage",
 * "To change your password, enter the user id used for login. A link will be sent to the registered email id."
 * ); put("UsernameUniquenessValidationMessage", "Username already exists.");
 * put("EmaiUniquenessValidationMessage", "Email ID already exists.");
 * put("SaveSuccessfullyMessage", "<Element Name> saved successfully.");
 * put("ProcessState_Configurations_Save_Successfully",
 * "Process state configurations saved successfully.");
 * put("AccountDeactivationMessage",
 * "Your account has been deactivated. Please contact your administrator.");
 * put("ForgotPasswordLinkSendSuccessfully",
 * "Link to reset password has been sent to the registered email id.");
 * put("PartCountMessage", "<count> Parts Selected"); put("ProcessCountMessage",
 * "<count> Process Selected"); put("ParameterSet_NoProcessMessage",
 * "Any Process"); put("ParameterSet_NoFeatureMessage", "Any Feature");
 * put("FeatureCountMessage", "<count> Feature Selected");
 * put("TagValueAlreayExists", "Tag already exists.");
 * put("ParameterSet_NoPartMessage", "Any Part");
 * put("ParameterSet_NoCodeMessage", "Any Code"); put("CodeCountMessage",
 * "<count> Code Selected"); put("ParameterSet_SelectedParts",
 * "Parts Selected:"); put("ParameterSet_NoTagMessage", "Any Tag");
 * put("ParameterSet_SelectedTags", "Select Tags");
 * put("MultiProcessCountMessage", "<count> Processes Selected");
 * put("SinglePartCountMessage", "<count> Part Selected");
 * put("MultiFeatureCountMessage", "<count> Features Selected");
 * put("EndDateSmallerThanStartDate",
 * "End Date/Time cannot be smaller than Start Date/Time.");
 * put("Part_AlreadyExists", "Part already exists.");
 * put("ValidationMessageForInvalidImage",
 * "File not uploaded. Invalid image format.");
 * put("ValidationMessageForGreaterThan600KBImage",
 * "File not uploaded. Size exceeds 600 KB.");
 * put("ValidationMessage_CreateSpecificationPage",
 * "Missing/Incorrect Information ! Correct or cancel them before saving.");
 * put("AccordionItem_OnlyInputPart",
 * "Part recipe(s) having this part revision as the only input part will be removed. Impacted part recipe"
 * ); put("AccordionItem_OnlyOutputPart",
 * "Part recipe(s) having this part revision as a single output part will be removed. Impacted part recipe"
 * ); put("Feature_DeleteConfirmaitonMessageWithAssociations",
 * "On removal of feature, following associations will also be removed:");
 * put("SpecLimit_DeleteConfirmaitonMessage",
 * "Do you want to remove manufacturing limit record for <Part,Revision,Feature,Lot,Process> combination?"
 * ); put("Part_DeleteConfirmaitonMessageWithAssociations",
 * "On removal of part revision, following associations will also be removed:");
 * put("Part_DeleteConfirmaitonMessageWithOutAssociations",
 * "Do you want to remove <PartName,Revision>?");
 * put("Tag_DeleteConfirmaitonMessageWithAssociations",
 * "On removal of tag, following associations will be impacted:");
 * put("Feature_DeleteConfirmaitonMessageWithOutAssociations",
 * "Do you want to remove <Element Name>?");
 * put("CollectionAid_DeleteConfirmationMessage",
 * "Do you want to remove part feature details record for <Part,Revision,Feature> combination?"
 * ); put("RemovedSuccessfullyMessage",
 * "<Element Removed> removed successfully.");
 * put("Process_DeleteConfirmaitonMessageWithAssociations",
 * "On removal of process, following associations will also be removed:");
 * put("ConfirmationMessageForUnsavedData",
 * "Do you want to navigate away from this page? You will lose the unsaved changes."
 * ); put(
 * "EditPartRevision_ConfirmationMessageForUnsavedDataOnClickingCreateSpecButton"
 * , "Do you want to save part revision changes before navigating away?");
 * put("ValidationDisplayedOnGivingEndDateLessThanStartDate",
 * "Activation Start Date & Time can�t be greater than the Activation End Date & Time."
 * ); put("ConfirmationMessage_EditFeaturePage",
 * "Do you want to save part revision changes before navigating away?");
 * put("AccordionItem_AssignedODMessage_Feature",
 * "Assigned to process model - operation");
 * put("AccordionItem_AssignedDCMessage_Feature",
 * "Assigned to data collection definition");
 * put("AccordionItem_AssignedProcessMessage_Tag", "Assigned to Process");
 * put("AccordionItem_AssignedPartMessage_Tag", "Assigned to Part");
 * put("AccordionItem_AssignedFeatureMessage_Tag", "Assigned to Feature");
 * put("AccordionItem_AssignedCodeMessage_Tag", "Assigned to Code");
 * put("AccordionItem_AssignedUserMessage_Tag", "Assigned to User");
 * put("AccordionItem_AssignedCodeGroupMessage_Tag", "Assigned to Code Group");
 * put("Feature_SpecLimit_ConfirmationMessage",
 * "Do you want to save feature changes before navigating away?");
 * put("TagGroup_DeleteConfirmaitonMessageWithAssociations",
 * "On removal of tag group, following associations will be impacted:");
 * put("Feature_SubGroup_ConfirmationMessage",
 * "Associated subgroup data collection entry records may be impacted.");
 * put("SubGroup_ConfirmationMessage",
 * "Associated subgroup data collection records may be impacted.");
 * put("Part_SubGroup_ConfirmationMessage",
 * "Impacted subgroup data collection"); put("ConfirmatioPopUp_MessageHeader",
 * "Confirmation Message");
 * put("ConfirmationMessageForTotalCountGreaterThanSubGroupSize",
 * "Entered Value is greater than subgroup size.");
 * put("ConfirmationMessage_ParametSetSelectEntityPage_Dynamic_Feature",
 * "Existing Feature selections will be lost. Are you sure you want to switch selection mode to Dynamic?"
 * ); put("ConfirmationMessage_ParametSetSelectEntityPage_Dynamic_Process",
 * "Existing Process selections will be lost. Are you sure you want to switch selection mode to Dynamic?"
 * ); put("ConfirmationMessage_ParametSetSelectEntityPage_Static_Feature",
 * "Existing Feature selections will be lost. Are you sure you want to switch selection mode to Static?"
 * ); put("ConfirmationMessage_ParametSetSelectEntityPage_Static_Process",
 * "Existing Process selections will be lost. Are you sure you want to switch selection mode to Static?"
 * ); put("AccordionItem_AssignedParameterSetMessage_Tag",
 * "Assigned to parameter set");
 * put("ConfirmationMessage_ParametSetSelectEntityPage_Dynamic_Part",
 * "Existing Part selections will be lost. Are you sure you want to switch selection mode to Dynamic?"
 * ); put("ConfirmationMessage_ParametSetSelectEntityPage_Static_Part",
 * "Existing Part selections will be lost. Are you sure you want to switch selection mode to Static?"
 * ); put("ValidationDisplayedOnGivingCreateToDateLessThanFromDate",
 * "From Date can't be greater than To Date."); put("SingleDCModalBoxMessage",
 * "(<Count> data collection definition exists.)"); put("DCModalBoxMessage",
 * "(<Count> data collection definitions exist.)");
 * put("SpecLimitModalBoxMessage", "(<Count> manufacturing limits exist.)");
 * put("SingleSpecLimitModalBoxMessage",
 * "(<Count> Manufacturing Limit exists.)"); put("OperationModalBoxMessage",
 * "(<Count> operations exist.)"); put("SinglePartRecipeModalBoxMessage",
 * "(<Count> part recipe exists.)"); put("PartRecipeModalBoxMessage",
 * "(<Count> part recipes exist.)"); put("OperationDiagramModalBoxMessage",
 * "(<Count> process models exist.)");
 * put("SingleOperationDiagramModalBoxMessage",
 * "(<Count> process model exists.)");
 * put("Process_Can'tBeDeletedMessage_OnlyProcess",
 * "Process <Process Name> can't be removed as it is the only process at this level."
 * ); put("Process_Can'tBeDeletedMessage",
 * "Process <Entity Name> can't be removed as child processes are associated with it:"
 * ); put("TagModalBoxMessage", "(<Count> tags exist.)");
 * put("SingleTagModalBoxMessage", "(<Count> tag exists.)");
 * put("SingleDCDefModalBoxMessage",
 * "(<Count> data collection definition exists.)"); put("DCDefModalBoxMessage",
 * "(<Count> data collection definitions exist.)");
 * put("ModalBox_PartRecipe_Title", "View Part Recipe");
 * put("PromptForSampleSize", "Prompt for Sample Size"); put("OnStart",
 * "On Start"); put("OnSave", "On Save"); put("SampleSizeValidatonMessage",
 * "Sample Size must be greater than or equal to <SampleSize>");
 * put("SytemEnteredSampleTime", "System Entered Sample Time");
 * put("UserEnteredSampleTime", "User Entered Sample Time");
 * put("TimeStamp_ValidationForFutureDate",
 * "Entered timestamp must be less than or equal to the current timestamp.");
 * put("EnterSampleTime", "Enter Sample Time");
 * 
 * put("ModalBox_OperationDiagram_Title", "View Process Model");
 * put("SingleOperationModalBoxMessage", "(<Count> operation exists.)");
 * put("ProcessPage_TagCount_MulitpleTag_Message",
 * "Process: <ProcessName> (<TagCount> tags exist.)");
 * put("Unauthorized_Access_Page_Message",
 * "You don't have permission to view this page.");
 * put("ProcessPage_TagCount_SingleTag_Message",
 * "Process: <ProcessName> (1 tag exists.)");
 * put("SaveSuccessfullyMessageForLimit",
 * "Limit of <PartName> - <FeatureName> saved successfully.");
 * put("Password_Change_Successful", "Password reset successfully");
 * put("UserConfiguredTagSaveSuccessfullyMessage",
 * "User configured fields saved successfully"); put("ModalBox_SpecLimit_Title",
 * "View Manufacturing Limit"); put("AllowModification", "Allow Modification");
 * put("SpecNotificationMessage",
 * "Display Scale,Highlight Grid Notification,Highlight Popup Notification,Play sound when a gauge value is entered Notification Rule(s)"
 * ); put("ModalBox_DC_Title", "View Data Collection Definition");
 * put("PS_SelectCodeHeaderTitle", "Select Codes (to include)");
 * put("PS_SelectProcessPopUpHeader_OpeationTitle",
 * "Operation - Selected Processes"); put("PS_SelectedProcessPopUpHeader_Title",
 * "Selected Processes"); put("AccordionItem_AssignedODMessage",
 * "Assigned to process model - part family");
 * put("AccordionItem_ImpactedPartRecipe", "Impacted Part recipe");
 * put("Default_ParentProcess", "Default");
 * 
 * put("actualAccordionItem_AssignedSpecLimitMessage_Feature",
 * "Assigned to Manufacturing Limit"); put("AccordionItem_AssignedSpecLimit",
 * "Assigned to Manufacturing Limit"); put("Create_Feature_Page_Title",
 * "Create Feature"); put("Spec_Page_Title", "Create Limit");
 * put("Unauthorized_Access_Page_Title", "Unauthorized Access");
 * put("Role_Header_Title", "Roles"); put("Create_Role_Page_Title",
 * "Create Role"); put("Individual_Settings_Page_Title", "Individual Settings");
 * put("Create_Part_Page_Title", "Create Part");
 * put("Set_Process_State_Page_Title", "Set State");
 * put("Create_Part_Revision_Page_Title", "Create Part Revision");
 * put("CodeGroup_Page_Title", "Create Code Group"); put("UserLandingPageTitle",
 * "Users"); put("Edit_Limit_Page_Title", "Edit Limit");
 * put("Edit_CodeGroup_Page_Title", "Edit Code Group");
 * put("Create_Process_Page_Title", "Create Process");
 * put("ManualDCLandingPageTitle", "Data Collections");
 * put("TagGroup_Page_Title", "Create Tag Group");
 * put("Configure_User_Tags_Title", "Configure Fields");
 * put("ModalBox_ViewCode_Title", "View Code"); put("Create_User_Page_Title",
 * "Create User"); put("DCTagPopUpTitle_AllPieces", "All Pieces - Add Tags");
 * put("CollectionAids_Page_Title", "Part Feature Details");
 * put("Create_CollectionAids_Page_Title", "Create Part Feature Details");
 * put("Edit_CollectionAids_Page_Title", "Edit Part Feature Details");
 * put("TagCount", "Tag 1 of 1"); put("ParameterSet_Page_Title",
 * "Create Parameter Set"); put("ModalBox_Operation_Title", "View Operation");
 * put("ModalBox_Tag_Title", "View Tag"); put("SelectProcessEntity_Page_Title",
 * "Select Processes (to include)"); put("ModalBox_Reset_Password",
 * "Reset Password"); put("ModalBox_Change_Password", "Change Password");
 * put("Part_Header_Title", "Parts"); put("Process_Header_Title", "Processes");
 * put("Spec_Header_Title", "Manufacturing Limits"); put("Feature_Header_Title",
 * "Features"); put("DataCollectionConfiguration_Header_Title",
 * "Data Collection Configurations"); put("DataCollection_Header_Title",
 * "Data Collections"); put("CodeGroup_Header_Title", "Code Groups");
 * put("TagGroup_Header_Title", "Tag Groups");
 * put("PartRecipeQuickAddition_Header_Title", "Part Recipe Management");
 * put("DCSetting_Header_Title", "Settings"); put("Process_States_Grid_Title",
 * "Active Process States"); put("Configure_Process_States_Page_Title",
 * "Configure Process States"); put("PartRevision_Header_Title",
 * "Part Revisions"); put("Process_States_Header_Title", "Process States");
 * put("Dashboard_Header_Title", "Dashboard");
 * put("Dashboard_Header_Title_Spanish", "Tableros de Control");
 * 
 * put("ColumnName_Piece", "Piece"); put("ParameterSet_Header_Title",
 * "Parameter Sets"); put("GridProcessSelectedEntity", "Processes Selected:");
 * put("SelectProcessEntity_Header_Title", "Select Processes");
 * put("SelectFeatureEntity_Header_Title", "Select Features");
 * put("SelectPartsEntity_Header_Title", "Select Parts");
 * 
 * put("ResponseGroupNotExist", "Response group doesn't exist.");
 * put("ControlLimit_Header_Title", "Control Limits");
 * put("ColumnName_PartRevision", "Revision"); put("ColumnName_Part_Name",
 * "Part Name"); put("ColumnName_USL", "USL"); put("ColumnName_LSL", "LSL");
 * put("ColumnName_Target", "Target"); put("ColumnName_FeatureName",
 * "Feature Name"); put("ColumnName_FeatureName_Spec", "Feature (Variable)");
 * put("ColumnName_Lot", "Lot"); put("ColumnName_Process", "Process");
 * put("ColumnName_URL", "URL"); put("ColumnName_UWL", "UWL");
 * put("ColumnName_LWL", "LWL"); put("ColumnName_LRL", "LRL");
 * put("ColumnName_UWP", "UWP"); put("ColumnName_LWP", "LWP");
 * put("ColumnName_USG", "USG"); put("ColumnName_LSG", "LSG");
 * put("ColumnName_TagGroup", "Tag Group"); put("ColumnName_CurrentState_Part",
 * "Current State"); put("ColumnName_PreviousState_Part", "Previous State");
 * put("ColumnName_ProcessState", "Process State"); put("ColumnName_StateType",
 * "State Type"); put("ColumnName_ChangeIntitiation", "Change Initiation");
 * put("ColumnName_MAVUpper", "MAV Upper"); put("ColumnName_Max_MAVUpper",
 * "Max % > MAV Upper"); put("ColumnName_MAV_LSC", "MAV - LSC");
 * put("ColumnName_MAVLower", "MAV Lower"); put("ColumnName_Max_MAVLower",
 * "Max % < MAV Lower"); put("ColumnName_T2Upper", "T2 Upper");
 * put("ColumnName_T1Upper", "T1 Upper"); put("ColumnName_T1T2Upper",
 * "Max % between T1T2 Upper"); put("ColumnName_Max_T2Upper",
 * "Max % > T2 Upper"); put("ColumnName_T1T2_LSC", "T1T2 - LSC");
 * put("ColumnName_T1Lower", "T1 Lower"); put("ColumnName_T2Lower", "T2 Lower");
 * put("ColumnName_Max_BetweenT1T2Lower", "Max % between T1T2 Lower");
 * put("ColumnName_MaxT2Lower", "Max % < T2 Lower");
 * put("ColumnName_UpdatedDate", "Updated Date");
 * put("ColumnName_LastUpdatedBy", "Last Updated by");
 * put("ColumnName_CreationDate", "Creation Date"); put("ColumnName_CreatedBy",
 * "Created by"); put("ColumnName_Image", "Image");
 * put("ColumnName_FeatureType", "Feature Type"); put("ColumnName_Tag", "Tag");
 * put("ColumnName_DataCollection", "Data Collection");
 * put("ColumnName_SpecificationLimit", "Manufacturing Limit");
 * put("ColumnName_Operation", "Operation"); put("ColumnName_ProcessName",
 * "Process Name"); put("ColumnName_ProcessCategory", "Process Category");
 * put("ColumnName_OperationDiagram", "Process Model"); put("ColumnName_Status",
 * "Status"); put("ColumnName_PartRecipe", "Part Recipe");
 * 
 * put("ColumnName_Units", "Units"); put("ColumnName_DataCollectionDefinition",
 * "Data Collection Definition"); put("ColumnName_OperationDiagramName",
 * "Process Model Name"); put("ColumnName_Feature", "Feature");
 * put("ColumnName_PartFamily", "Part Family"); put("ColumnName_Code", "Code");
 * put("ColumnName_CodeGroup", "Code Group"); put("ColumnName_Active",
 * "Active"); put("ColumnName_CodeName", "Code Name"); put("ColumnName_Role",
 * "Role"); put("ColumnName_Supervisor_Name", "Supervisor Name");
 * put("ColumnName_Preferred_Language", "Preferred Language");
 * put("ColumnName_Username", "Username"); put("ColumnName_Email", "Email ID");
 * put("ColumnName_Access_Level", "Access Level"); put("ColumnName_Name",
 * "Name"); put("ColumnName_Weight", "Weight"); put("ColumnName_TagType",
 * "Tag Type"); put("ColumnName_TextingNumber", "Texting No.");
 * put("ColumnName_TagGroupName", "Tag Group Name");
 * put("ColumnName_PartFamilyTitle", "<Element Name> Part Families");
 * put("ColumnName_Part", "Part"); put("ColumnName_ CollectionAid",
 * "Part Feature Details");
 * 
 * put("ColumnName_ParentPrcoessName", "Parent Process");
 * put("ColumnName_Part_Family", "Part Family - Name");
 * put("PartNotExistsValidationMessage", "Part doesn't exist.");
 * put("ColumnName_ParameterSetName", "Parameter Set Name");
 * put("ColumnName_Summary", "Summary"); put("ColumnName_Criteria", "Criteria");
 * put("ColumnName_AssignedWorkDashboard", "Assigned Work Dashboard");
 * put("ManualDCLandingPageGridHeader", "Data Collection Name");
 * put("ColumnName_SelectedFeature", "Selected Features");
 * put("CodeGroupNotExist", "Code group doesn't exist.");
 * put("ContextMenuUploadImage", "Upload Image"); put("ContextMenuChangeImage",
 * "Change Image"); put("ContextMenuRemoveImage", "Remove Image");
 * put("LandingPage_ContextMenu_CreatePartRevisionIconText", "Create Revision");
 * put("LandingPage_ContextMenu_HistoryIconText", "History");
 * put("LandingPage_ContextMenu_RemoveIconText", "Remove");
 * put("StateType_Idle", "Idle"); put("StateType_Pause", "Pause");
 * put("StateType_Run", "Run"); put("StateType_ScheduledDown",
 * "Scheduled Down"); put("StateType_Start", "Start"); put("StateType_Stop",
 * "Stop"); put("StateType_UnscheduledDown", "Unscheduled Down");
 * put("TagType_Numeric", "Numeric"); put("TagType_Textual", "Textual");
 * put("Status_Active", "0 - Active"); put("Status_Inactive", "1 - Inactive");
 * put("Status_Inactive_User", "0 - Invalid assignee.");
 * put("FeatureType_Variable", "Variable"); put("FeatureType_Defect", "Defect");
 * put("FeatureType_Defective", "Defective"); put("FeatureType_CheckList",
 * "Checklist"); put("ChangeIntitiation_Manual", "0 - Manual");
 * put("FeatureType_Time", "Time"); put("ChangeIntitiation_Automatic",
 * "2 - Automatic"); put("ChangeIntitiation_Event", "1 - Event");
 * put("ParameterSetTimeZone_Latest", "Latest");
 * put("ParameterSetTimeZone_Current", "Current");
 * put("ParameterSetTimeZone_Earlier", "Earlier");
 * put("ParameterSetTimeUnit_Minute", "Minute(s)");
 * put("ParameterSetTimeUnit_Hour", "Hour(s)"); put("ParameterSetTimeUnit_Day",
 * "Day(s)"); put("ParameterSetTimeUnit_Week", "Week(s)");
 * put("ParameterSetTimeUnit_Month", "Month(s)");
 * put("ParameterSetTimeUnit_Quarter", "Quarter(s)");
 * put("ParameterSetTimeUnit_Year", "Year(s)"); put("TimeSelectionType_Dynamic",
 * "Dynamic"); put("TimeSelectionType_Static", "Static");
 * put("Module_PartRevision", "Part Revision"); put("Module_Part", "Part");
 * put("ResponseType_SingleAnswer", "1 - Single Answer");
 * put("ResponseType_MultipleAnswer", "2 - Multiple Answer");
 * put("FilterButtonTitle", "Filters"); put("BackButton", "Back");
 * put("ColumnName_ConfigureColumnTitle", "Configure Columns");
 * put("CodeGroup_AddCodes", "Add Codes"); put("CodeGroup_CheckBoxLabel",
 * "Lock list during use"); put("Lable_SampleSize", "Sample Size");
 * 
 * put("LBL_All_Pieces", "All Pieces"); put("Lable_Edit", "Edit");
 * put("Lable_Delete", "Delete"); put("Condition_And", "AND");
 * put("Condition_OR", "OR"); put("Condition_XOR", "OR");
 * put("Condition_Is_Not", "is not"); put("Condition_State_Is", "State is");
 * put("Condition_State_Is_Not", "State is not"); put("Condition_Between",
 * "Between"); put("TotalCount", "Total : <count>"); put("Condition_Equals",
 * "Equals"); put("Condition_Is", "is"); put("Label_Part", "Part");
 * put("LicenseType_Username", "Username"); put("LicenseType_Workstation",
 * "Workstation"); put("SelectFeature_Exclude", "Select Features (to exclude)");
 * put("SelectPart_Exclude", "Select Parts (to exclude)");
 * put("SelectProcess_Exclude", "Select Processes (to exclude)");
 * put("SelectTag_Exclude", "Select Tags (to exclude)");
 * put("SelectFeature_Include", "Select Features (to include)");
 * put("SelectPart_Include", "Select Parts (to include)");
 * put("SelectProcess_Include", "Select Processes (to include)");
 * put("SelectTag_Include", "Select Tags (to include)");
 * put("ColumnName_SelectAll", "Select All"); put("Lable_Process", "Process");
 * put("AssignedDashboard_No", "No"); put("ParameterSet_None", "None");
 * put("ParameterSet_TagNotExists", "Tag Group doesn't exist.");
 * put("GridFeatureSelectedEntity", "Features Selected:"); put("To", "To");
 * put("SelectCode_Exclude", "Select Codes (to exclude)");
 * put("HelperText_TypeSelect", "Type/Select"); put("HelperText_Select",
 * "Select"); put("No_Record_Found", "No Record Found");
 * put("Password_Guidelines", "Password Rules" + "\n" +
 * "Minimum Password Length (characters): 8" + "\n" +
 * "Password must contain the following :" + "\n" +
 * "At least one numeric character" + "\n" +
 * "At least one upper and lower case character" + "\n" +
 * "At least one of the following special characters [ ] ? / < > ~ # ` ! @ _ - $ % ^ & * ( ) + = { } | : \" ; ' ,"
 * + "\n" + "Selected password cannot be reused before 365 days");
 * put("Password_Guidelines_Change_Password", "Password Rules" + "\n\n" +
 * "Password must contain the following:" + "\n" +
 * "Password must contain the following :" + "\n" +
 * "At least one numeric character" + "\n" +
 * "At least one upper and lower case character" + "\n" +
 * "At least one of the following special characters {}[]^$@%()..." + "\n" +
 * "New Password must not be the same as any of the previous 5 passwords");
 * put("HelperText_Type", "Type"); put("PS_FilterCountText", "filter applied");
 * put("CodeName_PlaceHolder", "Enter Code");
 * put("USL_gt_LRL_LWL_Target_UWL_ErrorMessage",
 * "USL must be greater than the LRL, LWL, Target and UWL");
 * put("Target_lt_USL_ErrorMessage", "Target must be less than USL");
 * put("UWL_lt_USL_ErrorMessage", "UWL must be less than USL");
 * put("LWL_lt_USL_ErrorMessage", "LWL must be less than USL");
 * put("LRL_lt_USL_ErrorMessage", "LRL must be less than USL");
 * put("URL_gt_Target_UWL_USL_ErrorMessage",
 * "URL must be greater than the Target, UWL and USL");
 * put("LSL_lt_LWL_Target_UWL_URL_ErrorMessage",
 * "LSL must be less than the LWL, Target, UWL, USL and URL");
 * put("LSG_lt_USG_ErrorMessage", "LSG must be less than USG");
 * put("USG_gt_LSG_ErrorMessage", "USG must be greater than LSG");
 * put("LWP_lt_UWP_ErrorMessage", "LWP must be less than UWP");
 * put("UWP_gt_LWP_ErrorMessage", "UWP must be greater than LWP");
 * put("UWL_gt_LWL_ErrorMessage", "UWL must be greater than LWL");
 * put("LWL_lt_UWL_ErrorMessage", "LWL must be less than UWL");
 * put("LSL_gt_LRL_ErrorMessage", "LSL must be greater than LRL");
 * put("LRL_lt_LSL_ErrorMessage", "LRL must be less than LSL");
 * put("USL_lt_URL_ErrorMessage", "USL must be less than URL");
 * put("URL_gt_USL_ErrorMessage", "URL must be greater than USL");
 * put("LSL_lt_LWL_ErrorMessage", "LSL must be less than LWL");
 * put("LWL_gt_LRL_LSL_ErrorMessage",
 * "LWL must be greater than the LRL and LSL"); put("LRL_lt_LWL_ErrorMessage",
 * "LRL must be less than LWL"); put("UWL_lt_USL_URL_ErrorMessage",
 * "UWL must be less than the USL and URL"); put("URL_gt_UWL_USL_ErrorMessage",
 * "URL must be greater than the UWL and USL");
 * put("USL_gt_LWL_Target_ErrorMessage",
 * "USL must be greater than the LWL and Target");
 * put("LWL_lt_Target_USL_URL_ErrorMessage",
 * "LWL must be less than the Target, USL and URL");
 * put("URL_gt_LWL_ErrorMessage", "URL must be greater than LWL");
 * put("LSL_lt_Target_ErrorMessage", "LSL must be less than Target");
 * put("Target_gt_LRL_LSL_LWL_ErrorMessage",
 * "Target must be greater than the LRL, LSL and LWL");
 * put("LWL_lt_Target_ErrorMessage", "LWL must be less than Target");
 * put("LRL_lt_LSL_Target_ErrorMessage",
 * "LRL must be less than the LSL and Target");
 * put("Target_lt_UWL_USL_URL_ErrorMessage",
 * "Target must be less than the UWL, USL and URL");
 * put("LSL_lt_UWL_ErrorMessage", "LSL must be less than UWL");
 * put("Target_lt_UWL_ErrorMessage", "Target must be less than UWL");
 * put("UWL_gt_LRL_LSL_LWL_Target_ErrorMessage",
 * "UWL must be greater than the LRL, LSL, LWL and Target");
 * put("LRL_lt_UWL_ErrorMessage", "LRL must be less than UWL");
 * put("URL_gt_LRL_ErrorMessage", "URL must be greater than LRL");
 * put("LRL_lt_URL_ErrorMessage", "LRL must be less than URL");
 * put("USL_gt_LSL_ErrorMessage", "USL must be greater than LSL");
 * put("LSL_lt_USL_ErrorMessage", "LSL must be less than USL");
 * put("LWL_lt_Target_UWL_USL_URL_ErrorMessage",
 * "LWL must be less than the Target, UWL, USL and URL");
 * put("URL_gt_LRL_LSL_LWL_Target_UWL_USL_ErrorMessage",
 * "URL must be greater than the LRL, LSL, LWL, Target, UWL and USL");
 * put("LRL_lt_LSL_LWL_Target_UWL_USL_URL_ErrorMessage",
 * "LRL must be less than the LSL, LWL, Target, UWL, USL and URL");
 * put("UWL_lt_URL_ErrorMessage", "UWL must be less than URL");
 * put("LWL_lt_URL_ErrorMessage", "LWL must be less than URL");
 * put("URL_gt_LSL_LWL_Target_UWL_USL_ErrorMessage",
 * "URL must be greater than the LSL, LWL, Target, UWL and USL");
 * put("USL_gt_UWL_ErrorMessage", "USL must be greater than UWL");
 * put("URL_gt_UWL_ErrorMessage", "URL must be greater than UWL");
 * put("Password_Not_Changed_Successfully",
 * "Password reset unsuccessful. Please try again."); put("InvalidCode",
 * "Invalid Code"); put("InvalidValueValidationMessage", "Invalid Value");
 * put("Password_Changed_Successfully",
 * "Password changed successfully. Please login using the new password.");
 * put("Activation_Start_Date_Greater_Than_End_Date",
 * "Activation Start Date can�t be greater than the Activation End Date.");
 * put("LWL_gt_LSL_ErrorMessage", "LWL must be greater than LSL");
 * put("URL_gt_LSL_ErrorMessage", "URL must be greater than LSL");
 * put("Password_Reset_Unsuccessful",
 * "Password reset unsuccessful. Please try again.");
 * put("Password_Change_Unsuccessful",
 * "Password change unsuccessful. Please try again.");
 * put("Password_Expired_Message", "Password expired. Please reset.");
 * put("T2_lt_T1_ErrorMessage", "T2 Lower must be less than T1 Lower");
 * put("T2_lt_LSC_T1_ErrorMessage",
 * "T2 Lower must be less than the LSC and T1 Lower");
 * put("LSC_gt_T1_T2_ErrorMessage",
 * "LSC must be greater than the T1 Lower and T2 Lower");
 * put("T1_lt_LSC_ErrorMessage", "T1 Lower must be less than LSC");
 * put("LSC_gt_MAVLower_ErrorMessage", "LSC must be greater than MAV Lower");
 * put("MAVUpper_gt_MAVLower_ErrorMessage",
 * "MAV Upper must be greater than MAV Lower");
 * put("MAVLower_lt_LSC_ErrorMessage", "MAV Lower must be less than LSC");
 * put("MAVLower_lt_LSC_MAVUpper_ErrorMessage",
 * "MAV Lower must be less than the LSC and MAV Upper");
 * put("LSC_lt_MAVUpper_ErrorMessage", "LSC must be less than MAV Upper");
 * put("MAVUpper_gt_LSC_MAVLower_ErrorMessage",
 * "MAV Upper must be greater than the LSC and MAV Lower");
 * put("MAVLower_lt_MAVUpper_ErrorMessage",
 * "MAV Lower must be less than MAV Upper");
 * put("T1Lower_lt_T2Upper_T1Upper_LSC_ErrorMessage",
 * "T1 Lower must be less than the T2 Upper, T1 Upper and LSC");
 * put("T2Lower_lt_T2Upper_T1Upper_LSC_T1Lower_ErrorMessage",
 * "T2 Lower must be less than the T2 Upper, T1 Upper, LSC and T1 Lower");
 * put("T2Lower_lt_LSC_ErrorMessage", "T2 Lower must be less than LSC");
 * put("T2Lower_lt_T1Upper_LSC_T1Lower_ErrorMessage",
 * "T2 Lower must be less than the T1 Upper, LSC and T1 Lower");
 * put("T1Lower_lt_T1Upper_LSC_ErrorMessage",
 * "T1 Lower must be less than the T1 Upper and LSC");
 * put("T1_gt_T2_ErrorMessage", "T1 Lower must be greater than T2 Lower");
 * put("T2Lower_lt_T1Upper_ErrorMessage",
 * "T2 Lower must be less than T1 Upper");
 * put("T1Lower_lt_T1Upper_ErrorMessage",
 * "T1 Lower must be less than T1 Upper");
 * put("T1Upper_lt_T2Upper_ErrorMessage",
 * "T1 Upper must be less than T2 Upper");
 * put("T2Lower_gt_T1Upper_ErrorMessage",
 * "T2 Upper must be greater than T1 Upper");
 * put("LSC_lt_T2Upper_T1Upper_ErrorMessage",
 * "LSC must be less than the T2 Upper and T1 Upper");
 * put("T2Upper_gt_LSC_ErrorMessage", "T2 Upper must be greater than LSC");
 * put("LSC_gt_T1Lower_ErrorMessage", "LSC must be greater than T1 Lower");
 * put("T2Upper_gt_T1Lower_ErrorMessage",
 * "T2 Upper must be greater than T1 Lower");
 * put("T1Upper_gt_T1Lower_ErrorMessage",
 * "T1 Upper must be greater than T1 Lower"); put("T1Upper_gt_Lsc_ErrorMessage",
 * "T1 Upper must be greater than LSC"); put("T1Upper_gt_T2Lower_ErrorMessage",
 * "T1 Upper must be greater than T2 Lower"); put("LSC_gt_T2Lower_ErrorMessage",
 * "LSC must be greater than T2 Lower"); put("T2Upper_gt_T2Lower_ErrorMessage",
 * "T2 Upper must be greater than T2 Lower");
 * put("MAVUpper_gt_LSC_ErrorMessage", "MAV Upper must be greater than LSC");
 * put("T2Upper_gt_T1Upper_LSC_T1Lower_T2Lower_ErrorMessage",
 * "T2 Upper must be greater than the T1 Upper, LSC, T1 Lower and T2 Lower");
 * put("T1Upper_gt_LSC_T1Lower_T2Lower_ErrorMessage",
 * "T1 Upper must be greater than the LSC, T1 Lower and T2 Lower");
 * put("LSC_lt_T1Upper_ErrorMessage", "LSC must be less than T1 Upper");
 * put("Part_Is_Inactive", "Part is inactive.");
 * put("Part_Feature_Existing_Combination_Message",
 * "Part - Feature combination already exists."); put("Process_Not_Exists",
 * "Process doesn't exist."); put("TagGroupName_Already_Exists",
 * "Tag Group Name already exists."); put("MinValue_lt_MaxValue",
 * "Min. value should always be less than the Max. value");
 * put("MaxValue_gt_MinValue",
 * "Max. value should always be greater than the Min. value");
 * put("FeatureNotExistsValidationMessage", "Feature doesn't exist.");
 * put("InvalidMaxValueValidationMessage",
 * "Value cannot be greater than maximum defined value.");
 * put("InvalidMinValueValidationMessage",
 * "Value cannot be less than minimum defined value.");
 * put("EndDateTimeCannotLessThanStartDateTime",
 * "End Date/Time cannot be smaller than Start Date/Time.");
 * put("NewAndConfirmPasswordMismatch",
 * "New Password and Confirm New Password didn�t match. Try Again.");
 * put("Part_Not_Exists", "Part doesn't exist."); put("PopOverPieceSpecLimit",
 * "Piece Manufacturing Limit"); put("Selected_Process", "Selected Process");
 * put("Would_You_Like_To_Continue", "Would you like to continue?");
 * put("ValueBelowReasonableLimit_Title", "Value below Reasonable limit");
 * put("ValueAboveReasonableLimit_Title", "Value above Reasonable Limit");
 * put("OutOfSpecificationLimits_Title",
 * "Out of Specification Limits: <Part> - <Feature>");
 * put("SelectPartPopUpHeader_Title", "Part Family - Selected Parts");
 * put("UnreasonableValueEntered", "Unreasonable value entered");
 * put("ValueMustBeWithinResonableLimit",
 * "Value must be within reasonable limits"); put("OutOfWarningLimits_Title",
 * "Out of Warning Limits: <Part> - <Feature>"); put("RemoveEntityPopupTitle",
 * "Remove <Element Name>"); put("IndividualSettings_AllValueRequired",
 * "All Values Required"); put("IndividualSettings_AtLeastOneValueRequired",
 * "At Least One Value Required"); put("IndividualSettings_NoValueRequired",
 * "No Values Required"); put("IndividualSettings_ValueOnly", "Value Only");
 * put("IndividualSettings_ValueAndRequiredCode", "Value and Required Code");
 * put("IndividualSettings_ValueAndOptionalCode", "Value and Optional Code");
 * put("IndividualSettings_AllValues", "All Values");
 * put("IndividualSettings_ReasonableValuesOnly", "Reasonable Values Only");
 * put("IndividualSettings_CodeOnly", "Code Only");
 * put("ProcessState_History_Last_20", "History (Last 20)");
 * put("Part_InActivation_Validation_Message",
 * "Part will become inactive on <Date>."); put("Process_State_Idle",
 * "3 - Idle"); put("Process_State_Pause", "5 - Pause");
 * put("Process_State_Run", "2 - Run"); put("Process_State_ScheduledDown",
 * "6 - Scheduled Down"); put("Process_State_Start", "1 - Start");
 * put("Process_State_Stop", "4 - Stop"); put("Process_State_UnscheduledDown",
 * "7 - Unscheduled Down");
 * 
 * put("Permissions_Create", "Create"); put("Permissions_View", "View");
 * put("Permissions_CreateRevision", "Create Revision"); put("Permissions_Edit",
 * "Edit"); put("Permissions_Remove", "Remove"); put("Permissions_EditUniqueId",
 * "Edit Unique ID"); put("Permissions_Release", "Release");
 * put("Permissions_ViewHistory", "View History"); put("FilterApplied",
 * "filter applied"); put("FiltersApplied", "filters applied");
 * put("InActivation_Date_Message",
 * "Process state is already set at this time."); put("MDC_AddLotDetails",
 * "Add lot details"); put("MDC_ConfirmationMessageDataCollection",
 * "Do you want to cancel the data collection?");
 * put("OutOfWithInPieceLimits_Title",
 * "Out of Within piece limits: <Part> - <Feature>"); put("Lot_TestingReleased",
 * "Testing - Released"); put("ViewCodeModalBoxMessage",
 * "Code Group: <CodeGroupName> (<Count> code exists.)");
 * put("MDC_MissingValue_HeaderTitle", "Missing Values");
 * put("MDC_MissingValueConfirmationMessage",
 * "Required Value(s) missing. Please complete before saving.");
 * put("Create_Lot_Page_Title", "Create Lot");
 * put("MDC_CreateLot_ConfirmationMessage",
 * "<LotName> doesn�t exist, a new lot will be created. Do you want to continue?"
 * ); put("Checklist_Default_Processes_Selected", "Any Process");
 * put("Checklist_Assignment_Grid_Label",
 * "Allow only the following to complete this checklist.");
 * put("Checklist_Process_Label", "Process"); put("Checklist_Name_Header",
 * "Name"); put("Checklist_Assignee_Header", "Assignee");
 * put("Checklist_Header_Title", "Checklists");
 * put("Checklist_BasicInformation_Section_Title", "Basic Information");
 * put("Checklist_ProcessSelection_Section_Title", "Process Selection");
 * put("Checklist_EventGeneration_Section_Title", "Event Generation");
 * put("Checklist_Assignment_Section_Title", "Assignment");
 * put("Checklist_Preview", "Preview"); put("ColumnName_Checklist",
 * "Checklist"); put("Checklist_Create", "Create Checklist");
 * put("DefineCondition", "Define Condition"); put("DefineAction",
 * "Define Action"); put("RequirementCondition", "Requirement Condition");
 * put("RequirementWindow", "Requirement Window");
 * put("Test Requirement Condition", "Test Requirement Condition"); put("Clear",
 * "Clear"); put("If True", "If True");
 * 
 * put("DefineActionTabTitle", "Then capture data collection");
 * put("SpecifyTime", "Specify Time"); put("RunOnce", "Run Once");
 * put("DefineFrequency", "Define Frequency"); put("Every", "Every");
 * put("SpecifyTime_FromLastDataCollection", "from last data collection");
 * put("SpecifyTime_BasedOnReference", "based on reference"); put("Days",
 * "Days"); put("Hours", "Hours"); put("Minutes", "Minutes");
 * put("SpecifyTime_ResetFrequencyOnPartChange", "Reset on part change");
 * put("SpecifyProcess", "Specify Process"); put("Deadline", "Deadline");
 * put("SetWindowTabTitle", "Set Window");
 * put("SetWindow_AfterScheduledOccurrence", "after scheduled occurrence");
 * put("SetWindow_BeforeScheduledOccurrence", "before scheduled occurrence");
 * put("SetWindow_MarkTheDataCollectionLateIfNotCollected",
 * "Mark the data collection late if not collected"); put("EarlyReminder",
 * "Early Reminder"); put("Reminder", "Reminder"); put("Occurrence",
 * "Occurrence"); put("EditExisting", "Edit Existing"); put("CreateNew",
 * "Create New");
 * 
 * put("Feature_AlreadyExists", "Feature already exists.");
 * put("Checklist_DefectTypeFeatureCannotBeSelected",
 * "Defect type feature can't be selected.");
 * put("Checklist_DefectiveTypeFeatureCannotBeSelected",
 * "Defective type feature can't be selected.");
 * put("Checklist_VariableTypeFeatureCannotBeSelected",
 * "Variable type feature can't be selected."); put("ColumnName_None", "None");
 * put("Checklist_AlreayExists", "Checklist already exists.");
 * put("Checklist_Role", "Role"); put("Checklist_User", "User");
 * put("Checklist_Workstation", "Workstation"); put("Months", "Months");
 * put("Weeks", "Weeks"); put("Years", "Years"); put("Late", "Late");
 * put("LotNotExistsValidationMessage", "Lot doesn't exist.");
 * put("LotUniquenessValidationMessage",
 * "Lot Number already exists for this part.");
 * put("MDC_DataCollectionType_PopupTitle", "Data Collection Type");
 * 
 * put("Checklist_RoleAlreadyExists", "Role already exists.");
 * put("Checklist_UserAlreadyExists", "User already exists.");
 * put("Checklist_WorkstationAlreadyExists", "Workstation already exists.");
 * put("Checklist_RoleNotExists", "Role doesn't exist.");
 * put("Checklist_UserNotExists", "User doesn't exist.");
 * put("Checklist_WorkstationNotExists", "Workstation doesn't exist.");
 * 
 * put("Checklist_PreviewHeader", "Preview - <Element Name>"); put("Preview",
 * "Preview"); put("AccordionItem_ChecklistFeature",
 * "<Element Name> - Feature assignment");
 * put("Checklist_DeleteConfirmaitonMessageWithAssociations",
 * "On removal of checklist, following associations will also be removed:");
 * put("DeleteConfirmaitonMessageWithOutAssociations",
 * "Do you want to remove <Element Name>?"); put("RemovalTitle",
 * "Remove <Element Name>"); put("Checklist_SingleTagPopUp_Header",
 * "Checklist: <ChecklistName> (<Count> tag exists.)");
 * 
 * put("Preview_Comment_Placeholder", "Enter your comment here");
 * put("Preview_Response_Placeholder", "Enter your response here");
 * put("User_Popup_Header", "View User"); put("SelectProcesses",
 * "Select Processes"); put("ConditionDoenstExist", "Condition doesn't exist.");
 * put("LateTimeMustBeLessThanDeadline",
 * "Late time must be less than deadline."); put("Conditions", "Conditions");
 * put("USL_gt_LRL_ErrorMessage", "USL must be greater than LRL");
 * put("TSL_gt_LRL_ErrorMessage", "Target must be greater than LRL");
 * put("LWL_gt_LRL_ErrorMessage", "LWL must be greater than LRL");
 * put("UWL_gt_LRL_ErrorMessage", "UWL must be greater than LRL");
 * put("Target_gt_LSL_ErrorMessage", "Target must be greater than LSL");
 * put("UWL_gt_LSL_ErrorMessage", "UWL must be greater than LSL");
 * put("LRL_lt_Target_ErrorMessage", "LRL must be less than Target");
 * put("USL_gt_Target_ErrorMessage", "USL must be greater than Target");
 * put("URL_gt_Target_ErrorMessage", "URL must be greater than Target");
 * put("UWL_gt_Target_ErrorMessage", "UWL must be greater than Target");
 * 
 * put("DCRequirement_PageTitle", "Define Data Collection Requirements");
 * put("ContinueButton", "Continue"); put("SampleSize_SubTitle",
 * "Please enter a Sample Size");
 * 
 * put("ConfirmationMessageForTotalCountLessThanOrEqualTo999",
 * "Entered value should be less than or equals to 100000000");
 * put("ResponseGroup_OneActiveChoiceMessage",
 * "At least an active choice needs to be set.");
 * put("ResponseGroup_FeaturePopUp_Title", "View Feature");
 * put("ResponseGroup_SingleFeaturePopUp_Header",
 * "Response Group: <RespGroupName> (<Count> Feature exists.)");
 * put("ResponseGroup_RemovalMessage",
 * "Do you want to remove <RespGroupName>?"); put("ResponseGroup_RemovalTitle",
 * "Remove <RespGroupName>"); put("ResponseGroup_RemovedSuccessfullyMessage",
 * "<RespGroupName> removed successfully."); put("ColumnName_QuestionText",
 * "Question Text");
 * 
 * put("ResponseGroup_Header_Title", "Response Groups");
 * put("CreateResponseGroup_Header_Title", "Create Response Group");
 * put("EditResponseGroup_Header_Title", "Edit Response Group");
 * put("ColumnName_ResponseType", "Response Type");
 * put("ColumnName_ResponseGroup", "Response Group"); put("ColumnName_Choice",
 * "Choice"); put("ColumnName_Comment", "Comment"); put("ColumnName_Track",
 * "Track"); put("RuleTemplateNotExists", "Rule Template doesn�t exist.");
 * put("FeatureTypeNotApplicale", "Not applicable for this feature type.");
 * put("ProceesingTemplateNotExists", "Processing Template doesn�t exist.");
 * put("ControlLimit_SaveSuccessfullyMessage",
 * "Control limit of <Element Name> saved successfully.");
 * put("ControlLimit_EffectiveDateMessage",
 * "Effective From should be greater than <Date>");
 * put("ControlLimit_EffectiveLesserDateMessage",
 * "Effective From should be lesser than <Date>");
 * put("ControlLimit_PopUpRemovalTitle", "Remove Control Limit");
 * put("ControlLimit_RemoveMessageAtEdit",
 * "Do you want to remove control limit effective from <Date>?");
 * put("AccordionItem_AssignedChildProcess", "Assigned child process");
 * 
 * put("Operation_Not_Exists", "Operation doesn't exist.");
 * put("ColumnName_EffectiveFrom", "Effective From");
 * put("ColumnName_ProcessSigma", "Process Sigma");
 * put("ColumnName_ProcessMean", "Process Mean");
 * put("ColumnName_WithinPieceSigma", "Within Piece Sigma");
 * put("ColumnName_RuleTemplate", "Rule Template");
 * put("ColumnName_ProcessingTemplate", "Processing Template");
 * put("CL_DataStream", "Data Stream"); put("CL_AssociatedCLPopUp",
 * "View Control Limit");
 * 
 * put("ViewRequirementConditions", "View Requirement Conditions");
 * put("Requirements", "Requirements"); put("Active", "Active");
 * put("DefectiveTypeFeatureCan'tBeSelected",
 * "Defective type feature can't be selected.");
 * put("DefectTypeFeatureCan'tBeSelected",
 * "Defect type feature can't be selected.");
 * put("ChecklistTypeFeatureCan'tBeSelected",
 * "Checklist type feature can't be selected."); put("ColumnName_Shift",
 * "Shift"); put("ParameterSet_TagAlreadyExists", "Tag already exists.");
 * put("PS_PartPopUpHeader_Title", "Selected Parts"); put("Shift_Exclude",
 * "Select Shifts (to exclude)"); put("Shift_Include",
 * "Select Shifts (to include)"); put("ParameterSet_NoShiftMessage",
 * "Any Shift"); put("GridShiftSelectedEntity", "Shifts Selected:");
 * put("SelectShiftEntity_Header_Title", "Select Shifts");
 * put("Lot_Header_Title", "Lots"); put("SelectLot_Include",
 * "Select Lots (to include)"); put("GridLotSelectedEntity", "Lots Selected:");
 * put("SelectLotEntity_Header_Title", "Select Lots"); put("Criteria_LotStatus",
 * "Lot Status"); put("Criteria_TagGroup", "Tag Group");
 * put("ColumnName_Category", "Category"); put("LotStatusType_Created",
 * "Created"); put("ColumnName_LotName", "Lot Name");
 * put("PS_SelectedLotPopUpHeader_Title", "Selected Lots");
 * put("PS_DeleteConfirmaitonMessageWithAssociations",
 * "On removal of parameter set, following associations will also be removed:");
 * put("AccordionItem_AssignedToDashboard", "Assigned to dashboard");
 * put("PS_RemovedSuccessfullyMessage",
 * "<ParameterSetName> removed successfully."); put("PS_RemovalMessage",
 * "Do you want to remove <ParameterSetName>?"); put("PS_RemovalTitle",
 * "Remove <ParameterSetName>"); put("EditKeyboardEnteredValuesDuringDataEntry",
 * "Edit keyboard entered values during data entry");
 * put("EditGaugeEnteredValuesDuringDataEntry",
 * "Edit gauge entered values during data entry"); put("DisplayScale",
 * "Violation Highlight (Scale or Defective Label)");
 * put("HighlightGridNotification", "Grid Highlight");
 * put("HighlightPopupNotification", "Violation Popup");
 * put("PlaySoundWhenAGaugeValueIsEntered",
 * "Play sound when a gauge value is entered");
 * put("SpecificationLimitNotification",
 * "Violation Notification (Manufacturing Limit or Defective)");
 * put("GaugeEnteredValueNotification", "Gauge Entered Value Notification");
 * put("Default", "Default"); put("Custom", "CUSTOM");
 * put("DcConfigSaveSuccessmsg",
 * "Data Collection Configuration for <Element Name> " +
 * "changes successfully."); put("DcConfigSaveSuccessmsg2",
 * "Data Collection Configuration for <Element Name> " + "saved successfully.");
 * put("ColumnName_ChildProcess", "Include Children"); put("ShiftCountMessage",
 * "<count> Shift Selected"); put("LotCountMessage", "<count> Lot Selected");
 * put("DC_DataCollectionType_ChkBoxLabel", "Data collection type");
 * put("DC_AllowLotCreation_ChkBoxLabel", "Allow lot creation");
 * put("DC_InputPartFaimily1_ChkboxLabel", "<DC Test Name>_InputPartFamily1");
 * put("DCIndSetting_EntryMethod", "Entry Method");
 * put("DCIndSetting_EntryMethod_NextValue", "Next Value");
 * put("DCIndSetting_EntryMethod_CurrentValue", "Current Value");
 * put("DCIndSetting_EntryMethod_NewestUnusedValue", "Newest Unused Value");
 * put("DCIndSetting_EntryMethod_OldestUnusedValue", "Oldest Unused Value");
 * put("DCIndSetting_EntryMethod_DispListOfValues",
 * "Display list of values to the user"); put("DCSetting_Assignment_AllowOnly",
 * "Allow only the following to perform the data collection");
 * put("GaugeDev_CurrentValue", "Current Value"); put("DCIndSetting_Custom",
 * "Custom"); put("DCIndSetting_Default", "Default");
 * put("IndividualSettings_WithinPieceMeasurement",
 * "Within Piece Measurements"); put("DCConfig_GlobalSampleSizeMessage",
 * "Sample size can not be greater than 200 for variable features. Sample size will be set to 200. Do you want to continue?"
 * );
 * 
 * put("DataCollectionConfig_SaveSuccessfullyMessage",
 * "Data Collection Configuration for <Element Name> saved successfully.");
 * 
 * put("AccordionItem_ResponseGroupFeature", "Assigned to feature");
 * put("ResponseGroup_DeleteConfirmaitonMessageWithAssociations",
 * "On removal of response group, following associations will also be removed:"
 * ); put("ColumnName_ControlLimit", "Control Limit");
 * put("SingleCLModalBoxMessage", "(<Count> control limit exists.)");
 * put("EditControlLimit_Title", "Edit Control Limit");
 * put("AccordionItem_AssignedProcessStateMessage",
 * "Assigned to current state of process"); put("FeatureTypeDrpDwn_Variable",
 * "1 - Variable"); put("GaugeValue_ShowNewestOnTop", "Show newest on top");
 * put("GaugeValue_SpecifyMaximumNumberOfValuesIn the list",
 * "Specify maximum number of values in the list");
 * put("GaugeValue_AllowPreviouslyUsedValuesToBeDisplayed",
 * "Allow previously used values to be displayed");
 * put("EntryMethod_NotificationMsgWhenBothCheckBoxUnchecked",
 * "At least one of the entry method needs to be selected.");
 * put("DynamicLabel", "Dynamic selection"); put("GaugeDevice", "Gauge Device");
 * put("DCRequirementAlreadyExistsMessage", "DC requirement already exists.");
 * put("NoNewChangeIsSaved", "No new change is saved.");
 * put("ResponseType_SingleAnswer_Checklist", "Single Answer");
 * put("ColumnName_Requirements", "Requirements"); put("Assignee_Role", "Role");
 * put("Feature_DCModalBoxMessage", "(<Count> Data Collections exist.)");
 * put("Feature_SingleDCModalBoxMessage", "(<Count> data collection exists.)");
 * put("ResponseType_MultipleAnswer_Checklist", "Multiple Answer");
 * put("User_Status_Active", "1 - Active"); put("User_Status_Inactive",
 * "0 - Inactive"); put("ShiftLandingPageTitle", "Shifts");
 * put("createShiftPageHeaderTitle", "Shifts"); put("ColumnShiftName",
 * "Shift Name"); put("CreateShiftTitle", "Create Shift");
 * put("ProcessShiftSchedule_CreateShiftPage", "Process Shift Schedule");
 * put("ColumnName_Monday", "Monday"); put("ColumnName_Tuesday", "Tuesday");
 * put("ColumnName_Wednesday", "Wednesday"); put("ColumnName_Thursday",
 * "Thursday"); put("ColumnName_Friday", "Friday"); put("ColumnName_Saturday",
 * "Saturday"); put("ColumnName_Sunday", "Sunday"); put("lbl_Schedule",
 * "Schedule"); put("lbl_DefineSchedule", "Define Schedule");
 * put("lbl_DerivedFromParentProcess", "Derived from parent process");
 * put("lbl_EffectiveFrom", "Effective From"); put("lbl_ViewProcesses",
 * "View Processes"); put("lbl_SelectProcess", "Select Process");
 * put("lbl_PlusOneDay", "+1 day"); put("error_TimeOverLapWithPreviousDay",
 * "Overlaps with previous day."); put("error_TimeOverLapWithNextDay",
 * "Overlaps with next day."); put("column_StartTime", "Start Time");
 * put("column_EndTime", "End Time"); put("ShiftAlreadyExists",
 * "Shift already exists.");
 * put("createShift_MessageForAtleastOneProcessSelection",
 * "At least a process schedule needs to be defined to create a shift.");
 * put("AccordionItem_AssignedShift", "Assigned to shift");
 * put("AccordionItem_ShiftDeleteSingleProcess",
 * "Shift(s) having only one removed process schedule will also be removed. Impacted shift"
 * ); put("ShiftCantBeRemoved_Process",
 * "Shift can�t be removed as other process schedule is also defined. Process schedule associations of this shift will not be removed."
 * ); put("Part_Is_Inactive_PFDetail", "Part is inactive.");
 * put("Global_Configuration", "Global Configuration");
 * put("Label_SpecificationLimits", "Specification Limits");
 * put("Label_WarningLimit", "Warning Limit"); put("Label_ReasonableLimit",
 * "Reasonable Limit"); put("Label_Auto-fill", "Auto-fill");
 * put("Label_%for'WarningLimits'", "% for 'Warning Limits'");
 * put("Label_xfor'ReasonableLimits'", " for 'Reasonable Limits'");
 * put("Label_DefaultCapabilityTargetValues",
 * "Default Capability Target Values"); put("Label_CpTarget", "Cp Target");
 * put("Label_PpTarget", "Pp Target"); put("Label_CpkTarget", "Cpk Target");
 * put("Label_PpkTarget", "Ppk Target"); put("SecurityPolicyPageTitle",
 * "Security Policy"); put("SecurityPolicyPageHeaderText",
 * "Configure Security Policy"); put("SecurityPolicyPage_UserloginSettingsTab",
 * "User Login Settings"); put("SecurityPolicyPage_CredentialSettingsTab",
 * "Credential Settings");
 * put("SecurityPolicyPage_DataAuthenticationSettingsTab",
 * "Data Authentication Settings");
 * put("SecurityPolicyPage_UserNameValidation_LengthHigherThanAllowed",
 * "Minimum username length can�t be greater than 90.");
 * put("SecurityPolicyPage_UserNameValidation_LengthLowerThanAllowed",
 * "Minimum username length can�t be less than 5.");
 * put("SecurityPolicyPage_SaveSuccessMessage",
 * "Security policy updated successfully."); put("Yes", "Yes"); put("No", "No");
 * put("ManageSettingsPageTitle", "Settings");
 * put("ManageSettingsPageHeaderText", "Settings"); put("CPK_Target_Range",
 * "<LowerValue> <= Cpk Target <= <UpperValue>"); put("CP_Target_Range",
 * "<LowerValue> <= Cp Target <= <UpperValue>"); put("PP_Target_Range",
 * "<LowerValue> <= Pp Target <= <UpperValue>"); put("PPK_Target_Range",
 * "<LowerValue> <= Ppk Target <= <UpperValue>"); put("Warning_Limit_Range",
 * "Range should be between <LowerValue>% to <UpperValue>%");
 * put("Reasonable_Limit_Range",
 * "Range should be between <LowerValue> to <UpperValue>");
 * 
 * put("SecurityPolicy_Header_Title", "Security Policy");
 * put("SecurityPolicy_IdleForOneDay", "1 day");
 * put("SecurityPolicy_UseEmailIdNo", "No"); put("GeneralSetting",
 * "General Settings"); put("UnitOfMeasurementAlreadyExists",
 * "Unit of Measurement already exists."); put("AbbreviationAlreadyExists",
 * "Abbreviation already exists."); put("GC_DataCollectionType_TabHeader",
 * "Data collection type"); put("Lbl_ChkBox_EnableDataCollectionType",
 * "Enable Data collection type"); put("ColumnName_Type", "Type");
 * put("GC_SaveSuccessMessage", "Global Configuration saved successfully.");
 * 
 * put("GC_DCType_AlreadyExistMessage", "Data Collection Type already exists.");
 * put("SecurityPolicy_MissingInfoMessage",
 * "Missing/Incorrect Information | Correct or Cancel them before saving.");
 * put("GlobalConfiguration_Header_Title", "Global Configuration");
 * put("ColumnName_Abbreviation", "Abbreviation");
 * put("ColumnName_Unit_Of_Measurement", "Unit Of Measurement");
 * put("ColumnName_UnitType", "Unit Type"); put("UnitType_Angle", "Angle");
 * put("UnitType_Area", "Area"); put("UnitType_Count", "Count");
 * put("UnitType_Currency", "Currency"); put("UnitType_Current", "Current");
 * put("UnitType_Data", "Data"); put("UnitType_Density", "Density");
 * put("UnitType_Energy", "Energy"); put("UnitType_Force", "Force");
 * put("UnitType_Height", "Height"); put("UnitType_Length", "Length");
 * put("UnitType_Luminosity", "Luminosity"); put("UnitType_Mass", "Mass");
 * put("UnitType_Power", "Power"); put("UnitType_Pressure", "Pressure");
 * put("UnitType_Speed", "Speed"); put("UnitType_Temperature", "Temperature");
 * put("UnitType_Time", "Time"); put("UnitType_Torque", "Torque");
 * put("UnitType_Viscosity", "Viscosity"); put("UnitType_Volume", "Volume");
 * put("UnitType_Width", "Width"); put("UnitType_Work", "Work");
 * put("UnitWillBeRemovedContinue", "Unit will be removed. Continue?");
 * put("GC_RemoveDCType_ConfirmationMessage",
 * "Do you want to remove <DCTypeName>?");
 * 
 * put("Events", "Events?"); put("Status_Removed", "2 - Removed");
 * put("Status_All", "3 - All");
 * 
 * put("GCAbbr_DeleteConfirmaitonMessageWithAssociations",
 * "On removal of Abbreviation, following associations will also be removed:");
 * put("AccordionItem_Impacted_Lot", "Impacted lot");
 * 
 * put("SecurityPolicyPage_Forever", "Forever");
 * put("SecurityPolicy_IdleForFiveDay", "5 days");
 * put("SecurityPolicy_IdleForThreeDay", "3 days");
 * put("SecurityPolicy_IdleFor15Min", "15 minutes");
 * put("SecurityPolicy_IdleFor30Min", "30 minutes");
 * put("SecurityPolicy_IdleFor1Hour", "1 hour");
 * put("SecurityPolicy_IdleFor4Hour", "4 hours");
 * put("SecurityPolicy_IdleFor8Hour", "8 hours");
 * put("SecurityPolicy_IdleFor15Hour", "15 hours"); put("Aggregated",
 * "Aggregated"); put("Raw", "Raw"); put("URL_CreateSpecHelpLink",
 * "SpecLimits/CreatingSpecLimits.htm"); put("RequiredAnswersMissing",
 * "Required answers missing."); put("ConfirmationMessage_NoResponseEntered",
 * "No response entered. Checklist will be cancelled.");
 * put("URL_SpecLimitLandingPageHelpLink", "SpecLimits/ManagingSpecLimits.htm");
 * put("URL_EditSpecLimitPageHelpLink", "SpecLimits/EditingSpecLimits.htm");
 * put("UserPage_UserNameValidation_LengthLowerThanAllowed",
 * "Minimum username length can�t be less than <SetLength>.");
 * put("uRL_SecurityPolicyPageHelpLink",
 * "Security/ConfiguringSecurityPolicy.htm");
 * put("SecurityPolicyPage_validationForPasswordLength_HigherThanAllowed",
 * "Minimum password length can�t be greater than 20.");
 * put("SecurityPolicyPage_validationForPasswordLength_LowerThanAllowed",
 * "Minimum password length can�t be less than 5.");
 * put("ManageSettingsPage_BasicInformation", "Basic Information");
 * put("ManageSettingsPage_Notifications", "Notifications"); put("Removed",
 * "Removed");
 * 
 * put("AccordionItem_Impacted_Lot", "Impacted lot");
 * put("GC_ActiveDCToBeDefined",
 * "At least one active data collection type needs to be defined.");
 * put("Role_Management", "Role Management"); put("Authentication",
 * "Authentication"); put("User_Management", "User Management");
 * put("AccessDeniedText", "You don't have permission for requested resource.");
 * 
 * put("NoAccessLevelMessage",
 * "No access level has been assigned to you. Please contact system administrator."
 * ); put("InvalidPermissionMessage",
 * "Invalid permissions. Please contact administrator."); put("FifteenMinutes",
 * "15 minutes"); put("ThirtyMinutes", "30 minutes"); put("OneHour", "1 hour");
 * put("FourHours", "4 hours"); put("EightHours", "8 hours");
 * put("FifteenHours", "15 hours"); put("OneDay", "1 day"); put("ThreeDays",
 * "3 days"); put("FiveDays", "5 days");
 * put("RoleNameUniquenessValidationMessage", "Role Name already exists.");
 * put("ValidationMessage_PasswordAdvanceNotification",
 * "Advance notification days can�t be greater than or equal to Password expiry days."
 * ); put("NoSystemAccess", "No System Access"); put("LastLogin", "Last Login");
 * put("d", "d"); put("m", "m"); put("y", "Y"); put("Ago", "AGO");
 * put("Count-TimeUnit-Ago", "<count><TimeUnit> AGO"); put("Today", "Today");
 * put("w", "W"); put("ParameterSet", "Parameter Set"); put("NotificationRule",
 * "Notification Rule"); put("PermissionTabText",
 * "Permissions - Keyword Oriented Alignment"); put("Role_AlreayExists",
 * "Role Name already exists."); put("GC_Chart", "Chart"); put("GC_CodeGroup",
 * "Code Group"); put("GC_Condition", "Condition"); put("GC_ControlLimit",
 * "Control Limit"); put("GC_Feature", "Feature"); put("GC_GaugeSetup",
 * "Gauge Setup"); put("GC_GlobalConfiguration", "Global Configuration");
 * put("GC_License", "License"); put("GC_MenuTemplate", "Menu Template");
 * put("GC_NotificationRule", "Notification Rule"); put("GC_ParameterSet",
 * "Parameter Set"); put("GC_ShiftLog", "Shift Log"); put("GC_StatisticalRule",
 * "Statistical Rule");
 * 
 * put("ManageSettingsPageMessage", "settings"); put("MenuTemplate_Not_Exist",
 * "Menu Template doesn't exist."); put("URL_CloneRolePageHelpLink",
 * "Roles/CloningRoles.htm"); put("URL_CreateRolePageHelpLink",
 * "Roles/CreatingRoles.htm"); put("URL_EditRolePageHelpLink",
 * "Roles/EditingRoles.htm"); put("URL_RoleLandingPageHelpLink",
 * "Roles/ManagingRoles.htm"); put("Roles_PopUp_AvailableUsers",
 * "Available User(s)"); put("Roles_PopUp_HelperMessage",
 * "Please select appropriate user(s) from left section and click on " + "\"" +
 * ">>" + "\"" + " to assign role to users and move them to Assigned Users.");
 * put("Roles_PopUp_AssignedUsers", "Assigned User(s)");
 * put("Roles_PopUp_AssignRoleToUsers", "Assign User to Role");
 * put("RolesLandingPage_RoleName", "Role Name"); put("RolesLandingPage_Users",
 * "Users"); put("RolesLandingPage_User", "User");
 * put("Roles_Permissions_ActionOrientedAlignment",
 * "Permissions - Action Oriented Alignment");
 * 
 * put("Permissions_Authentication", "Authentication");
 * put("Permissions_ConfigureParameters", "Configure Parameters");
 * put("ColumnName_FirstName", "First Name"); put("ColumnName_LastName",
 * "Last Name"); put("RolesLandingPage_UserPopUp_EntityHeading",
 * "Role: <RoleName>"); put("RolesLandingPage_UserPopUp_UsersCount",
 * "(<count> "); put("Roles_RemoveRole_ConfirmationMessage1",
 * "Do you want to remove <RoleName> role?");
 * put("Roles_RemoveRole_AssociationConfirmationMessage1",
 * "On removal of role, following associations will also be removed:");
 * put("Roles_AssignedToDcMessage", "Assigned to data collection definition");
 * put("Roles_AssignedToCheckListMessage", "Assigned to checklist");
 * put("ProcessStateLandingPageTimeZoneLabel",
 * "All times are in local 'process' time zone"); put("Date&Time(Local)_Label",
 * "Date & Time (Local)"); put("ShowRemovedRecords", "Show Removed Records");
 * put("Permissions_Manage", "Manage"); put("License", "License");
 * put("MenuTemplate", "Menu Template"); put("Workstation", "Workstation");
 * put("MenuTemplates_HeaderTitle", "Menu Templates");
 * put("CreateMenuTemplate_Title", "Create Menu Template");
 * 
 * put("Create_Condition_PageTitle", "Create Condition");
 * 
 * put("Gauge_Devices", "Gauge Devices");
 * 
 * put("Gauge_Initialization", "Gauge Initialization");
 * put("Measurement_Initialization", "Measurement Initialization");
 * put("Measurement_Start ", "Measurement Start "); put("Measurement_End",
 * "Measurement End"); put("Measurement_Read", "Measurement Read");
 * put("Measurement_Post", "Measurement Post"); put("Measurement_Request",
 * "Measurement Request"); put("Data_Collection_Start",
 * "Data Collection Start"); put("Data_Collection_End", "Data Collection End");
 * put("RuleTemplateLandingPage_Header_Title", "Rule Templates");
 * put("ColumnName_Rule_Template_Name", "Rule Template Name");
 * put("ColumnName_TimeToTimeRule", "Time To Time Rule");
 * put("ColumnName_BetweenPieceRule", "Between Piece Rule");
 * put("ColumnName_WithinPieceRule", "Within Piece Rule");
 * put("Create_RuleTemplate_Page_Title", "Create Rule Template");
 * 
 * put("AboveUpperControlLimit", "Above Upper Control Limit");
 * 
 * put("LicenseManagement", "License Management"); put("AddLicenseAssignment",
 * "Add License Assignment"); put("UsernameAndWorkstation",
 * "Username/Workstation"); put("RemainingLicenses", "Remaining licenses");
 * put("Gauge_Interface", "Gauge Interfaces");
 * 
 * put("Gauge_Formats", "Gauge Formats");
 * 
 * put("Agent", "Agent"); put("Gauge_Interface_Name", "Gauge Interface Name");
 * 
 * put("Port_Initialization", "Port Initialization"); put("Port_Termination",
 * "Port Termination"); put("Gauge_Format", "Gauge Format");
 * put("WorkstationLandingPageTitle", "Workstations");
 * put("Configure_Workstation_Page_Title", "Configure Workstations");
 * put("ColumnName_Workstation_Name", "Workstation Name");
 * put("Workstation_Configurations_Save_Successfully",
 * "Workstation configurations saved successfully.");
 * 
 * put("ProcessModels", "Process Models"); put("Security", "Security");
 * put("ShiftLogs", "Shift Logs"); put("Calculations", "Calculations");
 * put("Licenses", "Licenses"); put("Workstations", "Workstations");
 * put("NotificationRules", "Notification Rules"); put("StatisticalRules",
 * "Statistical Rules"); put("ProcessingTemplates", "Processing Templates");
 * put("GaugeAgentInstaller", "Gauge Agent Installer"); put("Global", "Global");
 * put("MenuTemplateName", "Menu Template Name");
 * put("NotificationRulesLandingPage_HeaderTitle", "Notification Rules");
 * put("CreateNotificationRulesPage_PageTitle", "Create Notification Rule");
 * put("NCC_Violation", "NCC Violation"); put("SpecificationViolation",
 * "Specification Violation"); put("StatisticalViolation",
 * "Statistical Violation"); put("ChecklistViolation", "Checklist Violation");
 * put("Defective", "Defective"); put("NotificationRules_StatusTabHeading",
 * "Generate notifications when <Element Name> are"); put("Due", "Due");
 * 
 * put("Missed", "Missed"); put("Success", "Success"); put("AlarmType",
 * "Alarm Type"); put("DataStream", "Data Stream(s)"); put("Recipients",
 * "Recipients"); put("NotificationRules_RecipientsTabHeading",
 * "User/Workstation/Role"); put("Configuration", "Configuration");
 * put("RealTimeAnalytics", "Real Time Analytics"); put("Labels", "Labels");
 * put("Downloads", "Downloads"); put("NotificationRuleName",
 * "Notification Rule Name");
 * 
 * put("Username", "1 - Username"); put("License_Workstation",
 * "2 - Workstation"); put("License_RemoveEntityPopupMessage",
 * "Are you sure you want to remove license assigned to <Element Name>?");
 * put("ModifyLicenseAssignment", "Modify License Assignment");
 * 
 * put("Create_Gauge_Interface", "Create Gauge Interface");
 * 
 * put("Create_Gauge_Format", "Create Gauge Format");
 * 
 * put("Data_Port_Configuration", "Data Port Configuration");
 * put("Port_Initialization", "Port Initialization");
 * 
 * put("LotNumber", "Lot Number"); put("CurrentStatus", "Current Status");
 * put("StatusTime", "Status Time");
 * 
 * put("Quantity", "Quantity"); put("Sound", "Sound");
 * put("DefineNotificationPlatform", "Define Notification Platform");
 * put("PlaySound",
 * "Play a sound when each new notification is received on header");
 * put("StatisticalRulesLandingPageTitle", "Statistical Rules");
 * put("ColumnName_Priority", "Priority"); put("ColumnName_RuleType",
 * "Rule Type"); put("ColumnName_Hits", "Hits"); put("ColumnName_Count",
 * "Count"); put("ColumnName_Label", "Label"); put("TimeToTimeRule_TabTitle",
 * "Time To Time"); put("BetweenPieceRule_TabTitle", "Between Piece");
 * put("WithinPieceRule_TabTitle", "Within Piece");
 * put("ProcessingTemplateLandingPage_Header_Title", "Processing Templates");
 * put("ColumnName_Processing_Template_Name", "Processing Template Name");
 * put("ColumnName_Feature_Type", "Feature Type");
 * put("ColumnName_Normalization", "Normalization");
 * put("ColumnName_Control_Limit_Confidence_Interval",
 * "Control Limit Confidence Interval"); put("ColumnName_Processing_Option",
 * "Processing Option"); put("ColumnName_Initialize_on_Part_Change",
 * "Initialize on Part Change"); put("priority", "Priority"); put("ruleType",
 * "Rule Type"); put("hits", "Hits"); put("count", "Count"); put("label",
 * "Label"); put("enabled", "Enabled");
 * 
 * put("Create_ProcessingTemplate_Page_Title", "Create Processing Template");
 * put("Password_Guidelines_ChangePassword_ManageSettings", "Password Rules" +
 * "\n" + "Minimum Password Length (characters): 8" + "\n" +
 * "Password must contain the following:" + "\n" +
 * "At least one numeric character" + "\n" +
 * "At least one upper and lower case character" + "\n" +
 * "At least one of the following special characters [ ] ? / < > ~ # ` ! @ _ - $ % ^ & * ( ) + = { } | : \" ; ' ,"
 * + "\n" + "Selected password cannot be reused before 365 days");
 * 
 * put("URL_WorkStationLandingPageHelpLink",
 * "Workstations/ManagingWorkstations.htm"); put("Workstation_AlreayExists",
 * "Workstation Name already exists."); put("Label_Already_Exists",
 * "Label already exists."); put("CountGreaterThanHits", "Count>=Hits");
 * put("HitsLessThanCount", "Hits<=Count");
 * put("Statistical_Rule_Delete_Message",
 * "Do you want to remove <Element Name>?" + "\n" + "\n" +
 * "On removal of statistical rule, all rule templates will be impacted.");
 * put("HelperText_Date", "M/d/yyyy h:mm:ss tt");
 * put("CombinationAlreadyExists", "This combination already exists.");
 * put("WorkStation_Header_AccessLevel_PopUp", "View Access Level");
 * put("Workstation_AccessLevelCount_Title",
 * "(<Element Name> access level exists.)");
 * put("Menu_Template_Name_already_exists",
 * "Menu Template Name already exists.");
 * 
 * put(
 * "Workstation_errorMsg_WorkStationNotAutothorizedAndUserNotAbleToAuthorize" ,
 * "You don't have permission to authenticate the workstation. Please contact system administrator."
 * ); put("GC_Workstation", "Workstation"); put("View_Workstation_Page_Title",
 * "View Workstations");
 * 
 * put("Menu_Template_Name_already_exists.",
 * "Menu Template Name already exists.");
 * put("WorkstationSavedSuccessfullyMessage",
 * "<Element Name> saved successfully.");
 * put("WorkStation_Header_Checklist_PopUp", "View Checklist");
 * put("Workstation_ChecklistCount_Title",
 * "(<Element Name> checklist exists.)"); put("viewPopUpTitleWorkstation",
 * "Workstation : <Element Name>"); put("Workstation_DCCount_Title",
 * "(<Element Name> data collection exists.)");
 * put("WorkStation_Header_NotificationRule_PopUp", "View Notification Rule");
 * put("Workstation_NotificationRuleCount_Title",
 * "(<Element Name> notification rule exists.)"); put("Column_Assigned_License",
 * "Assigned License"); put("Column_Last_Authenticated_By",
 * "Last Authenticated by"); put("View_Role", "View Role"); put("View_User",
 * "View User"); put("Menu_Template", "Menu Template");
 * put("MenuTemplateViewPopUpHeading",
 * "Menu Template: <MenuTemplateName> (<Count> <Module> exists.)");
 * put("Search", "Search"); put("StatisticalRule_HitsGreaterThanOne_Message",
 * "Hits>1"); put("URL_StatisticalPageHelpLink",
 * "StatisticalRules/ManagingStatisticalRules.htm");
 * put("URL_MenuTemplatelandingPage_HelpLink",
 * "MenuTemplates/ManagingMenuTemplates.htm");
 * put("URL_CreateMenuTemplatePage_HelpLink",
 * "MenuTemplates/CreatingMenuTemplates.htm");
 * put("URL_EditMenuTemplatePage_HelpLink",
 * "MenuTemplates/EditingMenuTemplates.htm"); put("Qty", "Qty:"); put("Lot",
 * "Lot"); put("MenuTemplate_DeleteConfirmaitonMessage_WithAssociation",
 * "Do you want " + "to remove <Element Name>?" + "\n" + "\n" +
 * "On removal of menu template, following associations will also be removed:");
 * put("AccordionItem_AssignedRoleMessage", "Assigned to Role");
 * put("Process_ProcessWithSameNameMsg",
 * "Short name already exists. Another record will be created with same name.");
 * put("Shifts_ProcessDeletetionMsg_IfOnlyOneProcessAssigned",
 * "Shift(s) having only one removed process schedule will also be removed. Impacted shift"
 * ); put("URL_LotLandingPageHelpLink", "Lots/ManagingLots.htm");
 * put("URL_CreateLotPageHelpLink", "Lots/CreatingLots.htm");
 * put("URL_EditLotPageHelpLink", "Lots/EditingLots.htm");
 * put("Lot_LotAlreadyExistAsRemoved",
 * "Lot Number already exists for this part as removed record.");
 * put("CurrentProcess", "Current Process"); put("Lot_LotAlreadyExistForPart",
 * "Lot Number already exists for this part.");
 * put("NotificationRuleNameAlreadyExists",
 * "Notification Rule Name already exists."); put("OnHold", "On Hold");
 * put("TestingComplete", "Testing - Complete");
 * put("ParameterSet_Time_InfoIconMessage",
 * "CURRENT: Data up to end of current time period." + "\n" +
 * "EARLIER: Data up to end of previous time period." + "\n" +
 * "LATEST: Data up to the second.");
 * 
 * put("StartDate&Time", "Start Date/Time"); put("EndDate&Time",
 * "End Date/Time"); put("DataCollectionS", "Data Collection(s)");
 * put("CheckListS", "Checklist(s)");
 * put("SelectCheckLlistsEntity_Header_Title", "Select Checklist");
 * put("SelectDataCollectionEntity_Header_Title", "Select Data Collections");
 * put("Above_T2_upper", "Above T2 upper"); put("Below_T2_lower",
 * "Below T2 lower"); put("Above_MAV_upper", "Above MAV upper");
 * put("Below_MAV_lower", "Below MAV lower"); put("Above_USL", "Above USL");
 * put("Below_LSL", "Below LSL"); put("Above_URL", "Above URL");
 * put("Below_LRL", "Below LRL"); put("Above_UWL", "Above UWL");
 * put("Below_LWL", "Below LWL"); put("Above_UWP", "Above UWP");
 * put("Below_LWP", "Below LWP"); put("Above_USG", "Above USG");
 * put("Below_LSG", "Below LSG"); put("Notify_When", "Notify When");
 * put("Upper", "Upper"); put("Lower", "Lower");
 * put("Below_Lower_Control_Limit", "Below Lower Control Limit");
 * put("In_or_Above_Upper_Zone_A", "In or Above Upper Zone A");
 * put("In_or_Below_Lower_Zone_A", "In or Below Lower Zone A");
 * put("In or_Above_Upper_Zone_B", "In or Above Upper Zone B");
 * put("In_or_Below_Lower_Zone_B", "In or Below Lower Zone B");
 * put("Run_Above_Centerline", "Run Above Centerline");
 * put("Run_Below_Centerline", "Run Below Centerline"); put("Others", "Others");
 * put("Run_within_Zone_C", "Run within Zone C"); put("Avoidance_of_Zone_C",
 * "Avoidance of Zone C"); put("Consecutive_Points_Rising",
 * "Consecutive Points Rising"); put("Consecutive_Points_Falling",
 * "Consecutive Points Falling"); put("Oscillating_Up_and_Down",
 * "Oscillating Up and Down"); put("No_Variation_in_Values",
 * "No Variation in Values"); put("DC_Assigned_Users", "DC Assigned Users");
 * put("Error_AtleastOneSelect_NotificationRule",
 * "Select at least one <element> to generate notifications.");
 * put("Error_ExistingSelectLost_NotificationRule",
 * "Existing selections will be lost. Are you sure you want to switch category?"
 * ); put("Lot_ClosedAccepted", "Closed - Accepted"); put("Lot_ClosedRejected",
 * "Closed - Rejected"); put("Notification_Rule_Any_Data_Collection",
 * "Any Data Collection"); put("Lots_Association_Message",
 * "On removal of lot, following associations will also be removed:");
 * put("No_License_Available_Message_For_User",
 * "You do not have a valid license to login on this machine, please contact your system administrator."
 * ); put("NotificationRule_NoDcMessage", "Any Data Collection");
 * put("AnyCheckList", "Any Checklist"); put("RecipientDoesNotExist",
 * "Recipient doesn't exist.");
 * put("WorkstationLicenseAssociatedConfirmationMessage",
 * "Workstation license is associated with it. Do you still want to authenticate this workstation?"
 * ); put("No_License_Available_Message_For_Machine",
 * "There is no license available to authenticate this machine, please contact your system administrator."
 * ); put("Username/Workstation_doesn't_exist",
 * "Username/Workstation doesn't exist."); put("License_already_exists.",
 * "License already exists.");
 * 
 * put("You_have_been_logged_out_from_this_session.",
 * "You have been logged out from this session.");
 * 
 * put("NotInListMessage", "Not In List");
 * 
 * put("Change", "Change"); put("URL_NotificationLandingPageHelpLink",
 * "NotificationRules/ManagingNotificationRules.htm");
 * put("URL_CreateNotificationPageHelpLink",
 * "NotificationRules/CreatingNotificationRules.htm");
 * put("URL_EditNotificationPageHelpLink",
 * "NotificationRules/EditingNotificationRules.htm"); put("TrackCountExceeded",
 * "Track count exceeded"); put("NotificationRules_ChecklistTabHeading",
 * "Generate Notifications for"); put("NotificationRules_Checklist_Pageheader",
 * "Select Checklist (to include)");
 * put("NotificationRules_DataCollection_Pageheader",
 * "Select Data Collections (to include)"); put("Workstation_doesn�t_exist",
 * "Workstation doesn�t exist."); put("URL_LicenseLandingPageHelpLink",
 * "Licenses/AssigningLicenses.htm"); put("EntityCountMessage",
 * "<count> <entity> Selected");
 * 
 * put("NotificationRule_UpdateSuccessMessage",
 * "Notification rules updated successfully.");
 * put("NotificationRule_AlreadyExistAsRemoved",
 * "Notification Rule Name already exists as removed record.");
 * 
 * put("ViewRequirements", "View Requirements"); put("CreateRequirements",
 * "Create Requirement"); put("MoreRequirements", "More Requirement(s)");
 * put("Create_Calculation", "Create Calculation"); put("Calculation_Name",
 * "Calculation Name"); put("Save_as_Feature", "Save as Feature");
 * put("Initiators", "Initiators"); put("Add_Below", "Add Below");
 * put("Add_Above", "Add Above"); put("Calculation", "Calculation");
 * put("Calculation_RemoveStepMessage",
 * "Removing Step <StepNumber> will create error in following steps. Do you want to continue?"
 * ); put("Calculation_StepNumber", "Step <StepNumber>");
 * put("Calculation_RemovePopUptTitle", "Remove Step <StepNumber>");
 * 
 * put("RuleTemplateNameAlreadyExistsErrorMsg",
 * "Rule Template Name already exists.");
 * put("RuleTemplateNameAlreadyExistsAsRemoveRecordErrorMsg",
 * "Rule Template Name already exists as removed record.");
 * put("URL_RuleTemplateLandingPageHelpLink",
 * "RuleTemplates/ManagingRuleTemplates.htm");
 * put("URL_CreateRuleTemplatePageHelpLink",
 * "RuleTemplates/CreatingRuleTemplates.htm");
 * put("URL_EditRuleTemplatePageHelpLink",
 * "RuleTemplates/EditingRuleTemplates.htm");
 * put("RuleTemplate_ViewPopUp_SubHeading", "Rule Template: <Element Name>");
 * put("RuleTemplate_ViewPopUp_SubHeadingWithOneCount",
 * "(<Count> rule exists.)");
 * put("RuleTemplate_ViewPopUp_SubHeadingWithMoreThanOneCount",
 * "(<Count> rules exist.)"); put("RuleTemplate_TimeToTimeViewPopUpHeader",
 * "View Time To Time Rule"); put("RuleTemplate_BetweenPieceViewPopUpHeader",
 * "View Between Piece Rule"); put("RuleTemplate_WithinPieceViewPopUpHeader",
 * "View Within Piece Rule");
 * 
 * put("Tag_Group_Name_already exists_as_removed_record",
 * "Tag Group Name already exists as removed record.");
 * put("Tag_already exists_as_removed_record",
 * "Tag already exists as removed record.");
 * 
 * put("CodeGroupRemoval_Success",
 * "Code Group <Element Name> removed successfully.");
 * put("CodeGroupRemoval_ConfirmationWithoutAssociation",
 * "Do you want to remove <Element Name> Code Group?" + "\n" + "\n" +
 * "On removal of code group, following associations will also be removed:");
 * put("Condition_Name", "Condition Name");
 * put("SettingSaveSuccessfullyMessage",
 * "<Element Name> settings saved successfully.");
 * put("Condtions_DeleteConfirmaitonMessage_WithAssociation", "Do you want " +
 * "to remove <Element Name>?" + "\n" + "\n" +
 * "On removal of condition, following associations will also be removed:");
 * 
 * put("AssignedToDcRequirementMessage", "Assigned to DC requirements");
 * put("Day_of_week", "Day of week");
 * put("Gauge_Interface_Connection_saved_successfully.",
 * "Gauge Interface Connection saved successfully."); put("TCP/IP", "TCP/IP");
 * put("Com_Port", "Com Port"); put("Gauge_Format_Name", "Gauge Format Name");
 * 
 * put("RuleTemplate_Association_Message",
 * "On removal of rule template, following associations will also be removed:");
 * put("Associated_ControlLimit_ConfirmationMessage",
 * "Associated control limit records will be impacted");
 * 
 * put("ProcessingTemplateNameAlreadyExistsAsRemoveRecordErrorMsg",
 * "Processing Template Name already exists as removed record.");
 * 
 * put("URL_CreateProcessPageHelpLink", "Processes/CreatingProcesses.htm");
 * put("message_RestoreConfirmation_WithoutAssociation",
 * "Do you want to restore <Element Name>?" + "\n\n" +
 * "On restoration of process, impacted associations will also be restored.");
 * put("RestoredSuccessfullyMessage", "<Element Name> restored successfully.");
 * 
 * put("RestorePopUpTitle", "Restore <Element Name>");
 * put("Create_Gauge_Device", "Create Gauge Device"); put("Gauge_Device_Name",
 * "Gauge Device Name");
 * put("DeleteConfirmaitonMessageWithAssociationsForGaugeInterface",
 * "Do you want " + "to remove <Element Name>?" + "\n" + "\n" +
 * "On removal of gauge interface, following associations will also be impacted:"
 * );
 * 
 * put("AccordionItem_AssignedGaugeFormat", "Removed Gauge Format");
 * 
 * put("AccordionItem_AssignedGaugeDevice", "Removed Gauge Device");
 * 
 * put("ProcessingOption_ShewhartCUSUM", "Shewhart CUSUM");
 * put("ProcessingOption_Exponentially_Weighted_Moving_Average",
 * "Exponentially Weighted Moving Average (EWMA)");
 * put("ProcessingOption_EconomicControlLimit", "Economic Control Limit (ECL)");
 * 
 * put("ProcessingOption_CoefficientOfVariation",
 * "Coefficient of Variation (%CV)");
 * 
 * put("Modifying_a_gauge_interface_connection_will_affect_1_gauge_device.",
 * "Modifying a gauge interface connection will affect 1 gauge device.");
 * put("Modifying_a_gauge_interface_connection_will_affect_N_gauge_devices.",
 * "Modifying a gauge interface connection will affect <count> gauge devices.");
 * put("NormalizationOption_Nominal", "Nominal");
 * 
 * put("Part - Feature combination already exists as removed record",
 * "Part - Feature combination already exists as removed record.");
 * 
 * put("NormalizationOption_Standardized", "Standardized");
 * 
 * put("SelectParentProcess", "Select Parent Process");
 * put("Msg_ParentProcessWithSameChildName",
 * "Parent process already contains a child process with same short name.");
 * put("Msg_ProcesslAlreadyContainsChildAsRemovedRecord",
 * "This process already contains a child process as removed record with same short name."
 * ); put("Msg_ResponseAlreadyExistAsRemovedRecord",
 * "Response Group already exists as removed record.");
 * put("Msg_ChoiceAlreadyExistAsRemovedRecord",
 * "Choice already exists as removed record.");
 * 
 * put("Restore_Confirmation_Message_For_PartRevision",
 * "Do you want to restore <Element Name>?" + "\n" + "\n" +
 * "On restoration of part revision, impacted associations will also be restored."
 * );
 * 
 * put("message_SpecLimitRestoreConfirmation_WithoutAssociation",
 * "Do you want to restore manufacturing limit record for <Element Name> combination?"
 * + "\n\n" +
 * "On restoration of manufacturing limit, impacted associations will also be restored."
 * );
 * 
 * put("message_RestoreConfirmation_WithoutAssociation_Feature",
 * "Do you want to restore <Element Name>?" + "\n\n" +
 * "On restoration of feature, impacted associations will also be restored.");
 * 
 * put("message_RestoreConfirmation_WithoutAssociation_Process",
 * "Do you want to restore <Element Name>?" + "\n\n" +
 * "On restoration of process, impacted associations will also be restored.");
 * 
 * put("Msg_ChecklistAlreadyExistAsRemovedRecord",
 * "Checklist already exists as removed record.");
 * put("Msg_LabelAlreadyExistAsRemovedRecord",
 * "Label already exists as removed record.");
 * 
 * put("ProcessingOption_TabularCUSUM", "Tabular CUSUM");
 * 
 * put("ShortName_AlreadyExistAsRemoved",
 * "Short name already exists as removed record.");
 * 
 * put("NormalizationOption_Target", "Target");
 * put("NormalizationOption_ProcessMean", "Process Mean");
 * 
 * put("AtLeastOneMeanShiftDetectionLimit_ErrorMessage",
 * "At least one Mean Shift Detection Limit is required.");
 * put("ProcessingTemplateNameAlreadyExistsErrorMsg",
 * "Processing Template Name already exists."); put("FeatureType_Attribute",
 * "Attribute"); put("AccessLevelPopUp", "Access Level(s)");
 * put("ToolTip_ControlLimitConfidenceInterval_Probability",
 * "Minimum Value = 90%" + "\n" + "Maximum Value = 99.999%");
 * put("ToolTip_WaitingFactor", "Minimum Value = 0" + "\n" +
 * "Maximum Value = 1"); put("ToolTip_FastInitialResponse",
 * "Minimum Value = 0 %" + "\n" + "Maximum Value = 99 %");
 * put("URL_ProcessingTemplateLandingPageHelpLink",
 * "ProcessingTemplates/ManagingProcessingTemplates.htm");
 * put("errorMessage_MSZLGreaterThanMSZU",
 * "mszl value should always be less than or equal to mszu value.");
 * put("errorMessage_MSZULessThanMSZL",
 * "mszu value should always be greater than or equal to mszl value.");
 * put("ProcessingTemplate_Association_Message",
 * "On removal of processing template, following associations will also be removed:"
 * ); put("URL_CalculationsLandingPageHelpLink",
 * "Calculations/ManagingCalculations.htm");
 * put("URL_CreateCalculationPageHelpLink",
 * "Calculations/CreatingCalculations.htm");
 * put("URL_EditCalculationPageHelpLink",
 * "Calculations/EditingCalculations.htm"); put("SelectAnOutputOption",
 * "Select an output option"); put("ConfigureOutput", "Configure Output");
 * put("Collect_Data", "Collect Data"); put("ChecklistRequirement_PageTitle",
 * "Define Checklist Requirements"); put("URL_GlobalConfigurationPageHelpLink",
 * "GlobalConfiguration/ConfiguringGlobalSettings.htm");
 * put("Workstation_doesn't_exist", "Workstation doesn�t exist.");
 * 
 * put("ErrorMessage_InputAlreadyExistsInEquation",
 * "Input already exists in the Equation.");
 * put("View_CollectionAids_Page_Title", "View Part Feature Details");
 * put("Static_NoEntitySelected", "Any <entity>");
 * put("ConfirmationMessage_Static_StaticToDynamic",
 * "Existing <entity> selections will be lost. Are you sure you want to switch selection mode to <StaticOrDynamic>?"
 * );
 * 
 * put("Static_xpathProcess", "Search Process Name"); put("Static_xpathPart",
 * "Search Part Name"); put("Static_xpathFeature", "Search Feature Name");
 * put("Static_xpathCheckList", "Search Checklist Name"); put("Static_xpathDC",
 * "Search Data Collection Name");
 * put("FeatureUpdate_ConfirmationMessageHeader",
 * "On updating feature type, the following associations will also be impacted."
 * ); put("AccordionItem_AssignedControlLimit_Feature",
 * "Assigned to control limit");
 * put("AccordionItem_AssignedPartFeature_Feature",
 * "Assigned to part feature details"); put("FeatureUpdate_PopUpTitle",
 * "Update feature type"); put("WarningLimitToolTip",
 * "Range should be between 1% to 99%"); put("ReasonableLimitToolTip",
 * "Range should be between 1.01 to 50"); put("StaticEntityPage_PageTitle",
 * "Select <EntityName>"); put("DynamicEntity_PageTitle",
 * "Select <EntityName> (to <Condition>)"); put("ValueAlreadySelected",
 * "Value already selected."); put("Entity_DoesNot_Exist",
 * "<EntityName> doesn't exist."); put("NoTagAvailableForSelection",
 * "No tag available for selection"); put("CountSelectedMessage",
 * "<count> <EntityName> Selected"); put("label_EntitySelected",
 * "<EntityName> Selected:"); put("dynamicCriteria_DefaultMessage", "Click/Tap "
 * + "\n" + "<CriteriaName>" + "\n" + " or " + "\n" + "Tag Group" + "\n" +
 * " to add selection criteria.");
 * 
 * put("CalculationNameAlreadyExists", "Calculation name already exists.");
 * put("AddInput", "Add Input"); put("Alert", "Alert");
 * put("UsedEntityCantBeChangedInEquationMessage",
 * "<Entity Name> can�t be changed as it is used in the equation.");
 * put("UsedEntityCantBeDeletedInEquationMessage",
 * "<Entity Name> can�t be removed as it is used in the equation.");
 * put("viewPopUpTitleCalculation", "Calculation: <Entity Name>");
 * put("lbl_ViewProcess", "View Process");
 * put("ViewProcessModalBoxMoreThanOneCountMessage",
 * "(<Count> processes exist.)"); put("ViewPartModalBoxMoreThanOneCountMessage",
 * "(<Count> Parts exist.)"); put("lbl_ViewPart", "View Part");
 * put("CalculationViewPopUpModalBoxTitle", "Calculation: <Entity Name>");
 * put("CalculationNameAlreadyExistsAsRemovedRecord",
 * "Calculation name already exists as removed record.");
 * put("SAYT_NoRecordFoundMessage", "NO RECORD FOUND");
 * put("ErrorMessage_FeatureDoesntExists", "Feature doesn't exist.");
 * put("ErrorMessage_FeatureUsedAsOutput", "Feature used as an Output");
 * put("ColumnName_Output", "Output"); put("Initiators_Header_Title",
 * "Initiators"); put("lbl_ViewInitiator", "View Initiator");
 * put("ViewInitiatorModalBoxMoreThanOneCountMessage",
 * "(<Count> initiators exist.)");
 * put("ViewFeatureModalBoxMoreThanOneCountMessage",
 * "(<Count> Features exist.)"); put("Step1", "STEP 1"); put("Step2", "STEP 2");
 * put("errorMessage_AtLeastOneStepIsRequired",
 * "At least one step is required.");
 * put("errorMessage_AllInitiatorsMustBeDefined",
 * "All initiators must be defined.");
 * put("errorMessage_AtLeastOneOutputMustBeDefined",
 * "At least one saved output must be defined.");
 * put("toolTipOnlyOneOperatorIsAllowed", "Only one operator is allowed.");
 * put("CalculationName_AlreayExists", "Calculation name already exists.");
 * put("ErrorMessage_NestedFunctionNotAllowedWithMoreButton",
 * "Nested functions will not be allowed.");
 * put("ErrorMessage_NestedFunctionNotAllowed",
 * "Nested functions will not be allowed."); put("StepCount", "STEP <count>");
 * put("errorMessage_AtLeastOneStepIsRequiredWithOutMoreButton",
 * "At least one step is required."); put("ErrorMessage_OutputMustBeDefined",
 * "Output must be defined."); put("Long Name", "Long Name");
 * put("AccordionItem_AssignedChecklist",
 * "Checklist(s) having only one removed feature assignment will also be removed. Impacted checklist"
 * ); put("URL_FeatureLandingPageHelpLink", "Features/ManagingFeatures.htm");
 * put("URL_CreateFeaturePageHelpLink", "Features/CreatingFeatures.htm");
 * put("URL_EditFeaturePageHelpLink", "Features/EditingFeatures.htm");
 * put("ErrorMessage_ThisItemWasRemoved", "This item was removed.");
 * put("FeatureAlreadyDefinedInOtherCalculation",
 * "<Entity Name> is also defined in other Calculations.");
 * put("ErrorMessage_InvalidEntry", "Invalid entry");
 * put("ErrorMessage_OutputAlreadyDefinedInStep",
 * "Output already defined in Step <Count>.");
 * put("toolTipParameterMustBeInputOrSavedFeature",
 * "Parameter must be an Input or a saved feature."); put("Backspace",
 * "Backspace"); put("FeatureAlreadyDefinedInOtherCalculationInStep",
 * "<Entity Name> is also defined in <Entity Name1> - Step <Step Count>.");
 * put("PopUp_RemoveStepTitle", "Remove Step <Count>");
 * put("PopUp_RemoveStepMessage", "Do you want to remove step <Count>");
 * put("ErrorMessage_FeatureAlsoDefinedInStep",
 * "<Entity Name> is also defined in step <Count>.");
 * put("productionAssignments", "Production Assignments"); put("English - US",
 * "English - US"); put("English - UK", "English - UK"); put("German - Germany",
 * "German - Germany"); put("Spanish - Mexico", "Spanish - Mexico");
 * put("Vietnamese - Vietnam", "Vietnamese - Vietnam"); put("Header_Purge",
 * "Purge"); put("Purge_HelperMessage",
 * "ATTENTION: Purging will permanently delete all removed items.");
 * put("Header_PurgeAllItems", "Purge All Items");
 * put("msg_PurgePopUp_ConfirmationMessage",
 * "Do you want to permanently delete all removed item(s)?" + "\n" + "\n" +
 * "On purging, following item(s) will be deleted:");
 * 
 * put("Msg_NoRemovedItemAvailable",
 * "No removed item is available for purging.");
 * put("GC_DCType_AlreadyExistAsRemovedMessage",
 * "Data Collection Type already exists as removed record.");
 * put("UnitOfMeasurementAlreadyExistsAsRemovedRecord",
 * "Unit of Measurement already exists as removed record.");
 * put("AbbreviationAlreadyExistsAsRemovedRecord",
 * "Abbreviation already exists as removed record."); put("msg_PurgeRunning",
 * "Purge is running in the background. It may take some time to complete." +
 * "\n" + "Feel free to navigate."); put("msg_CantRestoreMessage",
 * "<EntityName> can�t be restored as it is going to be purged.");
 * put("msg_PurgeFailed", "Last purge failed at"); put("msg_PurgeSuccess",
 * "Last purge successfully completed at"); put("lbl_AllRemovedItems",
 * "All Removed Items"); put("lbl_ProcessCollection", "Process Collection");
 * put("lbl_Appearance", "Appearance"); put("URL_CodeGroupLandingPageHelpLink",
 * "http://enacthelp.infinityqs.com/en-us/CodeGroups/ManagingCodeGroups.htm");
 * put("URL_EditCodeGroupLandingPageHelpLink",
 * "http://enacthelp.infinityqs.com/en-us/CodeGroups/EditingCodeGroups.htm");
 * put("URL_CreateCodeGroupLandingPageHelpLink",
 * "http://enacthelp.infinityqs.com/en-us/CodeGroups/CreatingCodeGroups.htm");
 * put("CodeGrp_AlreadyExistAsRemoved",
 * "Code Group already exists as removed record.");
 * put("CodeName_AlreadyExistAsRemoved",
 * "Code Name already exists as removed record."); put("TagGrp_AlreadyAssigned",
 * "Tag Group already assigned."); put("ErrorMessage_FeatureAlreadySelected",
 * "Feature already selected.");
 * put("AccordionItem_AssignedControlLimitMessage",
 * "Assigned to control limit data stream");
 * put("AccordionItem_AssignedUserAccessLevelMessage",
 * "Assigned as the only access level to user");
 * put("AccordionItem_AssignedWorkstationAccessLevelMessage",
 * "Assigned as the only access level to workstation");
 * put("AccordionItem_AssignedGaugeDeviceMessage_Process",
 * "Assigned as the only process to gauge device");
 * put("AccordionItem_AssignedLotMessage", "Assigned to lot");
 * put("AccordionItem_AssignedCalculationMessage", "Assigned to Calculation");
 * put("AccordionItem_AssignedProductionAssignmentsWillBeImpacted",
 * "Associated production assignments will be impacted");
 * put("txtPartProcessHeading", "Process & Part");
 * put("Label_LimitParameterSet",
 * "Limit parameter set to return Latest\nXrecords");
 * put("lblFeatureInCapitals", "FEATURE"); put("lblTestCaluclationPopUpTitle",
 * "Test Calculation"); put("lblValues", "Values");
 * put("txtMessageIsALsoDefinedInOtherCalculations",
 * "is also defined in other calculations:"); put("Step1_InCamelLetters",
 * "Step 1"); put("Data Collection - Features", "Data Collection - Features");
 * put("LandingPage_ContextMenu_LanguageIconText", "Language Label");
 * put("Lbl_AssignedChecklist", "Assigned to checklist");
 * put("Lbl_ParentProcessUpdateConfirmationMessage",
 * "On changing the parent process, the following associations will also be removed:"
 * ); put("Associated control limit records will be impacted",
 * "Associated control limit records will be impacted"); put("lblWorkDashboard",
 * "Work Dashboard"); put("lblError_TestCalculationPopUp", "Error!");
 * put("Static_xpathShift", "Search Shift Name"); put("ChecklistInCaps",
 * "CHECKLIST"); put("lblEditSubGroup", "Edit Subgroup"); put("lblDataTable",
 * "Data Table"); put("columnName_TimeZone", "Time Zone");
 * put("msg_ParentAndChildCantExistWithSameName",
 * "Parent and child process can't exist with same short name."); put("user",
 * "user"); put("msg_CantBeAssignedAsParentProcess",
 * "<EntityName> can't be assigned as a parent process.");
 * put("msg_ParentProcesslAlreadyContainsChildAsRemovedRecord",
 * "Parent process already contains a child process with same short name as removed record."
 * ); put("msg_ProcessCantBeRestoredUntilParentIsRestored",
 * "<ChildProcessName> process can't be restored until the parent process <ParentProcessName> is restored."
 * ); put("MenuTemplateName_AlreadyExistAsRemoved",
 * "Menu Template Name already exists as removed record.");
 * put("ParentProcessPopUp_CompanyDivisionCanNotSelect_Msg",
 * "Company and Division levels cannot be selected because data exists.");
 * put("ResponseGroupAlreadyExists", "Response Group already exists.");
 * put("ChoiceAlreadyExists", "Choice already exists.");
 * put("AccessCodeIsIncorrect", "Access code is incorrect.");
 * put("AuthenticateWorkstation", "Authenticate Workstation");
 * put("PleaseEnterTheAccessCodeSentToYourEmailId",
 * "Please enter the access code sent to your email id.");
 * put("Permissions_Assign", "Assign");
 * put("DC_Config_Common_NotificationMessage",
 * "Highlighted Feature/Part Family/Operation notifies that no gauge device or item name/part/process is associated with it respectively."
 * ); put("ShowingResult_Lbl", "Showing <count> Results");
 * 
 * put("LanguagelabelsSavedSuccesssfullyMessage",
 * "Language labels of <languageLabel> saved successfully.");
 * put("Lbl_SequenceRule", "Sequence Rule");
 * put("WorkStation_RemoteAuthentication", "Remote Authentication");
 * put("WorkStation_LocalAuthentication", "Local Authentication");
 * put("Lbl_Notification", "Notification"); put("Lbl_PromptForSampleSize",
 * "Prompt for Sample Size"); put("Lbl_SampleTime", "Sample Time");
 * put("Lbl_RequiredInformation", "Required Information");
 * put("Lbl_Application", "Application"); put("Lbl_CodeType", "Code Type");
 * put("Lbl_EventCode", "Event Code"); put("Lbl_EventCodes", "Event Codes");
 * put("Error_NoAccess_DataEntry",
 * "<EntityName> does not have access to data entry. Please re-enter.");
 * put("OneProcessSelectedMessage", "1 Process selected");
 * put("EditTotalLicense_NotificationMessage",
 * "Modifying license count immediately impacts your bill.");
 * put("License_ValidationMinCount", "Minimum licenses must be <count>.");
 * put("PartRecipe(s)SavedSuccessfullyMessage",
 * "Part recipe(s) of <OutputPart> saved successfully."); put("PartRecipes",
 * "Part Recipes"); put("CreatePartRecipe", "Create Part Recipe");
 * put("SelectProcessModel", "Select Process Model");
 * put("CreatePartRecipePageNoticiationMessage",
 * "Please add the part for corresponding part family. At least one input and one output part family must be assigned a part."
 * ); put("ProcessModelDoesntExist", "Process Model doesn't exist.");
 * put("SelectPart&ItsRevisionToCopyPartRecipe(s)",
 * "Select Part & its revision to copy part recipe(s)");
 * put("AccordionItem_AssignedParameterSet", "Assigned to parameter set");
 * put("Production_Assignments", "Production Assignments");
 * put("CreateProductionAssignment", "Create Production Assignment");
 * put("EditProductionAssignment", "Edit Production Assignment");
 * put("ActiveAssignments", "Active Assignments");
 * put("Assigments(Latest30Days)", "Assigments (Latest 30 days)");
 * put("OverlappingCombinationWillNotBeAllowed",
 * "Overlapping with same <part lot combination> combination will not be allowed."
 * ); put("ProductionAssignmentSavedSuccessfullyMessage",
 * "Production Assignment of <processName> saved successfully.");
 * put("ProductionAssignmentDeleteConfirmationMessage",
 * "Production assignment of <processName> will be permanently deleted. Do you still want to remove?"
 * ); put("ProductionAssignmentDeletePopUpTitle",
 * "Remove <processName> Production Assignment");
 * put("ProductionAssignmentDeleteSuccessfullyMessage",
 * "Production Assignments of <processName> removed successfully.");
 * put("Lbl_EventCodeName", "Event Code Name"); put("Lbl_ConfigureCodeTypes",
 * "Configure Code Types"); put("LanguageLabelSavedSuccessfullyForCodeType",
 * "Language labels of code type(s) saved successfully.");
 * put("LanguageLabelSavedSuccessfullyForCode",
 * "Language labels of event code(s) saved successfully."); put("Pareto",
 * "Pareto"); put("Hierarchy", "Hierarchy"); put("Violation", "Violation");
 * put("CollectedDataType", "Collected Data Type"); put("CollectionName",
 * "Collection Name"); put("EventCode", "EventCode"); put("EventCodeType",
 * "Event Code Type"); put("CollectedData", "Collected Data");
 * put("ProcessEvents", "Process Events"); put("SubgroupData", "Subgroup Data");
 * put("SystemAlerts", "System Alerts");
 * put("ToolTip_ControlLimitConfidenceInterval_Sigma", "Minimum Value = 1.632" +
 * "\n" + "Maximum Value = 4.417"); put("productionAssignment",
 * "Production Assignment");
 * 
 * put("undefined", "Undefined"); put("ParetoChart", "Pareto Chart");
 * put("Select View Type", "Select View Type"); put("Graph", "Graph");
 * put("GraphAndReport", "Graph & Report"); put("Report", "Report");
 * put("Total", "Total"); put("Pieces", "Pieces"); put("SIGL", "SIGL");
 * put("Total", "Total"); put("PartNotExistsWithoutX", "Part doesn't exist.");
 * put("Company", "Company");
 * put("ProductionAssignmentRemovalConfirmationMessage",
 * "Do you want to remove production assignment of <PartLotName> combination of <StartEndTime>?"
 * ); put("ProductionAssignmentRemovalConfirmationMessageWithoutTime",
 * "Do you want to remove production assignment of <PartLotName>?");
 * put("ProductionAssignmentRemovalConfirmationMessageBlankRow",
 * "Do you want to remove Production Assignment?");
 * put("ProductionAssignmentStartTimeCantGreaterMessage",
 * "Start Date & Time can�t be greater than the End Date & Time.");
 * put("ProductionAssignment_AtLeastOneAssingmentMessage",
 * "At least a production assignment needs to be defined.");
 * put("ProductionAssignment_RemovePopUp_Header",
 * "Remove Production Assignment"); put("ConfigureFilters",
 * "Configure Filters"); put("PartActiveAssignment",
 * "Part (Active Assignments)"); put("LotActiveAssignment",
 * "Lot (Active Assignments)"); put("Percent of Total (Count)",
 * "Percent of Total (Count)"); put("Pareto Chart", "Pareto Chart");
 * put("Chart Summary", "Chart Summary"); put("Total Subgroups",
 * "Total Subgroups"); put("Total Pieces", "Total Pieces"); put("Date Range",
 * "Date Range"); put("Part(s)", "Part(s)"); put("Process(es)", "Process(es)");
 * put("Feature(s)", "Feature(s)"); put("Total Events", "Total Events");
 * put("Portuguese_Brazil", "Portuguese - Brazil"); put("Spanish_Spain",
 * "Spanish - Spain"); put("Define Levels", "Define Levels");
 * put("No data to display. Please", "No data to display. Please");
 * put("select Parameter Set", "select Parameter Set."); put("Division",
 * "Division"); put("Region", "Region"); put("Site", "Site"); put("Department",
 * "Department"); put("Area", "Area"); put("Process Unit", "Process Unit");
 * put("Process", "Process"); put("Sub Process", "Sub Process");
 * put("No data to display", "No data to display");
 * put("Please select a chart to view details",
 * "Please select a chart to view details"); put("Select Level",
 * "Select Level"); put("Manual", "Manual"); put("EnterTag", "Enter Tag");
 * put("TagValueCharacterLimitMessage",
 * "Text cannot exceed <limit> character(s).");
 * put("TagValueMaximumValueMessage",
 * "Value cannot be greater than maximum defined value.");
 * put("errorMessage_AtLeastOneOutputMustBeDefinedWithoutMoreButton",
 * "At least one saved output must be defined.");
 * 
 * put("Lot_DeleteConfirmation_Message", "Do you want to remove <Element Name>?"
 * + "\n" + "\n" +
 * "On removal of lot, following associations will also be removed:");
 * put("ChangeHistory", "Change History"); put("Assign/Unassign",
 * "Assign/Unassign"); put("ChangeType", "Change Type"); put("Restore",
 * "Restore"); put("Column_RecordDate", "Record Date"); put("ASCII_LABEL",
 * "ASCII"); put("PreviousValue", "Previous Value"); put("Changes", "Changes");
 * put("Collections", "Collections"); put("LowerToggleState",
 * "Lower (<limit>) Events toggle state"); put("UpperToggleState",
 * "Upper (<limit>) Events toggle state"); put("LowerLimit", "Lower (<limit>)");
 * put("UpperLimit", "Upper (<limit>)"); put("MAVLSC",
 * "MAVMethod - Label Stated Content (LSC)"); put("T1T2LSC",
 * "T1T2Method - Label Stated Content (LSC)"); put("MAVUnitSameAsSpec",
 * "MAVMethod - Same as Manufacturing Limit Unitscheck-box state");
 * put("T1T2UnitSameAsSpec",
 * "T1T2Method - Same as Manufacturing Limit Unitscheck-box state");
 * put("MAVUnit", "MAVMethod - Units"); put("T1T2Unit", "T1T2Method - Units");
 * put("MaxGreaterUpper", "Max % > MAV Upper"); put("MaxLessLower",
 * "Max % < MAV Lower"); put("MAVUpperToggleState",
 * "MAV Upper Events toggle state"); put("MAVLowerToggleState",
 * "MAV Lower Events toggle state"); put("MAVUpper", "MAV Upper");
 * put("MAVLower", "MAV Lower"); put("MAXBetweenT1T2Upper",
 * "Max % between T1 T2Upper"); put("MAXBetweenT1T2Lower",
 * "Max % between T1 T2Lower"); put("View_Limit_Page_Title", "View Limit");
 * put("Default Name", "Default Name");
 * put("Message_RestoreConfirmation_WithoutAssociation_SpecLimit",
 * "Do you want to restore manufacturing limit record for <Element Name> combination?"
 * + "\n\n" +
 * "On restoration of manufacturing limit, impacted associations will also be restored."
 * ); put("Message_RestoreSuccess_SpecLimit",
 * "Limit of <Element Name> restored successfully.");
 * put("Message_SpecAlreadyExistForGivenCombination",
 * "Manufacturing Limit already exists as removed record for <Element Name> combination. Manufacturing Limit needs to be restored first before using it."
 * );
 * 
 * put("BulkDeleteSubgroupData", "Bulk Delete Subgroup Data"); put("Prompt",
 * "Prompt"); put("Prompt (Limited)", "Prompt (Limited)"); put("No Prompt",
 * "No Prompt"); put("DataCollectionTypeCountMessage",
 * "<count> Data Collection Type Selected");
 * put("GaugeInterfaceNameAlreadyExists",
 * "Gauge Interface Name already exists.");
 * put("GaugeInterfaceModifyMessageWhenDeviceIsAssociated",
 * "Modifying a gauge interface will affect all the gauge devices using this gauge interface."
 * + "\n" + "\n" + "Do you still want to continue?"); put("ViewGaugeDevice",
 * "View Gauge Device"); put("ViewGaugeDevicePopUpMessageForSingleDevice",
 * "Gauge Interface: <interfaceName> (1 gauge device exists.)");
 * put("ViewGaugeDevicePopUpMessageForMultipleDevices",
 * "Gauge Interface: <interfaceName> (<count> gauge devices exist.)");
 * put("ViewGaugeFormat", "View Gauge Format");
 * put("ViewGaugeFormatPopUpMessageForSingleFormat",
 * "Gauge Interface: <interfaceName> (1 gauge format exists.)");
 * put("ViewGaugeFormatPopUpMessageForMultipleFormat",
 * "Gauge Interface: <interfaceName> (<count> gauge formats exist.)");
 * 
 * put("No Prompt", "No Prompt"); put("DataCollectionTypeCountMessage",
 * "<count> Data Collection Type Selected"); put("EntityAlreadyExistMessage",
 * "<Entity Name> already exists."); put("Permissions_Configure", "Configure");
 * put("ASCIICharacterValues", "ASCII Character Values"); put("DataPurge",
 * "Data Purge"); put("Odd", "Odd"); put("Even", "Even"); put("Space", "Space");
 * put("Mark", "Mark"); put("XON/XOFF", "ON/XOFF"); put("CTS/RTS", "CTS/RTS");
 * put("RTS=off/DTR=on", "RTS=off/DTR=on"); put("View_Code_Types",
 * "View Code Types"); put("Configure_Code_Types", "Configure Code Types");
 * 
 * put("AccordionItem_AssignedEventCodes", "Assigned event codes");
 * put("RemoveConfirmationMessage_CodeTypeAssociatedWithEventCode",
 * "Code type <CodeTypeName> can�t be removed as event codes are associated with it."
 * ); put("Message_AtleastOneRequired", "At least 1 <entity> required.");
 * put("Entity_AlreadyExistAsRemoved",
 * "<EntityName> already exists as removed record.");
 * put("ValidationForGaugeAgentGaugeInterfaceAndComPortCombination",
 * "Combination of same gauge interface and data port configuration already exists for this agent."
 * ); put("SubValidationForGaugeAgentGaugeInterfaceAndComPortCombination",
 * "Same data port configuration settings are already assigned to another gauge interface for this agent."
 * ); put("Less", "Less"); put("LevelWithCount", "Level <Count>");
 * put("BasicInformation", "Basic Information"); put("Advanced", "Advanced");
 * put("FormatDescription", "FORMAT DESCRIPTION"); put("RecordDescription",
 * "RECORD DESCRIPTION"); put("MultiFieldOutputSection",
 * "MULTI FIELD OUTPUT SECTION"); put("MDC_HelpSectionDefaultMessage",
 * "Measure the <FeatureName> of <PartName>."); put("Analysis", "Analysis");
 * put("Data Management", "Data Management"); put("MDC_DefectiveCount",
 * "<count> Defective"); put("MDC_DefectiveViolationHeader",
 * "Defective: <PartFeatureName>"); put("MDC_AddLotDetails_SubHeading",
 * "Select the lot for <partName> part"); put("Port_Initialization_String",
 * "Port Initialization String"); put("Port_Termination_String",
 * "Port Termination String"); put("Delay(ms)", "Delay (ms)"); put("OK", "OK");
 * put("MDC_Piece_Info", "Piece <PieceNo> of <Total>"); put("MDC_PieceNumber",
 * "Piece <PieceNo>"); put("MDC_LotIsUnavailable",
 * "Lot is unavailable for selection."); put("MDC_TotalCount_SummaryHeader",
 * "<FeatureName> - Summary"); put("MDC_TotalCount", "Total : <count>");
 * put("ValidationForGaugeAgentGaugeInterfaceComPortCombinationAndGaugeFormat",
 * "Combination of same gauge interface (with communication source) and gauge format already exists for this agent."
 * ); put("Gauge_Interface_Connection", "Gauge Interface Connection");
 * 
 * put("Gauge_Agent", "Agent"); put("Process_Name", "Process Name");
 * put("ProcessView_PopUp_Header",
 * "Gauge Device: <gaugeDeviceName> (<Count> process exists.)");
 * put("ProcessView_PopUp_Header_For_Multiple_Process",
 * "Gauge Device: <GaugeDeviceName> (<Count> processes exist.)");
 * put("GaugeIntefaceConnectionMsgForSingleGaugeDevice",
 * "Gauge Interface Connection: <AgentName> - <InterfaceName> (<ComPortSetting>) (<count> gauge device exists.)"
 * ); put("ModifyingAGaugeInterfaceConnectionWillAffect2GaugeDevices",
 * "Modifying a gauge interface connection will affect 2 gauge devices.");
 * put("RawData", "Raw Data"); put("HexData", "Hex Data");
 * put("SpecialCharacters", "Special Characters"); put("CarriageReturn",
 * "Carriage Return"); put("LineFeed", "Line Feed"); put("SerialDataMonitor",
 * "Serial Data Monitor"); put("Compliance", "Compliance"); put("StreamSummary",
 * "Stream Summary"); put("ControlCharts", "Control Charts"); put("NetContent",
 * "Net Content"); put("Within", "Within"); put("Deviation", "Deviation");
 * put("Compliance_Values_Heading", "Compliance (Values");
 * put("ComplianceDataCollections_Heading", "Compliance (Data Collections)");
 * put("Received", "Received");
 * put("DeleteConfirmaitonMessageWhenProcessAssociationWillNotRemove",
 * "Gauge device can�t be removed as it is assigned to one or more other processes. Few process associations of this gauge device will be removed."
 * ); put("DeleteConfirmaitonMessageWhenProcessIsNotAssociate",
 * "Gauge device can�t be removed as it is assigned to one or more other processes. Process associations of this gauge device will not be removed."
 * ); put("DeleteConfirmaitonMessageWithAssociationswithDC", "Do you want " +
 * "to remove <Element Name>?" + "\n" + "\n" +
 * "On removal of gauge device, following associations will also be impacted:");
 * put("AccordionItem_AssignedDC", "Impacted data collection");
 * 
 * put("Gauge Initialization String", "Gauge Initialization String");
 * put("Measurement Initialization String",
 * "Measurement Initialization String"); put("Measurement Start String",
 * "Measurement Start String"); put("Measurement End String",
 * "Measurement End String"); put("Measurement Read String",
 * "Measurement Read String"); put("Measurement Post String",
 * "Measurement Post String"); put("Measurement Request String",
 * "Measurement Request String"); put("Data Collection Start String",
 * "Data Collection Start String"); put("Data Collection End String",
 * "Data Collection End String"); put("GaugeFormatNameAlreadyExists",
 * "Gauge Format Name already exists."); put("0 - ASCII/Text",
 * "0 - ASCII/Text"); put("1 - ASCII (16 bit)", "1 - ASCII (16 bit)");
 * put("2 - Binary (LSByte First)", "2 - Binary (LSByte First)");
 * put("3 - Binary (MSByte First)", "3 - Binary (MSByte First)");
 * put("ValidationForMultifieldSelectSendBox",
 * "At least a numeric type item needs to have send enabled in multi field output section grid."
 * ); put("ValidationForMultifieldNumericSelect",
 * "At least a numeric type item needs to be defined in multi field output section grid."
 * ); put("EntryMethodGDErrorMessage", "No <Element Name> available");
 * put("ValidationForGaugeDeviceGaugeAgentGaugeInterfaceComPortCombination",
 * "Combination of same gauge device name and gauge interface connection (with communication source) already exists for this agent."
 * ); put("GaugeMultiFieldValidation",
 * "Item is improperly configured in multi field output section grid.");
 * put("EditGaugeFormatConfirmaitonMessageWhenAttachedToGaugeDevice",
 * "Modifying a gauge format will affect all the gauge devices using this gauge format."
 * + "\n" + "\n" + "Do you still want to continue?");
 * put("ViewGaugeDevicePopUpForGaugeFormat",
 * "Gauge Format: <formatName> (1 gauge device exists.)");
 * put("removeGaugeFormatConfirmaitonMessageWhenAttachedToGaugeDevice",
 * "Do you want to remove <formatName>?" + "\n" + "\n" +
 * "On removal of gauge format, following associations will also be impacted:");
 * 
 * put(
 * "DeleteConfirmaitonMessageWithAssociationsForGaugeInterfaceForNonRemovableGD"
 * , "Gauge InterfaceX can't be removed " +
 * "as it is assigned to non removable gauge device(s).");
 * put("AccordionItem_AssignedNonRemovableGaugeFormat",
 * "Gauge Format(s) can�t be removed as it is assigned to non removable Gauge Device(s). Associated Gauge Format"
 * ); put("AccordionItem_AssignedNonRemovableGaugeDevice",
 * "Gauge device(s) can�t be removed as it is assigned to one or more other processes. Process associations of the gauge device(s) will not be removed. Associated Gauge Device"
 * );
 * 
 * put("Send", "Send");
 * 
 * put("= [Field]", "= [Field]"); put("<> [Field]", "<> [Field]");
 * put("> [Field]", "> [Field]"); put("< [Field]", "< [Field]");
 * put(">= [Field]", ">= [Field]"); put("<= [Field]", "<= [Field]");
 * put("Contains", "Contains"); put("ExclusionRule", "Exclusion Rules");
 * put("AssociationMessage_RemovedSingleGaugeDevice",
 * "Removed Gauge Device (1)"); put("GaugeFormatTesting_TestText",
 * "This section is for gauge format testing and it will only be enabled during gauge device setup."
 * ); put("GaugeFormatTesting_TestingArea",
 * "Initialize Gauge or Initialize Port must be pressed before any changes go into effect."
 * ); put("Field# = ", "Field# ="); put("Start Position = ",
 * "Start Position ="); put("Length = ", "Length =");
 * put("ManufacturingLimitViolation", "Manufacturing Limit Violation");
 * put("URL_CreateProcessingTemplatePageHelpLink",
 * "ProcessingTemplates/CreatingProcessingTemplates.htm");
 * put("URL_EditProcessingTemplatePageHelpLink",
 * "ProcessingTemplates/EditingProcessingTemplates.htm");
 * put("WorkFlow_Header_Title", "Workflows"); put("CreateWorkFlow_Page_Title",
 * "Create Workflow"); put("Lbl_EventCategory", "Event Category");
 * put("Msg_WorkFlow_CodeTypehaveAtleastOneEventCode",
 * "All required/optional event code types should have at least one event code assigned to it."
 * ); put("Msg_WorkFlow_AtLeastOneCodeTypeInOptionalRequiredPanel",
 * "At least one item must be available in either required or optional column."
 * ); put("WorkFlow_Status_Active", "Active"); put("WorkFlow_Status_Inactive",
 * "Inactive"); put("WorkFlow_Status_Disabled", "Disabled");
 * put("columnName_WorkflowName", "Workflow Name");
 * put("WorkFlowAssignment_Header_Title", "Workflow Assignments");
 * put("CreateWorkFlowAssignment_Page_Title", "Create Workflow Assignment");
 * put("EditWorkFlowAssignment_Page_Title", "Edit Workflow Assignment");
 * put("AccessCode", "Access code"); put("DataView", "Data View"); put("CL",
 * "CL"); put("UCL", "UCL"); put("LCL", "LCL"); put("Histogram Chart",
 * "Histogram Chart"); put("Maximum Value", "Maximum Value");
 * put("Minimum Value", "Minimum Value"); put("Mean", "Mean");
 * put("Mean - 3SD (lt)", "Mean - 3SD (lt)"); put("Mean + 3SD (lt)",
 * "Mean + 3SD (lt)"); put("Short term SD", "Short term SD");
 * put("Long term SD", "Long term SD"); put("Robustness", "Robustness");
 * put("CoVar", "CoVar"); put("Z-bench", "Z-bench"); put("Target ratio",
 * "Target ratio"); put("Specification", "Specification"); put("Z USL",
 * "Z USL"); put("Z Target", "Z Target"); put("Z LSL", "Z LSL");
 * put("Actual Above", "Actual Above"); put("Actual Below", "Actual Below");
 * put("Actual Total", "Actual Total"); put("Actual PPM", "Actual PPM");
 * put("Expected Above", "Expected Above"); put("Expected Below",
 * "Expected Below"); put("Expected Total", "Expected Total");
 * put("Expected PPM", "Expected PPM"); put("Potential Indices",
 * "Potential Indices"); put("Cp", "Cp"); put("Cr (1/Cp)", "Cr (1/Cp)");
 * put("Pp", "Pp"); put("Pr (1/Pp)", "Pr (1/Pp)"); put("Performance Indices",
 * "Performance Indices"); put("Cpk", "Cpk"); put("Cpk Upper", "Cpk Upper");
 * put("Cpk Lower", "Cpk Lower"); put("Cpm", "Cpm"); put("SIGL (st)",
 * "SIGL (st)"); put("Ppk", "Ppk"); put("Ppk Upper", "Ppk Upper");
 * put("Ppk Lower", "Ppk Lower"); put("Ppm", "Ppm"); put("SIGL (lt)",
 * "SIGL (lt)"); put("Moments of Distribution", "Moments of Distribution");
 * put("Avg Deviation", "Avg Deviation"); put("Std Deviation", "Std Deviation");
 * put("Variance", "Variance"); put("Skewness", "Skewness"); put("Kurtosis",
 * "Kurtosis"); put("Chi squared Goodness of FitX",
 * "XChi squared Goodness of Fit"); put("Chi-Squared", "Chi-Squared");
 * put("DFS", "DFS"); put("Chi Sq Prob", "Chi Sq Prob");
 * put("Analysis of Variance", "Analysis of Variance"); put("d.f", "d.f");
 * put("Plot Point Value", "Plot Point Value"); put("French - France",
 * "French - France"); put("SubGroupSize", "Subgroup Size"); put("Defectives",
 * "Defectives"); put("Defects", "Defects"); put("Spec_Limit_Value",
 * "XManufacturing LimitsX"); put("delay(ms)", "delay(ms)"); put("exclude",
 * "exclude"); put("include", "include"); put("ColumnName_Reason", "Reason");
 * put("ColumnName_Assigned_Work_Dashboard", "XAssigned Work DashboardX");
 * put("ColumnName_Assigned_License", "Assigned License");
 * put("MostRecentRecord", "XMost Recent RecordX"); put("Static_xpathDCType",
 * "Search Data Collection Type"); put("EventReviews", "Event Reviews");
 * put("ProcessInformation", "Process Information"); put("EventDetails",
 * "Event Details"); put("label_SelectEventCodeType", "Select Event Code Type");
 * put("label_AddEventCode", "Add Event Code");
 * put("MDC_PartPopUp_SelectThePartMakingFromOD",
 * "Select the part you are making from <ODName>");
 * put("MDC_ProcessPopUp_SelectTheProcessForOP",
 * "Select the process for <OpName> operation");
 * put("Restore Manufacturing Limit", "Restore Manufacturing Limit");
 * put("DataCollectionTypes", "Data Collection Types"); put("Day", "Day");
 * put("DatCollectionType_Exclude",
 * "Select Data Collection Types (to exclude)");
 * put("UserReactivationConfirmationMessageWithSingleReason",
 * "Are you sure you want to re-activate this user?" + "\n" + "\n" +
 * "<UserFullName> is inactive as of <DateTimeStamp> with reason '<ReasonName>'."
 * ); put("NoRecentLogins", "No recent logins");
 * put("ReActivationSuccessMessage",
 * "<UserFullName> has been re-activated successfully.");
 * put("msg_bulkDeleteSubgroupDataSuccess",
 * "Last subgroup deletion successfully completed at <entityTime>");
 * put("ManageLicenseReport", "Manage License Report"); put("ViewReport",
 * "View Report"); put("ControlChart", "Control Chart"); put("NoItemsFound",
 * "No items found"); put("Label_All", "All");
 * put("ConfirmationMessageForLicenseAssignment",
 * "Assigning a license may impact your bill. Are you sure?");
 * put("CodeType_Camera", "Camera"); put("Danish - Denmark",
 * "Danish - Denmark"); put("Swedish - Sweden", "Swedish - Sweden");
 * put("CodeList", "Code List"); put("CodeGridIncrement",
 * "Code Grid: Increment"); put("CodeGridNumeric", "Code Grid: Numeric");
 * put("RequireCodeforEachPiece", "Require a Code for Each Piece");
 * put("BoxAndWhiskerChart", "Box and Whisker Chart");
 * 
 * }
 * 
 * };
 * 
 * }
 */