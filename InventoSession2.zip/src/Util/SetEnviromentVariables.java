package Util;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import Base.BasePage;

public class SetEnviromentVariables {

	public static void main(String[] args) {
		try {
			String flagToStartExcelSeparation = "FlagToStartExcelSeparation";

			String flagToWaitTillExcelSeperationIsDone = "ExcelSeprationsIsInProgress";
			String location = System.getProperty("user.dir") + "\\..\\..";
			String deploymentName = "";
			String threads = "";
			if (args.length > 0) {
				// Set TestSiteURL

				if (!args[12].contains("${arg")) {
					deploymentName = args[12];

				}
				if (!args[13].contains("${arg"))
					threads = args[13];

				System.out.println("Yogendra" + deploymentName);
				threads = threads.replace(".0", "");
				System.out.println("Threads:" + threads);
			}
			if (!UtilityFunctions.checkFolderExistsAtGivenLocation(location, flagToStartExcelSeparation)) {

				// create folder at given location so that other threads
				// wait till excel is divided into number of parrallel
				// threads
				UtilityFunctions.createFolderAtGivenLocation(location, flagToStartExcelSeparation);
				UtilityFunctions.createFolderAtGivenLocation(location + "\\" + flagToStartExcelSeparation,
						flagToWaitTillExcelSeperationIsDone);

				String pathOfCSVFileWithName = System.getProperty("user.dir") + "\\..\\TestCases.csv";
				String pathOfMasterExcel = System.getProperty("user.dir") + "\\resources\\TestInputMasterSheet";
				UtilityFunctions.readCSVFileAndConvertIntoExcelWithRunModeAndTCID(pathOfCSVFileWithName,
						pathOfMasterExcel + "\\MasterSheetForSanity.xlsm");

				String nameOfMasterExcel = "MasterSheetForSanity.xlsm";

				List<String> tenantList = new ArrayList<String>();
				List<String> companyIdList = new ArrayList<String>();

				String dbURL = "", dbUserName = "", dbPassword = "", userPrefferedLanguage = "en-US";
				int numberOfParrallelThreads = Integer.parseInt(threads);

				UtilityFunctions.spiltMasterSheetAndSetConfig(pathOfMasterExcel, nameOfMasterExcel,
						numberOfParrallelThreads, tenantList, companyIdList, dbURL, dbUserName, dbPassword,
						userPrefferedLanguage);

				// put these excels in sanity folders CI(i)
				for (int i = 1; i <= numberOfParrallelThreads; i++) {
					String folderName = "CI" + i;

					String src = System.getProperty("user.dir") + "\\resources\\TestInputMasterSheet\\SepartedSheets"
							+ "\\TestExecutionInput" + i + ".xlsm";
					String destination = location + "\\" + folderName + "\\Framework\\src\\Test Data"
							+ "\\TestExecutionInput.xlsm";

					File file = new File(destination);
					// delete files at destination location
					UtilityFunctions.deleteFile(file);
					// rename files at destination location
					UtilityFunctions.renameFile(src, destination);

				}

				// delete once excel is separated and put at given location.
				UtilityFunctions.deleteFolderAtGivenLocation(location + "\\" + flagToStartExcelSeparation,
						flagToWaitTillExcelSeperationIsDone);

			} else {
				System.out.println("Started waiting for  TestExecutionInput excel \nseperation in seperate thread at "
						+ UtilityFunctions.getDateForFilters());
				while (UtilityFunctions.checkFolderExistsAtGivenLocation(location + "\\" + flagToStartExcelSeparation,
						flagToWaitTillExcelSeperationIsDone)) {

					Thread.sleep(10000);

				}
				System.out.println("Completed waiting for  TestExecutionInput excel \nseperation in seperate thread at "
						+ UtilityFunctions.getDateForFilters());
			}
			if (args.length > 0) {
				// Set TestSiteURL

				if (!args[0].contains("${arg"))
					BasePage.xls.setCellData("Config", 2, 1, args[0]);
				// Set CompanyID
				if (!args[1].contains("${arg"))
					BasePage.xls.setCellData("Config", 2, 4, args[1]);

				// Set DatabaseUrl
				if (!(args[2].contains("${arg") && args[3].contains("${arg"))) {
					String jdbcString = "jdbc:sqlserver://" + args[2] + ";databaseName=" + args[3];

					BasePage.xls.setCellData("Config", 2, 7, jdbcString);
				}

				// Set DatabaseUserName
				if (!args[4].contains("${arg"))
					BasePage.xls.setCellData("Config", 2, 8, args[4]);

				// Set DatabasePassword
				if (!args[5].contains("${arg"))
					BasePage.xls.setCellData("Config", 2, 9, args[5]);
				// Set DatabaseName
				if (!args[3].contains("${arg"))
					BasePage.xls.setCellData("Config", 2, 10, args[3]);

				// parrallel count
				if (!threads.equals(""))
					BasePage.xls.setCellData("Config", 2, 14, threads);

				// ----------------------SetEmailDetails----------------------------------------------------------------------
				// SendGridHostName
				if (!args[6].contains("${arg")) {
					BasePage.xls.setCellData("EmailDetails", 1, 1, "SendGridHostName");

					BasePage.xls.setCellData("EmailDetails", 2, 1, args[6]);
				}
				// SendGridPortNumber
				if (!args[7].contains("${arg")) {
					BasePage.xls.setCellData("EmailDetails", 1, 2, "SendGridPortNumber");
					BasePage.xls.setCellData("EmailDetails", 2, 2, args[7]);
				}
				// SendGridUserName
				if (!args[8].contains("${arg")) {
					BasePage.xls.setCellData("EmailDetails", 1, 3, "SendGridUserName");
					BasePage.xls.setCellData("EmailDetails", 2, 3, args[8]);
				}

				// SendGridPassword
				if (!args[9].contains("${arg")) {
					BasePage.xls.setCellData("EmailDetails", 1, 4, "SendGridPassword");
					BasePage.xls.setCellData("EmailDetails", 2, 4, args[9]);
				}

				// FromMailUser
				if (!args[10].contains("${arg")) {
					BasePage.xls.setCellData("EmailDetails", 1, 5, "FromMailUser");
					BasePage.xls.setCellData("EmailDetails", 2, 5, args[10]);
				}
				// RecipientsList
				if (!args[11].contains("${arg")) {
					BasePage.xls.setCellData("EmailDetails", 1, 6, "RecipientsList");
					BasePage.xls.setCellData("EmailDetails", 2, 6, args[11]);
				}

				// DeploymentName
				if (!deploymentName.equals("")) {
					BasePage.xls.setCellData("EmailDetails", 1, 7, "DeploymentName");
					BasePage.xls.setCellData("EmailDetails", 2, 7, deploymentName);
				}

				BasePage.setConfigPropertiesValue();

			}
		} catch (Exception e) {
			System.out.println("Excpetion in SetEnviromentVariables :" + e.getMessage());
		}

	}

}
