package Util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.io.Reader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import Base.BasePage;
import Util.DataBaseFunctionsLibraray;

import com.ibatis.common.jdbc.ScriptRunner;

public class SQLScriptExecutor {

	// This method will execute all the .sql files to create the test data
	public static void createTestData() throws Exception {

		// Read the SQL config line by line to get the .sql files to be executed
		// and execute the files.
		String strLine, completePage = " ", sCurrentLine;
		String aSQLScriptFilePath[] = new String[15];
		String[] dataScriptPropertiesKeys = null;

		int i = 0;

		try {
			BufferedReader br = new BufferedReader(
					new FileReader(System.getProperty("user.dir") + "\\src\\Config\\DataScriptConfig.properties"));

			// Read properties file line by line and save the valid key values
			// in an
			// array

			while ((strLine = br.readLine()) != null) {
				// If the line is not blank and line is not commented
				if (!strLine.startsWith("#") && !strLine.equals("")) {
					dataScriptPropertiesKeys = UtilityFunctions.splitString(strLine, "=");

					aSQLScriptFilePath[i] = (System.getProperty("user.dir") + dataScriptPropertiesKeys[1]);

				}

				i++;
			}

			int j = 0;
			// Give the input file to Reader
			while (j <= dataScriptPropertiesKeys.length) {
				BufferedReader brr = new BufferedReader(new FileReader(aSQLScriptFilePath[j]));

				while ((sCurrentLine = brr.readLine()) != null) {

					completePage = completePage + sCurrentLine + "\n";
				}
				j++;
				DataBaseFunctionsLibraray.executeSelectQuery(completePage);
				completePage = " ";
				sCurrentLine = " ";

			}

		} catch (Exception e) {
			throw e;
		}
	}// end of method
}// end of class
