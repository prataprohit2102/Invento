package Base;

import io.appium.java_client.android.AndroidDriver;

import java.awt.AWTException;
import java.awt.Robot;
import java.io.File;
import java.io.FileInputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.events.EventFiringWebDriver;


import Pages.InventoLogin;

import Util.DataBaseFunctionsLibraray;
import Util.ExcelUtility;
//import Util.GenericTestData;
import Util.LibraryFunctions;
import Util.TestLibrary;
import Util.UtilityFunctions;
import autoitx4java.AutoItX;

import com.jacob.com.LibraryLoader;

public class BasePage {
	public static InventoLogin login1 = null; 
	public static WebDriver dr = null;
	public static WebDriver dr_incognito = null;
	public static EventFiringWebDriver driver = null;
	//public static LoginPage login = null;
	public static String listOfAllowedSpecialCharcters = "Aa1 !`~@#$%^&*-_=+\"\\:,.'<>?/{}";
	public static String listOfNotAllowedSpecialCharcters = "()";
	private File file = null;
	public static String broswerExe = "chrome.exe";
	public static String broswerDriverExe = "chromedriver.exe";
	public static boolean IsLoggedIn = false;
	public static boolean isLocalizationIsOn = false;
	public static boolean setLocalizationVariable = true;
	public static Properties TestConfiguration = new Properties();
	public static Properties DataScriptConfiguration = new Properties();
	public static String currentMethodName = null;
	public static String userPrefferedLanguageInExcel = "";
	public static boolean isPurgeActivityPerformed = false;
	public static AutoItX autoIT;
	public static Robot robot;
	private static String jacobDllVersionToUse;
	public static String fileUploadDialogTitle;
	public static Hashtable<String, String> TestConfigurationFromExcel = new Hashtable<String, String>();
	public static int numberOfTestCaseExecuted;
	public static int numberOfTestCasePassed = 0;
	public static int numberOfTestCaseFailed = 0;
	public static String startTimeOfTestCase = "";
	public static String endTimeOfTestCase = "";
	public static String appURL = "";
	public static int totalNumberOfTestCaseExecuted;
	public static boolean copyDataToTestSummarySheet = true;
	public static String commonRepositoryFolderForParallelExecution = "CommonRepositoryFolderForParallelExecution";
	public static String flagToWaitTillExcelSeperationIsDone = "ExcelSeprationsIsInProgress";
	public static String executionFolderHistory = "AutomationExecutionFolderBackUp";
	public static String combinedFailedTestCasesSheet = "CombinedFailedTestCasesSheet.xlsx";
	public static int numberOfParallelExecution = 0;
	public static String excelNameForCombinedTestResultsOfParralExecution = "CombinedTestSummary.xlsx";
	public static String excel_User = "";
	public static String current_LoggedIn_User = "";
	public static String current_LoggedIn_User_PrefferedLanugage = "";
	public static String chromeDriverPath = System.getProperty("user.dir")
			+ "\\Resources\\Chrome_Driver\\chromedriver.exe";
	public static String jacobDLLPath = System.getProperty("user.dir") + "\\..\\Lib";

	//
	static final Logger log = Logger.getLogger("BasePage");
	public static boolean executeFailedTestCasesOfAllFolderInSingleSuite = false;
	public static int numberOfFailedTestCases = 0;
	// IN Progress Xpaths
	// public static String xPath_InProgressImage =
	// "//*[@data-selector='main-conatiner']//*[@class='loader-image']";
	// public static String xPath_InProgressText =
	// "//*[@data-selector='main-conatiner']//*[@class='loader-text']";
	public static String xPath_InProgressImage = "//*[@data-selector='main-conatiner']//*[@class='loader-image']";
	public static String xPath_InProgressText = "//*[@data-selector='main-conatiner']//*[@data-selector='loading-text']";

	// Top Navigation bar
//	public static PageHeader pageHeaderNavigation = new PageHeader();
	static File fileTestConfiguration = null;
	static File fileTestExecutionInput = null;
	public static boolean configPropertyValueIsNotEmpty = false;
	static String deviceID = null;
	public static String srcPath = System.getProperty("user.dir");
	public static int db_Default_CreatedAndUpdatedByUserId = 1;
	public static Hashtable<String, String> sharedStepsPassFailStatus = new Hashtable<String, String>();
	public static String titleOfTestCase = "";
	public static boolean checkForTitle = true;
	public static int columnTitleInTestInputSheet = 0;
	// date time formats

	// "d/MM/yyyy hh:mm:ss"
	public static SimpleDateFormat simpleDateFormat_Standard = null;

	// "yyyy-MM-dd HH:mm:ss"
	public static SimpleDateFormat simpleDateFormat_1 = null;

	// "yyyy-M-dd HH:mm"
	public static SimpleDateFormat simpleDateFormat_2 = null;

	// "M/d/YYY h:mm:ss a"
	public static SimpleDateFormat simpleDateFormat_3 = null;

	// "yyyy-MM-dd HH:mm"
	public static SimpleDateFormat simpleDateFormat_4 = null;

	// "M/d/yyyy h:mm a"
	public static SimpleDateFormat simpleDateFormat_5 = null;

	// "M/d/yyyy h:mm"
	public static SimpleDateFormat simpleDateFormat_6 = null;

	// "M/d/YYYY"
	// changed to M/d/yyyy on 29-03-2019
	public static SimpleDateFormat simpleDateFormat_7 = null;

	// "a"
	public static SimpleDateFormat simpleDateFormat_8 = null;

	// "h:m"
	public static SimpleDateFormat simpleDateFormat_9 = null;

	// "yyyy-M-dd HH:mm:ss"
	public static SimpleDateFormat simpleDateFormat_10 = null;

	// "M/d/yyyy h"
	public static SimpleDateFormat simpleDateFormat_11 = null;

	// "MM/dd/yyyy"
	public static SimpleDateFormat simpleDateFormat_12 = null;

	// "M/dd/yyyy h:mm a"
	public static SimpleDateFormat simpleDateFormat_13 = null;

	// "M/dd/yyyy hh:mm:ss a"
	public static SimpleDateFormat simpleDateFormat_14 = null;

	// "yyyy-M-dd hh:mm:ss a"
	public static SimpleDateFormat simpleDateFormat_15 = null;

	// "M/dd/yyyy hh:mm:ss a"
	public static SimpleDateFormat simpleDateFormat_16 = null;

	// "MM/dd/YYYY hh:mm a"
	public static SimpleDateFormat simpleDateFormat_17 = null;

	// "MM/dd/YYY hh:mm a"
	public static SimpleDateFormat simpleDateFormat_18 = null;

	// "M/d/yyyy h:mm:00 a"
	public static SimpleDateFormat simpleDateFormat_19 = null;

	// "M/d/yyyy h:mm:59 a"
	public static SimpleDateFormat simpleDateFormat_20 = null;

	// "M/d/yyyy h:00:00 a"
	public static SimpleDateFormat simpleDateFormat_21 = null;

	// "M/d/yyyy h:59:59 a"
	public static SimpleDateFormat simpleDateFormat_22 = null;

	// "M/dd/yyyy h:00:00 a"
	public static SimpleDateFormat simpleDateFormat_23 = null;

	// "M/dd/yyyy h:mm:ss a"
	public static SimpleDateFormat simpleDateFormat_24 = null;

	// "M/d/YYY h:mm a"
	public static SimpleDateFormat simpleDateFormat_25 = null;

	// "yyMMddHHmmss"
	public static SimpleDateFormat simpleDateFormat_26 = null;

	// "dd-MM-yyyy hh-mm-ss a"
	public static SimpleDateFormat simpleDateFormat_27 = null;

	// "dd-M-yyyy hh:mm"
	public static SimpleDateFormat simpleDateFormat_28 = null;

	// "M/d/yyyy h:mm a"
	public static SimpleDateFormat simpleDateFormat_29 = null;

	// M/d/yyyy h:mm:ss a
	public static SimpleDateFormat simpleDateFormat_30 = null;
	
	//HH:mm:ss
	public static SimpleDateFormat simpleDateFormat_31 = null;

	static {
		// Initialize properties object

		if (System.getProperty("user.dir").contains("src")) {

			srcPath = System.getProperty("user.dir") + "\\..";

		}

		fileTestConfiguration = new File(srcPath + "\\src\\Config\\TestConfig.properties");

		PropertyConfigurator.configure(srcPath + "\\src\\Config\\log4j.properties");

		try {
			FileInputStream fileStreamTestConfiguration = new FileInputStream(fileTestConfiguration);

			TestConfiguration.load(fileStreamTestConfiguration);

		} catch (Exception e) {
			log.error("Initialization of Test Config Properties throws exception ");
		}
	}

	public static ExcelUtility xls = new ExcelUtility(srcPath + TestConfiguration.getProperty("TestInputSheetPath"));

	public static ExcelUtility xls_Summary = new ExcelUtility(
			srcPath + TestConfiguration.getProperty("TestSummarySheetPath"));

	static {

		// Set properties values for TestConfig.properties file
		setConfigPropertiesValue();

		// Set Config Properties value is not empty
		configPropertyValueIsNotEmpty = checkCofigPropertiesValueIsSet();

		deviceID = TestConfigurationFromExcel.get(ExcelUtility.CONFIG_Device_ID);

		appURL = BasePage.TestConfiguration.getProperty("TestSiteURL");

		userPrefferedLanguageInExcel = BasePage.TestConfiguration.getProperty("UserPrefferedLanguage");
		setDateTimeFormatAsPerLanguageLocale();
		numberOfParallelExecution = Integer.parseInt(TestConfiguration.getProperty("NumberOfCIParallelExecution"));

		current_LoggedIn_User_PrefferedLanugage = userPrefferedLanguageInExcel;

		if (setLocalizationVariable) {

			//setLocalizationVariable();
			System.out.println("Localization On :" + BasePage.isLocalizationIsOn);

			setLocalizationVariable = false;

		}
		// run the test data generation scripts
		try {
			// restore DB and insert generic data

			restoreDataBaseAndInsertGenericData();
			//SecurityPolicyPage.resetSecurityConfigurationFromDB();

		} catch (Exception e) {
			log.error("Error occured while Restoring and inserting Test Data in Database");
		}

	}
	// declare variables for filter for Tags
	public static final String filter_Tag_1 = "Tag_1";
	public static final String filter_Tag_2 = "Tag_2";
	public static final String filter_Tag_3 = "Tag_3";
	public static final String filter_Tag_1_Value_1 = "Tag_1_Value_1";
	public static final String filter_Tag_1_Value_2 = "Tag_1_Value_2";
	public static final String filter_Tag_1_Value_3 = "Tag_1_Value_3";
	public static final String filter_Tag_2_Value_1 = "Tag_2_Value_1";
	public static final String filter_Tag_2_Value_2 = "Tag_2_Value_2";
	public static final String filter_Tag_2_Value_3 = "Tag_2_Value_3";
	public static final String filter_Tag_3_Value_1 = "Tag_3_Value_1";
	public static final String filter_Tag_3_Value_2 = "Tag_3_Value_2";
	public static final String filter_Tag_3_Value_3 = "Tag_3_Value_3";

	// //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	// Default constructor
	public BasePage() {

	}

	// Parameterized constructor to initialize the the browsers
	// Modified By : Tanmay
	// Modified For : Moved code block to initialize logger to static blocks
	// from the constructor
	// modified by :Yogendra Rathore
	// added code to set size of browser.

	public BasePage(String browser, String AppURL) {

		if (isBrowserClosed()) {

			if (browser.equals("Mozilla")) {
				DesiredCapabilities capabilities = DesiredCapabilities.firefox();
				capabilities.setCapability("nativeEvents", false);
				dr = new FirefoxDriver(capabilities);
				dr.manage().window().maximize();
				fileUploadDialogTitle = "File Upload";
				// code to set to register the jacob dll
				// Select the appropriate jcob.dll based on the version of jdk.
				if (jvmBitVersion().contains("32")) {
					jacobDllVersionToUse = "jacob-1.18-M2-x86.dll";
				} else {
					jacobDllVersionToUse = "jacob-1.18-M2-x64.dll";
				}

				// Register the jacob.dll
				File file = new File(jacobDLLPath, jacobDllVersionToUse);
				System.setProperty(LibraryLoader.JACOB_DLL_PATH, file.getAbsolutePath());

				// Initialize the AutoIT object
				// autoIT = new AutoItX();

				// Initialize the Robot object
				try {
					robot = new Robot();
				} catch (AWTException e) {
					log.error("Error occured while creating Robot class object");
				}

			} else if (browser.equals("IE")) {
				broswerExe = "iexplore.exe";
				broswerDriverExe = "IEDriverServer.exe";
				// kill existing IE broswer driver exe
				UtilityFunctions.killProcess(broswerDriverExe);
				UtilityFunctions.killProcess(broswerExe);

				file = new File(System.getProperty("user.dir") + "\\..\\IE_Driver\\IEDriverServer.exe");
				System.setProperty("webdriver.ie.driver", file.getAbsolutePath());

				DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
				capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,
						true);

				capabilities.setCapability("initialBrowserUrl", AppURL);
				capabilities.setCapability("requireWindowFocus", false);
				capabilities.setCapability("nativeEvents", false);

				dr = new InternetExplorerDriver(capabilities);
				dr.manage().window().maximize();
				fileUploadDialogTitle = "Choose File to Upload";

				// code to set to register the jacob dll
				// Select the appropriate jcob.dll based on the version of jdk.
				if (jvmBitVersion().contains("32")) {
					jacobDllVersionToUse = "jacob-1.18-M2-x86.dll";
				} else {
					jacobDllVersionToUse = "jacob-1.18-M2-x64.dll";
				}

				// Register the jacob.dll
				File file = new File(jacobDLLPath, jacobDllVersionToUse);
				System.setProperty(LibraryLoader.JACOB_DLL_PATH, file.getAbsolutePath());

				// Initialize the AutoIT object
				// autoIT = new AutoItX();

				// Initialize the Robot object
				try {
					robot = new Robot();
				} catch (AWTException e) {
					log.error("Error occured while creating Robot class object");
				}
			} else if (browser.equals("Chrome")) {

				file = new File(chromeDriverPath);
				System.setProperty("webdriver.chrome.driver", file.getAbsolutePath());
				DesiredCapabilities capabilities = DesiredCapabilities.chrome();
				ChromeOptions options = new ChromeOptions();
				options.addArguments("test-type", "start-maximized");
				options.addArguments("enable-automation");
				options.addArguments("--disable-infobars");
				// options.addArguments("--headless");
				// options.addArguments("--window-size=1920,1080");

				options.addArguments("--disable-features=VizDisplayCompositor");
				if (!userPrefferedLanguageInExcel.equals("Default"))
					options.addArguments("--lang=" + userPrefferedLanguageInExcel);
				// added to handle save
				Map<String, Object> prefs = new HashMap<String, Object>();
				prefs.put("credentials_enable_service", false);
				prefs.put("password_manager_enabled", false);
				options.setExperimentalOption("prefs", prefs);

				capabilities.setCapability("chrome.binary", file.getAbsolutePath());
				capabilities.setCapability(ChromeOptions.CAPABILITY, options);
				capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);

				LibraryFunctions.closeBrowser();

				dr = new ChromeDriver(capabilities);
				dr.manage().window().maximize();

				// added code to set size of browser.
				int height = dr.manage().window().getSize().height;
				int width = dr.manage().window().getSize().width;
				System.out.println("width=" + width);
				System.out.println("Height=" + height);

				if (height < 841 && width < 1552) {
					Dimension d = new Dimension(1028, 656);
					// Resize the current window to the given dimension
					dr.manage().window().setSize(d);

					height = dr.manage().window().getSize().height;
					width = dr.manage().window().getSize().width;

					if (height < 841 && width < 1552) {
						System.out.println("Not able set height more than given resolution");
						System.out.println("updated width=" + width);
						System.out.println("updated Height=" + height);
					}
				}

				fileUploadDialogTitle = "Open";

				// code to set to register the jacob dll
				// Select the appropriate jcob.dll based on the version of jdk.
				if (jvmBitVersion().contains("32")) {
					jacobDllVersionToUse = "jacob-1.18-M2-x86.dll";
				} else {
					jacobDllVersionToUse = "jacob-1.18-M2-x64.dll";
				}

				// Register the jacob.dll
				File file = new File(jacobDLLPath, jacobDllVersionToUse);
				System.setProperty(LibraryLoader.JACOB_DLL_PATH, file.getAbsolutePath());

				// Initialize the AutoIT object
				// autoIT = new AutoItX();

				// Initialize the Robot object
				try {
					robot = new Robot();
				} catch (AWTException e) {
					log.error("Error occured while creating Robot class object");
				}
			}

			else if (browser.equals("AndroidChrome")) {
				DesiredCapabilities capabilities = new DesiredCapabilities(); // 47900217fa677100
																				// 19768b0b02df3581
																				// 0541d8250a22656db
																				// HT4AYJT01291
				capabilities.setCapability("device", "Android");
				capabilities.setCapability("platformName", "Android");
				capabilities.setCapability("deviceName", deviceID);

				capabilities.setCapability(CapabilityType.BROWSER_NAME, "Chrome");

				try {
					dr = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
				} catch (MalformedURLException e) {
					log.error("Error occured while creation AndroidDriver Object");
				} // End of catch

			} // End of if

			driver = new EventFiringWebDriver(dr);
			// pageHeaderNavigation = new PageHeader();
			driver.navigate().to(AppURL);
			driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			UtilityFunctions.applicationWait(1000);

		} // End of If

	} // End of default constructor

	// ----------------------------------------------------------------------------------------------------------------------

	// Method to check the jdk version of the system (JDK 32 bit or JDK 64 bit)
	private static String jvmBitVersion() {
		return System.getProperty("sun.arch.data.model");

	}

	// ---------------------------------------------------------------------------------------------------------------------------
	// Code to run sql scripts if run environment is Exec(manual)
	// Author: Yogendra Rathore
	// Modified By : Chanchal Jain
	// Modified By : Tanmay
	// Modified For : Redis cache clean up code added
	private static void restoreDataBaseAndInsertGenericData() throws Exception {
		try {

			if (TestConfiguration.getProperty("TestSiteURL").contains("Exec")) {
				String dbName = TestConfiguration.getProperty("DatabaseName");

				// Code to clean redis cache -- Added By Tanmay
				/*
				 * try { System.out.print(new File(System.getProperty("user.dir") +
				 * "\\..\\RedisCleanUp\\Redis_Cache-Cleanup.lnk") .getAbsolutePath());
				 * Runtime.getRuntime() .exec("cmd.exe /c " + new File(
				 * System.getProperty("user.dir") +
				 * "\\..\\RedisCleanUp\\Redis_Cache-Cleanup.lnk") .getAbsolutePath()); } catch
				 * (Exception e) { log.error("Redis cache not cleared"); }
				 */

				ResultSet resultSet = null;
				int countOfTablesBeforeRestore = 0;
				int numberOfRecordsInGenericData = Integer
						.parseInt(TestConfiguration.getProperty("NumberOfRecordsInGenericData"));

				// get number of tables before restore:
				resultSet = DataBaseFunctionsLibraray.executeSelectQuery("Select count(*) as countTables from " + dbName
						+ ".information_schema.tables WHERE table_type = 'base table'");

				if (resultSet.next()) {
					countOfTablesBeforeRestore = resultSet.getInt("countTables");
				}

				// restore DB
				DataBaseFunctionsLibraray.restoreDatabase(dbName,
						TestConfiguration.getProperty("DataBaseBackUP") + dbName + ".bak");

				// check DB restored successfully. and insert generic data.
				if (DataBaseFunctionsLibraray.checkDBRestoredSuccessfully(TestConfiguration.getProperty("DatabaseName"),
						countOfTablesBeforeRestore)) {
					// create user
					createUserAndAssignRole();

					if (numberOfRecordsInGenericData != 0) {
						// code to insert test data queries

//						GenericTestData.insertGenericTestData(numberOfRecordsInGenericData);

						// check data inserted properly.
						if (!DataBaseFunctionsLibraray.checkTestDataInsertedProperly()) {
							log.error("Test Data is not inserted successfully in DataBase");

							// close the cmd.exe to terminate the execution
							UtilityFunctions.killProcess("cmd.exe");
						}
					}

				} else {

					log.error("DB not restored successfully ");
					// close the cmd.exe to terminate the execution
					UtilityFunctions.killProcess("cmd.exe");

				}
			} else {
				// create user
				createUserAndAssignRole();
			}
		} catch (Exception e) {
			log.error("Error occured while Restoring and inserting Test Data in Database");
			throw e;
		}

	}

	// ----------------------------------------------------------------------------------------------------------------------
	// Set property value from Excel File
	// Modified By : YOgendra Rathore <30-08-2017>
	// added set email detials
	public static void setConfigPropertiesValue() {

		TestConfigurationFromExcel = UtilityFunctions.getConfigDetailsFromExcel();

		BasePage.TestConfiguration.setProperty("TestSiteURL",
				TestConfigurationFromExcel.get(ExcelUtility.CONFIG_TestSiteURL));
		BasePage.TestConfiguration.setProperty("UserName",
				TestConfigurationFromExcel.get(ExcelUtility.CONFIG_UserName));
		BasePage.TestConfiguration.setProperty("Password",
				TestConfigurationFromExcel.get(ExcelUtility.CONFIG_Password));
		BasePage.TestConfiguration.setProperty("CompanyID",
				TestConfigurationFromExcel.get(ExcelUtility.CONFIG_CompanyID));
		BasePage.TestConfiguration.setProperty("Browser", TestConfigurationFromExcel.get(ExcelUtility.CONFIG_Browser));
		BasePage.TestConfiguration.setProperty("DatabaseUrl",
				TestConfigurationFromExcel.get(ExcelUtility.CONFIG_DatabaseUrl));
		BasePage.TestConfiguration.setProperty("DatabaseUserName",
				TestConfigurationFromExcel.get(ExcelUtility.CONFIG_DatabaseUserName));
		BasePage.TestConfiguration.setProperty("DatabasePassword",
				TestConfigurationFromExcel.get(ExcelUtility.CONFIG_DatabasePassword));
		BasePage.TestConfiguration.setProperty("DatabaseName",
				TestConfigurationFromExcel.get(ExcelUtility.CONFIG_DatabaseName));
		BasePage.TestConfiguration.setProperty("DataBaseBackUP",
				TestConfigurationFromExcel.get(ExcelUtility.CONFIG_DataBaseBackUP));
		BasePage.TestConfiguration.setProperty("NumberOfRecordsInGenericData",
				TestConfigurationFromExcel.get(ExcelUtility.CONFIG_NumberOfRecordsInGenericData));
		BasePage.TestConfiguration.setProperty("UserEmail",
				TestConfigurationFromExcel.get(ExcelUtility.CONFIG_UserEmail));
		BasePage.TestConfiguration.setProperty("NumberOfCIParallelExecution",
				TestConfigurationFromExcel.get(ExcelUtility.CONFIG_NumberOfCIParallelExecution));
		BasePage.TestConfiguration.setProperty("UserPrefferedLanguage",
				TestConfigurationFromExcel.get(ExcelUtility.CONFIG_UserPrefferedLanguage));
		// set email detials
		if (BasePage.xls.checkSheetExists("EmailDetails")) {
			BasePage.TestConfiguration.setProperty("SendGridHostName",
					TestConfigurationFromExcel.get(ExcelUtility.CONFIG_SendGridHostName));

			BasePage.TestConfiguration.setProperty("SendGridPortNumber",
					TestConfigurationFromExcel.get(ExcelUtility.CONFIG_SendGridPortNumber));

			BasePage.TestConfiguration.setProperty("SendGridUserName",
					TestConfigurationFromExcel.get(ExcelUtility.CONFIG_SendGridUserName));

			BasePage.TestConfiguration.setProperty("SendGridPassword",
					TestConfigurationFromExcel.get(ExcelUtility.CONFIG_SendGridPassword));

			BasePage.TestConfiguration.setProperty("FromMailUser",
					TestConfigurationFromExcel.get(ExcelUtility.CONFIG_FromMailUser));

			BasePage.TestConfiguration.setProperty("RecipientsList",
					TestConfigurationFromExcel.get(ExcelUtility.CONFIG_RecipientsList));
			BasePage.TestConfiguration.setProperty("DeploymentName",
					TestConfigurationFromExcel.get(ExcelUtility.CONFIG_DeploymentName));
		}

	}

	// ----------------------------------------------------------------------------------------------------------------------
	// Validate Config properties file values are set properly
	private static boolean checkCofigPropertiesValueIsSet() {

		if (BasePage.TestConfiguration.getProperty("TestSiteURL").isEmpty()
				|| BasePage.TestConfiguration.getProperty("UserName").isEmpty()
				|| BasePage.TestConfiguration.getProperty("Password").isEmpty()
				|| BasePage.TestConfiguration.getProperty("CompanyID").isEmpty()
				|| BasePage.TestConfiguration.getProperty("Browser").isEmpty()
				|| BasePage.TestConfiguration.getProperty("DatabaseUrl").isEmpty()
				|| BasePage.TestConfiguration.getProperty("DatabaseUserName").isEmpty()
				|| BasePage.TestConfiguration.getProperty("DatabasePassword").isEmpty()
				|| BasePage.TestConfiguration.getProperty("DatabaseName").isEmpty()
				|| BasePage.TestConfiguration.getProperty("UserEmail").isEmpty()) {

			// Return false if Any one property file value is empty
			return false;
		}
		return true;

	}

	// ---------------------------------------------------------------------------------------------------------------------------
	// Method to create User
	// Author: Yogendra Rathore
	// Modified By: Bhupendra Singh
	// Need to use this method in User Page so update it's access modifier
	// Modified BY :Yogendra Rathore < 18-08-2017>
	// Action : updated select user query.
	// Modified BY :Yogendra Rathore < 16-02-2018>
	// Action: added condition for password expiration
	// Modified BY :Yogendra Rathore < 22-02-2018>
	// Action: commented condition for password expiration and handleld the code
	// in listeners
	public static void createUserAndAssignRole() throws Exception {
		try {
			// declare variables
			String userName = "", selectUserQuery = "", user_Email = "";
			ResultSet resultSet;
			Hashtable<String, String> testData = new Hashtable<String, String>();

			// get user name
			userName = BasePage.TestConfiguration.getProperty("UserName");
			excel_User = userName;

			if (!userName.equalsIgnoreCase("Admin") && !userName.equalsIgnoreCase("Admin2")) {

				// get user Email
				user_Email = BasePage.TestConfiguration.getProperty("UserEmail");

				// select query of User
				selectUserQuery = "select u.id   from [User] u  inner join userrolemap urm on u.id=urm.userid inner join "
						+ "license l on u.id= l.userid inner join useraccesslevel ual on ual.userid=u.id "
						+ " where  urm.isdeleted=0  and ual.isdeleted=0 and Name='" + userName + "' ";

				resultSet = DataBaseFunctionsLibraray.executeSelectQuery(selectUserQuery);
				// check user name created
				
			}

			//getCreatedByAndUpdatedByUserId(userName);

		} catch (Exception e) {
			throw e;
		}

	}

	// ----------------------------------------------------------------------------------------------------------------------
	// Check browser is closed
	// Method returns True if Browser is closed
	// Author : Bhupendra Singh
	// Modified by :Yogendra Rathore
	// Added driver==null condition
	public static boolean isBrowserClosed() {
		if (driver == null)
			return true;

		if (dr == null)
			return true;

		if (dr != null) {
			if (((RemoteWebDriver) dr).getSessionId() == null) {
				log.error("driver is not null, but session id is null ");
				return true;
			}
		}

		return false;
	}



	// ----------------------------------------------------------------------------------------------------------------------
	// open browser in incognito mode , login the application and return the
	// driver.
	// Author : Yogendra Rathore
	// Modified By : Yogendra Rathore
	// Updated By Rakesh
	// return incognito driver and set basepage.driver in finally
	// date: 24-01-2019
	// change by rakesh on 16-04-19
	// options.addArguments("--disable-features=VizDisplayCompositor");

	public static EventFiringWebDriver openApplicationInIncognitoModeOfChromeAndLogin(
			Hashtable<String, String> testData, boolean quitBrowser) throws Exception {
		EventFiringWebDriver tempdriver = null;
		EventFiringWebDriver tempdriver2 = null;
		try {
			String userName = "";
			String password = BasePage.TestConfiguration.getProperty("Password");
			String companyId = BasePage.TestConfiguration.getProperty("CompanyID");

			// set user defined user name
			if (testData.containsKey("UserName"))
				userName = testData.get("UserName");
			else
				userName = BasePage.TestConfiguration.getProperty("UserName");

			ChromeOptions options = null;
			// set user defined workstation
			if (testData.containsKey("WorkStation"))
			
			options = new ChromeOptions();
			options.addArguments("--incognito");

			DesiredCapabilities capabilities = DesiredCapabilities.chrome();
			capabilities.setCapability(ChromeOptions.CAPABILITY, options);

			// set path for chrome driver
			File file = new File(System.getProperty("user.dir") + "\\Resources\\Chrome_Driver\\chromedriver.exe");
			System.setProperty("webdriver.chrome.driver", file.getAbsolutePath());

			options.addArguments("test-type", "start-maximized");
			options.addArguments("--disable-features=VizDisplayCompositor");

			capabilities.setCapability("chrome.binary", file.getAbsolutePath());
			capabilities.setCapability(ChromeOptions.CAPABILITY, options);
			capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);

			dr_incognito = new ChromeDriver(capabilities);

			dr_incognito.navigate().to(BasePage.TestConfiguration.getProperty("TestSiteURL"));

			// assingn temp driver to hold object of driver of chorme browser
			tempdriver = BasePage.driver;

			// set BasePage.driver to incongnito mode driver to use all the
			// methods of the framework on incognito mode
			BasePage.driver = new EventFiringWebDriver(dr_incognito);

			//DashboardPage dashboardPage = BasePage.login.doLogin(userName, password, companyId);

				tempdriver2 = BasePage.driver;

			// close bowser if required.
			if (quitBrowser)
				dr_incognito.quit();

			// returning incognito driver
			return tempdriver2;
		} catch (Exception e) {
			throw new Exception("BasePage - openApplicationInIncognitoModeOfChromeAndLogin " + e);
		} finally {
			// assign back the value of chrome driver to the BasePage.driver. so
			// that if we are just starting incognito but not assigning it
			// anywhere
			BasePage.driver = tempdriver;
		}

	}



	// --------------------------------------------------------------------------------------------------------------------------------
	// set date time format as per language locale
	// Author : Yogendra Rathore
	// TODO : Need to do for other lanugages

	public static void setDateTimeFormatAsPerLanguageLocale() {

		try {
			String languageName = userPrefferedLanguageInExcel;

			String columnName = "";
			String excelLanugage = BasePage.TestConfiguration.getProperty("UserPrefferedLanguage");

			if (BasePage.current_LoggedIn_User.equals("")
					|| BasePage.current_LoggedIn_User_PrefferedLanugage.equals(excelLanugage))
				columnName = excelLanugage;
			else
				columnName = BasePage.current_LoggedIn_User_PrefferedLanugage;

			if (columnName.equals("Default")) {
				// columnName = "en-US";
				columnName = excelLanugage;
			}
			languageName = columnName;

			if (languageName.equals("en-GB")) {
				simpleDateFormat_Standard = new SimpleDateFormat("d/MM/yyyy hh:mm:ss");
				simpleDateFormat_1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				simpleDateFormat_2 = new SimpleDateFormat("yyyy-M-dd HH:mm");
				simpleDateFormat_3 = new SimpleDateFormat("M/d/YYY h:mm:ss a");
				simpleDateFormat_4 = new SimpleDateFormat("yyyy-MM-dd HH:mm");
				simpleDateFormat_5 = new SimpleDateFormat("M/d/yyyy h:mm a");
				simpleDateFormat_6 = new SimpleDateFormat("M/d/yyyy h:mm");
				simpleDateFormat_7 = new SimpleDateFormat("M/d/yyyy"); // changed
																		// to
																		// M/d/yyyy
																		// on
																		// 29-03-2019
				simpleDateFormat_8 = new SimpleDateFormat("a");
				simpleDateFormat_9 = new SimpleDateFormat("h:m");
				simpleDateFormat_10 = new SimpleDateFormat("yyyy-M-dd HH:mm:ss");
				simpleDateFormat_11 = new SimpleDateFormat("M/d/yyyy h");
				simpleDateFormat_12 = new SimpleDateFormat("MM/dd/yyyy");
				simpleDateFormat_13 = new SimpleDateFormat("M/dd/yyyy h:mm a");
				simpleDateFormat_14 = new SimpleDateFormat("M/dd/yyyy hh:mm:ss a");
				simpleDateFormat_15 = new SimpleDateFormat("yyyy-M-dd hh:mm:ss a");
				simpleDateFormat_16 = new SimpleDateFormat("M/dd/yyyy hh:mm:ss a");
				simpleDateFormat_17 = new SimpleDateFormat("MM/dd/YYYY hh:mm a");
				simpleDateFormat_18 = new SimpleDateFormat("MM/dd/YYY hh:mm a");
				simpleDateFormat_19 = new SimpleDateFormat("M/d/yyyy h:mm:00 a");
				simpleDateFormat_20 = new SimpleDateFormat("M/d/yyyy h:mm:59 a");

				simpleDateFormat_21 = new SimpleDateFormat("M/d/yyyy h:00:00 a");

				simpleDateFormat_22 = new SimpleDateFormat("M/d/yyyy h:59:59 a");

				simpleDateFormat_23 = new SimpleDateFormat("M/dd/yyyy h:00:00 a");

				simpleDateFormat_24 = new SimpleDateFormat("M/dd/yyyy h:mm:ss a");

				simpleDateFormat_25 = new SimpleDateFormat("M/d/YYY h:mm a");

				simpleDateFormat_26 = new SimpleDateFormat("yyMMddHHmmss");

				simpleDateFormat_27 = new SimpleDateFormat("dd-MM-yyyy hh-mm-ss a");

				simpleDateFormat_28 = new SimpleDateFormat("dd-M-yyyy hh:mm");

				simpleDateFormat_29 = new SimpleDateFormat("M/d/yyyy h:mm a");
				simpleDateFormat_30 = new SimpleDateFormat("M/d/yyyy h:mm:ss a");
				simpleDateFormat_31= new SimpleDateFormat("HH:mm:ss");

			} else if (languageName.equals("en-US")) {

				simpleDateFormat_Standard = new SimpleDateFormat("M/d/yyyy h:mm:ss a");
				simpleDateFormat_1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				simpleDateFormat_2 = new SimpleDateFormat("yyyy-M-dd HH:mm");
				simpleDateFormat_3 = new SimpleDateFormat("M/d/YYY h:mm:ss a");
				simpleDateFormat_4 = new SimpleDateFormat("yyyy-MM-dd HH:mm");
				simpleDateFormat_5 = new SimpleDateFormat("M/d/yyyy h:mm a");
				simpleDateFormat_6 = new SimpleDateFormat("M/d/yyyy h:mm");
				simpleDateFormat_7 = new SimpleDateFormat("M/d/yyyy");
				simpleDateFormat_8 = new SimpleDateFormat("a");
				simpleDateFormat_9 = new SimpleDateFormat("h:m");
				simpleDateFormat_10 = new SimpleDateFormat("yyyy-M-dd HH:mm:ss");
				simpleDateFormat_11 = new SimpleDateFormat("M/d/yyyy h");
				simpleDateFormat_12 = new SimpleDateFormat("MM/dd/yyyy");
				simpleDateFormat_13 = new SimpleDateFormat("M/dd/yyyy h:mm a");
				simpleDateFormat_14 = new SimpleDateFormat("M/dd/yyyy hh:mm:ss a");

				simpleDateFormat_15 = new SimpleDateFormat("yyyy-M-dd hh:mm:ss a");
				simpleDateFormat_16 = new SimpleDateFormat("M/dd/yyyy hh:mm:ss a");
				simpleDateFormat_17 = new SimpleDateFormat("MM/dd/YYYY hh:mm a");
				simpleDateFormat_18 = new SimpleDateFormat("MM/dd/YYY hh:mm a");
				simpleDateFormat_19 = new SimpleDateFormat("M/d/yyyy h:mm:00 a");
				simpleDateFormat_20 = new SimpleDateFormat("M/d/yyyy h:mm:59 a");

				simpleDateFormat_21 = new SimpleDateFormat("M/d/yyyy h:00:00 a");

				simpleDateFormat_22 = new SimpleDateFormat("M/d/yyyy h:59:59 a");

				simpleDateFormat_23 = new SimpleDateFormat("M/dd/yyyy h:00:00 a");

				simpleDateFormat_24 = new SimpleDateFormat("M/dd/yyyy h:mm:ss a");

				simpleDateFormat_25 = new SimpleDateFormat("M/d/YYY h:mm a");

				simpleDateFormat_26 = new SimpleDateFormat("yyMMddHHmmss");

				simpleDateFormat_27 = new SimpleDateFormat("dd-MM-yyyy hh-mm-ss a");

				simpleDateFormat_28 = new SimpleDateFormat("dd-M-yyyy hh:mm");

				simpleDateFormat_29 = new SimpleDateFormat("M/d/yyyy h:mm a");

				simpleDateFormat_30 = new SimpleDateFormat("M/d/yyyy h:mm:ss a");
				simpleDateFormat_31= new SimpleDateFormat("HH:mm:ss");
			} else if (languageName.equals("de-DE")) {

				simpleDateFormat_Standard = new SimpleDateFormat("M/d/yyyy h:mm:ss a");
				simpleDateFormat_1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				simpleDateFormat_2 = new SimpleDateFormat("yyyy-M-dd HH:mm");
				simpleDateFormat_3 = new SimpleDateFormat("M/d/YYY h:mm:ss a");
				simpleDateFormat_4 = new SimpleDateFormat("yyyy-MM-dd HH:mm");
				simpleDateFormat_5 = new SimpleDateFormat("M/d/yyyy h:mm a");
				simpleDateFormat_6 = new SimpleDateFormat("M/d/yyyy h:mm");
				simpleDateFormat_7 = new SimpleDateFormat("M/d/yyyy");
				simpleDateFormat_8 = new SimpleDateFormat("a");
				simpleDateFormat_9 = new SimpleDateFormat("h:m");
				simpleDateFormat_10 = new SimpleDateFormat("yyyy-M-dd HH:mm:ss");
				simpleDateFormat_11 = new SimpleDateFormat("M/d/yyyy h");
				simpleDateFormat_12 = new SimpleDateFormat("MM/dd/yyyy");
				simpleDateFormat_13 = new SimpleDateFormat("M/dd/yyyy h:mm a");
				simpleDateFormat_14 = new SimpleDateFormat("M/dd/yyyy hh:mm:ss a");

				simpleDateFormat_15 = new SimpleDateFormat("yyyy-M-dd hh:mm:ss a");
				simpleDateFormat_16 = new SimpleDateFormat("M/dd/yyyy hh:mm:ss a");
				simpleDateFormat_17 = new SimpleDateFormat("MM/dd/YYYY hh:mm a");
				simpleDateFormat_18 = new SimpleDateFormat("MM/dd/YYY hh:mm a");
				simpleDateFormat_19 = new SimpleDateFormat("M/d/yyyy h:mm:00 a");
				simpleDateFormat_20 = new SimpleDateFormat("M/d/yyyy h:mm:59 a");

				simpleDateFormat_21 = new SimpleDateFormat("M/d/yyyy h:00:00 a");

				simpleDateFormat_22 = new SimpleDateFormat("M/d/yyyy h:59:59 a");

				simpleDateFormat_23 = new SimpleDateFormat("M/dd/yyyy h:00:00 a");

				simpleDateFormat_24 = new SimpleDateFormat("M/dd/yyyy h:mm:ss a");

				simpleDateFormat_25 = new SimpleDateFormat("M/d/YYY h:mm a");

				simpleDateFormat_26 = new SimpleDateFormat("yyMMddHHmmss");

				simpleDateFormat_27 = new SimpleDateFormat("dd-MM-yyyy hh-mm-ss a");

				simpleDateFormat_28 = new SimpleDateFormat("dd-M-yyyy hh:mm");

				simpleDateFormat_29 = new SimpleDateFormat("M/d/yyyy h:mm a");
				
				simpleDateFormat_31= new SimpleDateFormat("HH:mm:ss");
			} else if (languageName.equals("es-MX")) {

				simpleDateFormat_Standard = new SimpleDateFormat("M/d/yyyy h:mm:ss a");
				simpleDateFormat_1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				simpleDateFormat_2 = new SimpleDateFormat("yyyy-M-dd HH:mm");
				simpleDateFormat_3 = new SimpleDateFormat("M/d/YYY h:mm:ss a");
				simpleDateFormat_4 = new SimpleDateFormat("yyyy-MM-dd HH:mm");
				simpleDateFormat_5 = new SimpleDateFormat("M/d/yyyy h:mm a");
				simpleDateFormat_6 = new SimpleDateFormat("M/d/yyyy h:mm");
				simpleDateFormat_7 = new SimpleDateFormat("M/d/yyyy");
				simpleDateFormat_8 = new SimpleDateFormat("a");
				simpleDateFormat_9 = new SimpleDateFormat("h:m");
				simpleDateFormat_10 = new SimpleDateFormat("yyyy-M-dd HH:mm:ss");
				simpleDateFormat_11 = new SimpleDateFormat("M/d/yyyy h");
				simpleDateFormat_12 = new SimpleDateFormat("MM/dd/yyyy");
				simpleDateFormat_13 = new SimpleDateFormat("M/dd/yyyy h:mm a");
				simpleDateFormat_14 = new SimpleDateFormat("M/dd/yyyy hh:mm:ss a");

				simpleDateFormat_15 = new SimpleDateFormat("yyyy-M-dd hh:mm:ss a");
				simpleDateFormat_16 = new SimpleDateFormat("M/dd/yyyy hh:mm:ss a");
				simpleDateFormat_17 = new SimpleDateFormat("MM/dd/YYYY hh:mm a");
				simpleDateFormat_18 = new SimpleDateFormat("MM/dd/YYY hh:mm a");
				simpleDateFormat_19 = new SimpleDateFormat("M/d/yyyy h:mm:00 a");
				simpleDateFormat_20 = new SimpleDateFormat("M/d/yyyy h:mm:59 a");

				simpleDateFormat_21 = new SimpleDateFormat("M/d/yyyy h:00:00 a");

				simpleDateFormat_22 = new SimpleDateFormat("M/d/yyyy h:59:59 a");

				simpleDateFormat_23 = new SimpleDateFormat("M/dd/yyyy h:00:00 a");

				simpleDateFormat_24 = new SimpleDateFormat("M/dd/yyyy h:mm:ss a");

				simpleDateFormat_25 = new SimpleDateFormat("M/d/YYY h:mm a");

				simpleDateFormat_26 = new SimpleDateFormat("yyMMddHHmmss");

				simpleDateFormat_27 = new SimpleDateFormat("dd-MM-yyyy hh-mm-ss a");

				simpleDateFormat_28 = new SimpleDateFormat("dd-M-yyyy hh:mm");

				simpleDateFormat_29 = new SimpleDateFormat("M/d/yyyy h:mm a");
				
				simpleDateFormat_31= new SimpleDateFormat("HH:mm:ss");
			} else if (languageName.equals("vi")) {
				simpleDateFormat_Standard = new SimpleDateFormat("M/d/yyyy h:mm:ss a");
				simpleDateFormat_1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				simpleDateFormat_2 = new SimpleDateFormat("yyyy-M-dd HH:mm");
				simpleDateFormat_3 = new SimpleDateFormat("M/d/YYY h:mm:ss a");
				simpleDateFormat_4 = new SimpleDateFormat("yyyy-MM-dd HH:mm");
				simpleDateFormat_5 = new SimpleDateFormat("M/d/yyyy h:mm a");
				simpleDateFormat_6 = new SimpleDateFormat("M/d/yyyy h:mm");
				simpleDateFormat_7 = new SimpleDateFormat("M/d/yyyy");
				simpleDateFormat_8 = new SimpleDateFormat("a");
				simpleDateFormat_9 = new SimpleDateFormat("h:m");
				simpleDateFormat_10 = new SimpleDateFormat("yyyy-M-dd HH:mm:ss");
				simpleDateFormat_11 = new SimpleDateFormat("M/d/yyyy h");
				simpleDateFormat_12 = new SimpleDateFormat("MM/dd/yyyy");
				simpleDateFormat_13 = new SimpleDateFormat("M/dd/yyyy h:mm a");
				simpleDateFormat_14 = new SimpleDateFormat("M/dd/yyyy hh:mm:ss a");

				simpleDateFormat_15 = new SimpleDateFormat("yyyy-M-dd hh:mm:ss a");
				simpleDateFormat_16 = new SimpleDateFormat("M/dd/yyyy hh:mm:ss a");
				simpleDateFormat_17 = new SimpleDateFormat("MM/dd/YYYY hh:mm a");
				simpleDateFormat_18 = new SimpleDateFormat("MM/dd/YYY hh:mm a");
				simpleDateFormat_19 = new SimpleDateFormat("M/d/yyyy h:mm:00 a");
				simpleDateFormat_20 = new SimpleDateFormat("M/d/yyyy h:mm:59 a");

				simpleDateFormat_21 = new SimpleDateFormat("M/d/yyyy h:00:00 a");

				simpleDateFormat_22 = new SimpleDateFormat("M/d/yyyy h:59:59 a");

				simpleDateFormat_23 = new SimpleDateFormat("M/dd/yyyy h:00:00 a");

				simpleDateFormat_24 = new SimpleDateFormat("M/dd/yyyy h:mm:ss a");

				simpleDateFormat_25 = new SimpleDateFormat("M/d/YYY h:mm a");

				simpleDateFormat_26 = new SimpleDateFormat("yyMMddHHmmss");

				simpleDateFormat_27 = new SimpleDateFormat("dd-MM-yyyy hh-mm-ss a");

				simpleDateFormat_28 = new SimpleDateFormat("dd-M-yyyy hh:mm");

				simpleDateFormat_29 = new SimpleDateFormat("M/d/yyyy h:mm a");
				
				simpleDateFormat_31= new SimpleDateFormat("HH:mm:ss");
			} else if (languageName.equals("es-ES")) {
				simpleDateFormat_Standard = new SimpleDateFormat("M/d/yyyy h:mm:ss a");
				simpleDateFormat_1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				simpleDateFormat_2 = new SimpleDateFormat("yyyy-M-dd HH:mm");
				simpleDateFormat_3 = new SimpleDateFormat("M/d/YYY h:mm:ss a");
				simpleDateFormat_4 = new SimpleDateFormat("yyyy-MM-dd HH:mm");
				simpleDateFormat_5 = new SimpleDateFormat("M/d/yyyy h:mm a");
				simpleDateFormat_6 = new SimpleDateFormat("M/d/yyyy h:mm");
				simpleDateFormat_7 = new SimpleDateFormat("M/d/yyyy");
				simpleDateFormat_8 = new SimpleDateFormat("a");
				simpleDateFormat_9 = new SimpleDateFormat("h:m");
				simpleDateFormat_10 = new SimpleDateFormat("yyyy-M-dd HH:mm:ss");
				simpleDateFormat_11 = new SimpleDateFormat("M/d/yyyy h");
				simpleDateFormat_12 = new SimpleDateFormat("MM/dd/yyyy");
				simpleDateFormat_13 = new SimpleDateFormat("M/dd/yyyy h:mm a");
				simpleDateFormat_14 = new SimpleDateFormat("M/dd/yyyy hh:mm:ss a");

				simpleDateFormat_15 = new SimpleDateFormat("yyyy-M-dd hh:mm:ss a");
				simpleDateFormat_16 = new SimpleDateFormat("M/dd/yyyy hh:mm:ss a");
				simpleDateFormat_17 = new SimpleDateFormat("MM/dd/YYYY hh:mm a");
				simpleDateFormat_18 = new SimpleDateFormat("MM/dd/YYY hh:mm a");
				simpleDateFormat_19 = new SimpleDateFormat("M/d/yyyy h:mm:00 a");
				simpleDateFormat_20 = new SimpleDateFormat("M/d/yyyy h:mm:59 a");

				simpleDateFormat_21 = new SimpleDateFormat("M/d/yyyy h:00:00 a");

				simpleDateFormat_22 = new SimpleDateFormat("M/d/yyyy h:59:59 a");

				simpleDateFormat_23 = new SimpleDateFormat("M/dd/yyyy h:00:00 a");

				simpleDateFormat_24 = new SimpleDateFormat("M/dd/yyyy h:mm:ss a");

				simpleDateFormat_25 = new SimpleDateFormat("M/d/YYY h:mm a");

				simpleDateFormat_26 = new SimpleDateFormat("yyMMddHHmmss");

				simpleDateFormat_27 = new SimpleDateFormat("dd-MM-yyyy hh-mm-ss a");

				simpleDateFormat_28 = new SimpleDateFormat("dd-M-yyyy hh:mm");

				simpleDateFormat_29 = new SimpleDateFormat("M/d/yyyy h:mm a");
				
				simpleDateFormat_31= new SimpleDateFormat("HH:mm:ss");
			} else if (languageName.equals("pt-BR")) {
				simpleDateFormat_Standard = new SimpleDateFormat("M/d/yyyy h:mm:ss a");
				simpleDateFormat_1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				simpleDateFormat_2 = new SimpleDateFormat("yyyy-M-dd HH:mm");
				simpleDateFormat_3 = new SimpleDateFormat("M/d/YYY h:mm:ss a");
				simpleDateFormat_4 = new SimpleDateFormat("yyyy-MM-dd HH:mm");
				simpleDateFormat_5 = new SimpleDateFormat("M/d/yyyy h:mm a");
				simpleDateFormat_6 = new SimpleDateFormat("M/d/yyyy h:mm");
				simpleDateFormat_7 = new SimpleDateFormat("M/d/yyyy");
				simpleDateFormat_8 = new SimpleDateFormat("a");
				simpleDateFormat_9 = new SimpleDateFormat("h:m");
				simpleDateFormat_10 = new SimpleDateFormat("yyyy-M-dd HH:mm:ss");
				simpleDateFormat_11 = new SimpleDateFormat("M/d/yyyy h");
				simpleDateFormat_12 = new SimpleDateFormat("MM/dd/yyyy");
				simpleDateFormat_13 = new SimpleDateFormat("M/dd/yyyy h:mm a");
				simpleDateFormat_14 = new SimpleDateFormat("M/dd/yyyy hh:mm:ss a");

				simpleDateFormat_15 = new SimpleDateFormat("yyyy-M-dd hh:mm:ss a");
				simpleDateFormat_16 = new SimpleDateFormat("M/dd/yyyy hh:mm:ss a");
				simpleDateFormat_17 = new SimpleDateFormat("MM/dd/YYYY hh:mm a");
				simpleDateFormat_18 = new SimpleDateFormat("MM/dd/YYY hh:mm a");
				simpleDateFormat_19 = new SimpleDateFormat("M/d/yyyy h:mm:00 a");
				simpleDateFormat_20 = new SimpleDateFormat("M/d/yyyy h:mm:59 a");

				simpleDateFormat_21 = new SimpleDateFormat("M/d/yyyy h:00:00 a");

				simpleDateFormat_22 = new SimpleDateFormat("M/d/yyyy h:59:59 a");

				simpleDateFormat_23 = new SimpleDateFormat("M/dd/yyyy h:00:00 a");

				simpleDateFormat_24 = new SimpleDateFormat("M/dd/yyyy h:mm:ss a");

				simpleDateFormat_25 = new SimpleDateFormat("M/d/YYY h:mm a");

				simpleDateFormat_26 = new SimpleDateFormat("yyMMddHHmmss");

				simpleDateFormat_27 = new SimpleDateFormat("dd-MM-yyyy hh-mm-ss a");

				simpleDateFormat_28 = new SimpleDateFormat("dd-M-yyyy hh:mm");

				simpleDateFormat_29 = new SimpleDateFormat("M/d/yyyy h:mm a");
				
				simpleDateFormat_31= new SimpleDateFormat("HH:mm:ss");
			} else if (languageName.equals("fr-FR")) {
				simpleDateFormat_Standard = new SimpleDateFormat("M/d/yyyy h:mm:ss a");
				simpleDateFormat_1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				simpleDateFormat_2 = new SimpleDateFormat("yyyy-M-dd HH:mm");
				simpleDateFormat_3 = new SimpleDateFormat("M/d/YYY h:mm:ss a");
				simpleDateFormat_4 = new SimpleDateFormat("yyyy-MM-dd HH:mm");
				simpleDateFormat_5 = new SimpleDateFormat("M/d/yyyy h:mm a");
				simpleDateFormat_6 = new SimpleDateFormat("M/d/yyyy h:mm");
				simpleDateFormat_7 = new SimpleDateFormat("M/d/yyyy");
				simpleDateFormat_8 = new SimpleDateFormat("a");
				simpleDateFormat_9 = new SimpleDateFormat("h:m");
				simpleDateFormat_10 = new SimpleDateFormat("yyyy-M-dd HH:mm:ss");
				simpleDateFormat_11 = new SimpleDateFormat("M/d/yyyy h");
				simpleDateFormat_12 = new SimpleDateFormat("MM/dd/yyyy");
				simpleDateFormat_13 = new SimpleDateFormat("M/dd/yyyy h:mm a");
				simpleDateFormat_14 = new SimpleDateFormat("M/dd/yyyy hh:mm:ss a");

				simpleDateFormat_15 = new SimpleDateFormat("yyyy-M-dd hh:mm:ss a");
				simpleDateFormat_16 = new SimpleDateFormat("M/dd/yyyy hh:mm:ss a");
				simpleDateFormat_17 = new SimpleDateFormat("MM/dd/YYYY hh:mm a");
				simpleDateFormat_18 = new SimpleDateFormat("MM/dd/YYY hh:mm a");
				simpleDateFormat_19 = new SimpleDateFormat("M/d/yyyy h:mm:00 a");
				simpleDateFormat_20 = new SimpleDateFormat("M/d/yyyy h:mm:59 a");

				simpleDateFormat_21 = new SimpleDateFormat("M/d/yyyy h:00:00 a");

				simpleDateFormat_22 = new SimpleDateFormat("M/d/yyyy h:59:59 a");

				simpleDateFormat_23 = new SimpleDateFormat("M/dd/yyyy h:00:00 a");

				simpleDateFormat_24 = new SimpleDateFormat("M/dd/yyyy h:mm:ss a");

				simpleDateFormat_25 = new SimpleDateFormat("M/d/YYY h:mm a");

				simpleDateFormat_26 = new SimpleDateFormat("yyMMddHHmmss");

				simpleDateFormat_27 = new SimpleDateFormat("dd-MM-yyyy hh-mm-ss a");

				simpleDateFormat_28 = new SimpleDateFormat("dd-M-yyyy hh:mm");

				simpleDateFormat_29 = new SimpleDateFormat("M/d/yyyy h:mm a");
				
				simpleDateFormat_31= new SimpleDateFormat("HH:mm:ss");
			} else if (languageName.equals("Default")) {
				simpleDateFormat_Standard = new SimpleDateFormat("M/d/yyyy h:mm:ss a");
				simpleDateFormat_1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				simpleDateFormat_2 = new SimpleDateFormat("yyyy-M-dd HH:mm");
				simpleDateFormat_3 = new SimpleDateFormat("M/d/YYY h:mm:ss a");
				simpleDateFormat_4 = new SimpleDateFormat("yyyy-MM-dd HH:mm");
				simpleDateFormat_5 = new SimpleDateFormat("M/d/yyyy h:mm a");
				simpleDateFormat_6 = new SimpleDateFormat("M/d/yyyy h:mm");
				simpleDateFormat_7 = new SimpleDateFormat("M/d/yyyy");
				simpleDateFormat_8 = new SimpleDateFormat("a");
				simpleDateFormat_9 = new SimpleDateFormat("h:m");
				simpleDateFormat_10 = new SimpleDateFormat("yyyy-M-dd HH:mm:ss");
				simpleDateFormat_11 = new SimpleDateFormat("M/d/yyyy h");
				simpleDateFormat_12 = new SimpleDateFormat("MM/dd/yyyy");
				simpleDateFormat_13 = new SimpleDateFormat("M/dd/yyyy h:mm a");
				simpleDateFormat_14 = new SimpleDateFormat("M/dd/yyyy hh:mm:ss a");

				simpleDateFormat_15 = new SimpleDateFormat("yyyy-M-dd hh:mm:ss a");
				simpleDateFormat_16 = new SimpleDateFormat("M/dd/yyyy hh:mm:ss a");
				simpleDateFormat_17 = new SimpleDateFormat("MM/dd/YYYY hh:mm a");
				simpleDateFormat_18 = new SimpleDateFormat("MM/dd/YYY hh:mm a");
				simpleDateFormat_19 = new SimpleDateFormat("M/d/yyyy h:mm:00 a");
				simpleDateFormat_20 = new SimpleDateFormat("M/d/yyyy h:mm:59 a");

				simpleDateFormat_21 = new SimpleDateFormat("M/d/yyyy h:00:00 a");

				simpleDateFormat_22 = new SimpleDateFormat("M/d/yyyy h:59:59 a");

				simpleDateFormat_23 = new SimpleDateFormat("M/dd/yyyy h:00:00 a");

				simpleDateFormat_24 = new SimpleDateFormat("M/dd/yyyy h:mm:ss a");

				simpleDateFormat_25 = new SimpleDateFormat("M/d/YYY h:mm a");

				simpleDateFormat_26 = new SimpleDateFormat("yyMMddHHmmss");

				simpleDateFormat_27 = new SimpleDateFormat("dd-MM-yyyy hh-mm-ss a");

				simpleDateFormat_28 = new SimpleDateFormat("dd-M-yyyy hh:mm");

				simpleDateFormat_29 = new SimpleDateFormat("M/d/yyyy h:mm a");
				
				simpleDateFormat_31= new SimpleDateFormat("HH:mm:ss");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}// end of function

}
