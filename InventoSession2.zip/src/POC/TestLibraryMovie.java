package POC;

import TestCases.*;

import org.testng.Assert;

import Base.BasePage;
import Pages.InventoLogin;
import Util.ConstantsUtility;
import Util.LibraryFunctions;
import Util.TestLibrary;
import Util.UtilityFunctions;

public class TestLibraryMovie
{
	public static InventoLogin navigateToInventoLoginPageAndVerifyLoginPageIsDisplayed() throws Exception {
        try {
              
               // if browser closed then open broswer and hit test site url

               if (LibraryFunctions.isBrowserClosed())

                     // Open Browser and Url of application
                     BasePage.login1 = new InventoLogin(BasePage.TestConfiguration.getProperty("Browser"),
                                   BasePage.TestConfiguration.getProperty("TestSiteURL"));

               if (BasePage.login1.checkLoginPageIsDisplayed() == false) {
                     try {
                            Assert.assertEquals(ConstantsUtility.errSomeErrorOccured,
                                          "Appliction url should open and Login Page should displayed");
                     } catch (Throwable t) {
                            TestLibrary.reportErrorAndtakeScreenshot(t, "Application_Url_did_not_open");
                            
                     } // End of catch
               } // End of If
        } catch (Exception e) {
               throw new Exception(UtilityFunctions.throwException(Thread.currentThread(), e));

        }
        return new InventoLogin();
 }
}
